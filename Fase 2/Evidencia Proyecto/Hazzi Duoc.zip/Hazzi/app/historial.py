"""historial de eventos. el archivo de lo que ya no esta vigente.

hay dos formas de entrar al historial. la primera y mas comun es un
evento vigente que deja de serlo. mientras esta vigente vive en
memoria y cache y el dia que se cae de la lista que calcula
retention.py queda archivado aca. la segunda es directo sin pasar por
vigentes. son los eventos de solo registro. entran por esta puerta dos
casos con el mismo motivo de fondo que es que no ameritan una alerta
operativa pero si sirven de contexto. primero los sismos bajo m4
porque chile tiene decenas por dia y no afectan la operacion. segundo
cualquier evento de cualquier tipo que no tenga ninguna sucursal en su
area afectada. paso es real pero no es una alerta operativa para el
negocio.

ojo aprendido a los golpes: un evento asi no puede pasar por el
parametro vigentes de registrar_ciclo para "asegurarse" de que quede
guardado. eso lo marca vigente en true en la base que es exactamente
lo que lo excluye de obtener_historial que solo devuelve vigente en
false. tiene que entrar por registros igual que un sismo bajo m4.

retencion: 15 dias en general y 7 para sismos. configurable en
ajustes.py.

reusa el mismo hazard.db que dotacion.py. una sola base de datos para
todo el proyecto no un motor de storage nuevo por feature."""
from __future__ import annotations

import json
import re
from datetime import datetime, timedelta

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    MetaData,
    String,
    Table,
    Text,
    delete,
    insert,
    select,
    update,
)

from . import ajustes
from .db import engine
from .normalize import es_registro

# cuanto se conserva un evento archivado es configurable desde el
# admin. vive en ajustes.py con las claves retencion_dias y
# retencion_dias_sismo. chile es un pais sismico. hay sismos todos los
# dias y el historial se llena de ruido si se guardan tanto como una
# alerta. por eso los sismos tienen su propia retencion mas corta

_metadata = MetaData()

historial_tabla = Table(
    "eventos_historial",
    _metadata,
    Column("clave", String, primary_key=True),
    Column("datos", Text, nullable=False),      # evento completo serializado en json
    Column("vigente", Boolean, nullable=False, default=True),
    Column("ultima_vez_vigente", DateTime, nullable=False),
)


def init_schema() -> None:
    """crea la tabla si no existe. idempotente."""
    _metadata.create_all(engine)


# identidad de un evento.
#
# regla unica aprendida a los golpes: la clave solo puede armarse con
# campos que la fuente no reescribe entre ciclos. si un campo mutable
# entra en la clave cada actualizacion de la fuente genera una clave
# nueva la version anterior queda huerfana y registrar_ciclo la
# archiva como finalizada aunque el evento siga 100% vigente. ese es
# el bug del evento fantasma y reaparecio dos veces por parchear campo
# a campo en vez de aplicar la regla.
#
# fecha en senapred y dmc es la fecha de actualizacion del boletin no
# la del hecho asi que cambia en cada refresh. fecha en conaf tampoco
# es inmutable porque la fuente corrige la hora de inicio del incendio
# sobre la marcha. se vio en vivo pasar de 11:35 a 11:20. titulo en
# senapred es mutable porque el sistema le agrega el fenomeno
# detectado como "(Viento)" en cuanto el boletin actualizado lo
# menciona asi que el mismo evento cambia de titulo solo. fenomeno en
# senapred es mutable por la misma razon. no viene en el feed se
# deduce del texto del boletin asi que pasa de none a viento en cuanto
# el texto lo menciona. se vio en vivo. en dmc en cambio fenomeno es
# un campo estructurado del feed y si sirve para separar dos avisos
# simultaneos en la misma region.
#
# por eso la identidad se declara aca por tipo en un solo mapa legible
# en vez de repartida en ifs. agregar una fuente es agregar una linea


def _zona(e: dict) -> str:
    """comuna si la hay si no la region porque dmc solo trae region.

    usa "or" y no .get con default porque dict.get devuelve el
    default solo si falta la clave no si el valor es none. con comuna
    en none el bug viejo metia el string literal "none" en la clave."""
    return e.get("comuna") or e.get("region") or ""


# sismos de csn y usgs: el titulo es "m<mag> - <lugar>" donde lugar es
# una referencia geografica autogenerada como "114 km al ne de san
# pedro de atacama" que la fuente calcula a partir del epicentro. y el
# epicentro no es inmutable. el csn publica primero una solucion
# automatica preliminar y mas tarde la revisa con mas estaciones lo
# que corre el lugar unos cuantos km. por ejemplo paso de "114 km al
# ne" a "102 km al ne" del mismo sismo. la pagina oficial del csn no
# lo nota porque ahi es una sola fila que se actualiza. en hazzi si
# lugar fuera parte de la identidad via zona o titulo completo cada
# revision generaba una clave nueva y el sismo quedaba duplicado en el
# historial. exactamente el bug reportado. la magnitud en cambio casi
# nunca se corrige para cuando el catalogo diario la publica asi que
# es la parte estable del titulo. se aisla con regex en vez de usarlo
# completo
_RE_MAGNITUD = re.compile(r"^M([\d.]+)")


def _magnitud(e: dict) -> str:
    m = _RE_MAGNITUD.match(e.get("titulo") or "")
    return m.group(1) if m else ""


_EXTRACTORES = {
    "source": lambda e: e.get("source") or "",
    "titulo": lambda e: e.get("titulo") or "",
    "fecha": lambda e: e.get("fecha") or "",
    "fenomeno": lambda e: e.get("fenomeno") or "",
    "magnitud": _magnitud,
    "zona": _zona,
}

# la zona va siempre. una alerta senapred que cubre varias comunas
# llega como varios eventos que comparten todo lo demas uno por
# comuna. sin la zona en la clave se pisarian entre si y el historial
# guardaria una sola comuna en vez de todas
_IDENTIDAD_POR_TIPO: dict[str, tuple[str, ...]] = {
    # senapred. retention.py ya garantiza como mucho una alerta vigente
    # por comuna quedandose con el registro mas reciente asi que la
    # comuna es la identidad. todo lo demas como titulo fecha y
    # fenomeno se lo reescribe la fuente en cada actualizacion del
    # boletin
    "alerta": ("source", "zona"),
    # dmc. fecha es fecha_actu que es mutable. un aviso por fenomeno y region
    "meteorologico": ("source", "zona", "fenomeno"),
    # conaf. el nombre del incendio es lo unico estable. f_inicio se corrige
    "incendio": ("source", "zona", "titulo"),
    # csn y usgs. ni zona ni titulo completo sirven aca porque los dos
    # incluyen el lugar autogenerado a partir del epicentro y el
    # epicentro se revisa. fecha si es la hora real del hecho y no
    # cambia. magnitud aislada del titulo es la parte estable que
    # sobrevive a la revision. juntas alcanzan para no fusionar dos
    # sismos distintos sin depender de un texto que la fuente puede
    # corregir
    "sismo": ("source", "fecha", "magnitud"),
    # sernageomin. un volcan es un volcan. cambia de nivel no de identidad
    "volcan": ("source", "zona", "titulo"),
}
_IDENTIDAD_DEFAULT = ("source", "zona", "titulo")


def clave_evento(e: dict) -> str:
    """llave estable de un evento segun los campos declarados para su tipo."""
    campos = _IDENTIDAD_POR_TIPO.get(e.get("tipo"), _IDENTIDAD_DEFAULT)
    return "|".join(_EXTRACTORES[c](e) for c in campos)


# episodios. clave_evento da una identidad "base" pensada para que un
# aviso que sigue vigente no se fragmente en varias filas solo porque
# la fuente le reescribio el titulo o la fecha entre ciclos, ver el
# comentario largo mas arriba sobre el bug del evento fantasma. pero
# esa misma identidad gruesa, para alertas es apenas (fuente, zona),
# se queda corta para otra cosa: dos episodios REALMENTE distintos que
# pasan por la misma comuna en semanas distintas. una alerta amarilla
# por lluvia el lunes y una roja por desborde el jueves, ya cancelada
# la primera, comparten la misma base. sin nada mas, la segunda pisaba
# en el mismo lugar de la tabla el registro archivado de la primera y
# la semana quedaba con un solo evento de senapred en el historial en
# vez de dos. eso fue justo lo que reporto antonella.
#
# la solucion no es afinar mas el parseo de texto, ya se intento y por
# eso la identidad de alerta es tan gruesa. es reconocer que "misma
# base" no siempre quiere decir "mismo episodio", y guardar cada
# episodio nuevo en su propio slot, base, base#2, base#3, sin tocar el
# de uno anterior que ya termino. un episodio sigue siendo el mismo
# mientras la base tenga una fila vigente en true. en cuanto esa fila
# se archiva, la proxima vez que aparezca algo con la misma base es
# necesariamente un episodio nuevo y se gana un slot propio.
def _familia(claves: set[str], base: str) -> list[str]:
    """todas las claves ya usadas para esta identidad base, la original
    sin sufijo mas cualquier base#n de episodios anteriores."""
    prefijo = base + "#"
    return [c for c in claves if c == base or c.startswith(prefijo)]


def _clave_de_episodio_vigente(claves_vigentes: set[str], base: str) -> str | None:
    """la clave real de un episodio de esta base que sigue vigente ahora,
    si lo hay. none si no hay ninguno, sea porque nunca hubo o porque
    el ultimo ya se archivo, en cuyo caso lo que llega es un episodio
    nuevo y le toca clave propia."""
    familia = _familia(claves_vigentes, base)
    return familia[0] if familia else None


# hipo de la fuente: un evento que sigue 100% vigente pero la fuente no
# lo trae en un ciclo puntual. caso real visto en produccion, conaf,
# 29-09-2026: el incendio "vertedero san antonio" no aparecio en un
# ciclo de 60s del feed arcgis, se archivo, y 4 minutos despues volvio
# con los mismos datos exactos (mismo f_inicio, misma hectarea, mismo
# estado). para entonces _clave_de_episodio_vigente ya no encontraba
# nada vigente de esa base asi que le abria un slot #2 nuevo dejando
# la fila archivada huerfana para siempre en el historial mientras la
# #2 seguia vigente en el mapa. el mismo incendio en las dos pantallas
# a la vez, sintoma identico al bug de la clave mutable pero con una
# causa distinta esta vez: no cambio ningun campo, la fuente
# simplemente no lo trajo un ciclo.
#
# la solucion no es reintentar el fetch, eso ya lo maneja fetcher.py a
# su nivel y aca no hay forma de saber si valio la pena. es darle a un
# episodio recien archivado un margen antes de darlo por perdido de
# verdad: si vuelve dentro de este margen Y con el mismo contenido se
# revive la misma fila en vez de abrir una nueva. cinco minutos es
# holgado para un par de ciclos fallidos seguidos.
#
# ojo con solo mirar el tiempo: un episodio realmente distinto puede
# nacer en la misma comuna minutos despues de que el anterior se
# resolvio, por ejemplo dos avisos de senapred consecutivos. si se
# revive por antiguedad nomas, ese episodio nuevo pisaria al viejo en
# la misma fila en vez de ganarse la suya, exactamente el bug que
# _clave_libre existe para evitar. por eso ademas de reciente tiene
# que ser el MISMO contenido, titulo y fecha iguales al de la fila
# archivada. eso es justo lo que distingue un hipo de fuente (mismos
# datos, solo desaparecio un ciclo) de un episodio nuevo de verdad
# (datos distintos aunque la base sea igual)
_GRACIA_REVIVIR = timedelta(minutes=5)


def _clave_para_revivir(
    claves_existentes: set[str],
    claves_vigentes: set[str],
    ultima_vez_por_clave: dict[str, datetime],
    snapshot_por_clave: dict[str, dict],
    base: str,
    e: dict,
    ahora: datetime,
) -> str | None:
    """la clave de un episodio archivado de esta base que se dio de baja
    hace menos de _GRACIA_REVIVIR y con el mismo titulo y fecha que el
    evento que esta llegando ahora, si lo hay. solo mira archivados,
    nunca uno vigente, se llama despues de que _clave_de_episodio_vigente
    ya devolvio none. none si no hay ninguno que califique, en cuyo
    caso el llamador abre un episodio nuevo como siempre."""
    titulo = e.get("titulo") or ""
    fecha = e.get("fecha") or ""
    for clave in _familia(claves_existentes, base):
        if clave in claves_vigentes:
            continue  # ese lo atiende _clave_de_episodio_vigente, no aca
        ultima = ultima_vez_por_clave.get(clave)
        if ultima is None or ahora - ultima > _GRACIA_REVIVIR:
            continue
        snapshot = snapshot_por_clave.get(clave) or {}
        if (snapshot.get("titulo") or "") == titulo and (snapshot.get("fecha") or "") == fecha:
            return clave
    return None


def _clave_libre(claves_existentes: set[str], base: str) -> str:
    """proxima clave disponible para un episodio nuevo de esta base.

    la base sola si nadie la uso todavia, para que el primer episodio
    de siempre de una identidad se siga viendo igual que antes de este
    fix y no se rompa ningun dato ya guardado. si ya esta ocupada, sea
    por un episodio vigente o uno archivado, se suma un sufijo
    numerico hasta encontrar uno libre."""
    if base not in claves_existentes:
        return base
    n = 2
    while f"{base}#{n}" in claves_existentes:
        n += 1
    return f"{base}#{n}"


def registrar_ciclo(vigentes: list[dict], registros: list[dict] | None = None) -> None:
    """punto de entrada unico llamado en cada refresh.

    primero actualiza o inserta los eventos actualmente vigentes con
    timestamp fresco, cada uno en el slot de su episodio, ver el
    bloque de arriba. si no hay ningun episodio vigente de esa base
    pero si uno archivado hace menos de _GRACIA_REVIVIR, se revive esa
    misma fila en vez de abrir una nueva, ver _clave_para_revivir y el
    caso real documentado ahi. segundo archiva directo los registros como los
    sismos bajo m4 o una alerta sin tienda cerca porque nunca pasan
    por vigentes y entran ya como historial. uno se considera "el
    mismo" que uno ya guardado, y no se vuelve a insertar, solo si
    ademas de la base comparte titulo. si el titulo cambio es un
    boletin distinto y se gana su propio slot en vez de descartarse
    en silencio. tercero lo que estaba vigente y ya no aparece pasa a
    vigente false y ese es el momento en que entra al historial.
    ultima_vez_vigente queda congelado ahi y de ahi arranca la
    retencion sin resetearse despues. cuarto purga lo que supero su
    retencion."""
    init_schema()
    ahora = datetime.now()

    with engine.begin() as conn:
        filas = conn.execute(
            select(
                historial_tabla.c.clave,
                historial_tabla.c.vigente,
                historial_tabla.c.datos,
                historial_tabla.c.ultima_vez_vigente,
            )
        ).all()
        claves_existentes = {f.clave for f in filas}
        claves_vigentes_db = {f.clave for f in filas if f.vigente}
        ultima_vez_por_clave = {f.clave: f.ultima_vez_vigente for f in filas}
        # snapshot completo por clave. sirve dos veces: para el chequeo
        # de "mismo titulo y fecha" de _clave_para_revivir y, mas abajo
        # sin volver a parsear nada, para el chequeo de "mismo boletin
        # ya visto" de un registro
        snapshot_por_clave: dict[str, dict] = {}
        for f in filas:
            try:
                snapshot_por_clave[f.clave] = json.loads(f.datos)
            except (ValueError, TypeError):
                snapshot_por_clave[f.clave] = {}

        tocadas_este_ciclo: set[str] = set()
        for e in vigentes:
            base = clave_evento(e)
            valores = {
                "datos": json.dumps(e, ensure_ascii=False),
                "vigente": True,
                "ultima_vez_vigente": ahora,
            }
            k = _clave_de_episodio_vigente(claves_vigentes_db, base)
            if not k:
                k = _clave_para_revivir(
                    claves_existentes, claves_vigentes_db, ultima_vez_por_clave,
                    snapshot_por_clave, base, e, ahora,
                )
            if k:
                conn.execute(update(historial_tabla).where(historial_tabla.c.clave == k).values(**valores))
            else:
                k = _clave_libre(claves_existentes, base)
                claves_existentes.add(k)
                conn.execute(insert(historial_tabla).values(clave=k, **valores))
            claves_vigentes_db.add(k)
            tocadas_este_ciclo.add(k)

        for e in registros or []:
            base = clave_evento(e)
            titulo_nuevo = e.get("titulo") or ""
            ya_registrado = any(
                (snapshot_por_clave.get(c) or {}).get("titulo") == titulo_nuevo
                for c in _familia(claves_existentes, base)
            )
            if ya_registrado:
                continue  # mismo boletin ya visto. no refrescar, su reloj de retencion ya arranco
            k = _clave_libre(claves_existentes, base)
            claves_existentes.add(k)
            snapshot_por_clave[k] = e
            conn.execute(insert(historial_tabla).values(
                clave=k,
                datos=json.dumps(e, ensure_ascii=False),
                vigente=False,
                ultima_vez_vigente=ahora,
            ))

        vigentes_en_db = conn.execute(
            select(historial_tabla.c.clave).where(historial_tabla.c.vigente.is_(True))
        ).scalars().all()
        para_archivar = [k for k in vigentes_en_db if k not in tocadas_este_ciclo]
        if para_archivar:
            conn.execute(
                update(historial_tabla)
                .where(historial_tabla.c.clave.in_(para_archivar))
                .values(vigente=False, ultima_vez_vigente=ahora)
            )

        _purgar(conn, ahora)


def _purgar(conn, ahora: datetime) -> None:
    """borra los archivados que superaron la retencion de su tipo.

    la retencion depende del tipo y el tipo vive dentro del json de
    datos asi que se resuelve en python en vez de armar un where por
    cada tipo. son pocas filas de dias de historial y no vale la pena
    complicar la query."""
    filas = conn.execute(
        select(historial_tabla.c.clave, historial_tabla.c.datos,
               historial_tabla.c.ultima_vez_vigente)
        .where(historial_tabla.c.vigente.is_(False))
    ).mappings().all()

    vencidas = []
    for f in filas:
        try:
            tipo = json.loads(f["datos"]).get("tipo")
        except (ValueError, TypeError):
            tipo = None
        dias = ajustes.retencion_dias(tipo)
        if f["ultima_vez_vigente"] < ahora - timedelta(days=dias):
            vencidas.append(f["clave"])

    if vencidas:
        conn.execute(delete(historial_tabla).where(historial_tabla.c.clave.in_(vencidas)))


def obtener_historial() -> list[dict]:
    """eventos archivados que ya no estan vigentes de mas reciente a mas viejo.

    le agrega archivado_en en formato iso que es el momento en que
    dejo de estar vigente para que el frontend pueda mostrar "hace x
    dias" sin tener que adivinar nada."""
    init_schema()
    with engine.begin() as conn:
        filas = conn.execute(
            select(historial_tabla)
            .where(historial_tabla.c.vigente.is_(False))
            .order_by(historial_tabla.c.ultima_vez_vigente.desc())
        ).mappings().all()
    resultado = []
    for f in filas:
        e = json.loads(f["datos"])
        e["archivado_en"] = f["ultima_vez_vigente"].isoformat()
        resultado.append(e)
    return resultado
