"""senapred. alertas oficiales de emergencia de chile.

es la fuente mas importante del monitor. aca llegan las alertas rojas
amarillas y tempranas preventivas que ordenan evacuaciones. se
consulta la api oficial que es appsync graphql con acceso invitado
firmado con sigv4. ver senapred_client.py.

las alertas no traen coordenadas. la zona afectada viene en el texto
del titulo porque las relaciones estructuradas de comunas suelen venir
vacias. por eso se extraen los lugares del titulo y se geocodifican
reutilizando el cache de comunas de las tiendas para poder ubicarlas
en el mapa y cruzarlas con tiendas."""
from __future__ import annotations

import html as html_mod
import re
from datetime import datetime

from .. import area as area_mod
from .. import fenomeno as fenomeno_mod
from ..ai_client import clasificar_alerta_senapred
from ..normalize import Event
from ..regiones_cl import REGIONES as _REGIONES_PATRONES
from ..regiones_cl import region_desde_texto, sin_tildes
from ..senapred_client import graphql
from ..stores import geocode_lugares

_LIMIT = 40  # alertas mas recientes a revisar

_QUERY = """query AlertasByDate($type: String!, $sortDirection: ModelSortDirection, $limit: Int) {
  alertasByDate(type: $type, sortDirection: $sortDirection, limit: $limit) {
    items { id titulo fechaHora isActive isDeleted variableRiesgo { nombre } contenido }
  }
}"""

_TAG = re.compile(r"<[^>]+>")
_TABLA_FILA = re.compile(r"<tr[^>]*>(.*?)</tr>", re.I | re.S)
_TABLA_CELDA = re.compile(r"<t[dh][^>]*>(.*?)</t[dh]>", re.I | re.S)
_FECHA_POST_ISO = re.compile(r"^(\d{4})-(\d{2})-(\d{2})")
_DIA_MES = re.compile(r"^(\d{2})-(\d{2})$")


def _texto_plano(html_str: str | None) -> str:
    """contenido viene en html porque senapred suele citar textual el
    boletin de la dmc ahi adentro. se limpia a texto plano para poder
    buscarle palabras clave como fenomeno o region igual que se hace
    con el titulo."""
    if not html_str:
        return ""
    sin_tags = _TAG.sub(" ", html_str)
    return re.sub(r"\s+", " ", html_mod.unescape(sin_tags)).strip()


def _vigencia_hasta_desde_contenido(contenido_html: str | None, fecha_hora_post: str | None) -> str | None:
    """fecha real hasta la que vale el aviso vigente citado en el boletin.

    el contenido de una alerta suele traer una tablita citando el
    boletin de la dmc con columnas alertamiento pronostico inicio fin
    y enlace por ejemplo "fin: 11-09". es distinto de la narrativa de
    la alerta amarilla regional en si que suele decir que esta vigente
    hasta que las condiciones lo ameriten sin fecha fija. pero el
    aviso puntual citado si tiene una ventana concreta y es la que de
    verdad dice si el motivo actual de la alerta sigue corriendo hoy.
    si senapred cita mas de un aviso en la misma tabla se toma el de
    fin mas lejano porque el mas nuevo manda.

    devuelve dd-mm-yyyy porque la tabla solo trae dia y mes y el anio
    se infiere de la fecha del posteo. o none si no hay una tabla asi.
    no todas las alertas la traen, por ejemplo la sanitaria de arica
    no cita boletin dmc, y en ese caso simplemente no hay fecha
    explicita que ofrecer. ver retention.py que ante none cae de nuevo
    a su ventana de renovacion de siempre."""
    if not contenido_html:
        return None
    tabla = [
        [_texto_plano(celda) for celda in _TABLA_CELDA.findall(fila)]
        for fila in _TABLA_FILA.findall(contenido_html)
    ]
    tabla = [fila for fila in tabla if fila]
    if len(tabla) < 2:
        return None
    encabezado = [c.strip().lower() for c in tabla[0]]
    if "fin" not in encabezado:
        return None
    i_fin = encabezado.index("fin")

    m_post = _FECHA_POST_ISO.match(fecha_hora_post or "")
    if not m_post:
        return None
    anio_post, mes_post = int(m_post.group(1)), int(m_post.group(2))

    mejor_tupla: tuple[int, int, int] | None = None
    mejor_texto: str | None = None
    for fila in tabla[1:]:
        if i_fin >= len(fila):
            continue
        m_fin = _DIA_MES.match(fila[i_fin].strip())
        if not m_fin:
            continue
        dia, mes = m_fin.group(1), int(m_fin.group(2))
        # si el mes del fin es bastante menor al del posteo el aviso
        # cruza de anio. por ejemplo posteo en diciembre fin en enero
        # pasa al anio siguiente
        anio = anio_post + 1 if mes < mes_post - 6 else anio_post
        tupla = (anio, mes, int(dia))
        if mejor_tupla is None or tupla > mejor_tupla:
            mejor_tupla = tupla
            mejor_texto = f"{dia}-{m_fin.group(2)}-{anio}"
    return mejor_texto


def _enriquecer_titulo(titulo: str, fen: str | None) -> str:
    """si se detecto un fenomeno meteorologico como viento o calor y el
    titulo no lo nombra ya de forma explicita se agrega entre
    parentesis para que quede claro de que fenomeno se trata y no
    solo que hay un evento meteorologico generico. por ejemplo
    "monitoreo alerta amarilla por evento meteorologico" pasa a
    "... (Viento)"."""
    if not fen or fenomeno_mod.ya_mencionado(titulo, fen):
        return titulo
    return f"{titulo} ({fenomeno_mod.ETIQUETAS[fen]})"

# nivel de alerta a severidad o color. la preventiva es la mas baja
def _nivel(titulo: str) -> str:
    """severidad segun el titulo respetando cancelaciones y declaraciones.

    un titulo como "se cancela alerta roja y declara alerta amarilla"
    no es una alerta roja. el nivel vigente es el que se declara que
    es amarilla. una cancelacion sin nueva declaracion deja de exigir
    la accion del nivel cancelado."""
    t = titulo.lower()
    # lo que se declara explicitamente manda. maneja "cancela x y declara y"
    m = re.search(r"declara\s+alerta\s+(roja|amarilla)", t)
    if m:
        return m.group(1)
    if "temprana preventiva" in t or "alerta preventiva" in t or "alerta temprana" in t:
        return "verde"
    # cancelacion sin nueva declaracion. ya no es una alerta activa de ese nivel
    if "cancela" in t:
        return "info"
    if "alerta roja" in t:
        return "roja"
    if "alerta amarilla" in t:
        return "amarilla"
    return "info"


# prefijos que anteceden a los nombres de lugar en los titulos de senapred
_PREFIJOS = re.compile(
    r"\b(las comunas de|la comuna de|las provincias de|la provincia del|"
    r"la provincia de|las regiones de|la region de|la regi\u00f3n de|"
    r"comunas de|comuna de|provincia del|provincia de|regiones de|"
    r"region de|regi\u00f3n de)\b",
    re.I,
)

_PARA = re.compile(r"\bpara\b", re.I)
_POR = re.compile(r"\bpor\b", re.I)

# esto solo sirve para detectar que un segmento es una region completa
# y no una lista de comunas antes de partirlo por "y" o "," -- ver
# _lugares_desde_titulo
_PREFIJO_REGION = re.compile(r"\b(la regi\u00f3n de|la region de|regi\u00f3n de|region de)\b", re.I)

# esto solo sirve para detectar que el segmento habla de provincias y
# no de comuna ni region. a diferencia de una region senapred si
# declara alertas para varias provincias a la vez como "las provincias
# de x e y" asi que a diferencia de _prefijo_region esto no busca el
# nombre completo contra una lista fija. solo marca que lo que sigue
# son provincias para que cada nombre ya partido por comuna coma o y
# se re-arme como "provincia de <nombre>" antes de geocodificar. el
# por que esta mas abajo
_PREFIJO_PROVINCIA = re.compile(r"\b(las provincias de|la provincia del|la provincia de|provincia del|provincia de)\b", re.I)


def _tema_desde_titulo(titulo: str) -> str:
    """causa o topico de una alerta que es la parte "por ..." del
    titulo, por ejemplo "por viento" o "por alteracion sanitaria". o
    el titulo completo si no la trae.

    sirve para distinguir dos alertas de hazards distintos que
    coinciden en la misma comuna, por ejemplo una alerta sanitaria y
    una meteorologica declaradas ambas para arica al mismo tiempo (fue
    un caso real que motivo esto), de los estados sucesivos de una
    misma alerta que si hablan de la misma causa. estados como declara
    monitoreo modifica cancela deben colapsarse en retention.py para
    quedarse solo con el estado mas reciente. se normaliza a
    minusculas y sin espacios de mas para poder comparar por
    igualdad."""
    m = _POR.search(titulo)
    causa = titulo[m.start():].strip() if m else titulo.strip()
    return re.sub(r"\s+", " ", causa).lower()


def _titulo_sin_lugares(titulo: str) -> str:
    """le saca el listado de comunas provincias o regiones al titulo.

    senapred redacta titulos como "se declara alerta amarilla para
    las comunas de lonquimay curacautin... por viento". cuando la
    alerta cubre varias comunas esa lista puede ser larguisima y ya
    vive estructurada en el campo comuna de cada evento (uno por
    comuna, ver fetch_events) y en el chip list "comunas afectadas"
    del modal de detalle. repetirla en el titulo es puro ruido
    redundante. se conserva el prefijo "se declara alerta amarilla" y
    la causa si la trae "por viento". solo se descarta el tramo "para
    <lugares>". si el titulo no tiene ese patron se devuelve tal
    cual. nunca rompe, solo prolija cuando puede."""
    m_para = _PARA.search(titulo)
    if not m_para:
        return titulo
    prefijo = titulo[: m_para.start()].strip()
    resto = titulo[m_para.end() :]
    m_por = _POR.search(resto)
    causa = resto[m_por.start() :].strip() if m_por else ""
    return f"{prefijo} {causa}".strip() if causa else prefijo


def _lugares_desde_titulo(titulo: str) -> list[str]:
    """extrae nombres de comuna provincia o region mencionados en el titulo."""
    # la zona afectada va tras "para ..." y antes de la causa "por ..."
    m = re.search(r"\bpara\b(.*)", titulo, re.I)
    seg = m.group(1) if m else titulo
    seg = re.split(r"\bpor\b", seg, maxsplit=1, flags=re.I)[0]

    # si el segmento es una region completa, por ejemplo "la region de
    # arica y parinacota", se devuelve entera. es el nombre oficial de
    # una sola region que es la unica de chile que lleva un "y" en el
    # nombre, no una lista de dos comunas separadas por y. bug real
    # que esto arregla: se estaba partiendo en "arica" y "parinacota"
    # por separado y la mitad "arica" terminaba con el mismo nombre de
    # comuna que otras alertas realmente declaradas para la comuna de
    # arica. retention.py las trataba como la misma alerta por su
    # regla de quedarse con la mas reciente por comuna y la alerta
    # regional entera desaparecia aunque siguiera activa
    if _PREFIJO_REGION.search(seg):
        resto = _PREFIJO_REGION.sub("", seg).strip(" .\t\u00a0")
        plano = sin_tildes(resto.lower()).strip()
        for patron, nombre in _REGIONES_PATRONES:
            if re.fullmatch(patron, plano):
                return [nombre]

    # provincia, por ejemplo "la provincia de cautin" o "las
    # provincias de cautin e imperial". a diferencia de una comuna si
    # se geocodifica el nombre pelado "cautin" en vez de calificado
    # "provincia de cautin" el buscador puede devolver un homonimo de
    # menor jerarquia. bug real que esto arregla: "cautin" a secas
    # resolvia a una calle llamada cautin en puerto montt a mas de 600
    # km de la provincia real porque esa calle hace match exacto de
    # nombre y el geocodificador la prefiere por sobre el limite
    # administrativo cuyo nombre real en el mapa es "provincia de
    # cautin" no "cautin" solo. manteniendo el calificador pegado al
    # nombre la busqueda queda sin ambiguedad y resuelve al limite
    # provincial correcto. verificado en vivo contra nominatim. mismo
    # criterio ya probado arriba con las regiones completas
    es_provincia = bool(_PREFIJO_PROVINCIA.search(seg))

    seg = _PREFIJOS.sub("", seg)
    partes = re.split(r",|\by\b|\be\b", seg, flags=re.I)
    lugares = []
    for p in partes:
        nombre = p.strip(" .\t\u00a0")
        if len(nombre) > 2 and not nombre.lower().startswith("alerta"):
            lugares.append(f"Provincia de {nombre}" if es_provincia else nombre)
    return lugares


def _fmt_fecha(iso: str | None) -> str | None:
    """convierte algo como 2026-08-27t13:17:58.5858-04:00 a
    27-08-2026 13:17 hrs en hora chile."""
    if not iso:
        return None
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})", iso)
    if not m:
        return iso
    y, mo, d, h, mi = m.groups()
    return f"{d}-{mo}-{y} {h}:{mi} hrs"


_CANCELA_NIVEL = re.compile(r"cancela\s+alerta\s+(roja|amarilla)", re.I)


def _severidad_cancelada(titulo: str) -> str | None:
    """que nivel de alerta cierra un aviso de cancelacion.

    se usa para no cerrar por error una alerta de otro nivel que por
    casualidad coincide en el mismo lugar. caso real que esto evita:
    arica tuvo una vez una alerta sanitaria y una meteorologica
    vigentes al mismo tiempo (ver retention.py). si un aviso cancela
    solo una de las dos, exigir que coincida el nivel evita apagar la
    otra por error. none si el titulo no deja claro que nivel cierra,
    y en ese caso _cancelaciones prefiere no usarlo antes que arriesgar
    un cierre de mas."""
    t = titulo.lower()
    m = _CANCELA_NIVEL.search(t)
    if m:
        return m.group(1)
    if "cancela" in t and ("temprana preventiva" in t or "alerta preventiva" in t):
        return "verde"
    return None


def _cancelaciones(items: list[dict]) -> list[tuple[str, str, str]]:
    """lugar, fecha y nivel de cada aviso que cierra una alerta anterior.

    senapred manda estos avisos con isActive=false, y fetch_events los
    descarta antes de mirarlos porque esa bandera en todo lo demas
    significa "ya no vale". para un aviso de cancelacion es al reves:
    isActive=false es justo la marca de que es un cierre legitimo, no
    un error. sin esto una alerta roja vieja se queda mostrandose para
    siempre porque nadie le avisa a hazzi que ya cerro. caso real que
    esto corrige: "se cancela alerta roja para la region de biobio por
    desborde" del 26-09-2026, nunca se procesaba y la alerta original
    del 24-09-2026 seguia vigente cuatro dias despues."""
    out: list[tuple[str, str, str]] = []
    for a in items:
        titulo = a.get("titulo") or ""
        if "cancela" not in titulo.lower():
            continue
        nivel = _severidad_cancelada(titulo)
        if nivel is None:
            continue  # no queda claro que nivel cierra. mejor no usarlo
        fecha = _fmt_fecha(a.get("fechaHora"))
        if not fecha:
            continue
        for lugar in _lugares_desde_titulo(titulo):
            out.append((lugar.strip().lower(), fecha, nivel))
    return out


def _fue_cancelado(e: Event, cancelaciones: list[tuple[str, str, str]]) -> bool:
    """true si un evento ya vencido por un aviso de cancelacion mas nuevo.

    exige mismo lugar, mismo nivel de severidad y que la cancelacion
    sea posterior al evento. las tres condiciones a la vez, no solo el
    lugar, para no cerrar de mas."""
    comuna = (e.comuna or "").strip().lower()
    if not comuna or not e.fecha:
        return False
    try:
        fecha_evento = datetime.strptime(e.fecha, "%d-%m-%Y %H:%M hrs")
    except ValueError:
        return False
    for lugar, fecha_cancel, nivel in cancelaciones:
        if lugar != comuna or nivel != e.severidad:
            continue
        try:
            if datetime.strptime(fecha_cancel, "%d-%m-%Y %H:%M hrs") > fecha_evento:
                return True
        except ValueError:
            continue
    return False


def fetch_events() -> list[Event]:
    res = graphql(_QUERY, {"type": "Alerta", "sortDirection": "DESC", "limit": _LIMIT})
    items = (res.get("data") or {}).get("alertasByDate", {}).get("items", []) or []

    # solo alertas vigentes activas y no borradas. son las que exigen accion
    vigentes = [a for a in items if a.get("isActive") and not a.get("isDeleted")]

    # avisos que cierran una alerta anterior. viven con isActive=false,
    # que la linea de arriba descarta, asi que se procesan aparte. ver
    # _cancelaciones
    cancelaciones = _cancelaciones([a for a in items if not a.get("isDeleted")])

    # extraccion primaria por reglas con regex y palabras clave. solo
    # para las alertas donde las reglas no encuentran nada se pide un
    # respaldo a la ia. en modo mock esto no hace ninguna llamada
    # externa ni cambia el comportamiento actual
    lugares_por_id: dict[str, list[str]] = {}
    severidad_por_id: dict[str, str] = {}
    for a in vigentes:
        titulo = a["titulo"]
        lugares = _lugares_desde_titulo(titulo)
        severidad = _nivel(titulo)
        if not lugares or severidad == "info":
            respaldo = clasificar_alerta_senapred(titulo)
            if not lugares and respaldo["lugares"]:
                lugares = respaldo["lugares"]
            if severidad == "info" and respaldo["severidad"]:
                severidad = respaldo["severidad"]
        lugares_por_id[a["id"]] = lugares
        severidad_por_id[a["id"]] = severidad

    # geocodificar de una sola pasada todos los lugares. reusa cache de comunas
    todos_lugares = {lug for lugs in lugares_por_id.values() for lug in lugs}
    coords = geocode_lugares(sorted(todos_lugares))

    eventos: list[Event] = []
    for a in vigentes:
        titulo = a["titulo"]
        sev = severidad_por_id[a["id"]]
        if sev == "info":
            # cancelacion sin nueva declaracion. no es una alerta
            # accionable, es puro ruido. se descarta. roja amarilla y
            # verde siguen igual
            continue
        fecha = _fmt_fecha(a.get("fechaHora"))
        riesgo = (a.get("variableRiesgo") or {}).get("nombre") or "Emergencia"
        lugares = lugares_por_id[a["id"]]

        # contenido suele citar el boletin de la dmc con fenomeno
        # intensidad y regiones. se usa para identificar
        # explicitamente de que fenomeno se trata, como viento calor
        # nieve o lluvia, cuando el titulo por si solo no lo dice. por
        # ejemplo "monitoreo alerta amarilla por evento meteorologico"
        contenido_txt = _texto_plano(a.get("contenido"))
        fen = fenomeno_mod.detectar(titulo, riesgo, contenido_txt)
        region = region_desde_texto(f"{titulo} {contenido_txt}")
        tema = _tema_desde_titulo(titulo)
        vigencia_hasta = _vigencia_hasta_desde_contenido(a.get("contenido"), a.get("fechaHora"))

        # un evento por lugar geolocalizado. asi aparece en el mapa y
        # cruza tiendas. el titulo mostrado al usuario va sin el
        # listado de lugares (ver _titulo_sin_lugares) porque esa info
        # ya queda en el campo comuna de cada evento y en el chip list
        # "comunas afectadas" del modal. repetirla en el titulo era la
        # queja original de "para que ponerlo dos veces"
        titulo_limpio = _enriquecer_titulo(_titulo_sin_lugares(titulo), fen)
        ubicados = [(lug, coords[lug]) for lug in lugares if lug in coords]
        if not ubicados:
            # sin geo. igual se lista y aparece en eventos aunque no en el mapa
            eventos.append(_evento(titulo_limpio, sev, fecha, riesgo, None, None, None, fen, region, tema=tema, vigencia_hasta=vigencia_hasta))
            continue
        for lug, geo in ubicados:
            area = _area_comuna(lug, geo, sev)
            # el pin va en el centro geometrico del area declarada si
            # hay poligono, y no en el punto crudo que devuelve el
            # geocodificador, porque nominatim puede devolver
            # cualquier punto de referencia de la comuna, no
            # necesariamente su centro. asi el pin queda en el medio
            # de la zona que se ve pintada en el mapa. ver
            # area.centroide_poligono
            lat, lon = geo["lat"], geo["lon"]
            if area and area.get("forma") == "poligono":
                centro = area_mod.centroide_poligono(area["anillos"])
                if centro:
                    lat, lon = centro
            eventos.append(_evento(titulo_limpio, sev, fecha, riesgo, lug, lat, lon, fen, region, area, tema=tema, vigencia_hasta=vigencia_hasta))

    if cancelaciones:
        eventos = [e for e in eventos if not _fue_cancelado(e, cancelaciones)]
    return eventos


def _area_comuna(lugar: str, geo: dict, severidad: str) -> dict | None:
    """area de una alerta que es la comuna real que la alerta declara afectada.

    senapred declara sus alertas por comuna como "se declara alerta
    amarilla para las comunas de x y" asi que el area afectada es la
    comuna ni mas ni menos. antes se usaba un circulo de 30 km desde
    el centro que en providencia, con unos 4 km de lado, inventaba una
    emergencia siete veces mas grande que la comuna, y en natales, con
    unos 470 km, dejaba fuera casi todo el territorio realmente
    afectado.

    en alerta roja se agrega ademas un margen de cercania marcado
    aparte como potencial. una roja implica evacuacion y conviene que
    las tiendas justo al otro lado del limite comunal se preparen pero
    sin declararlas afectadas cuando todavia no lo estan."""
    # ojo. lugar no siempre es una comuna en sentido estricto porque a
    # veces senapred declara la alerta a nivel de region completa como
    # "arica y parinacota" asi que el tooltip muestra el nombre tal
    # cual viene sin anteponerle la palabra "comuna" porque quedaria
    # mal si en realidad es una region u otra localidad
    area = area_mod.por_anillos(geo.get("poly"), f"{lugar} (zona declarada por SENAPRED)")
    if area and severidad == "roja":
        return area_mod.con_margen(
            area,
            area_mod.MARGEN_ALERTA_ROJA_KM,
            "Cercania a una comuna en Alerta Roja: aun no declarada afectada, pero podria serlo",
        )
    return area


def _evento(titulo, sev, fecha, riesgo, comuna, lat, lon, fen, region, area=None, tema=None, vigencia_hasta=None) -> Event:
    detalle = f"Riesgo: {riesgo}"
    if comuna:
        detalle += f" | Zona: {comuna}"
    return Event(
        source="SENAPRED",
        tipo="alerta",
        titulo=titulo,
        severidad=sev,
        region=region,
        comuna=comuna,
        lat=lat,
        lon=lon,
        fecha=fecha,
        estado="Vigente",
        activa=True,
        detalle=detalle,
        fenomeno=fen,
        area=area,
        tema=tema,
        vigencia_hasta=vigencia_hasta,
    )
