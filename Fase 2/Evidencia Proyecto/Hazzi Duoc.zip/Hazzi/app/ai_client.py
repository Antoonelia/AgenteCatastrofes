"""cliente de ia. capa de abstraccion para clasificacion y resumen con llm.

mismo patron que dotacion.py para el sql. el resto del sistema llama a
estas funciones sin saber que hay detras. hoy el proveedor por defecto
es un modo mock que son reglas simples sin llamar a ningun servicio
externo y cero permisos necesarios. o si se configura una api key
gemini que ya se confirmo alcanzable directo desde la red de walmart
sin truco de proxy. el dia que este aprobado el acceso al gateway
interno de ia de walmart se agrega un proveedor nuevo aca adentro y se
cambia la variable de entorno ai_provider. el resto del codigo no
cambia.

salvaguarda de diseno: el prompt le pide explicitamente al modelo que
no invente datos que no esten en el contexto entregado. si el proveedor
real falla por cualquier motivo como sin api key sin red o error del
servicio se degrada automaticamente al modo mock en vez de romper el
dashboard."""
from __future__ import annotations

import json
import os
import urllib.request

AI_PROVIDER = os.environ.get("AI_PROVIDER", "mock")  # mock, gemini, o en el futuro walmart_gateway
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
GEMINI_URL = (
    "https://generativelanguage.googleapis.com/v1beta/models/"
    "gemini-2.0-flash:generateContent"
)

_PROMPT_BASE = (
    "Eres un asistente que resume el estado de riesgo de catastrofes naturales "
    "para sucursales de Walmart Chile. Responde en 2-3 frases, en espanol, "
    "lenguaje claro y no tecnico. IMPORTANTE: usa UNICAMENTE los datos "
    "entregados a continuacion, no inventes cifras ni eventos que no esten "
    "en el contexto.\n\nDatos:\n{contexto}"
)


def _contexto(resumen_severidad: dict, total_eventos: int, tiendas_en_riesgo: list) -> str:
    partes = [f"Eventos activos totales: {total_eventos}."]
    if resumen_severidad:
        detalle = ", ".join(f"{k}: {v}" for k, v in resumen_severidad.items())
        partes.append(f"Por severidad: {detalle}.")
    partes.append(f"Sucursales en riesgo: {len(tiendas_en_riesgo)}.")
    if tiendas_en_riesgo:
        cercana = min(tiendas_en_riesgo, key=lambda t: t.get("distancia_km", 9e9))
        partes.append(
            f"La mas cercana a un evento es {cercana.get('formato')} en "
            f"{cercana.get('comuna')}, a {cercana.get('distancia_km')} km "
            f"del evento '{cercana.get('evento')}'."
        )
    return " ".join(partes)


def _resumen_mock(resumen_severidad: dict, total_eventos: int, tiendas_en_riesgo: list) -> str:
    """respaldo sin llm. reglas simples siempre disponible cero permisos."""
    if total_eventos == 0:
        return "No hay eventos activos registrados en este momento. Situacion tranquila."
    graves = resumen_severidad.get("roja", 0) + resumen_severidad.get("naranja", 0)
    if not tiendas_en_riesgo:
        return (
            f"Hay {total_eventos} evento(s) activo(s) monitoreados, mientras que "
            "ninguna sucursal se encuentra dentro del radio de riesgo por ahora."
        )
    cercana = min(tiendas_en_riesgo, key=lambda t: t.get("distancia_km", 9e9))
    return (
        f"Hay {total_eventos} evento(s) activo(s) ({graves} de severidad alta), "
        f"con {len(tiendas_en_riesgo)} sucursal(es) en riesgo. La mas expuesta es "
        f"{cercana.get('formato')} en {cercana.get('comuna')} "
        f"({cercana.get('distancia_km')} km del evento)."
    )


def _resumen_gemini(contexto: str) -> str | None:
    """llama a gemini. devuelve none si algo falla para poder degradar a mock."""
    if not GEMINI_API_KEY:
        return None
    payload = {
        "contents": [{"parts": [{"text": _PROMPT_BASE.format(contexto=contexto)}]}],
    }
    req = urllib.request.Request(
        f"{GEMINI_URL}?key={GEMINI_API_KEY}",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return data["candidates"][0]["content"]["parts"][0]["text"].strip()
    except Exception:  # noqa: BLE001
        return None


def resumen_ejecutivo(resumen_severidad: dict, total_eventos: int, tiendas_en_riesgo: list) -> dict:
    """punto de entrada unico que usa main.py para el resumen del dashboard.

    devuelve texto proveedor y es_estimado. nunca lanza excepcion. si
    el proveedor real falla degrada a mock."""
    if AI_PROVIDER == "gemini":
        contexto = _contexto(resumen_severidad, total_eventos, tiendas_en_riesgo)
        texto = _resumen_gemini(contexto)
        if texto:
            return {"texto": texto, "proveedor": "gemini", "es_estimado": False}
    return {
        "texto": _resumen_mock(resumen_severidad, total_eventos, tiendas_en_riesgo),
        "proveedor": "mock",
        "es_estimado": True,
    }


# clasificacion de alertas senapred. es el requisito de uso de
# inteligencia artificial.
#
# senapred entrega el titulo en texto libre sin lugares ni severidad
# estructurados. sources/senapred.py ya resuelve esto con reglas
# deterministicas que son gratis instantaneas y cubren el formato
# habitual de titulo con cero errores en produccion hasta ahora. la ia
# entra solo como respaldo cuando esas reglas no encuentran nada asi la
# fuente mas critica del sistema que es la que ordena evacuaciones no
# depende de una llamada de red para su camino normal

_PROMPT_EXTRACCION = (
    "Analiza este titulo de una alerta oficial de emergencia de Chile "
    "(SENAPRED) y extrae SOLO lo que este explicitamente en el texto. NO "
    "inventes lugares ni niveles que no esten escritos. Responde SOLO con un "
    "JSON valido, sin texto adicional, con este formato exacto:\n"
    '{{"lugares": ["nombre de comuna/provincia/region", ...], '
    '"severidad": "roja"|"naranja"|"amarilla"|"verde"|null}}\n\n'
    "Si no hay lugares mencionados, usa una lista vacia. Si no puedes "
    "determinar la severidad con certeza, usa null.\n\n"
    "Titulo: {titulo}"
)


def _clasificar_gemini(titulo: str) -> dict | None:
    if not GEMINI_API_KEY:
        return None
    payload = {"contents": [{"parts": [{"text": _PROMPT_EXTRACCION.format(titulo=titulo)}]}]}
    req = urllib.request.Request(
        f"{GEMINI_URL}?key={GEMINI_API_KEY}",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        texto = data["candidates"][0]["content"]["parts"][0]["text"].strip()
        texto = texto.removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        parseado = json.loads(texto)
        return {"lugares": parseado.get("lugares") or [], "severidad": parseado.get("severidad")}
    except Exception:  # noqa: BLE001
        return None


def clasificar_alerta_senapred(titulo: str) -> dict:
    """respaldo con ia para cuando las reglas de senapred.py no encuentran nada.

    devuelve lugares severidad y proveedor. en modo mock que es el
    default no hace ninguna llamada externa y devuelve listas vacias.
    el llamador simplemente mantiene su comportamiento actual con el
    evento sin geo. nunca lanza excepcion."""
    if AI_PROVIDER == "gemini":
        resultado = _clasificar_gemini(titulo)
        if resultado is not None:
            return {**resultado, "proveedor": "gemini"}
    return {"lugares": [], "severidad": None, "proveedor": "mock"}
