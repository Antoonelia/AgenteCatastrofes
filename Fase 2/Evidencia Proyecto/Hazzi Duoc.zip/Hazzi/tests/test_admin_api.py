"""tests de admin_api.py tras migrar de admin_key a sesiones reales.

la autorizacion en si (quien pasa, quien no, 401 vs 403) ya la cubre
test_sesiones.py de punta a punta contra sesiones.requiere_rol. lo que
corresponde verificar aca es mas acotado: que admin_api arme esa
dependencia con el rol correcto ("admin", no "admin_usuarios" por
error) y que la lectura siga funcionando igual que siempre, sin el
campo proteccion_activa que ya no existe.
"""
from __future__ import annotations

import json

from app import admin_api


def test_requiere_admin_exige_el_rol_admin_y_no_otro():
    """regresion puntual: si alguien cambia "admin" por "admin_usuarios"
    por error, el admin operativo perderia acceso a su propio panel."""
    usuario_admin = {"id": 1, "nombre": "Ana", "roles": ["admin"], "rut_enmascarado": "11XXXXXX-1"}
    usuario_otro_rol = {"id": 2, "nombre": "Beto", "roles": ["admin_usuarios"], "rut_enmascarado": "22XXXXXX-2"}

    import sys
    import types
    from unittest.mock import MagicMock

    # _requiere_admin ya es la dependencia construida (sesiones.requiere_rol("admin")).
    # se ejercita contra objetos usuario ya resueltos, no contra un token real,
    # porque eso es exactamente lo que ya prueba test_sesiones.py
    from app import sesiones as s

    original = s.obtener_usuario
    try:
        s.obtener_usuario = lambda token: usuario_admin if token == "tok-admin" else usuario_otro_rol
        dependencia = s.requiere_rol("admin")
        assert dependencia(hazzi_sesion="tok-admin")["roles"] == ["admin"]
        try:
            dependencia(hazzi_sesion="tok-otro")
            assert False, "un admin_usuarios no deberia pasar requiere_rol('admin')"
        except Exception as exc:
            assert getattr(exc, "status_code", None) == 403
    finally:
        s.obtener_usuario = original


def test_la_lectura_de_ajustes_trae_lo_que_la_pantalla_necesita():
    cuerpo = admin_api.leer_ajustes().body.decode()
    d = json.loads(cuerpo)
    assert "proteccion_activa" not in d, "ya no existe: la proteccion ahora es sesion real, no un flag"
    assert d["ajustes"] and d["radios"]
    for a in d["ajustes"]:
        for campo in ("clave", "etiqueta", "ayuda", "minimo", "maximo",
                      "defecto", "valor", "entero", "modificado"):
            assert campo in a, f"falta {campo} en {a.get('clave')}"


def test_los_radios_se_agrupan_con_su_justificacion():
    """los radios se muestran para explicar el modelo. sin nota no sirven."""
    d = json.loads(admin_api.leer_ajustes().body.decode())
    for g in d["radios"]:
        assert g["titulo"] and g["nota"] and g["filas"]


def test_guardar_ajustes_registra_en_la_auditoria():
    """cada escritura queda trazada a quien la hizo, ver auditoria.py."""
    from app import ajustes, auditoria

    quien = {"id": 1, "nombre": "Ana", "roles": ["admin"], "rut_enmascarado": "11XXXXXX-1"}
    llamadas = []
    original_registrar = auditoria.registrar
    original_guardar = ajustes.guardar
    try:
        auditoria.registrar = lambda usuario, accion, detalle=None: llamadas.append((usuario, accion, detalle))
        ajustes.guardar = lambda cambios: {"magnitud_minima": 4.0}
        admin_api.guardar_ajustes({"magnitud_minima": 4.0}, quien=quien)
        assert len(llamadas) == 1
        assert llamadas[0][0] == quien
        assert llamadas[0][1] == "guardar_ajustes"
    finally:
        auditoria.registrar = original_registrar
        ajustes.guardar = original_guardar
