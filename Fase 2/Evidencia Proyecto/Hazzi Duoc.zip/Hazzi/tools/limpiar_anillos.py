"""Limpia el ruido de los contornos ya cacheados (islotes de <=5 puntos).

Aplica la misma regla que _anillos_geojson sobre lo que ya esta en disco, sin
volver a pedirle nada a Nominatim.
"""
import json
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from app.stores import _COMUNAS_CACHE, _MIN_PUNTOS_ANILLO, _load_comunas_cache

cache = _load_comunas_cache()
antes = len(json.dumps(cache)) / 1024
tocadas = 0

for nombre, v in cache.items():
    poly = (v or {}).get("poly")
    if not poly:
        continue
    utiles = [a for a in poly if len(a) > _MIN_PUNTOS_ANILLO] or [max(poly, key=len)]
    if len(utiles) != len(poly):
        print(f"   {nombre:<22} {len(poly):>4} -> {len(utiles)} anillos")
        v["poly"] = utiles
        tocadas += 1

_COMUNAS_CACHE.write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding="utf-8")
despues = len(json.dumps(cache)) / 1024
print(f"\n{tocadas} comunas limpiadas   {antes:.0f} KB -> {despues:.0f} KB")
