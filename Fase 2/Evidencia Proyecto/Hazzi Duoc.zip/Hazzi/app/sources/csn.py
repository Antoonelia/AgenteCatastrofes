"""csn. centro sismologico nacional de la universidad de chile.

es la fuente oficial chilena de sismos. capta mucho mejor que usgs los
sismos chicos y los que caen cerca de la frontera porque tiene redes
locales mas densas. se lee el catalogo diario publico en html porque no
hay api json asi que se parsea la tabla con regex.

requisito: estar en la vpn de walmart o wifi eagle porque el fetch pasa
por el proxy corporativo."""
from __future__ import annotations

import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone

from .. import area as area_mod
from .. import ajustes
from ..fetcher import fetch_text, text_de
from ..normalize import Event, num, severidad_sismo, texto_fecha_cl

_LAT_MIN, _LAT_MAX = -56.5, -17.0  # mismo cuadrante que usgs para consistencia
_LON_MIN, _LON_MAX = -76.0, -66.0
_BASE = "https://www.sismologia.cl/sismicidad/catalogo"
# la ventana de dias y la magnitud minima se comparten con usgs y se editan
# desde el admin. viven en ajustes.py no aca. antes estaban duplicadas en
# las dos fuentes y era justo lo que se queria sacar

# cada fila de la tabla trae mas o menos esto:
#   <td><a ...>fecha_local</a><br>lugar</td>
#   <td>fecha_utc</td>
#   <td>lat<br> lon</td>
#   <td>prof km</td>
#   <td class="magnitud">mag tipo</td>
_ROW = re.compile(
    r"<td><a[^>]*>([^<]+)</a><br>\s*([^<]+?)\s*</td>\s*"
    r"<td>([^<]+)</td>\s*"
    r"<td>\s*([-\d.]+)\s*<br>\s*([-\d.]+)\s*</td>\s*"
    r"<td>\s*([\d.]+)\s*km\s*</td>\s*"
    r'<td class="magnitud">\s*([\d.]+)\s*(\w+)\s*</td>',
    re.S,
)


def _urls_recientes() -> list[str]:
    """urls del catalogo para cada uno de los ultimos dias en hora utc."""
    hoy = datetime.now(timezone.utc).date()
    urls = []
    for i in range(ajustes.ventana_dias() + 1):  # uno mas por si cayo justo en el borde
        d = hoy - timedelta(days=i)
        urls.append(f"{_BASE}/{d.year:04d}/{d.month:02d}/{d.year:04d}{d.month:02d}{d.day:02d}.html")
    return urls


def urls_requeridas() -> list[str]:
    """urls que necesita esta fuente. se piden todas juntas con las demas."""
    return _urls_recientes()


def _dentro_de_chile(lat: float | None, lon: float | None) -> bool:
    if lat is None or lon is None:
        return False
    return _LAT_MIN <= lat <= _LAT_MAX and _LON_MIN <= lon <= _LON_MAX


def _es_reciente(fecha_utc: str) -> bool:
    """true si el sismo paso en las ultimas 24 horas segun la fecha utc del csn."""
    try:
        dt = datetime.strptime(fecha_utc.strip(), "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
        return (datetime.now(timezone.utc) - dt).total_seconds() <= 24 * 3600
    except ValueError:
        return False


def _parse_dia(html: str) -> list[Event]:
    eventos: list[Event] = []
    for fecha_local, lugar, fecha_utc, lat_s, lon_s, prof_s, mag_s, mag_tipo in _ROW.findall(html):
        mag = num(mag_s)
        if mag is None or mag < ajustes.magnitud_minima():
            continue
        lat, lon = num(lat_s), num(lon_s)
        if not _dentro_de_chile(lat, lon):
            continue

        prof = num(prof_s)
        reciente = _es_reciente(fecha_utc)
        detalle = f"Magnitud {mag} {mag_tipo}"
        if prof is not None:
            detalle += f" | Profundidad {prof} km"

        eventos.append(
            Event(
                source="CSN",
                tipo="sismo",
                titulo=f"M{mag} - {lugar.strip()}",
                severidad=severidad_sismo(mag),
                # el csn da la ubicacion como referencia geografica tipo "45 km
                # al ne de ovalle". se expone en region para que la ui la
                # muestre en su parte de ubicacion y no quede escondida en el
                # titulo
                region=lugar.strip() or None,
                lat=lat,
                lon=lon,
                fecha=texto_fecha_cl(fecha_local),
                estado="Reciente (<24h)" if reciente else "Ocurrido",
                activa=reciente,
                detalle=detalle,
                area=area_mod.por_sismo(mag),
            )
        )
    return eventos


def fetch_events(prefetched: dict[str, str] | None = None) -> list[Event]:
    """trae los catalogos diarios de la ventana configurada.

    cada dia es un archivo html aparte y cada descarga pasa por un proceso
    de powershell nuevo. pedirlos uno por uno paga el arranque de
    powershell ocho veces siempre.

    lo normal es que prefetched ya traiga los ocho dias pedidos en un solo
    proceso junto con las demas fuentes. aca solo se parsea sin gastar
    ningun proceso nuevo. si algun dia no vino en el lote o no hay
    prefetch para nada se piden en paralelo solo los que faltan asi el
    costo queda acotado al dia mas lento y no a la suma de todos."""
    urls = _urls_recientes()
    eventos: list[Event] = []
    faltantes = []
    for url in urls:
        html = text_de(url, prefetched)
        if html:
            try:
                eventos.extend(_parse_dia(html))
            except Exception:  # noqa: BLE001 - un dia con formato raro no rompe el resto
                continue
        else:
            faltantes.append(url)

    if faltantes:
        with ThreadPoolExecutor(max_workers=len(faltantes)) as pool:
            futuros = {pool.submit(fetch_text, url): url for url in faltantes}
            for fut in as_completed(futuros):
                try:
                    eventos.extend(_parse_dia(fut.result()))
                except Exception:  # noqa: BLE001
                    continue
    return eventos
