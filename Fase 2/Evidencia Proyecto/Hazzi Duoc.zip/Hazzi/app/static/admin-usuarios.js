/* admin-usuarios.js. alta, edicion y borrado de cuentas de admin, mas la
 * bitacora de auditoria.
 *
 * vive en su propio archivo y no dentro del html, misma razon que
 * admin-instalaciones.js: esta pantalla tiene tabla, popup de alta/edicion
 * y popup de borrado -- embebido todo en el html se iba bastante mas alla
 * de las 600 lineas y se volvia imposible de leer.
 */

const $ = (id) => document.getElementById(id);
const escapar = (t) => String(t == null ? '' : t).replace(/[&<>"]/g, (c) =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

function sesionExpiro(r) {
  if (r.status === 401 || r.status === 403) { location.href = '/'; return true; }
  return false;
}

/* toLocaleString('es-CL') sin opciones tira cosas como
   "05-10-2026, 2:35:07 p. m.": coma de mas, segundos que a nadie le
   importan en una bitacora y un "p. m." con puntitos rarunos. con
   opciones explicitas y 24 horas queda "05-10-2026 14:35", mismo dato,
   mitad de caracteres y nada de ambiguedad am/pm. */
function fechaCorta(iso) {
  try {
    const d = new Date(iso);
    const fecha = d.toLocaleDateString('es-CL', { day: '2-digit', month: '2-digit', year: 'numeric' });
    const hora = d.toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit', hour12: false });
    return `${fecha} ${hora}`;
  } catch (e) { return iso; }
}

function iniciales(nombre) {
  const partes = (nombre || '').trim().split(/\s+/).filter(Boolean);
  if (partes.length === 0) return '?';
  const primera = partes[0][0] || '';
  const segunda = partes.length > 1 ? (partes[1][0] || '') : '';
  return (primera + segunda).toUpperCase();
}

const ETIQUETA_ROL_PANEL = { admin: 'Administrador', admin_usuarios: 'Gestion de usuarios' };

function badgesRoles(roles) {
  return roles.map((r) => `<span class="us-badge-rol text-xs font-semibold px-2 py-0.5 rounded-full mr-1 mb-1 inline-block">${ETIQUETA_ROL_PANEL[r] || r}</span>`).join('');
}

const ICONO_KEBAB = '<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="12" cy="19" r="1.8"/></svg>';

/* ---------- bitacora: traducir accion cruda a texto humano ----------
 * una entrada por cada valor que puede llegar a emitir auditoria.registrar
 * (ver grep de "auditoria.registrar(" en admin_api.py / usuarios_api.py /
 * auth_api.py). si alguna vez aparece un valor nuevo que no esta en este
 * mapa, el fallback de abajo lo arma solo (reemplaza '_' por espacio y
 * pone mayuscula), asi la tabla nunca muestra un hueco vacio. */
const ETIQUETA_ACCION = {
  login: 'Inicio de sesion',
  logout: 'Cierre de sesion',
  login_fallido: 'Intento de acceso fallido',
  crear_instalacion: 'Instalacion creada',
  editar_instalacion: 'Instalacion editada',
  eliminar_instalacion: 'Instalacion eliminada',
  reincluir_instalacion: 'Instalacion reincluida',
  guardar_ajustes: 'Ajustes guardados',
  restablecer_ajustes: 'Ajustes restablecidos',
  refrescar_fuentes: 'Fuentes refrescadas',
  crear_usuario: 'Usuario creado',
  editar_usuario: 'Usuario editado',
  eliminar_usuario: 'Usuario eliminado',
  agregar_rol_usuario: 'Rol agregado',
  quitar_rol_usuario: 'Rol quitado',
  activar_usuario: 'Usuario activado',
  desactivar_usuario: 'Usuario desactivado',
  cambiar_clave_usuario: 'Clave cambiada',
};

function etiquetaAccion(accion) {
  return ETIQUETA_ACCION[accion] || accion.replace(/_/g, ' ').replace(/^./, (c) => c.toUpperCase());
}

/* categoria visual de cada accion, para el color del badge. el orden de
   los if importa poco porque los prefijos no se pisan entre si. */
function categoriaAccion(accion) {
  if (/^(eliminar|desactivar|login_fallido)/.test(accion)) return 'mal';
  if (/^(crear|activar|reincluir)/.test(accion)) return 'ok';
  if (/^(login|logout|refrescar)/.test(accion)) return 'neutro';
  return 'cambio';
}

/* etiquetas de las claves mas comunes que aparecen en el "detalle" json
   de cada fila (ver segundo argumento de auditoria.registrar en el
   backend). claves que no esten aca se muestran tal cual llegan, asi
   una clave nueva no queda oculta -- solo queda menos bonita hasta que
   se agregue aca. */
const ETIQUETA_DETALLE_CLAVE = {
  iid: 'Instalacion',
  id: 'ID',
  accion: 'Tipo',
  cambios: 'Cambios',
  rol_agregado: 'Rol agregado',
  rol_quitado: 'Rol quitado',
  roles_resultantes: 'Roles resultantes',
  rut_enmascarado: 'RUT',
  roles: 'Roles',
};

function formatValorDetalle(clave, valor) {
  if (Array.isArray(valor)) {
    if (clave === 'roles' || clave === 'roles_resultantes') {
      return valor.map((r) => ETIQUETA_ROL_PANEL[r] || r).join(', ') || 'ninguno';
    }
    return valor.join(', ');
  }
  if (valor && typeof valor === 'object') {
    return Object.entries(valor).map(([k, v]) => `${k}: ${v}`).join(', ');
  }
  return String(valor);
}

function formatDetalle(detalle) {
  if (!detalle || typeof detalle !== 'object') return '<span class="us-detalle-item">&mdash;</span>';
  const entradas = Object.entries(detalle);
  if (entradas.length === 0) return '<span class="us-detalle-item">&mdash;</span>';
  return entradas.map(([clave, valor]) => {
    const etiqueta = ETIQUETA_DETALLE_CLAVE[clave] || clave;
    return `<span class="us-detalle-item"><b>${escapar(etiqueta)}:</b> ${escapar(formatValorDetalle(clave, valor))}</span>`;
  }).join('');
}

/* ---------- tabla de cuentas ---------- */

let USUARIOS = [];

function filaUsuario(u) {
  return `<tr data-id="${u.id}">
    <td class="px-4 py-2">
      <div class="us-fila-cuenta">
        <div class="us-avatar ${u.activo ? '' : 'us-avatar-inactivo'}">${escapar(iniciales(u.nombre))}</div>
        <div>
          <div class="us-nombre">${escapar(u.nombre)}</div>
          <div class="us-rut-chico">${escapar(u.rut_enmascarado)}</div>
          <div class="us-creado-chico">Creado el ${fechaCorta(u.creado_en)}</div>
        </div>
      </div>
    </td>
    <td class="px-4 py-2">${badgesRoles(u.roles)}</td>
    <td class="px-4 py-2">
      <span class="us-estado-chip ${u.activo ? 'us-activo' : 'us-inactivo'}">
        <span class="us-estado-dot"></span>${u.activo ? 'Activo' : 'Inactivo'}
      </span>
    </td>
    <td class="px-4 py-2 text-right">
      <div class="us-kebab-wrap">
        <button type="button" class="us-kebab-btn" data-id="${u.id}" aria-haspopup="true"
          aria-expanded="false" aria-label="Acciones de ${escapar(u.nombre)}">${ICONO_KEBAB}</button>
      </div>
    </td>
  </tr>`;
}

function pintarTabla() {
  $('tabla-usuarios').innerHTML = USUARIOS.map(filaUsuario).join('');
  $('usuarios-vacio').classList.toggle('hidden', USUARIOS.length > 0);
}

function filaAuditoria(a) {
  return `<tr>
    <td class="px-4 py-2 text-xs us-fecha-chica whitespace-nowrap">${fechaCorta(a.creado_en)}</td>
    <td class="px-4 py-2">${escapar(a.nombre)}<br><span class="text-xs text-slate-400 font-mono">${escapar(a.rut_enmascarado)}</span></td>
    <td class="px-4 py-2 text-xs">${(a.roles || []).map((r) => ETIQUETA_ROL_PANEL[r] || r).join(', ') || '&mdash;'}</td>
    <td class="px-4 py-2"><span class="us-badge-accion ${categoriaAccion(a.accion)}">${escapar(etiquetaAccion(a.accion))}</span></td>
    <td class="px-4 py-2">${formatDetalle(a.detalle)}</td>
  </tr>`;
}

async function cargarUsuarios() {
  const r = await fetch('/api/usuarios');
  if (sesionExpiro(r)) return;
  const d = await r.json();
  USUARIOS = d.usuarios;
  cerrarMenuKebab();
  pintarTabla();
}

async function cargarAuditoria() {
  const r = await fetch('/api/usuarios/auditoria?limite=50');
  if (sesionExpiro(r)) return;
  const d = await r.json();
  $('tabla-auditoria').innerHTML = d.acciones.map(filaAuditoria).join('');
  $('auditoria-vacio').classList.toggle('hidden', d.acciones.length > 0);
}

/* ---------- ultimos accesos a monitorear (panel plegable) ---------- */
function filaVisita(v) {
  return `<li class="us-visita">
    <span class="us-visita-av">${escapar(iniciales(v.nombre))}</span>
    <span class="us-visita-nombre">${escapar(v.nombre)}</span>
    <span class="us-visita-fecha">${fechaCorta(v.ultima_vez)}</span>
  </li>`;
}

async function cargarVisitas() {
  const r = await fetch('/api/usuarios/visitas?limite=10');
  if (sesionExpiro(r)) return;
  const d = r.ok ? await r.json() : { visitas: null };
  const visitas = d.visitas || [];
  $('lista-visitas').innerHTML = visitas.map(filaVisita).join('');
  $('visitas-vacio').textContent = d.visitas
    ? 'Todavia nadie ha entrado a monitorear.'
    : 'No se pudo cargar la lista de accesos.';
  $('visitas-vacio').classList.toggle('hidden', visitas.length > 0);
}

// la pantalla suele quedar abierta mientras otras personas entran, asi que
// se refresca sola cada 20 s (solo con el panel desplegado y la pestana visible)
setInterval(() => {
  if (document.hidden || $('visitas-toggle').getAttribute('aria-expanded') !== 'true') return;
  cargarVisitas().catch(() => {});
}, 20000);

$('visitas-toggle').addEventListener('click', () => {
  const boton = $('visitas-toggle');
  const abrir = boton.getAttribute('aria-expanded') !== 'true';
  boton.setAttribute('aria-expanded', String(abrir));
  $('visitas-cuerpo').classList.toggle('hidden', !abrir);
  if (abrir) cargarVisitas();
});

/* ---------- menu de 3 puntitos: un unico elemento "flotante" en vez de
   uno por fila. vive afuera de la tabla (ver #menu-kebab-usuario en
   admin-usuarios.html, al fondo del <body>), asi que nunca lo recorta
   el overflow:hidden de la tarjeta ni se destruye cada vez que
   pintarTabla() redibuja las filas -- abrir/cerrar solo mueve este
   unico elemento y cambia a que fila apunta. ---------- */

let menuAbiertoId = null;  // id del usuario cuyo menu esta abierto, o null
const menuKebab = $('menu-kebab-usuario');

function posicionarMenuKebab(boton) {
  const r = boton.getBoundingClientRect();
  const alto = menuKebab.offsetHeight;
  const ancho = menuKebab.offsetWidth;
  let top = r.bottom + 4;
  if (top + alto > window.innerHeight - 8) top = r.top - alto - 4;
  let left = r.right - ancho;
  if (left < 8) left = 8;
  if (left + ancho > window.innerWidth - 8) left = window.innerWidth - ancho - 8;
  menuKebab.style.top = `${top}px`;
  menuKebab.style.left = `${left}px`;
}

function abrirMenuKebab(boton, id) {
  if (menuAbiertoId === id) { cerrarMenuKebab(); return; }
  menuAbiertoId = id;
  document.querySelectorAll('.us-kebab-btn').forEach((b) => b.setAttribute('aria-expanded', String(b === boton)));
  menuKebab.classList.remove('hidden');
  posicionarMenuKebab(boton);
}

function cerrarMenuKebab() {
  menuAbiertoId = null;
  document.querySelectorAll('.us-kebab-btn').forEach((b) => b.setAttribute('aria-expanded', 'false'));
  menuKebab.classList.add('hidden');
}

$('tabla-usuarios').addEventListener('click', (ev) => {
  const kebabBtn = ev.target.closest('.us-kebab-btn');
  if (kebabBtn) abrirMenuKebab(kebabBtn, Number(kebabBtn.dataset.id));
});

$('menu-kebab-editar').addEventListener('click', () => {
  const usuario = USUARIOS.find((u) => u.id === menuAbiertoId);
  cerrarMenuKebab();
  if (usuario) abrirModalEditar(usuario);
});
$('menu-kebab-eliminar').addEventListener('click', () => {
  const usuario = USUARIOS.find((u) => u.id === menuAbiertoId);
  cerrarMenuKebab();
  if (usuario) abrirModalEliminar(usuario);
});

document.addEventListener('click', (e) => {
  if (menuAbiertoId !== null && !e.target.closest('.us-kebab-wrap') && !e.target.closest('#menu-kebab-usuario')) {
    cerrarMenuKebab();
  }
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && menuAbiertoId !== null) cerrarMenuKebab();
});

// si se scrollea o se cambia el tamano de ventana con el menu abierto,
// se reposiciona para que siga pegado al boton -- o se cierra si el
// boton ya se salio de la pantalla. captura en fase de captura porque
// "scroll" no burbujea desde un div interno.
function reposicionarOCerrarMenuKebab() {
  if (menuAbiertoId === null) return;
  const boton = document.querySelector('.us-kebab-btn[aria-expanded="true"]');
  if (!boton) { cerrarMenuKebab(); return; }
  const r = boton.getBoundingClientRect();
  if (r.bottom < 0 || r.top > window.innerHeight) { cerrarMenuKebab(); return; }
  posicionarMenuKebab(boton);
}
window.addEventListener('scroll', reposicionarOCerrarMenuKebab, true);
window.addEventListener('resize', reposicionarOCerrarMenuKebab);

/* ---------- popup de alta/edicion: abrir/cerrar ---------- */

let editandoId = null;  // id del usuario en edicion, o null si es un alta

function aplicarModoFormulario(editar) {
  $('form-titulo').textContent = editar ? 'Editar cuenta de administracion' : 'Nueva cuenta de administracion';
  $('form-sub').textContent = editar
    ? 'El RUT no se puede cambiar. La clave es opcional: dejala vacia para conservar la actual.'
    : 'Elige el rol, carga los datos y confirma la clave.';
  $('btn-guardar-txt').textContent = editar ? 'Guardar cambios' : 'Crear usuario';
  $('nuevo-rut').disabled = editar;
  $('nuevo-clave').required = !editar;
  $('nuevo-clave-confirmar').required = !editar;
  $('nuevo-clave').placeholder = editar ? 'Dejar en blanco para no cambiarla' : 'Minimo 8 caracteres';
  $('nuevo-clave-confirmar').placeholder = editar ? 'Repetila si cargaste una nueva' : 'Escribela de nuevo';
  $('campo-estado-edicion').classList.toggle('hidden', !editar);
}

function abrirModalCrear() {
  editandoId = null;
  $('form-crear').reset();
  aplicarModoFormulario(false);
  rolesSeleccionados = new Set(['admin']);
  pintarRoles();
  activarEstado(true);
  actualizarHintClave();
  actualizarHintCoincidencia();
  $('crear-error').classList.add('hidden');
  $('modal-form').classList.remove('hidden');
  setTimeout(() => $('nuevo-rut').focus(), 80);
}

function abrirModalEditar(usuario) {
  editandoId = usuario.id;
  $('form-crear').reset();
  aplicarModoFormulario(true);
  $('nuevo-rut').value = usuario.rut_enmascarado;
  $('nuevo-nombre').value = usuario.nombre;
  rolesSeleccionados = new Set(usuario.roles);
  pintarRoles();
  activarEstado(usuario.activo);
  actualizarHintClave();
  actualizarHintCoincidencia();
  $('crear-error').classList.add('hidden');
  $('modal-form').classList.remove('hidden');
  setTimeout(() => $('nuevo-nombre').focus(), 80);
}

function cerrarModalCrear() {
  $('modal-form').classList.add('hidden');
}

$('btn-fab-nuevo').addEventListener('click', abrirModalCrear);
$('btn-cancelar-crear').addEventListener('click', cerrarModalCrear);
$('modal-form-cerrar').addEventListener('click', cerrarModalCrear);
$('modal-form').addEventListener('click', (e) => { if (e.target.id === 'modal-form') cerrarModalCrear(); });
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && !$('modal-form').classList.contains('hidden')) cerrarModalCrear();
});

/* ---------- roles: pastillas de seleccion multiple ---------- */

let rolesSeleccionados = new Set(['admin']);

function pintarRoles() {
  document.querySelectorAll('#rol-op-admin, #rol-op-admin-usuarios').forEach((btn) => {
    btn.setAttribute('aria-pressed', String(rolesSeleccionados.has(btn.dataset.rol)));
  });
}

document.querySelectorAll('#rol-op-admin, #rol-op-admin-usuarios').forEach((btn) => {
  btn.addEventListener('click', () => {
    const rol = btn.dataset.rol;
    if (rolesSeleccionados.has(rol)) rolesSeleccionados.delete(rol);
    else rolesSeleccionados.add(rol);
    pintarRoles();
  });
});

/* ---------- estado activa/inactiva: pastillas de seleccion unica,
   solo visibles editando ---------- */

let estadoActivo = true;

function activarEstado(activo) {
  estadoActivo = activo;
  $('estado-op-activo').setAttribute('aria-pressed', String(activo));
  $('estado-op-inactivo').setAttribute('aria-pressed', String(!activo));
}

$('estado-op-activo').addEventListener('click', () => activarEstado(true));
$('estado-op-inactivo').addEventListener('click', () => activarEstado(false));

/* ---------- ojito de mostrar/ocultar clave ---------- */

const ICONO_OJO = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z"/><circle cx="12" cy="12" r="3"/></svg>';
const ICONO_OJO_TACHADO = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.9 17.9A10.9 10.9 0 0 1 12 19c-7 0-11-7-11-7a18.5 18.5 0 0 1 4.22-5.05M9.9 4.24A10.9 10.9 0 0 1 12 4c7 0 11 7 11 7a18.5 18.5 0 0 1-2.16 3.19"/><path d="M14.12 14.12A3 3 0 1 1 9.88 9.88"/><path d="M1 1l22 22"/></svg>';

document.querySelectorAll('.us-ojo-btn').forEach((btn) => {
  btn.innerHTML = ICONO_OJO;
  btn.addEventListener('click', () => {
    const input = $(btn.dataset.ojoDe);
    const verlo = input.type === 'password';
    input.type = verlo ? 'text' : 'password';
    btn.innerHTML = verlo ? ICONO_OJO_TACHADO : ICONO_OJO;
    btn.setAttribute('aria-label', verlo ? 'Ocultar clave' : 'Mostrar clave');
  });
});

/* ---------- pistas en vivo: largo minimo y coincidencia ---------- */

const ICONO_CIRCULO = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/></svg>';
const ICONO_CHECK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9 12l2 2 4-4"/></svg>';
const ICONO_X = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M15 9l-6 6M9 9l6 6"/></svg>';

function actualizarHintClave() {
  const clave = $('nuevo-clave').value;
  const hint = $('clave-hint');
  if (editandoId !== null && !clave) {
    hint.classList.remove('ok');
    hint.innerHTML = ICONO_CIRCULO + '<span>Vacia: la clave actual no cambia</span>';
    return;
  }
  const ok = clave.length >= 8;
  hint.classList.toggle('ok', ok);
  hint.innerHTML = (ok ? ICONO_CHECK : ICONO_CIRCULO) +
    `<span>${ok ? 'Cumple el minimo de 8 caracteres' : 'Minimo 8 caracteres'}</span>`;
}

function actualizarHintCoincidencia() {
  const clave = $('nuevo-clave').value;
  const confirmar = $('nuevo-clave-confirmar').value;
  const hint = $('clave-match-hint');
  if (!clave && !confirmar) { hint.style.visibility = 'hidden'; return; }
  hint.style.visibility = 'visible';
  const coincide = clave === confirmar;
  hint.classList.toggle('ok', coincide);
  hint.classList.toggle('mal', !coincide);
  hint.innerHTML = (coincide ? ICONO_CHECK : ICONO_X) +
    `<span>${coincide ? 'Las claves coinciden' : 'Las claves no coinciden'}</span>`;
}

$('nuevo-clave').addEventListener('input', () => { actualizarHintClave(); actualizarHintCoincidencia(); });
$('nuevo-clave-confirmar').addEventListener('input', actualizarHintCoincidencia);

/* ---------- alta/edicion de usuario ---------- */

$('form-crear').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const err = $('crear-error');
  err.classList.add('hidden');

  const roles = [...rolesSeleccionados];
  if (roles.length === 0) { err.textContent = 'Elegi al menos un rol.'; err.classList.remove('hidden'); return; }

  const clave = $('nuevo-clave').value;
  const confirmar = $('nuevo-clave-confirmar').value;
  const cambiaClave = editandoId === null || clave || confirmar;
  if (cambiaClave) {
    if (clave.length < 8) { err.textContent = 'La clave debe tener al menos 8 caracteres.'; err.classList.remove('hidden'); return; }
    if (clave !== confirmar) { err.textContent = 'Las dos claves deben ser iguales.'; err.classList.remove('hidden'); return; }
  }

  try {
    let r;
    if (editandoId === null) {
      r = await fetch('/api/usuarios', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rut: $('nuevo-rut').value.trim(), nombre: $('nuevo-nombre').value.trim(), clave, roles }),
      });
    } else {
      r = await fetch(`/api/usuarios/${editandoId}`, {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nombre: $('nuevo-nombre').value.trim(), roles, clave: cambiaClave ? clave : null }),
      });
      if (!sesionExpiro(r) && r.ok) {
        // el estado activo/inactivo es una llamada aparte (cambiar_activo),
        // asi la auditoria lo distingue de un simple cambio de nombre/rol
        await fetch(`/api/usuarios/${editandoId}/activo`, {
          method: 'PUT', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ activo: estadoActivo }),
        });
      }
    }
    if (sesionExpiro(r)) return;
    const d = await r.json();
    if (!r.ok) { err.textContent = d.detail || 'No se pudo guardar.'; err.classList.remove('hidden'); return; }
    cerrarModalCrear();
    await Promise.all([cargarUsuarios(), cargarAuditoria()]);
  } catch (e) {
    err.textContent = 'Error de red: ' + e.message;
    err.classList.remove('hidden');
  }
});

/* ---------- confirmacion de borrado ---------- */

let eliminandoId = null;

function abrirModalEliminar(usuario) {
  eliminandoId = usuario.id;
  $('modal-sub').textContent = `${usuario.nombre} (${usuario.rut_enmascarado})`;
  $('modal-error').classList.add('hidden');
  $('modal').classList.remove('hidden');
  setTimeout(() => $('modal-confirmar').focus(), 50);
}

function cerrarModalEliminar() {
  $('modal').classList.add('hidden');
  eliminandoId = null;
}

$('modal-cerrar').addEventListener('click', cerrarModalEliminar);
$('modal-cancelar').addEventListener('click', cerrarModalEliminar);
$('modal').addEventListener('click', (e) => { if (e.target.id === 'modal') cerrarModalEliminar(); });

$('form-eliminar').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  if (eliminandoId === null) return;
  const boton = $('modal-confirmar');
  boton.disabled = true;
  const textoOriginal = boton.textContent;
  boton.textContent = 'Eliminando…';
  try {
    const r = await fetch(`/api/usuarios/${eliminandoId}`, { method: 'DELETE' });
    if (sesionExpiro(r)) return;
    const d = await r.json().catch(() => ({}));
    if (!r.ok) {
      $('modal-error').textContent = d.detail || 'No se pudo eliminar.';
      $('modal-error').classList.remove('hidden');
      return;
    }
    cerrarModalEliminar();
    await Promise.all([cargarUsuarios(), cargarAuditoria()]);
  } catch (e) {
    $('modal-error').textContent = 'Error de red: ' + e.message;
    $('modal-error').classList.remove('hidden');
  } finally {
    boton.disabled = false;
    boton.textContent = textoOriginal;
  }
});

cargarUsuarios();
cargarAuditoria();
cargarVisitas();
