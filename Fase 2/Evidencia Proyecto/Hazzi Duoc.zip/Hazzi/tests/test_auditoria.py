"""tests de auditoria.py: se registra lo que hay que registrar y nunca
se filtra el rut completo."""
from __future__ import annotations

from app import auditoria

from ._aislar_motor import motor_temporal_para

USUARIO = {"nombre": "Ana Soto", "roles": ["admin"], "rut_enmascarado": "11XXXXXX-1"}
USUARIO_DOBLE_ROL = {"nombre": "Beto Gestor", "roles": ["admin", "admin_usuarios"], "rut_enmascarado": "22XXXXXX-2"}


def test_registrar_y_listar():
    with motor_temporal_para(auditoria):
        auditoria.registrar(USUARIO, "guardar_ajustes", {"cambios": {"magnitud_minima": 4.0}})
        acciones = auditoria.listar()
        assert len(acciones) == 1
        assert acciones[0]["accion"] == "guardar_ajustes"
        assert acciones[0]["nombre"] == "Ana Soto"
        assert acciones[0]["detalle"]["cambios"]["magnitud_minima"] == 4.0


def test_nunca_guarda_el_rut_completo():
    with motor_temporal_para(auditoria):
        auditoria.registrar(USUARIO, "login")
        acciones = auditoria.listar()
        assert acciones[0]["rut_enmascarado"] == "11XXXXXX-1"
        assert "X" in acciones[0]["rut_enmascarado"]


def test_mas_reciente_primero():
    with motor_temporal_para(auditoria):
        auditoria.registrar(USUARIO, "primera_accion")
        auditoria.registrar(USUARIO, "segunda_accion")
        acciones = auditoria.listar()
        assert acciones[0]["accion"] == "segunda_accion"
        assert acciones[1]["accion"] == "primera_accion"


def test_detalle_opcional():
    with motor_temporal_para(auditoria):
        auditoria.registrar(USUARIO, "logout")
        acciones = auditoria.listar()
        assert acciones[0]["detalle"] is None


def test_respeta_el_limite():
    with motor_temporal_para(auditoria):
        for i in range(5):
            auditoria.registrar(USUARIO, f"accion_{i}")
        assert len(auditoria.listar(limite=3)) == 3


def test_guarda_los_varios_roles_de_una_cuenta():
    """una cuenta con dos roles a la vez queda trazada con los dos, no
    solo uno -- justo lo que antonella pidio poder auditar."""
    with motor_temporal_para(auditoria):
        auditoria.registrar(USUARIO_DOBLE_ROL, "login")
        acciones = auditoria.listar()
        assert sorted(acciones[0]["roles"]) == ["admin", "admin_usuarios"]
