"""conaf. incendios forestales. arcgis featureserver publico."""
from __future__ import annotations

from .. import area as area_mod
from ..fetcher import json_de
from ..normalize import Event, num, ms_to_str

URL = (
    "https://services5.arcgis.com/A1ELWse9bRAi2JiV/ArcGIS/rest/services/"
    "incendios_base/FeatureServer/0/query"
    "?where=1=1&outFields=nombre,estado,sup_total,f_inicio,lat,lon,comuna,region"
    "&returnGeometry=false&outSR=4326&f=json"
)

_SEVERIDAD = {
    "En Combate": "roja",
    "Controlado": "amarilla",
    "Extinguido": "info",
}

_ESTADO = {  # estado legible y si sigue activa
    "En Combate": ("Activo (en combate)", True),
    "Controlado": ("Controlado", True),
    "Extinguido": ("Finalizado", False),
}


def urls_requeridas() -> list[str]:
    """urls que necesita esta fuente. se piden todas juntas con las demas."""
    return [URL]


def fetch_events(prefetched: dict[str, str] | None = None) -> list[Event]:
    data = json_de(URL, prefetched)
    eventos: list[Event] = []
    for feat in data.get("features", []):
        a = feat.get("attributes", {})
        estado = (a.get("estado") or "").strip()
        sup = a.get("sup_total")
        titulo = a.get("nombre") or "Incendio forestal"
        estado_txt, activa = _ESTADO.get(estado, (estado or "Desconocido", True))
        detalle = f"{sup} hectareas quemadas" if sup else "Superficie quemada no informada"
        eventos.append(
            Event(
                source="CONAF",
                tipo="incendio",
                titulo=titulo,
                severidad=_SEVERIDAD.get(estado, "info"),
                region=a.get("region"),
                comuna=a.get("comuna"),
                lat=num(a.get("lat")),
                lon=num(a.get("lon")),
                fecha=ms_to_str(a.get("f_inicio")),
                estado=estado_txt,
                activa=activa,
                detalle=detalle,
                # el fuego real segun las hectareas que informa conaf mas el
                # margen operativo por humo y cortes de camino. ver area.py
                area=area_mod.por_incendio(num(sup), activa),
            )
        )
    return eventos
