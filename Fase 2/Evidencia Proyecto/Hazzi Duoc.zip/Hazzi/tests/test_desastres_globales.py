"""la historia "Mundo" del inicio depende de gdacs.org, una fuente
externa que main.py no controla. estos tests no pegan a la red: fijan un
xml de muestra con la misma forma que gdacs realmente devuelve (ver la
muestra real guardada durante el desarrollo) y verifican que el parser
filtra lo que debe y que obtener() no revienta si la fuente falla, la
condicion que mas importa para una historia que es solo informativa."""
from __future__ import annotations

import app.desastres_globales as dg

_RSS_MUESTRA = """<?xml version="1.0" encoding="utf-8"?>
<rss version="2.0" xmlns:gdacs="http://www.gdacs.org">
  <channel>
    <item>
      <title>Green flood alert in Thailand</title>
      <link>https://www.gdacs.org/report.aspx?eventtype=FL&amp;eventid=1</link>
      <pubDate>Wed, 30 Sep 2026 12:20:31 GMT</pubDate>
      <guid isPermaLink="false">FL1</guid>
      <gdacs:eventtype>FL</gdacs:eventtype>
      <gdacs:alertlevel>Green</gdacs:alertlevel>
      <gdacs:country>Thailand</gdacs:country>
    </item>
    <item>
      <title>Orange earthquake in Taiwan</title>
      <link>https://www.gdacs.org/report.aspx?eventtype=EQ&amp;eventid=2</link>
      <pubDate>Wed, 30 Sep 2026 05:00:00 GMT</pubDate>
      <guid isPermaLink="false">EQ2</guid>
      <gdacs:eventtype>EQ</gdacs:eventtype>
      <gdacs:alertlevel>Orange</gdacs:alertlevel>
      <gdacs:country>Taiwan</gdacs:country>
    </item>
    <item>
      <title>Red tropical cyclone in Mexico</title>
      <link>https://www.gdacs.org/report.aspx?eventtype=TC&amp;eventid=3</link>
      <pubDate>Mon, 21 Sep 2026 06:39:52 GMT</pubDate>
      <guid isPermaLink="false">TC3</guid>
      <gdacs:eventtype>TC</gdacs:eventtype>
      <gdacs:alertlevel>Red</gdacs:alertlevel>
      <gdacs:country>Mexico</gdacs:country>
    </item>
    <item>
      <title>Orange drought in several countries</title>
      <link>https://www.gdacs.org/report.aspx?eventtype=DR&amp;eventid=4</link>
      <pubDate>Wed, 11 Feb 2026 09:57:31 GMT</pubDate>
      <guid isPermaLink="false">DR4</guid>
      <gdacs:eventtype>DR</gdacs:eventtype>
      <gdacs:alertlevel>Orange</gdacs:alertlevel>
      <gdacs:country>Several</gdacs:country>
    </item>
  </channel>
</rss>
"""


def _reset_cache():
    dg._CACHE["data"] = None
    dg._CACHE["ts"] = 0.0


def test_parsear_descarta_verdes_y_tipos_sin_cubrir():
    eventos = dg._parsear(_RSS_MUESTRA)
    # el flood verde (sin novedad) y la sequia naranja (condicion en
    # curso, no evento puntual) quedan afuera. solo el sismo y el
    # ciclon, los dos con alerta real, sobreviven
    assert [e["id"] for e in eventos] == ["EQ2", "TC3"]


def test_parsear_normaliza_tipo_y_severidad():
    eventos = dg._parsear(_RSS_MUESTRA)
    sismo = next(e for e in eventos if e["id"] == "EQ2")
    assert sismo["tipo"] == "sismo"
    assert sismo["severidad"] == "naranja"
    assert sismo["pais"] == "Taiwan"
    ciclon = next(e for e in eventos if e["id"] == "TC3")
    assert ciclon["tipo"] == "ciclon"
    assert ciclon["severidad"] == "roja"


def test_parsear_saca_el_prefijo_de_alerta_del_titulo():
    # "Orange earthquake in Taiwan" -> "earthquake in Taiwan". el nivel
    # de alerta ya se pinta aparte como el tag de color, y dejarlo
    # adentro del titulo le arruina la traduccion automatica despues
    eventos = dg._parsear(_RSS_MUESTRA)
    sismo = next(e for e in eventos if e["id"] == "EQ2")
    assert sismo["titulo"] == "earthquake in Taiwan"
    ciclon = next(e for e in eventos if e["id"] == "TC3")
    assert ciclon["titulo"] == "tropical cyclone in Mexico"


def test_traducir_lote_ignora_textos_vacios_y_pide_solo_una_vez_por_unico(monkeypatch):
    pedidos = []

    def _fake_fetch_many(urls):
        pedidos.append(urls)
        return {u: '{"responseData":{"translatedText":"traducido"}}' for u in urls}

    monkeypatch.setattr(dg, "fetch_many", _fake_fetch_many)
    resultado = dg._traducir_lote(["Mexico", "Mexico", "", "Taiwan"])
    assert resultado == {"Mexico": "traducido", "Taiwan": "traducido"}
    assert len(pedidos[0]) == 2  # "Mexico" no se pide dos veces


def test_traducir_lote_descarta_el_aviso_de_cuota_agotada(monkeypatch):
    # mymemory no devuelve un error http cuando se acaba la cuota gratis
    # del dia, devuelve 200 con el aviso metido en el mismo campo del
    # texto traducido. eso no debe colarse como si fuera una traduccion real
    def _fake_fetch_many(urls):
        return {u: '{"responseData":{"translatedText":"MYMEMORY WARNING: YOU USED ALL AVAILABLE FREE TRANSLATIONS"}}' for u in urls}

    monkeypatch.setattr(dg, "fetch_many", _fake_fetch_many)
    assert dg._traducir_lote(["Taiwan"]) == {}


def test_traducir_lote_no_revienta_si_fetch_many_falla(monkeypatch):
    def _fake_fetch_many(urls):
        raise RuntimeError("sin red")

    monkeypatch.setattr(dg, "fetch_many", _fake_fetch_many)
    assert dg._traducir_lote(["Taiwan"]) == {}


def test_traducir_eventos_aplica_traduccion_a_titulo_y_pais(monkeypatch):
    eventos = [{"titulo": "earthquake in Taiwan", "pais": "Taiwan"}]

    def _fake_traducir_lote(textos):
        return {"earthquake in Taiwan": "terremoto en Taiwán", "Taiwan": "Taiwán"}

    monkeypatch.setattr(dg, "_traducir_lote", _fake_traducir_lote)
    dg._traducir_eventos(eventos)
    assert eventos[0]["titulo"] == "terremoto en Taiwán"
    assert eventos[0]["pais"] == "Taiwán"


def test_traducir_eventos_deja_en_ingles_lo_que_no_se_pudo_traducir(monkeypatch):
    eventos = [{"titulo": "earthquake in Taiwan", "pais": "Taiwan"}]
    monkeypatch.setattr(dg, "_traducir_lote", lambda textos: {})
    dg._traducir_eventos(eventos)
    assert eventos[0]["titulo"] == "earthquake in Taiwan"
    assert eventos[0]["pais"] == "Taiwan"


def test_obtener_cachea_y_no_vuelve_a_pedir(monkeypatch):
    _reset_cache()
    llamadas = []

    def _fake_fetch(url):
        llamadas.append(url)
        return _RSS_MUESTRA

    monkeypatch.setattr(dg, "fetch_text", _fake_fetch)
    # sin esto la traduccion pegaria de verdad a mymemory.translated.net
    # en cada test. la traduccion en si ya tiene sus propios tests arriba
    monkeypatch.setattr(dg, "fetch_many", lambda urls: {})
    primero = dg.obtener()
    segundo = dg.obtener()
    assert len(llamadas) == 1
    assert primero == segundo
    assert len(primero["eventos"]) == 2


def test_obtener_no_revienta_si_gdacs_falla(monkeypatch):
    _reset_cache()

    def _fake_fetch_falla(url):
        raise RuntimeError("gdacs.org no contesta")

    monkeypatch.setattr(dg, "fetch_text", _fake_fetch_falla)
    resultado = dg.obtener()
    assert resultado["eventos"] == []
    assert "gdacs.org no contesta" in resultado["error"]
