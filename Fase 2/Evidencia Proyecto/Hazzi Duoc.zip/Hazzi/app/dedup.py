"""evita contar dos veces el mismo evento real cuando dos fuentes lo
reportan por separado. tipo un sismo grande que sale en usgs y en csn a la
vez. o una alerta que dmc y senapred anuncian las dos."""
from __future__ import annotations

from datetime import datetime

from .stores import haversine

_FMT = "%d-%m-%Y %H:%M hrs"
_MAX_KM = 70.0   # que tan cerca tienen que estar dos sismos para contar como el mismo
_MAX_MIN = 3.0   # y que tan juntos en el tiempo
_PRIORIDAD = {"CSN": 0, "USGS": 1}  # si empatan gana el numero mas bajo. csn


def _fecha(e: dict) -> datetime | None:
    try:
        return datetime.strptime((e.get("fecha") or "").strip(), _FMT)
    except (ValueError, AttributeError):
        return None


def _mismo_sismo(a: dict, b: dict) -> bool:
    if None in (a.get("lat"), a.get("lon"), b.get("lat"), b.get("lon")):
        return False
    if haversine(a["lat"], a["lon"], b["lat"], b["lon"]) > _MAX_KM:
        return False
    fa, fb = _fecha(a), _fecha(b)
    if fa is None or fb is None:
        return False  # sin fecha confiable. mejor no fusionar
    return abs((fa - fb).total_seconds()) <= _MAX_MIN * 60


def deduplicar_sismos(eventos: list[dict]) -> list[dict]:
    """devuelve la lista de eventos sin sismos duplicados entre fuentes."""
    sismos = [e for e in eventos if e.get("tipo") == "sismo"]
    otros = [e for e in eventos if e.get("tipo") != "sismo"]

    conservados: list[dict] = []
    for s in sorted(sismos, key=lambda e: _PRIORIDAD.get(e.get("source"), 9)):
        if any(_mismo_sismo(s, k) for k in conservados):
            continue
        conservados.append(s)

    return otros + conservados


_METEO_MAX_H = 5 * 24.0  # senapred no siempre declara el mismo dia que sale el aviso dmc


def _mismo_fenomeno(dmc_ev: dict, senapred_ev: dict) -> bool:
    if not dmc_ev.get("fenomeno") or dmc_ev.get("fenomeno") != senapred_ev.get("fenomeno"):
        return False
    regiones_dmc = {r.strip() for r in (dmc_ev.get("region") or "").split(",") if r.strip()}
    regiones_sen = {r.strip() for r in (senapred_ev.get("region") or "").split(",") if r.strip()}
    if not (regiones_dmc & regiones_sen):
        return False  # ninguna region en comun
    fd, fs = _fecha(dmc_ev), _fecha(senapred_ev)
    if fd is None or fs is None:
        return True  # sin fecha alcanza con que coincidan fenomeno y region
    return abs((fd - fs).total_seconds()) <= _METEO_MAX_H * 3600


def deduplicar_meteorologicos(eventos: list[dict]) -> list[dict]:
    """si dmc y senapred hablan del mismo fenomeno en la misma region y en
    fechas cercanas es la misma alerta contada dos veces. se descarta la de
    dmc y se queda la de senapred que es la fuente oficial. si dmc reporta
    algo que senapred nunca declaro como alerta se conserva igual."""
    dmc = [e for e in eventos if e.get("tipo") == "meteorologico"]
    resto = [e for e in eventos if e.get("tipo") != "meteorologico"]
    alertas_meteo = [e for e in resto if e.get("tipo") == "alerta" and e.get("fenomeno")]

    conservados_dmc = [d for d in dmc if not any(_mismo_fenomeno(d, s) for s in alertas_meteo)]
    return resto + conservados_dmc
