"""sesiones de administrador del lado del servidor.

antes la "sesion" vivia solo en el navegador (sessionStorage, ver
sesion.js) y la unica barrera real era una clave compartida en un
header. eso ya no alcanza para "gestion de usuarios": si hay usuarios
reales con roles reales, la sesion tiene que poder validarse en el
servidor sin confiar en lo que diga el cliente.

diseno minimo a proposito: un token aleatorio en una cookie httponly,
una fila en esta tabla que dice de quien es y hasta cuando vale. nada
de JWT ni librerias nuevas -- un token opaco que el servidor puede
revocar borrando la fila es mas simple y mas facil de auditar que un
token que hay que decodificar, y la dependencia nueva no se justifica
para este alcance.
"""
from __future__ import annotations

import secrets
from datetime import datetime, timedelta

from fastapi import Cookie, HTTPException
from sqlalchemy import Column, DateTime, Integer, MetaData, String, Table, delete, select

from . import usuarios
from .db import engine

COOKIE_NOMBRE = "hazzi_sesion"
DURACION = timedelta(hours=8)  # un turno. se vuelve a pedir login al dia siguiente

_metadata = MetaData()

sesiones_tabla = Table(
    "sesiones",
    _metadata,
    Column("token", String, primary_key=True),
    Column("usuario_id", Integer, nullable=False),
    Column("creado_en", DateTime, nullable=False),
    Column("expira_en", DateTime, nullable=False),
)


def init_schema() -> None:
    _metadata.create_all(engine)


def crear(usuario_id: int) -> str:
    """nueva sesion para este usuario. devuelve el token para la cookie."""
    token = secrets.token_urlsafe(32)
    ahora = datetime.now()
    init_schema()
    with engine.begin() as conn:
        conn.execute(
            sesiones_tabla.insert().values(
                token=token,
                usuario_id=usuario_id,
                creado_en=ahora,
                expira_en=ahora + DURACION,
            )
        )
    return token


def _purgar_expiradas(conn) -> None:
    conn.execute(delete(sesiones_tabla).where(sesiones_tabla.c.expira_en < datetime.now()))


def obtener_usuario(token: str | None) -> dict | None:
    """usuario activo de esta sesion, o none si el token no vale.

    no vale por tres motivos posibles: no hay token, no existe esa
    fila, o ya vencio. tambien se invalida si el usuario fue
    desactivado despues de haber iniciado sesion -- la sesion no debe
    sobrevivir a una baja.
    """
    if not token:
        return None
    init_schema()
    with engine.begin() as conn:
        _purgar_expiradas(conn)
        fila = conn.execute(
            select(sesiones_tabla).where(sesiones_tabla.c.token == token)
        ).first()
    if fila is None:
        return None

    with engine.begin() as conn:
        u = conn.execute(
            select(usuarios.usuarios_tabla).where(usuarios.usuarios_tabla.c.id == fila.usuario_id)
        ).first()
    if u is None or not u.activo:
        return None
    return {
        "id": u.id,
        "nombre": u.nombre,
        "roles": usuarios.roles_de(u.id),
        "rut_enmascarado": u.rut_enmascarado,
    }


def cerrar(token: str | None) -> None:
    if not token:
        return
    init_schema()
    with engine.begin() as conn:
        conn.execute(delete(sesiones_tabla).where(sesiones_tabla.c.token == token))


# --- dependencias de fastapi --------------------------------------------


def usuario_actual(hazzi_sesion: str | None = Cookie(default=None)) -> dict | None:
    """sesion actual o none. no rechaza -- los endpoints que necesitan
    rechazar usan requiere_rol de abajo. esta sirve para /api/auth/yo."""
    return obtener_usuario(hazzi_sesion)


def requiere_rol(*roles_permitidos: str):
    """fabrica una dependencia que exige sesion valida con AL MENOS UNO
    de estos roles. una cuenta puede tener varios roles a la vez (ver
    usuarios.py), asi que esto es una interseccion, no una igualdad.

    401 sin sesion valida, 403 con sesion valida pero ningun rol que
    corresponda. la diferencia importa para el frontend: 401 manda a
    loguearse de nuevo, 403 dice "no te corresponde", no "logueate".
    """

    def _dependencia(hazzi_sesion: str | None = Cookie(default=None)) -> dict:
        usuario = obtener_usuario(hazzi_sesion)
        if usuario is None:
            raise HTTPException(status_code=401, detail="Sesion invalida o vencida. Inicia sesion de nuevo.")
        if not set(usuario["roles"]) & set(roles_permitidos):
            raise HTTPException(status_code=403, detail="Tu rol no tiene acceso a esta accion.")
        return usuario

    return _dependencia
