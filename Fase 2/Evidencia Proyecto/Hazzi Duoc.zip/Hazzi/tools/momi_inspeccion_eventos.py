import json
import urllib.request

BASE = "http://127.0.0.1:8000"
eventos = json.load(urllib.request.urlopen(f"{BASE}/api/events"))["eventos"]

for e in eventos:
    e2 = {k: v for k, v in e.items() if k != "area"}
    area = e.get("area") or {}
    e2["area_forma"] = area.get("forma")
    e2["area_anillos_len"] = len(area.get("anillos") or [])
    print(json.dumps(e2, ensure_ascii=False, indent=2))
    print("---")
