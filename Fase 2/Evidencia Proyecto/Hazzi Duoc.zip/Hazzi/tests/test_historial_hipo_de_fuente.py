"""regresion del bug real de produccion, 29-09-2026: el mismo incendio
CONAF apareciendo a la vez en Eventos vigentes y en Historial.

no es el bug viejo de la clave con un campo mutable (ver
test_historial_identidad.py), ese sigue sano. este es distinto: la
fuente (conaf, feed arcgis) no trajo el incendio "VERTEDERO SAN
ANTONIO" durante un ciclo de recoleccion de 60 segundos, sin que el
incendio hubiera cambiado en nada. registrar_ciclo lo archivo de
inmediato por no aparecer ese ciclo. cuatro minutos despues conaf lo
volvio a traer con los mismos datos exactos (mismo f_inicio, misma
hectarea, mismo estado), pero para entonces ya no habia ningun
episodio vigente de esa base asi que se le abrio un slot "#2" nuevo.
resultado: la fila archivada original quedo huerfana en el historial
para siempre mientras la #2 seguia vigente en el mapa. el mismo
incendio en las dos pantallas.

datos reales capturados de hazard.db en el momento del bug.

corre con historial.engine parcheado a una sqlite temporal propia via
motor_temporal(), ver _aislar_historial.py para el porque: pisar
DATABASE_URL no alcanza en un proceso donde otro test ya importo el
engine real antes. ese fue justo el descuido que la primera version de
este archivo cometio y termino borrando el historial real de
antonella corriendo la suite -- no vuelvas a ese patron."""
from __future__ import annotations

from datetime import datetime, timedelta

from sqlalchemy import select, update

from ._aislar_historial import motor_temporal
from app import historial as h
from app.historial import clave_evento, historial_tabla, obtener_historial, registrar_ciclo

VERTEDERO_SAN_ANTONIO = {
    "source": "CONAF", "tipo": "incendio", "comuna": "San Antonio", "region": "Valparaíso",
    "titulo": "VERTEDERO SAN ANTONIO", "severidad": "info",
    "fecha": "28-09-2026 21:12 hrs", "estado": "Bajo observacion", "activa": True,
    "detalle": "Estado: Bajo observacion | 0.1 ha",
}


def _fila(clave):
    with h.engine.begin() as conn:
        return conn.execute(
            select(historial_tabla.c.vigente, historial_tabla.c.ultima_vez_vigente)
            .where(historial_tabla.c.clave == clave)
        ).first()


def _envejecer(clave, minutos):
    with h.engine.begin() as conn:
        conn.execute(
            update(historial_tabla).where(historial_tabla.c.clave == clave)
            .values(ultima_vez_vigente=datetime.now() - timedelta(minutes=minutos))
        )


def test_reaparece_enseguida_revive_la_misma_fila_no_abre_episodio_nuevo():
    """el caso real: la fuente lo pierde un ciclo y lo vuelve a traer
    identico minutos despues. tiene que quedar UNA sola fila vigente,
    no una archivada huerfana mas una '#2' nueva."""
    with motor_temporal():
        base = clave_evento(VERTEDERO_SAN_ANTONIO)

        registrar_ciclo([VERTEDERO_SAN_ANTONIO], [])
        assert _fila(base).vigente is True

        registrar_ciclo([], [])  # la fuente no lo trae este ciclo. hipo
        assert _fila(base).vigente is False, "sin el fix esto ya lo archiva, es esperado"

        registrar_ciclo([VERTEDERO_SAN_ANTONIO], [])  # vuelve, identico, al toque

        assert _fila(base).vigente is True, "tiene que revivir la fila original"
        assert _fila(f"{base}#2") is None, "no se debe abrir un episodio nuevo para esto"
        assert obtener_historial() == [], "no puede quedar en el historial si sigue vigente"


def test_si_paso_demasiado_tiempo_si_es_un_episodio_nuevo():
    """la gracia tiene un limite. si el episodio archivado ya es viejo
    de verdad, lo que vuelve con la misma base semanas despues es un
    incendio nuevo, no el mismo, y tiene que ganarse su propio slot en
    vez de resucitar algo que de verdad ya termino."""
    with motor_temporal():
        base = clave_evento(VERTEDERO_SAN_ANTONIO)

        registrar_ciclo([VERTEDERO_SAN_ANTONIO], [])
        registrar_ciclo([], [])  # se archiva
        _envejecer(base, minutos=60)  # ya paso la gracia de sobra

        registrar_ciclo([VERTEDERO_SAN_ANTONIO], [])

        assert _fila(base).vigente is False, "el episodio viejo se queda archivado tal cual"
        assert _fila(f"{base}#2").vigente is True, "el que vuelve tarde es un episodio propio"


def test_un_episodio_realmente_vigente_no_se_toca_por_este_fix():
    """garantia vieja intacta: mientras sigue vigente sin interrupcion
    nunca pasa por el camino de revivir, sigue siendo la misma fila de
    siempre."""
    with motor_temporal():
        base = clave_evento(VERTEDERO_SAN_ANTONIO)

        registrar_ciclo([VERTEDERO_SAN_ANTONIO], [])
        registrar_ciclo([VERTEDERO_SAN_ANTONIO], [])
        registrar_ciclo([VERTEDERO_SAN_ANTONIO], [])

        assert _fila(base).vigente is True
        assert _fila(f"{base}#2") is None
