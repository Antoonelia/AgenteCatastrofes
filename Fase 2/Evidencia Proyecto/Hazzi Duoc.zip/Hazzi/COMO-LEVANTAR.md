# Como levantar Hazzi

## 1. Preparar el entorno la primera vez

Esto se hace una sola vez en un computador nuevo. Necesitas Python 3.11 o superior instalado. Desde la carpeta Hazzi abre una terminal de PowerShell y crea el entorno virtual.

```powershell
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
```

Si ya tienes la carpeta .venv de este mismo computador puedes saltarte este paso.

## 2. Levantar el servidor

Desde la carpeta Hazzi.

```powershell
.venv\Scripts\python.exe -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Si quieres que corra en segundo plano y deje un registro.

```powershell
.venv\Scripts\python.exe -m uvicorn app.main:app --host 0.0.0.0 --port 8000 > server.log 2>&1
```

No uses la opcion reload. Rompe el ciclo de recoleccion que corre por detras.

### Crear el primer administrador

Ya no existe una clave compartida. Ahora hay cuentas reales con RUT y clave y dos roles. El rol admin maneja las instalaciones y los umbrales. El rol admin_usuarios maneja las altas y bajas de cuentas y la bitacora de auditoria.

La primera vez que se levanta el servidor si no hay ningun usuario creado el panel admin queda inaccesible y el servidor avisa por consola. Para crear el primero.

```powershell
.venv\Scripts\python.exe tools\crear_admin.py
```

Te pide el RUT el nombre la clave y el rol de forma interactiva. La clave debe tener al menos 8 caracteres. Tambien puedes pasar todo por argumento.

```powershell
.venv\Scripts\python.exe tools\crear_admin.py 11111111-1 "Ana Soto" "claveSegura123" admin_usuarios
```

Con ese usuario ya puedes entrar por la portada con la puerta Administrar. Si su rol es admin_usuarios puedes crear el resto de las cuentas desde /admin/usuarios sin volver a la consola.

La sesion vive en el servidor y dura 8 horas. Cerrar la pestana no cierra la sesion pero el acceso vence solo.

### Notificaciones por Teams

Es opcional. Para activarlas hay que definir dos variables de entorno que son NOTIFICADOR con el valor teams y TEAMS_WEBHOOK_URL con la direccion del webhook. En Windows se guardan de forma persistente asi.

```powershell
setx NOTIFICADOR "teams"
setx TEAMS_WEBHOOK_URL "<la URL del webhook>"
```

Despues abre una terminal nueva porque setx no actualiza las que ya estaban abiertas. El detalle completo esta en docs/wellbeing/04-notificaciones.md. Si no configuras nada Hazzi funciona igual pero sin enviar avisos.

## 3. Abrir Hazzi

Entra siempre por 127.0.0.1 y nunca por localhost. El nombre del usuario se guarda en el navegador y para el navegador son origenes distintos.

| Pagina | Direccion |
|---|---|
| Portada de entrada | http://127.0.0.1:8000/ |
| Dashboard | http://127.0.0.1:8000/inicio |
| Mapa | http://127.0.0.1:8000/mapa |
| Admin diagnostico | http://127.0.0.1:8000/admin |
| Admin umbrales | http://127.0.0.1:8000/admin/ajustes |
| Usuarios y auditoria | http://127.0.0.1:8000/admin/usuarios |

### Como se entra

La portada tiene dos puertas.

- Monitorear. Pide nombre y apellido y entra al dashboard. No necesita cuenta porque es de solo lectura. Igual queda registrada la visita.
- Administrar. Pide RUT y clave reales. Segun el rol de la cuenta entra a /admin o a /admin/usuarios.

La proteccion real es la sesion del servidor. Sin una sesion valida de un usuario activo con el rol correcto la API rechaza cualquier escritura. Responde 401 si no hay sesion y 403 si hay sesion pero el rol no corresponde. El RUT nunca se guarda completo. Se guarda como una huella irreversible y se muestra enmascarado.

## 4. Verificar que hay conexion a internet

Esto es lo primero que falla. Hazzi sale a internet con PowerShell usando las credenciales de tu sesion de Windows. Necesita estar conectado a la VPN de Walmart o al WiFi corporativo.

La forma rapida de saberlo es abrir /admin. Si las fuentes aparecen en rojo no es culpa del codigo sino de la conexion.

Tambien puedes probarlo desde la consola.

```powershell
.venv\Scripts\python.exe -c "from app.fetcher import fetch_text; print(len(fetch_text('https://api.gael.cloud/general/public/sismos')))"
```

## 5. Pruebas

```powershell
.venv\Scripts\python.exe -m tests
```

Deberian pasar todas. La API de admin no entra en esa suite porque necesita el servidor levantado y un usuario real. Se prueba aparte con el servidor corriendo.

```powershell
.venv\Scripts\python.exe tools\crear_admin.py 11111111-1 "Admin Demo" "claveSegura123" admin
.venv\Scripts\python.exe tools\probar_admin.py 11111111-1 claveSegura123
```

La logica de sesion se prueba con Node.

```powershell
node tools\probar_sesion.js
```

## Notas

- La base data/hazard.db es dato generado. Si no existe se crea sola al primer arranque. Ahi viven tambien los umbrales editados desde el admin y las cuentas de usuario. Borrarla deja todo en sus valores por defecto.
- El diagnostico de /admin arranca vacio a proposito. Despues de un minuto se llena solo.
- Si el puerto 8000 aparece ocupado puedes cerrar el servidor anterior con este comando.

```powershell
Get-CimInstance Win32_Process -Filter "Name='python.exe'" |
  Where-Object { $_.CommandLine -like '*uvicorn app.main*' } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
```

El filtro por linea de comando importa porque cierra solo uvicorn y no otros programas como Teams.
