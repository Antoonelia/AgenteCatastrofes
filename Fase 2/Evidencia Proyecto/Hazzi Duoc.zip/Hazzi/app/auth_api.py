"""login, logout y sesion actual. el reemplazo real de admin_key.

login valida rut + clave contra usuarios.py, abre una sesion en
sesiones.py y la entrega como cookie httponly -- el javascript de la
pagina no puede leerla ni robarla por xss, pero el navegador la manda
sola en cada request a admin_api.py y usuarios_api.py.

secure=true en la cookie exige https. hazzi hoy corre en http plano
dentro de la red de walmart (ver COMO-LEVANTAR.md), asi que secure se
prende solo si HAZZI_HTTPS=1 esta en el entorno. es la misma logica de
"falla cerrado, no abierto" que ya usaba admin_key: si no se declara
lo contrario, se asume el escenario menos permisivo para produccion
real, pero no se rompe el desarrollo local.
"""
from __future__ import annotations

import os
import re

from fastapi import APIRouter, Cookie, Depends, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from . import auditoria, sesiones, usuarios, visitas
from .limitador import Limitador

router = APIRouter(prefix="/api/auth")

_COOKIE_SEGURA = os.environ.get("HAZZI_HTTPS") == "1"

# fuerza bruta: se cuentan solo los intentos fallidos. por ip (10 en 10 min)
# y por rut (5 en 15 min). el limite por rut deja a un atacante bloquear a
# un admin desde la misma ip, pero la ventana corta evita que sea un
# bloqueo permanente. la visita de monitoreo es publica y escribe en la
# base, asi que lleva su propio techo por ip.
_LOGIN_POR_IP = Limitador(maximo=10, ventana_s=600)
_LOGIN_POR_RUT = Limitador(maximo=5, ventana_s=900)
_VISITA_POR_IP = Limitador(maximo=30, ventana_s=60)
_CONTROL = re.compile(r"[\x00-\x1f\x7f]")


def _ip(request: Request) -> str:
    return request.client.host if request.client else "desconocida"


def _rut_enmascarado_seguro(rut: str) -> str:
    """enmascara lo que haya escrito el usuario sin lanzar nunca: un rut
    mal escrito no debe tumbar el registro del intento fallido."""
    try:
        normalizado = usuarios.normalizar_rut(rut)
        if "-" in normalizado:
            return usuarios.enmascarar_rut(normalizado)
    except Exception:  # noqa: BLE001
        pass
    return "(rut invalido)"


class LoginEntrada(BaseModel):
    rut: str = Field(max_length=20)
    clave: str = Field(max_length=200)


class VisitaEntrada(BaseModel):
    nombre: str = Field(max_length=80)


def _usuario_publico(u: dict) -> dict:
    return {"nombre": u["nombre"], "roles": u["roles"], "rut_enmascarado": u["rut_enmascarado"]}


@router.post("/login")
def login(datos: LoginEntrada, request: Request):
    clave_ip = _ip(request)
    clave_rut = usuarios.normalizar_rut(datos.rut)
    espera = max(_LOGIN_POR_IP.espera(clave_ip), _LOGIN_POR_RUT.espera(clave_rut))
    if espera:
        # no se audita el rechazo: un atacante llenaria la bitacora. los
        # intentos fallidos que lo llevaron al bloqueo ya quedaron auditados
        raise HTTPException(
            status_code=429,
            detail=f"Demasiados intentos fallidos. Intenta de nuevo en {max(1, round(espera / 60))} min.",
            headers={"Retry-After": str(espera)},
        )

    usuario = usuarios.verificar_login(datos.rut, datos.clave)
    if usuario is None:
        _LOGIN_POR_IP.registrar(clave_ip)
        _LOGIN_POR_RUT.registrar(clave_rut)
        auditoria.registrar(
            {"nombre": "(sin identificar)", "rut_enmascarado": _rut_enmascarado_seguro(datos.rut), "roles": []},
            "login_fallido",
        )
        raise HTTPException(status_code=401, detail="RUT o clave incorrectos, o cuenta inactiva.")

    _LOGIN_POR_IP.limpiar(clave_ip)
    _LOGIN_POR_RUT.limpiar(clave_rut)
    token = sesiones.crear(usuario["id"])
    auditoria.registrar(usuario, "login")

    respuesta = JSONResponse({"ok": True, "usuario": _usuario_publico(usuario)})
    respuesta.set_cookie(
        key=sesiones.COOKIE_NOMBRE,
        value=token,
        httponly=True,
        samesite="lax",
        secure=_COOKIE_SEGURA,
        max_age=int(sesiones.DURACION.total_seconds()),
    )
    return respuesta


@router.post("/logout")
def logout(
    usuario: dict | None = Depends(sesiones.usuario_actual),
    hazzi_sesion: str | None = Cookie(default=None),
):
    if usuario:
        auditoria.registrar(usuario, "logout")
    # borrar solo la cookie no invalida el token: si alguien lo copio sigue
    # sirviendo hasta que venza. se elimina tambien la fila del servidor
    sesiones.cerrar(hazzi_sesion)
    respuesta = JSONResponse({"ok": True})
    respuesta.delete_cookie(sesiones.COOKIE_NOMBRE)
    return respuesta


@router.get("/yo")
def yo(usuario: dict | None = Depends(sesiones.usuario_actual)):
    """sesion de admin actual, o null. lo usa el frontend para pintar el
    rol correcto sin volver a pedir rut y clave en cada pagina."""
    return JSONResponse({"usuario": _usuario_publico(usuario) if usuario else None})


@router.post("/visita")
def registrar_visita(datos: VisitaEntrada, request: Request):
    """la puerta Monitorear llama esto al entrar. sin clave, sin sesion:
    es solo lectura y no hay nada que proteger, pero queda quien entro."""
    clave_ip = _ip(request)
    espera = _VISITA_POR_IP.espera(clave_ip)
    if espera:
        raise HTTPException(status_code=429, detail="Demasiadas solicitudes.", headers={"Retry-After": str(espera)})
    _VISITA_POR_IP.registrar(clave_ip)
    visitas.registrar(_CONTROL.sub("", datos.nombre))
    return JSONResponse({"ok": True})
