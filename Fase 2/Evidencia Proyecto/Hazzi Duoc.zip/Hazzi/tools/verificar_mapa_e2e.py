"""Verificacion E2E del mapa: que el area afectada se dibuje como geometria real.

El navegador headless no tiene salida a internet en la red corporativa, asi que
las librerias de CDN (Leaflet, Tailwind) se interceptan y se sirven desde
_basecheck/vendor. Sin esto la pagina falla con 'L is not defined', que parece
un bug de la app pero es del entorno de prueba.
"""
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from playwright.sync_api import sync_playwright

URL = "http://127.0.0.1:8000/mapa"
_VENDOR = Path(__file__).parent.parent / "_basecheck" / "vendor"


def _ruteo_cdn(route):
    """Sirve Leaflet desde disco; lo demas del CDN se corta (no hace falta)."""
    url = route.request.url
    for nombre, tipo in (("leaflet.js", "application/javascript"), ("leaflet.css", "text/css")):
        if nombre in url:
            return route.fulfill(status=200, content_type=tipo, body=(_VENDOR / nombre).read_bytes())
    if "tailwindcss" in url:
        return route.fulfill(status=200, content_type="application/javascript", body=b"")
    return route.abort()


def main() -> int:
    with sync_playwright() as p:
        nav = p.chromium.launch(channel="chrome")
        pagina = nav.new_page(viewport={"width": 1500, "height": 950})
        errores = []
        pagina.on("pageerror", lambda e: errores.append(str(e)))
        pagina.route("**://cdn.tailwindcss.com/**", _ruteo_cdn)
        pagina.route("**://unpkg.com/**", _ruteo_cdn)
        pagina.route("**://*.tile.openstreetmap.org/**", lambda r: r.abort())

        pagina.goto(URL, wait_until="domcontentloaded")
        pagina.wait_for_function("typeof TODOS_EVENTOS !== 'undefined' && TODOS_EVENTOS.length > 0", timeout=45000)
        pagina.wait_for_timeout(1500)

        estado = pagina.evaluate("""() => {
            const capas = capaRadios.getLayers();
            return {
                eventos: TODOS_EVENTOS.length,
                conArea: TODOS_EVENTOS.filter(e => e.area).length,
                capasArea: capas.length,
                poligonos: capas.filter(c => c instanceof L.Polygon && !(c instanceof L.Circle)).length,
                circulos: capas.filter(c => c instanceof L.Circle).length,
                tooltip: capas.length ? (capas[0].getTooltip() || {})._content : null,
                vertices: capas.length && capas[0].getLatLngs ? capas[0].getLatLngs().flat(2).length : 0,
                marcadores: capa.getLayers().length,
                filtros: [...document.querySelectorAll('#filtros-capas label')].map(l => l.textContent.trim()),
            };
        }""")

        print("=== estado del mapa ===")
        for k, v in estado.items():
            print(f"  {k}: {v}")
        print(f"\nerrores JS: {errores or 'ninguno'}")

        # Detalle: abrir el modal del evento y leer lo que muestra
        pagina.evaluate("abrirDetalle(TODOS_EVENTOS[0])")
        pagina.wait_for_timeout(700)
        modal = pagina.evaluate("""() => {
            const m = document.querySelector('.modal-body');
            if (!m) return null;
            return {
                tieneFilaArea: m.innerText.includes('Area afectada') || m.innerText.includes('\\u00c1rea afectada'),
                tituloTiendas: [...m.querySelectorAll('h4')].map(h => h.textContent.trim()),
                dice_dentro: m.innerText.includes('dentro'),
                extracto: m.innerText.slice(0, 400),
            };
        }""")
        print("\n=== modal de detalle ===")
        if modal:
            for k, v in modal.items():
                print(f"  {k}: {v}")

        Path("_basecheck").mkdir(exist_ok=True)
        pagina.screenshot(path="_basecheck/mapa_detalle.png")
        pagina.keyboard.press("Escape")   # el modal se cierra con Esc
        pagina.wait_for_timeout(400)
        pagina.evaluate("map.setView([-18.5, -70.3], 9)")
        pagina.wait_for_timeout(1200)
        pagina.screenshot(path="_basecheck/mapa_arica.png")

        ok = (
            estado["poligonos"] >= 1
            and estado["circulos"] == 0
            and not errores
            and modal
            and modal["tieneFilaArea"]
        )
        print("\n" + ("VEREDICTO: OK -- se dibuja geometria real, no un circulo" if ok else "VEREDICTO: revisar"))
        nav.close()
        return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
