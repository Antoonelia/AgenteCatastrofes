"""registro liviano de quien entro a monitorear.

la puerta "Monitorear" (ver portada.html) solo pide nombre y apellido,
sin clave ni rut -- es de solo lectura, no toca nada, y antonella
decidio explicitamente mantenerla rapida (ver sesion.js). pero igual
hay que poder responder "quien entro a mirar", asi que cada nombre que
pasa por ahi queda aca.

no interesa cuantas veces entro la misma persona, solo quien entro.
por eso es upsert por nombre y no un log que crece sin limite: si
"Juan Perez" entra 4 veces, hay una sola fila para Juan Perez con la
fecha de su visita mas reciente.
"""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import Column, DateTime, MetaData, String, Table, insert, select, update

from .db import engine

_metadata = MetaData()

visitas_tabla = Table(
    "visitas_monitoreo",
    _metadata,
    Column("nombre", String, primary_key=True),
    Column("primera_vez", DateTime, nullable=False),
    Column("ultima_vez", DateTime, nullable=False),
)


def init_schema() -> None:
    _metadata.create_all(engine)


def registrar(nombre: str) -> None:
    """guarda o actualiza la visita de esta persona. nombre vacio se ignora."""
    nombre = (nombre or "").strip()
    if not nombre:
        return
    ahora = datetime.now()
    init_schema()
    with engine.begin() as conn:
        existe = conn.execute(
            select(visitas_tabla.c.nombre).where(visitas_tabla.c.nombre == nombre)
        ).first()
        if existe:
            conn.execute(
                update(visitas_tabla).where(visitas_tabla.c.nombre == nombre).values(ultima_vez=ahora)
            )
        else:
            conn.execute(
                insert(visitas_tabla).values(nombre=nombre, primera_vez=ahora, ultima_vez=ahora)
            )


def ultimas(n: int = 30) -> list[dict]:
    """las n personas que entraron mas recientemente, sin duplicados."""
    init_schema()
    with engine.begin() as conn:
        filas = conn.execute(
            select(visitas_tabla).order_by(visitas_tabla.c.ultima_vez.desc()).limit(n)
        ).all()
    return [
        {
            "nombre": f.nombre,
            "primera_vez": f.primera_vez.isoformat(),
            "ultima_vez": f.ultima_vez.isoformat(),
        }
        for f in filas
    ]
