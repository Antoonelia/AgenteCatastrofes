/* historias.js. franja de "que hay de nuevo" en el inicio: una por
   fuente oficial (CSN, CONAF, SERNAGEOMIN, DMC, SENAPRED) mas una
   global de catastrofes fuera de chile (gdacs, ver /api/historias/global
   y app/desastres_globales.py).

   el anillo de cada circulo es el semaforo: gris plano si no hay nada
   sin ver, y en color neon segun la severidad mas grave sin ver si la
   hay. "sin ver" se guarda en localStorage por id de evento junto con
   la severidad con la que se vio, asi una alerta que escala de
   amarilla a roja vuelve a encenderse aunque ya la hubieras visto en
   amarilla, aunque tecnicamente "ya la viste".

   sismos no tiene dos historias para csn y usgs. dedup.py ya
   deduplica ambas fuentes en un solo evento (gana csn en empate), asi
   que dos historias mostrarian casi siempre el mismo dato dos veces,
   o un circulo de usgs perpetuamente vacio. csn lleva el logo
   principal, usgs va de respaldo en un badge chico en la esquina.

   depende de common.js: SEV_META, RANK_SEV, TIPO_META, glyphTipo,
   fechaVal, _tiempoRel, sucursalesDe (de inicio.js, opcional). inicio.js
   llama a pintarHistorias(_datos) dentro de su propio cargar(); esta
   franja no tiene timer propio, se refresca con el resto del inicio. */

const HIST_VISTOS_KEY = "hz_historias_vistas";
const HIST_ORDEN = ["sismo", "incendio", "volcan", "meteorologico", "alerta"];

const HIST_LOGO = {
  sismo: "/static/logos/fuentes/csn.jpg",
  incendio: "/static/logos/fuentes/conaf.png",
  volcan: "/static/logos/fuentes/sernageomin.png",
  meteorologico: "/static/logos/fuentes/dmc.png",
  alerta: "/static/logos/fuentes/senapred.png",
};
const HIST_BADGE = { sismo: "/static/logos/fuentes/usgs.png" };
const HIST_NOMBRE = {
  sismo: "CSN", incendio: "CONAF", volcan: "SERNAGEOMIN",
  meteorologico: "DMC", alerta: "SENAPRED", global: "Mundo",
};
const HIST_SEV_LABEL = { roja: "Crítica", naranja: "Alta", amarilla: "Moderada" };
// gdacs no cubre chile, asi que sus tipos no calzan 1 a 1 con TIPO_META
// (que no tiene "ciclon" ni "inundacion"). el pais que trae gdacs queda
// en ingles a proposito, traducirlo bien requeriria una base de datos
// de paises que no vale la pena para esto
const HIST_GLOBAL_TIPO_LABEL = {
  sismo: "Sismo", ciclon: "Ciclón tropical", inundacion: "Inundación", volcan: "Actividad volcánica", incendio: "Incendio",
};

let _histSlides = {};          // clave de historia -> lista de slides ya armada
let _histOrdenAbiertos = [];   // claves en el orden de la franja, para navegar entre historias
let _histVisor = { clave: null, indice: 0, timer: null };
let _histUltimoFoco = null;
let _histPausado = false;      // pausa manual (hover/mantener presionado), distinta de _histVisor.timer == null
let _histRestanteMs = 0;       // cuanto le quedaba al avance automatico al momento de pausar
let _histInicioMs = 0;         // marca de tiempo de cuando arranco el timer activo (nuevo o reanudado)

function _histEsc(t) {
  return String(t == null ? "" : t).replace(/[&<>"]/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
}

function _histVistos() {
  try { return JSON.parse(localStorage.getItem(HIST_VISTOS_KEY) || "{}"); }
  catch (e) { return {}; }
}
function _histMarcarVisto(id, severidad) {
  if (!id) return;
  const v = _histVistos();
  v[id] = severidad;
  localStorage.setItem(HIST_VISTOS_KEY, JSON.stringify(v));
}

// fecha de un evento global (gdacs), formato rfc-822 tipo "Wed, 30 Sep
// 2026 12:20:31 GMT". distinto del "dd-mm-yyyy hh:mm" que usa fechaVal
// para los eventos domesticos, por eso no se reusa esa funcion aca
function _histFechaGlobal(fecha) {
  const t = Date.parse(fecha || "");
  return Number.isNaN(t) ? -Infinity : t;
}

// slides de una fuente propia: una historia se cuenta en el orden en que
// paso, no de la mas grave a la menos grave -- si hay un evento del 7 de
// agosto y otro del 27, el del 7 va primero aunque sea menos critico. el
// recorte a 6 si hay mas eventos que eso si prioriza los mas recientes
// (son los mas relevantes hoy), pero una vez elegidos esos 6 se cuentan
// en orden cronologico. si no hay ninguno, un solo slide "en calma" --
// la historia no desaparece los dias tranquilos, solo se apaga
function _histSlidesPropios(tipo, eventos) {
  const propios = eventos
    .filter((e) => e.tipo === tipo)
    .sort((a, b) => fechaVal(b) - fechaVal(a))
    .slice(0, 6)
    .sort((a, b) => fechaVal(a) - fechaVal(b));
  if (!propios.length) return [{ calma: true, tipo }];
  return propios.map((e) => ({ ...e, calma: false }));
}

// slides de la historia global, a partir de lo que devuelve
// /api/historias/global. mismo criterio que las propias: cronologico
function _histSlidesGlobal(eventosGlobales) {
  if (!eventosGlobales.length) return [{ calma: true, tipo: "global" }];
  return eventosGlobales
    .slice()
    .sort((a, b) => _histFechaGlobal(b.fecha) - _histFechaGlobal(a.fecha))
    .slice(0, 6)
    .sort((a, b) => _histFechaGlobal(a.fecha) - _histFechaGlobal(b.fecha))
    .map((e) => ({ ...e, calma: false, global: true }));
}

// peor severidad sin ver entre los slides de una historia. null si no
// hay ninguno sin ver, lo que incluye siempre al slide "en calma"
function _histSeveridadSinVer(slides) {
  const vistos = _histVistos();
  const sinVer = slides.filter((s) => !s.calma && vistos[s.id] !== s.severidad);
  if (!sinVer.length) return null;
  return sinVer.sort((a, b) => RANK_SEV[a.severidad] - RANK_SEV[b.severidad])[0].severidad;
}

// se usa tanto en el circulo chico de la franja como en el encabezado
// del visor. si el logo real todavia no esta (ver histLogoFallback),
// cae al mismo glifo e icono que ya usan mapa y estadisticas
function _histLogoHtml(clave) {
  if (clave === "global") {
    // planeta tierra de verdad, no el mismo glifo de circulo con
    // meridianos que ya usa el selector de idioma del header -- antes
    // se confundian a simple vista. gira solo de vez en cuando (ver
    // @keyframes historia-globo-vuelta), no todo el tiempo, para que
    // no sea una distraccion constante en el rabillo del ojo
    return `<span class="historia-globo-gira" role="img" aria-label="Mundo">🌎</span>`;
  }
  const logo = HIST_LOGO[clave];
  return `<img src="${logo}" alt="" data-tipo="${clave}" onerror="histLogoFallback(this)" />`;
}

// fallback global, referenciado desde el atributo onerror de arriba.
// pide los logos reales por su nombre de archivo exacto: dejarlos en
// /static/logos/fuentes/{csn,usgs,conaf,sernageomin,dmc,senapred}.png,
// cuadrados y con fondo transparente. mientras no esten, esto evita el
// icono roto del navegador y muestra el mismo circulo de color que ya
// usan el mapa y las estadisticas para ese tipo
function histLogoFallback(img) {
  const tipo = img.dataset.tipo;
  const color = (TIPO_META[tipo] || {}).color || "#0036CF";
  const glyph = glyphTipo(tipo).replaceAll("#fff", color);
  const padre = img.parentElement;
  if (padre) padre.innerHTML = `<svg width="22" height="22" viewBox="0 0 24 24">${glyph}</svg>`;
}

function _histRenderBar() {
  const cont = document.getElementById("historias-bar");
  if (!cont) return;
  cont.innerHTML = _histOrdenAbiertos.map((clave) => {
    const slides = _histSlides[clave] || [{ calma: true, tipo: clave }];
    const sev = _histSeveridadSinVer(slides);
    const anillo = sev ? `historia-anillo historia-anillo--${sev}` : "historia-anillo";
    const badge = HIST_BADGE[clave]
      ? `<span class="historia-badge"><img src="${HIST_BADGE[clave]}" alt="" onerror="this.parentElement.remove()" /></span>`
      : "";
    const estado = sev ? (HIST_SEV_LABEL[sev] || "Novedad") : "Sin novedades nuevas";
    return `
      <button type="button" class="historia" data-clave="${clave}" aria-haspopup="dialog"
        aria-label="${_histEsc(HIST_NOMBRE[clave])}: ${_histEsc(estado)}">
        <span class="${anillo}">
          <span class="historia-logo">${_histLogoHtml(clave)}</span>
          ${badge}
        </span>
        <span class="historia-etq">${_histEsc(HIST_NOMBRE[clave])}</span>
      </button>`;
  }).join("");
  cont.querySelectorAll(".historia").forEach((btn) => {
    btn.addEventListener("click", () => _histAbrir(btn.dataset.clave, 0, btn));
  });
}

function _histPararTimer() {
  if (_histVisor.timer) { clearTimeout(_histVisor.timer); _histVisor.timer = null; }
  _histPausado = false;
  _histRestanteMs = 0;
}

function _histProgramarAvance() {
  _histPararTimer();
  // quien prefiere menos movimiento no recibe avance automatico. sigue
  // pudiendo navegar con las flechas o el teclado, solo que a su ritmo
  if (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const slide = (_histSlides[_histVisor.clave] || [])[_histVisor.indice];
  const duracionMs = slide && !slide.calma ? 5000 : 3500;
  document.documentElement.style.setProperty("--hv-dur", `${duracionMs}ms`);
  _histRestanteMs = duracionMs;
  _histInicioMs = Date.now();
  _histVisor.timer = setTimeout(_histSiguiente, duracionMs);
}

// pausa "de verdad": mantiene el tiempo que faltaba en vez de reiniciar,
// y congela la barra de progreso en su punto exacto (animation-play-state)
// en vez de esconderla. se dispara al mantener presionada/con el mouse
// encima la tarjeta, como en instagram, para poder leer con calma
function _histPausar() {
  if (_histPausado || !_histVisor.timer) return;
  _histPausado = true;
  clearTimeout(_histVisor.timer);
  _histVisor.timer = null;
  _histRestanteMs = Math.max(0, _histRestanteMs - (Date.now() - _histInicioMs));
  const barra = document.querySelector("#hv-progreso i.hv-activa b");
  if (barra) barra.style.animationPlayState = "paused";
}

function _histReanudar() {
  if (!_histPausado) return;
  _histPausado = false;
  const barra = document.querySelector("#hv-progreso i.hv-activa b");
  if (barra) barra.style.animationPlayState = "running";
  if (_histRestanteMs <= 0) { _histSiguiente(); return; }
  _histInicioMs = Date.now();
  _histVisor.timer = setTimeout(_histSiguiente, _histRestanteMs);
}

function _histPintarSlide() {
  const slides = _histSlides[_histVisor.clave] || [];
  if (!slides.length) { _histCerrar(); return; }
  // un refresco de fondo (cargar() corre cada 2 minutos) puede achicar
  // la lista de slides de la historia que esta abierta justo ahora, por
  // ejemplo una alerta que se resolvio. en vez de cerrar el visor de
  // golpe debajo del usuario, se acomoda al ultimo slide que si existe
  if (_histVisor.indice >= slides.length) _histVisor.indice = slides.length - 1;
  const slide = slides[_histVisor.indice];

  // se marca como visto cuando el slide se muestra de verdad, no al
  // abrir la historia entera. si cierras a mitad de camino, lo que no
  // llegaste a ver sigue sin ver la proxima vez
  if (!slide.calma) _histMarcarVisto(slide.id, slide.severidad);

  const prog = document.getElementById("hv-progreso");
  prog.innerHTML = slides.map((_, i) => {
    const cls = i < _histVisor.indice ? "hv-vista" : (i === _histVisor.indice ? "hv-activa" : "");
    return `<i class="${cls}"><b></b></i>`;
  }).join("");

  const nombre = HIST_NOMBRE[_histVisor.clave] || _histVisor.clave;
  document.getElementById("hv-logo").innerHTML = _histLogoHtml(_histVisor.clave);
  document.getElementById("hv-fuente-nombre").textContent = nombre;

  const cuerpo = document.getElementById("hv-cuerpo");
  const tiempo = document.getElementById("hv-tiempo");
  const link = document.getElementById("hv-link");

  if (slide.calma) {
    tiempo.textContent = "";
    cuerpo.innerHTML = `
      <div class="hv-tag" style="background:#16a34a">Sin novedades</div>
      <div class="hv-tipo">Todo tranquilo por ahora</div>
      <p class="hv-detalle">${_histEsc(nombre)} no reporta nada relevante en este momento.</p>`;
    link.classList.add("hidden");
  } else if (slide.global) {
    const ts = _histFechaGlobal(slide.fecha);
    tiempo.textContent = Number.isFinite(ts) ? _tiempoRel(ts) : "";
    const color = (SEV_META[slide.severidad] || SEV_META.info).color;
    // titulo y pais ya llegan traducidos al espanol desde el backend (ver
    // desastres_globales.py, _traducir_eventos). el tipo se arma aca
    // igual, es el mismo texto fijo para todas las historias globales de
    // ese tipo y no vale la pena pedirselo a un traductor
    const tipoLabel = HIST_GLOBAL_TIPO_LABEL[slide.tipo] || "Catástrofe";
    cuerpo.innerHTML = `
      <div class="hv-tag" style="background:${color}">${_histEsc(HIST_SEV_LABEL[slide.severidad] || slide.severidad)}</div>
      <div class="hv-tipo">${_histEsc(tipoLabel)} — ${_histEsc(slide.pais || "Ubicación no especificada")}</div>
      <p class="hv-detalle">${_histEsc(slide.titulo)}</p>`;
    // la url viene de un feed externo: solo se enlaza si es http(s), un
    // javascript: aqui ejecutaria codigo al hacer clic
    if (slide.url && /^https?:\/\//i.test(slide.url)) {
      link.href = slide.url;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.classList.remove("hidden");
    } else {
      link.classList.add("hidden");
    }
  } else {
    const ts = fechaVal(slide);
    tiempo.textContent = Number.isFinite(ts) ? _tiempoRel(ts) : "";
    const color = (SEV_META[slide.severidad] || SEV_META.info).color;
    const n = (typeof sucursalesDe === "function") ? sucursalesDe(slide.titulo) : 0;
    const notaSucursales = n > 0
      ? `<p class="hv-detalle" style="color:#ffd968">${n} sucursal${n === 1 ? "" : "es"} afectada${n === 1 ? "" : "s"}</p>`
      : "";
    cuerpo.innerHTML = `
      <div class="hv-tag" style="background:${color}">${_histEsc(HIST_SEV_LABEL[slide.severidad] || slide.severidad)}</div>
      <div class="hv-tipo">${_histEsc(slide.titulo)}</div>
      <p class="hv-detalle">${_histEsc(slide.region || slide.comuna || "Ubicación no especificada")}</p>
      ${notaSucursales}`;
    const claveUrl = `${slide.titulo || ""}|${slide.fecha || ""}`;
    // a diferencia de la global, esta es navegacion interna -- se
    // queda en la misma pestana, no abre una nueva
    link.href = `/mapa?alerta=${encodeURIComponent(claveUrl)}`;
    link.removeAttribute("target");
    link.removeAttribute("rel");
    link.classList.remove("hidden");
  }

  _histRenderBar(); // los anillos de atras se actualizan en caliente a medida que se ve
  _histProgramarAvance();
}

function _histAbrir(clave, indice, origen) {
  _histPararTimer();
  _histUltimoFoco = origen || document.activeElement;
  _histVisor.clave = clave;
  _histVisor.indice = indice;
  const visor = document.getElementById("historia-visor");
  visor.classList.remove("hidden");
  document.addEventListener("keydown", _histTeclado);
  _histPintarSlide();
  const cerrar = document.getElementById("hv-cerrar");
  if (cerrar) cerrar.focus();
}

function _histCerrar() {
  _histPararTimer();
  const visor = document.getElementById("historia-visor");
  if (visor) visor.classList.add("hidden");
  document.removeEventListener("keydown", _histTeclado);
  if (_histUltimoFoco && typeof _histUltimoFoco.focus === "function") _histUltimoFoco.focus();
}

function _histSiguiente() {
  const slides = _histSlides[_histVisor.clave] || [];
  if (_histVisor.indice < slides.length - 1) {
    _histVisor.indice++;
    _histPintarSlide();
    return;
  }
  // se acabaron los slides de esta historia. si hay una historia
  // siguiente en la franja, se sigue ahi mismo, como instagram
  const pos = _histOrdenAbiertos.indexOf(_histVisor.clave);
  const siguiente = _histOrdenAbiertos[pos + 1];
  if (siguiente) _histAbrir(siguiente, 0, _histUltimoFoco);
  else _histCerrar();
}

function _histAnterior() {
  if (_histVisor.indice > 0) {
    _histVisor.indice--;
    _histPintarSlide();
    return;
  }
  const pos = _histOrdenAbiertos.indexOf(_histVisor.clave);
  const anterior = _histOrdenAbiertos[pos - 1];
  if (anterior) {
    const slidesAnt = _histSlides[anterior] || [];
    _histAbrir(anterior, Math.max(0, slidesAnt.length - 1), _histUltimoFoco);
  }
  // si ya es la primera historia en su primer slide, no hay adonde ir
}

function _histTeclado(e) {
  if (e.key === "Escape") _histCerrar();
  else if (e.key === "ArrowRight") _histSiguiente();
  else if (e.key === "ArrowLeft") _histAnterior();
}

// entrada publica. inicio.js la llama dentro de su propio cargar(), con
// los mismos datos que ya trajo fetchEvents -- no hay que pedirlos de
// nuevo. lo unico que se consulta aparte es la historia global, que
// vive en su propio endpoint cacheado 10 minutos en el backend
async function pintarHistorias(datos) {
  const eventos = datos.eventos || [];
  const nuevo = {};
  HIST_ORDEN.forEach((tipo) => { nuevo[tipo] = _histSlidesPropios(tipo, eventos); });

  // la global no bloquea a las propias. gdacs cachea 10 minutos en el
  // backend, pero en frio (el primer pedido despues de vencer esa
  // cache) el fetch por powershell de un feed de 700kb puede tardar
  // varios segundos. esperar eso antes de mostrar nada dejaria la
  // franja entera en blanco, rompiendo la promesa de "esto se ve al
  // toque" que es justo el punto de esta franja. se mantiene lo ultimo
  // que se sabia de la global hasta que llegue lo nuevo, en vez de
  // vaciarla: si el visor esta abierto justo en "mundo" cuando esto
  // corre (cargar() se repite cada 2 minutos), vaciarla de golpe le
  // correria el piso al usuario a mitad de lectura
  nuevo.global = _histSlides.global || [{ calma: true, tipo: "global" }];
  _histSlides = nuevo;
  _histOrdenAbiertos = [...HIST_ORDEN, "global"];
  _histRenderBar();

  try {
    const r = await fetch("/api/historias/global");
    const g = await r.json();
    _histSlides = { ..._histSlides, global: _histSlidesGlobal(g.eventos || []) };
  } catch (e) {
    // sin cambios: se queda con lo ultimo que sabia en vez de borrarlo
  }
  _histRenderBar();
}

document.addEventListener("DOMContentLoaded", () => {
  const visor = document.getElementById("historia-visor");
  if (!visor) return; // esta pagina no tiene historias
  document.getElementById("hv-cerrar").addEventListener("click", _histCerrar);
  document.getElementById("hv-prev").addEventListener("click", _histAnterior);
  document.getElementById("hv-next").addEventListener("click", _histSiguiente);
  // "ver detalle" de la global abre una pestana nueva. sin esto el
  // avance automatico sigue corriendo en la pestana de atras mientras
  // el usuario lee la nota, y para cuando vuelve ya se comio dos o
  // tres historias mas sin que las haya mirado
  document.getElementById("hv-link").addEventListener("click", _histPararTimer);
  visor.addEventListener("click", (e) => { if (e.target === visor) _histCerrar(); });

  // pausar para leer con calma: mantener presionado (touch) o pasar el
  // mouse por encima de la tarjeta (desktop), igual que instagram. suelta
  // o saca el mouse y sigue donde iba, no desde cero
  const tarjeta = document.getElementById("hv-tarjeta");
  if (tarjeta) {
    tarjeta.addEventListener("pointerdown", _histPausar);
    tarjeta.addEventListener("pointerup", _histReanudar);
    tarjeta.addEventListener("pointercancel", _histReanudar);
    tarjeta.addEventListener("pointerenter", _histPausar);
    tarjeta.addEventListener("pointerleave", _histReanudar);
  }
});

// pestana oculta, misma idea que el link de arriba: nadie esta mirando,
// asi que nadie deberia estar "viendo" ni avanzando historias. al
// volver a la pestana se retoma desde donde quedo (no desde cero),
// reusando la misma pausa/reanuda de mantener presionado la tarjeta
document.addEventListener("visibilitychange", () => {
  const visor = document.getElementById("historia-visor");
  if (!visor || visor.classList.contains("hidden")) return;
  if (document.hidden) _histPausar();
  else _histReanudar();
});
