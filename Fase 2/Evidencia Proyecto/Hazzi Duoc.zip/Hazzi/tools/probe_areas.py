"""Sonda: que campos de 'tamano de area' ya nos regalan las otras fuentes."""
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from app.fetcher import fetch_json
from app.sources import conaf, sernageomin

print("=== SERNAGEOMIN (volcanes por peligro) ===")
d = fetch_json(sernageomin.URL)
print("geometryType:", d.get("geometryType"))
feats = d.get("features", [])
print("features:", len(feats))
if feats:
    for k, v in feats[0]["attributes"].items():
        print(f"   {k} = {str(v)[:60]}")

print()
print("=== CONAF (superficie de incendios) ===")
d = fetch_json(conaf.URL)
feats = d.get("features", [])
sup = [f["attributes"].get("sup_total") for f in feats]
con_sup = [s for s in sup if s]
print(f"features={len(feats)}  con sup_total={len(con_sup)}")
if con_sup:
    con_sup.sort()
    print(f"   min={con_sup[0]} ha   max={con_sup[-1]} ha")
    for f in feats[:5]:
        a = f["attributes"]
        print(f"   {str(a.get('nombre'))[:30]:<32} {a.get('estado'):<12} {a.get('sup_total')} ha")
