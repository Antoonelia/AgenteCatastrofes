/*
 * Verifica que la tabla de /admin/instalaciones MUESTRE lo que se guarda.
 *
 * Nace de un bug real (2026-09-17): se creaba una oficina, el API respondia
 * 200 y la fila quedaba correcta en SQL, pero la tabla dibujaba solo las
 * primeras 300 de 398 filas y las instalaciones propias caen AL FINAL de la
 * lista (el scraping de Lider va primero). Resultado: parecia que no se
 * guardaba nada. Los 31 checks de probar_instalaciones.py pasaban igual,
 * porque miran el API, no la pantalla.
 *
 * No usa navegador a proposito: los binarios de Playwright no bajan detras
 * del proxy corporativo, y para esto alcanza con ejecutar las funciones de
 * ordenamiento y recorte contra datos reales del API.
 *
 * Uso:  node tools\probar_instalaciones_tabla.js [http://127.0.0.1:8000]
 */
'use strict';

const fs = require('fs');
const path = require('path');

const BASE = process.argv[2] || 'http://127.0.0.1:8000';
const JS = path.join(__dirname, '..', 'app', 'static', 'admin-instalaciones.js');

let fallos = 0;
const ok = (m) => console.log('  OK   ' + m);
const mal = (m, d) => { fallos++; console.log('  FALLA ' + m + (d ? ' -> ' + d : '')); };

(async () => {
  const fuente = fs.readFileSync(JS, 'utf8');

  console.log('\n[1] El archivo parsea');
  try {
    new Function(fuente);
    ok('admin-instalaciones.js sin errores de sintaxis');
  } catch (e) {
    mal('SyntaxError', e.message);
    process.exit(1);
  }

  console.log('\n[2] Datos reales del API');
  const r = await fetch(BASE + '/api/admin/instalaciones');
  const d = await r.json();
  const LISTA = d.instalaciones;
  ok(`${LISTA.length} instalaciones, ${LISTA.filter((i) => i.origen === 'manual').length} manuales`);

  // Se extraen las dos funciones que deciden que se ve, sin montar un DOM:
  // el orden y el tope de filas son logica pura sobre el arreglo.
  const TOPE = Number((fuente.match(/const TOPE_FILAS = (\d+)/) || [])[1]);
  if (!TOPE) { mal('no se encontro TOPE_FILAS'); process.exit(1); }
  ok(`tope de filas dibujadas: ${TOPE}`);

  // El criterio de orden se replica aca en vez de recortarlo del archivo por
  // indices de texto (fragil: corta mal en cuanto se toca una llave). Si
  // alguien cambia el orden en la pagina y se olvida de esto, el check [3]
  // falla y avisa -- que es justo lo que se quiere.
  const ordenar = (lista) => lista.sort((a, b) => {
    if (!!a.editada !== !!b.editada) return a.editada ? -1 : 1;
    if (a.editada && b.editada) return (b.actualizado || 0) - (a.actualizado || 0);
    return (a.nombre || '').localeCompare(b.nombre || '', 'es');
  });

  if (!/if \(!!a\.editada !== !!b\.editada\)/.test(fuente)) {
    mal('la pagina ya no ordena poniendo lo editado primero');
  } else {
    ok('la pagina ordena lo editado primero');
  }

  console.log('\n[3] Lo editado se ve sin tener que buscarlo');
  const ordenada = ordenar(LISTA.slice());
  const visibles = ordenada.slice(0, TOPE);
  const editadas = LISTA.filter((i) => i.editada);

  if (!editadas.length) {
    ok('(no hay instalaciones editadas para probar; se omite)');
  } else {
    const ocultas = editadas.filter((e) => !visibles.some((v) => v.iid === e.iid));
    if (ocultas.length === 0) {
      ok(`las ${editadas.length} instalaciones editadas entran en las primeras ${TOPE} filas`);
    } else {
      mal(`${ocultas.length} instalacion(es) editadas quedan fuera de la tabla`,
          ocultas.map((o) => o.nombre).join(', '));
    }
    const primera = ordenada[0];
    if (primera && primera.editada) ok(`la primera fila es una editada ("${primera.nombre}")`);
    else mal('la primera fila deberia ser una instalacion editada', primera && primera.nombre);
  }

  console.log('\n[4] El recorte se avisa, no se esconde');
  if (/mostrando \$\{TOPE_FILAS\}/.test(fuente)) ok('el contador avisa cuando hay mas filas que el tope');
  else mal('el recorte de filas no se le avisa al usuario');

  console.log('\n[5] Tras guardar, la instalacion queda a la vista');
  if (/\$\('buscar'\)\.value = nombre/.test(fuente)) ok('al guardar se filtra por el nombre recien usado');
  else mal('tras guardar no se hace nada para dejar visible la instalacion');

  console.log('\n[6] Leaflet mide bien su contenedor');
  const invalidaciones = (fuente.match(/invalidateSize\(\)/g) || []).length;
  if (invalidaciones >= 2) ok(`invalidateSize() presente (${invalidaciones} llamadas)`);
  else mal('falta invalidateSize(): el pin puede dibujarse corrido', String(invalidaciones));

  // --- [7] Lo que rompia el mapa: instalaciones sin formato comercial ------
  // metaFormato() devolvia {pin:null} para una oficina, y el mapa pintaba
  // <img src="null"> -- un pin roto. Se prueba la funcion REAL de common.js,
  // no una copia, con los stubs minimos de navegador que necesita al cargar.
  console.log('\n[7] Toda instalacion tiene pin y nombre (mapa)');
  const comun = fs.readFileSync(
    path.join(__dirname, '..', 'app', 'static', 'common.js'), 'utf8');
  const salida = {};
  const stub = {
    localStorage: { getItem: () => null, setItem: () => {} },
    document: { documentElement: { classList: { add() {}, remove() {} } },
                addEventListener() {}, getElementById: () => null,
                querySelectorAll: () => [], body: { classList: { add() {}, remove() {} } } },
    window: {}, navigator: { userAgent: '' },
  };
  new Function('g', 'localStorage', 'document', 'window', 'navigator',
    comun + ';g.metaFormato=metaFormato;g.nombreInstalacion=nombreInstalacion;g.TIPO_INST_META=TIPO_INST_META;'
  )(salida, stub.localStorage, stub.document, stub.window, stub.navigator);

  const casos = [
    ['oficina', { nombre: 'CE 537', tipo: 'oficina', formato: '' }],
    ['cd', { nombre: 'CD Lo Aguirre', tipo: 'cd', formato: '' }],
    ['planta', { nombre: 'Planta', tipo: 'planta', formato: '' }],
    ['sucursal manual', { nombre: 'Mi Lider', tipo: 'sucursal', formato: 'Lider' }],
    ['tienda de Lider', { formato: 'Express de Lider' }],
  ];
  for (const [etiqueta, caso] of casos) {
    const m = salida.metaFormato(caso);
    const titulo = salida.nombreInstalacion(caso);
    if (m.pin && m.pin !== 'null' && titulo && titulo !== 'undefined') {
      ok(`${etiqueta}: pin valido y titulo "${titulo}"`);
    } else {
      mal(`${etiqueta}: pin=${m.pin} titulo=${titulo}`);
    }
  }

  // Las instalaciones reales del API tambien tienen que resolver bien.
  const sinPin = LISTA.filter((i) => {
    const m = salida.metaFormato(i);
    return !m.pin || m.pin === 'null';
  });
  if (sinPin.length === 0) ok(`las ${LISTA.length} instalaciones del API resuelven su pin`);
  else mal(`${sinPin.length} instalacion(es) sin pin`, sinPin.slice(0, 3).map((i) => i.nombre).join(', '));

  console.log(fallos ? `\n=> ${fallos} FALLA(S)` : '\n=> TODO OK');
  process.exit(fallos ? 1 : 0);
})();
