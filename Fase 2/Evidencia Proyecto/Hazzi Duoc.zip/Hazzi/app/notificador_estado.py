"""cuando notificar. una alerta nueva o una modificacion real. nunca un recordatorio.

va separado de notificador.py que se ocupa de como mandar el mensaje
por cada canal porque esto resuelve una pregunta distinta que es si
corresponde mandarlo. mismo criterio de cohesion que ya separa
dotacion.py de main.py.

version anterior: una ventana de tiempo fija de 3 horas evitaba
reenviar la misma alerta pero pasada esa ventana la volvia a mandar
igual si seguia activa. un recordatorio periodico. antonella lo dejo
claro. no hace falta porque el canal de teams ya deja todo registrado.
lo unico que amerita un aviso nuevo es un evento que nunca se aviso o
uno que si se aviso pero cambio de verdad: escalo o bajo de severidad
se sumaron o sacaron comunas o cambio la cantidad de tiendas en
riesgo. si nada de eso cambio no se vuelve a mandar sin importar
cuanto tiempo haya pasado.

por eso ya no se guarda si se aviso o no con un bool que vence. se
guarda el ultimo estado avisado por evento y cada ciclo se compara
contra eso. queda persistido en sql en la misma base que ajustes y
dotacion para que sobreviva a un reinicio del server. si no cada
restart haria que todo evento activo se vea como nunca avisado y
vuelva a salir por teams. fue un bug real reportado en vivo.

ampliacion del 25-09-2026 a pedido explicito de antonella. cualquier
cambio importante es mas ancho que severidad comunas con tienda o
tiendas. se agrego tema y fenomeno que es el tipo de evento que
declara la fuente. por ejemplo "por lluvia" paso a "por inundaciones".
mismo hecho naturaleza distinta. y area_hash que es la huella de la
cobertura geografica que declara la fuente y detecta un cambio de area
aunque ninguna tienda entre o salga del calculo. a diferencia de
comunas que solo mira comunas con tienda. los campos nuevos son best
effort. si vienen vacios porque es una fila vieja de antes de este
cambio simplemente no se comparan esa vez y no se marcan como cambio
falso solo por haber estado en blanco.

excepcion para sismos. mismo pedido mismo dia. un sismo ya paso no es
un fenomeno que evoluciona como una alerta de inundacion. que el
catalogo lo revise despues con un epicentro mas fino o una magnitud
distinta en 0.2 no amerita un segundo aviso. para tipo sismo alcanza
con saber que ya se aviso sin comparar ningun campo.

se probo y se saco un aviso de resolucion cuando un evento dejaba de
estar vigente. antonella lo pidio y despues viendolo andar decidio que
no lo quiere porque agrega ruido sin aportar. 25-09-2026."""
from __future__ import annotations

import time

from sqlalchemy import Column, Float, Integer, MetaData, String, Table, delete, insert, inspect, select, text

from .db import engine as _engine

_metadata = MetaData()
_tabla_estado = Table(
    "notificaciones_estado",
    _metadata,
    Column("evento_id", String, primary_key=True),
    Column("severidad", String, nullable=False),
    Column("comunas", String, nullable=False),  # ordenadas unidas con una barra vertical
    Column("tiendas", Integer, nullable=False),
    Column("enviado_ts", Float, nullable=False),
    Column("tema", String, nullable=False, default=""),
    Column("fenomeno", String, nullable=False, default=""),
    Column("area_hash", String, nullable=False, default=""),
)

# columnas agregadas despues de la version original de la tabla.
# create_all no altera una tabla que ya existe como un hazard.db de
# instalaciones viejas asi que se migran a mano en _init_schema.
# idempotente. se salta si ya estan.
#
# nota: hubo tambien una columna titulo para el aviso de resuelto que
# se saco. se dejo de escribir y leer pero si tu hazard.db ya la tiene
# de una instalacion anterior no pasa nada. sqlite no se queja de una
# columna de mas que nadie toca
_COLUMNAS_NUEVAS = {"tema": "TEXT NOT NULL DEFAULT ''",
                    "fenomeno": "TEXT NOT NULL DEFAULT ''", "area_hash": "TEXT NOT NULL DEFAULT ''"}

# orden de severidad para saber si un cambio es una escalada o una
# baja. solo cambia el verbo del mensaje entre escalo y bajo no si se
# notifica
_ORDEN_SEVERIDAD = ["verde", "amarilla", "naranja", "roja"]


def _init_schema() -> None:
    """crea la tabla si no existe y migra columnas nuevas si faltan."""
    _metadata.create_all(_engine)
    existentes = {c["name"] for c in inspect(_engine).get_columns("notificaciones_estado")}
    faltantes = {n: t for n, t in _COLUMNAS_NUEVAS.items() if n not in existentes}
    if not faltantes:
        return
    with _engine.begin() as conn:
        for nombre, tipo_sql in faltantes.items():
            conn.execute(text("ALTER TABLE notificaciones_estado ADD COLUMN " + nombre + " " + tipo_sql))


def _describir_cambio(
    anterior: dict, severidad: str, comunas: list[str], tiendas: int,
    tema: str = "", fenomeno: str = "", area_hash: str = "",
) -> str:
    """texto humano de que cambio desde el ultimo aviso. vacio si nada
    cambio. el llamador decide que hacer con eso. esta funcion solo
    describe."""
    partes = []
    if anterior["severidad"] != severidad:
        try:
            escalo = _ORDEN_SEVERIDAD.index(severidad) > _ORDEN_SEVERIDAD.index(anterior["severidad"])
        except ValueError:
            escalo = True  # severidad no reconocida. mejor avisar que no
        verbo = "Escalo" if escalo else "Bajo"
        partes.append(f"{verbo} de {anterior['severidad']} a {severidad}")

    comunas_antes = set(anterior["comunas"].split("|")) if anterior["comunas"] else set()
    comunas_ahora = set(comunas)
    agregadas = sorted(comunas_ahora - comunas_antes)
    quitadas = sorted(comunas_antes - comunas_ahora)
    if agregadas:
        partes.append(f"Se agregaron comunas: {', '.join(agregadas)}")
    if quitadas:
        partes.append(f"Ya no incluye: {', '.join(quitadas)}")

    if anterior["tiendas"] != tiendas:
        # se usa la flecha ascii y no una flecha unicode porque la consola
        # de windows en cp1252 no la puede imprimir y revienta el ciclo de
        # notificacion completo. fue un bug real encontrado corriendo la
        # suite de tests en windows
        partes.append(f"Tiendas en riesgo: {anterior['tiendas']} -> {tiendas}")

    # los campos nuevos solo cuentan si el valor anterior no esta vacio.
    # una fila vieja de antes de este cambio no tiene tema fenomeno ni
    # area_hash guardados y comparar contra vacio marcaria un falso cambio
    # de tipo la primera vez que se toca cada fila vieja
    if anterior.get("tema") and tema and anterior["tema"] != tema:
        partes.append(f"Cambio de tipo: {anterior['tema']} -> {tema}")
    elif anterior.get("fenomeno") and fenomeno and anterior["fenomeno"] != fenomeno:
        partes.append(f"Cambio de fenomeno: {anterior['fenomeno']} -> {fenomeno}")
    if anterior.get("area_hash") and area_hash and anterior["area_hash"] != area_hash:
        partes.append("Cambio en el area de cobertura declarada")

    return "; ".join(partes)


def clasificar(
    evento_id: str, severidad: str, comunas: list[str], tiendas: int,
    tema: str = "", fenomeno: str = "", area_hash: str = "",
) -> tuple[str, str]:
    """decide si el evento es nueva modificada o sin_cambios contra lo
    ultimo que se aviso de el. la descripcion solo viene poblada en
    modificada. el titulo no se compara porque la fuente lo reescribe
    seguido sin que cambie nada real. ver historial.py."""
    _init_schema()
    with _engine.begin() as conn:
        fila = conn.execute(
            select(_tabla_estado).where(_tabla_estado.c.evento_id == evento_id)
        ).mappings().first()
    if fila is None:
        return "nueva", ""
    descripcion = _describir_cambio(dict(fila), severidad, comunas, tiendas, tema, fenomeno, area_hash)
    return ("modificada", descripcion) if descripcion else ("sin_cambios", "")


def guardar(
    evento_id: str, severidad: str, comunas: list[str], tiendas: int,
    tema: str = "", fenomeno: str = "", area_hash: str = "",
    ahora: float | None = None,
) -> None:
    ahora = time.time() if ahora is None else ahora
    _init_schema()
    with _engine.begin() as conn:
        conn.execute(delete(_tabla_estado).where(_tabla_estado.c.evento_id == evento_id))
        conn.execute(
            insert(_tabla_estado).values(
                evento_id=evento_id,
                severidad=severidad,
                comunas="|".join(sorted(comunas)),
                tiendas=tiendas,
                enviado_ts=ahora,
                tema=tema,
                fenomeno=fenomeno,
                area_hash=area_hash,
            )
        )


def existe(evento_id: str) -> bool:
    """si ya hay una fila guardada para esta clave.

    se usa para la excepcion de sismos. un sismo se avisa una vez para
    siempre sin importar cuanto se revise despues su magnitud o area
    asi que no necesita comparar campos solo saber si ya se aviso
    alguna vez."""
    _init_schema()
    with _engine.begin() as conn:
        fila = conn.execute(
            select(_tabla_estado.c.evento_id).where(_tabla_estado.c.evento_id == evento_id)
        ).first()
    return fila is not None


def reiniciar() -> None:
    """limpia el estado de eventos notificados. solo para tests."""
    _init_schema()
    with _engine.begin() as conn:
        conn.execute(delete(_tabla_estado))
