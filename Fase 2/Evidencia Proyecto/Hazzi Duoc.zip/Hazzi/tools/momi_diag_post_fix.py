import sys
sys.path.insert(0, ".")
from app.sources import senapred
from app.retention import filtrar_eventos

eventos = [e.to_dict() for e in senapred.fetch_events()]
print("total senapred post-cancelacion:", len(eventos))
no_verdes = [e for e in eventos if e.get("severidad") != "verde"]
print("no verdes:", len(no_verdes))
for e in no_verdes:
    print(e.get("comuna"), "|", e.get("severidad"), "|", e.get("tema"), "|", e.get("fecha"), "|", e.get("vigencia_hasta"))

print("---")
vigentes = filtrar_eventos(eventos)
print("vigentes tras retention:", len(vigentes))
for e in vigentes:
    print(e.get("comuna"), "|", e.get("severidad"), "|", e.get("tema"))
