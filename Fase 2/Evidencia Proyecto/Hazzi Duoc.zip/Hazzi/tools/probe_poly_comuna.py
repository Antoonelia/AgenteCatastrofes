"""Sonda: Nominatim puede dar el contorno REAL de la comuna (polygon_geojson)."""
import json
import sys
import urllib.parse

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from app.fetcher import fetch_json

for lugar in ("Providencia", "Sierra Gorda", "Natales"):
    q = urllib.parse.quote(f"{lugar}, Chile")
    url = (
        f"https://nominatim.openstreetmap.org/search?q={q}&format=json&limit=1"
        "&countrycodes=cl&polygon_geojson=1&polygon_threshold=0.01"
    )
    d = fetch_json(url)
    if not d:
        print(f"{lugar:<15} sin resultado")
        continue
    g = d[0].get("geojson") or {}
    coords = g.get("coordinates") or []
    def contar(c):
        return sum(contar(x) for x in c) if c and isinstance(c[0], list) else 1
    print(f"{lugar:<15} geojson={g.get('type'):<15} puntos={contar(coords):<6} KB={len(json.dumps(g)) / 1024:.1f}")
