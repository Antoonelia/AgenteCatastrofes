"""Uso puntual: reemplaza los pines de oficina, cd (centro de distribucion) y
planta por las ilustraciones que Antonella dejo en Downloads, a pedido suyo
del 29-09-2026.

Antes estas tres instalaciones no tenian pin fotografico: se dibujaba un
icono svg generico en azul walmart al vuelo (ver pinInstalacionSVG en
common.js). Con estos tres assets nuevos pasan a usar arte real, igual que
ya hacen los 4 formatos de tienda, para poder distinguirlas de un vistazo en
el mapa (torre = oficina, bodega con camion = cd, fabrica con chimeneas =
planta).

Mismo criterio de recorte que el resto de los pines: bbox por canal alpha
mas 14px de margen parejo, para que el drop-shadow del pin no quede pegado
al borde. Las tres imagenes ya traen transparencia real.
"""
from __future__ import annotations

from pathlib import Path

from PIL import Image

DOWNLOADS = Path.home() / "Downloads"
LOGOS = Path(__file__).resolve().parent.parent / "app" / "static" / "logos"
PADDING = 14

TRABAJOS = [
    (DOWNLOADS / "oficina.png", LOGOS / "pin-oficina.png"),
    (DOWNLOADS / "cd.png", LOGOS / "pin-cd.png"),
    (DOWNLOADS / "planta.png", LOGOS / "pin-planta.png"),
]


def main() -> None:
    for origen, destino in TRABAJOS:
        if not origen.exists():
            print(f"[saltado] no existe {origen}")
            continue
        im = Image.open(origen).convert("RGBA")
        bbox = im.getbbox()
        if bbox:
            x0, y0, x1, y1 = bbox
            x0 = max(0, x0 - PADDING)
            y0 = max(0, y0 - PADDING)
            x1 = min(im.width, x1 + PADDING)
            y1 = min(im.height, y1 + PADDING)
            im = im.crop((x0, y0, x1, y1))
        im.save(destino)
        print(f"{destino.name}: {im.size} -> {destino}")
        print(f"  pinRatio nuevo: {im.width} / {im.height} = {im.width / im.height:.4f}")


if __name__ == "__main__":
    main()
