# De dolores a historias de usuario — Sprint 1 Wellbeing

Guía de redacción + candidatas pre-escritas.

> **Las historias de acá abajo son HIPÓTESIS, no backlog.** Las escribí desde lo que
> Hazzi puede hacer, sin haber hablado con nadie. Sirven para dos cosas:
> (a) que no arranques de una hoja en blanco, (b) tener algo concreto que ellos
> puedan romper. Si después de la reunión sobreviven las 5 intactas, sospechá:
> significa que no escuchaste, escribiste.

---

## 1 · El formato

```
Como <rol específico, no "usuario">
quiero <capacidad>
para <resultado que le importa a ESE rol>
```

**Criterios de aceptación** en Gherkin, que es lo que se puede probar:

```
Dado   <contexto>
Cuando <acción>
Entonces <resultado observable>
```

### Las cinco reglas que la gente rompe

1. **El rol es una persona, no "el usuario".** "Analista de Wellbeing" ≠ "Jefe de tienda"
   ≠ "Gerente de RR.HH.". Roles distintos = historias distintas, siempre.
2. **El "para" nunca es "para tener un dashboard".** Es el porqué humano.
   Si no lo sabés escribir, no entendiste el dolor.
3. **Si la historia no cabe en un sprint, es un épico.** Partila.
4. **Criterio de aceptación sin número no es criterio.** "Rápido" no se puede testear;
   "en menos de 10 segundos" sí.
5. **Toda historia que toque datos de personas lleva su nota de privacidad.** Sin excepción.

---

## 2 · Definición de Listo / Terminado

**Lista (para entrar al sprint):**
- [ ] Rol identificado con nombre real de cargo
- [ ] Validada por al menos un stakeholder que hace ese trabajo
- [ ] Criterios de aceptación medibles
- [ ] Origen del dato identificado (¿existe? ¿quién es el dueño?)
- [ ] Revisión de privacidad hecha si toca datos personales

**Terminada:**
- [ ] Criterios de aceptación pasan
- [ ] WCAG 2.2 AA (contraste, teclado, `aria-live`, `prefers-reduced-motion`)
- [ ] Tests automatizados en `tests/`
- [ ] Funciona sin datos reales de asociados (datos de prueba o anonimizados)
- [ ] Demostrada al stakeholder que la pidió

---

## 3 · Candidatas (hipótesis a validar)

Estimación en **tallas**, no en horas: S = 1-2 días, M = 3-5 días, L = más de un sprint.

---

### HU-01 — Dimensionar el impacto humano de un evento
**Talla: S** · *Apoyada casi entera en lo que ya existe*

> **Como** analista de Wellbeing
> **quiero** ver cuántos asociados están potencialmente afectados por un evento activo,
> agrupados por tienda y comuna,
> **para** dimensionar la magnitud de la respuesta sin llamar tienda por tienda.

**Criterios de aceptación**
```
Dado   un evento activo con tiendas en riesgo
Cuando abro la vista de impacto social
Entonces veo el total de asociados potencialmente afectados
Y      el desglose por tienda, comuna y nivel de riesgo
Y      cada cifra indica si es estimada o dato confirmado

Dado   que la dotación es un valor estimado por formato de tienda
Cuando se muestra cualquier cifra de personas
Entonces aparece la marca visible "estimado" junto al número
```

**Base existente:** `dotacion.py` + `stores.stores_at_risk()`. Es casi cablear
dos cosas que ya funcionan.
**Riesgo:** la dotación es estimada, no real. Si alguien la toma como verdad
operativa, decide mal. Por eso el criterio de marcarla es obligatorio, no cosmético.
**Privacidad:** ninguna — son agregados, no personas.

---

### HU-02 — Alerta temprana al equipo Wellbeing
**Talla: S**

> **Como** analista de Wellbeing
> **quiero** recibir un aviso apenas se detecta un evento que afecta tiendas con
> asociados,
> **para** activar el protocolo antes de que me llamen preguntando.

**Criterios de aceptación**
```
Dado   un evento nuevo que pone tiendas en riesgo
Cuando el sistema lo detecta
Entonces genera una alerta en menos de 2 minutos desde la detección
Y      la alerta indica evento, comunas, tiendas y asociados estimados

Dado   un evento ya notificado
Cuando el ciclo de actualización vuelve a verlo
Entonces NO se vuelve a notificar
```

**Base existente:** el bucle de refresco (`_bucle_actualizacion`) ya corre cada 60s.
**Pregunta abierta para la reunión:** ¿el aviso va por correo, Teams, o basta con
la pantalla? No lo asumas.
**Privacidad:** ninguna — agregados.

---

### HU-03 — Confirmación de bienestar ("estoy bien")
**Talla: L — esto es un épico, no una historia**

> **Como** jefe de tienda
> **quiero** registrar rápido el estado de mi equipo después de un evento
> **para** que Wellbeing sepa quién está bien y quién necesita ayuda, sin
> cadenas de WhatsApp.

**Por qué es un épico:** necesita identidad de personas, canal de contacto,
registro de respuestas y seguimiento. Son cuatro historias como mínimo.

**Bloqueantes reales — resolvelos ANTES de comprometerte:**
- Requiere nómina real por tienda → no existe hoy en Hazzi
- Requiere integración con HRIS → permisos, no código
- Datos personales bajo Ley 21.719 (vigencia plena diciembre 2026)
- ¿Quién es el dueño del dato? ¿Legal aprobó?

> **Recomendación:** si esto sale como prioridad #1 en la reunión, **no lo prometas
> para el Sprint 1**. Proponé una versión reducida: el jefe de tienda reporta un
> **conteo agregado** ("28 de 31 confirmados, 3 sin contacto") sin nombres. Resuelve
> el 70% del dolor de Wellbeing, es construible ya, y no toca dato personal.
> Eso es una historia S, y se llama HU-03a.

---

### HU-04 — Reporte post-evento automático
**Talla: M**

> **Como** gerente de Wellbeing
> **quiero** un reporte del evento con impacto en personas y acciones tomadas
> **para** rendir cuentas sin dedicarle un día a armar un PowerPoint.

**Criterios de aceptación**
```
Dado   un evento cerrado en el historial
Cuando pido el reporte social
Entonces obtengo un documento con cronología, tiendas y comunas afectadas,
       asociados estimados y resumen ejecutivo generado por IA
Y      el documento es exportable a PDF
Y      ninguna persona aparece identificada nominalmente
```

**Base existente:** `historial.py` + `ai_client.resumen_ejecutivo()` + la exportación
a PDF que ya existe en `tiendas.html` y `estadisticas.js`.
**Privacidad:** exigir agregados. Un PDF que circula por correo con nombres de
damnificados es un incidente esperando ocurrir.

---

### HU-05 — Registro de acciones de apoyo
**Talla: M**

> **Como** analista de Wellbeing
> **quiero** registrar qué apoyos se activaron por evento y tienda
> **para** tener trazabilidad y saber qué se hizo la próxima vez.

**Criterios de aceptación**
```
Dado   un evento activo
Cuando registro una acción de apoyo
Entonces queda guardada con tipo, tienda, responsable, fecha y estado
Y      aparece en el reporte post-evento

Dado   un evento con acciones registradas
Cuando lo consulto en el historial
Entonces veo la cronología completa de la respuesta
```

**Privacidad:** registrar la **acción**, no al beneficiario. "3 anticipos gestionados
en tienda X" en vez de "Juan Pérez recibió anticipo".

---

## 4 · Mapa de esfuerzo vs. valor

| Historia | Talla | Base existente | Bloqueo de datos | Candidata a Sprint 1 |
|---|---|---|---|---|
| HU-01 Impacto humano | S | Alta | No | **Sí** |
| HU-02 Alerta temprana | S | Alta | No | **Sí** |
| HU-03a Confirmación agregada | S | Media | No | Sí |
| HU-04 Reporte post-evento | M | Alta | No | Tal vez |
| HU-05 Registro de apoyos | M | Baja | No | Tal vez |
| HU-03 Confirmación nominal | L | Baja | **Sí** | No |

> **Patrón, por si no saltó a la vista:** todo lo verde evita datos personales.
> Lo único bloqueado es justo lo que los necesita. Eso no es casualidad — es
> la restricción que define la arquitectura de este sprint.

---

## 5 · Antes de comprometer el sprint

- [ ] Cada historia fue **dicha por alguien** en la reunión, no inventada por vos
- [ ] El rol de cada historia corresponde a una persona real que conocés
- [ ] Ninguna historia del sprint depende de un dato que no existe
- [ ] Sprint 1 = máximo 3 historias. Prometer menos y entregar es mejor que lo contrario
- [ ] Lo que quedó afuera está **escrito** y ellos lo saben
