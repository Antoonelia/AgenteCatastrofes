$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot
$env:ADMIN_KEY = "qwerty"

$pythonExe = Join-Path $PSScriptRoot ".venv\Scripts\python.exe"
$stdout = Join-Path $PSScriptRoot "server.log"
$stderr = Join-Path $PSScriptRoot "server.err.log"

if (Test-Path $stdout) { Remove-Item $stdout -Force }
if (Test-Path $stderr) { Remove-Item $stderr -Force }

$proc = Start-Process -FilePath $pythonExe `
    -ArgumentList "-m", "uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000" `
    -WorkingDirectory $PSScriptRoot `
    -RedirectStandardOutput $stdout `
    -RedirectStandardError $stderr `
    -WindowStyle Hidden `
    -PassThru

$proc.Id | Out-File -FilePath (Join-Path $PSScriptRoot "server.pid") -Encoding ascii
Write-Output "STARTED_PID=$($proc.Id)"
