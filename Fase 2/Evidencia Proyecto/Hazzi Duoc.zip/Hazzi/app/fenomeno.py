"""detecta el fenomeno meteorologico a partir de texto libre.

lo usan dmc.py para normalizar su propio campo de fenomeno. senapred.py
para adivinarlo por palabras clave ya que no trae uno confiable. y
mapa-fx.js que solo lee el valor ya normalizado sin duplicar reglas en js."""
from __future__ import annotations

import re

_PATRONES: list[tuple[str, "re.Pattern[str]"]] = [
    ("viento", re.compile(r"viento|ventisca|vendaval", re.I)),
    ("nieve", re.compile(r"nieve|nevada|nival", re.I)),
    ("calor", re.compile(r"calor|temperatura|caluroso|t[eé]rmic", re.I)),
    ("lluvia", re.compile(r"lluvia|precipita|chubasco|marejada|temporal", re.I)),
]  # el orden importa. el primero que matchea gana

ETIQUETAS = {
    "viento": "Viento",
    "nieve": "Nieve",
    "calor": "Altas temperaturas",
    "lluvia": "Lluvia",
}


def detectar(*textos: str | None) -> str | None:
    """busca el primer fenomeno reconocible en los textos dados. devuelve la
    clave normalizada o none si ninguno matchea."""
    junto = " ".join(t for t in textos if t)
    for nombre, patron in _PATRONES:
        if patron.search(junto):
            return nombre
    return None


def ya_mencionado(texto: str | None, clave: str) -> bool:
    """true si el texto ya nombra el fenomeno. sirve para no agregarlo de
    nuevo como sufijo cuando ya esta dicho."""
    for nombre, patron in _PATRONES:
        if nombre == clave:
            return bool(patron.search(texto or ""))
    return False
