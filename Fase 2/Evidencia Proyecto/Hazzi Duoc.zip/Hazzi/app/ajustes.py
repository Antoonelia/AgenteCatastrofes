"""ajustes editables del motor. fuente unica de verdad persistida en sql.

por que existe este modulo: la magnitud minima de sismo estaba escrita
dos veces en csn.py y usgs.py con el mismo valor 3.5. dos copias del
mismo numero son una bomba de tiempo. se cambia una se olvida la otra y
el sistema queda filtrando distinto segun la fuente. aca vive una sola
vez y las dos fuentes la leen de aca.

diseno: cada ajuste se declara una vez en _definiciones con su tipo
rango valido y texto de ayuda. de esa declaracion salen solos la
validacion el valor por defecto y la descripcion que muestra la
pantalla de admin. agregar un ajuste nuevo es agregar una linea a esa
tabla nada mas.

precedencia de menor a mayor: default del codigo. variable de entorno.
valor guardado en sql.

la variable de entorno sirve para fijar un valor en un despliegue
concreto sin tocar el codigo. lo guardado en sql es lo que edita el
usuario desde el admin y manda por sobre todo lo demas.

los valores se cachean en memoria porque se leen en cada ciclo de
recoleccion. invalidar_cache se llama solo al guardar."""
from __future__ import annotations

import os
from typing import Any, Callable, NamedTuple

from sqlalchemy import Column, MetaData, String, Table, select

from .db import engine as _engine


class Ajuste(NamedTuple):
    """declaracion de un ajuste. de aca sale la validacion y la ui."""

    clave: str
    etiqueta: str
    ayuda: str
    tipo: Callable[[str], Any]
    defecto: Any
    minimo: float
    maximo: float
    unidad: str = ""

    def convertir(self, valor: Any) -> Any:
        """convierte y valida contra el rango declarado. lanza valueerror."""
        try:
            v = self.tipo(valor)
        except (TypeError, ValueError) as exc:
            esperado = "un numero entero" if self.tipo is int else "un numero"
            raise ValueError(f"{self.etiqueta}: se esperaba {esperado}.") from exc
        if not self.minimo <= v <= self.maximo:
            raise ValueError(
                f"{self.etiqueta}: debe estar entre {self.minimo} y {self.maximo}"
                f"{' ' + self.unidad if self.unidad else ''}."
            )
        return v


# umbrales que el usuario puede tocar desde el admin. los radios de
# area.py no estan aca a proposito porque son una tabla por tramos con
# justificacion tecnica escrita y se muestran en pantalla como solo
# lectura
_DEFINICIONES: tuple[Ajuste, ...] = (
    Ajuste(
        clave="magnitud_minima",
        etiqueta="Magnitud minima de sismo",
        ayuda=(
            "Sismos por debajo de esta magnitud se descartan al recolectar. "
            "Bajarla trae mucho ruido: en Chile tiembla sobre M3 casi todos "
            "los dias. Afecta a las dos fuentes sismicas (CSN y USGS)."
        ),
        tipo=float,
        defecto=3.5,
        minimo=1.0,
        maximo=9.0,
        unidad="M",
    ),
    Ajuste(
        clave="ventana_dias",
        etiqueta="Ventana de consulta sismica",
        ayuda=(
            "Cuantos dias hacia atras se le piden a CSN y USGS en cada "
            "consulta. Mas dias es mas contexto historico, pero respuestas "
            "mas pesadas y ciclos mas lentos."
        ),
        tipo=int,
        defecto=7,
        minimo=1,
        maximo=30,
        unidad="dias",
    ),
    Ajuste(
        clave="retencion_dias",
        etiqueta="Retencion general en historial",
        ayuda=(
            "Dias que se conserva un evento DESPUES de que dejo de estar "
            "vigente (es decir, desde que las fuentes dejaron de reportarlo). "
            "No se cuenta desde la fecha de termino del evento, porque pocas "
            "fuentes la informan de manera confiable."
        ),
        tipo=int,
        defecto=15,
        minimo=1,
        maximo=365,
        unidad="dias",
    ),
    Ajuste(
        clave="retencion_dias_sismo",
        etiqueta="Retencion de sismos en historial",
        ayuda=(
            "Igual que la anterior, pero solo para sismos. Suele ser mas "
            "corta porque son muchos y pierden interes operativo rapido."
        ),
        tipo=int,
        defecto=7,
        minimo=1,
        maximo=365,
        unidad="dias",
    ),
)

_POR_CLAVE = {d.clave: d for d in _DEFINICIONES}

_metadata = MetaData()

ajustes_tabla = Table(
    "ajustes",
    _metadata,
    Column("clave", String, primary_key=True),
    Column("valor", String, nullable=False),
)

_cache: dict[str, Any] | None = None


def init_schema() -> None:
    """crea la tabla si no existe. idempotente."""
    _metadata.create_all(_engine)


def definiciones() -> tuple[Ajuste, ...]:
    """declaracion de todos los ajustes. la usa el admin para armar el formulario."""
    return _DEFINICIONES


def invalidar_cache() -> None:
    global _cache
    _cache = None


def _desde_entorno(d: Ajuste) -> Any:
    """lee ajuste_clave del entorno. si es invalido se ignora en silencio.

    un valor mal escrito en el entorno no debe voltear el arranque del
    sistema. es preferible seguir con el default que quedarse sin monitor."""
    crudo = os.environ.get(f"AJUSTE_{d.clave.upper()}")
    if crudo is None:
        return d.defecto
    try:
        return d.convertir(crudo)
    except ValueError:
        return d.defecto


def _cargar() -> dict[str, Any]:
    global _cache
    if _cache is not None:
        return _cache

    valores = {d.clave: _desde_entorno(d) for d in _DEFINICIONES}
    try:
        init_schema()
        with _engine.begin() as conn:
            for fila in conn.execute(select(ajustes_tabla)).mappings():
                d = _POR_CLAVE.get(fila["clave"])
                if d is None:
                    continue  # ajuste viejo que ya no existe. se ignora
                try:
                    valores[d.clave] = d.convertir(fila["valor"])
                except ValueError:
                    pass  # guardado corrupto. se queda el default
    except Exception:  # noqa: BLE001
        pass  # sin base todavia. se opera con defaults y no se cae el sistema

    _cache = valores
    return _cache


def obtener(clave: str) -> Any:
    """valor vigente de un ajuste."""
    return _cargar()[clave]


def todos() -> dict[str, Any]:
    """todos los valores vigentes."""
    return dict(_cargar())


def guardar(cambios: dict[str, Any]) -> dict[str, Any]:
    """valida y persiste. todo o nada. si uno falla no se guarda ninguno.

    devuelve los valores vigentes despues de guardar."""
    desconocidas = set(cambios) - set(_POR_CLAVE)
    if desconocidas:
        raise ValueError(f"Ajuste desconocido: {', '.join(sorted(desconocidas))}")

    validados = {c: _POR_CLAVE[c].convertir(v) for c, v in cambios.items()}

    init_schema()
    with _engine.begin() as conn:
        for clave, valor in validados.items():
            existe = conn.execute(
                select(ajustes_tabla.c.clave).where(ajustes_tabla.c.clave == clave)
            ).first()
            if existe:
                conn.execute(
                    ajustes_tabla.update()
                    .where(ajustes_tabla.c.clave == clave)
                    .values(valor=str(valor))
                )
            else:
                conn.execute(
                    ajustes_tabla.insert().values(clave=clave, valor=str(valor))
                )

    invalidar_cache()
    return todos()


def restablecer() -> dict[str, Any]:
    """borra lo guardado y vuelve a los defaults o a lo que diga el entorno."""
    init_schema()
    with _engine.begin() as conn:
        conn.execute(ajustes_tabla.delete())
    invalidar_cache()
    return todos()


# accesos con nombre. para que el resto del codigo no ande escribiendo
# strings sueltos

def magnitud_minima() -> float:
    return obtener("magnitud_minima")


def ventana_dias() -> int:
    return obtener("ventana_dias")


def retencion_dias(tipo: str | None = None) -> int:
    """dias de retencion para un tipo de evento. o la general si no aplica."""
    if tipo == "sismo":
        return obtener("retencion_dias_sismo")
    return obtener("retencion_dias")
