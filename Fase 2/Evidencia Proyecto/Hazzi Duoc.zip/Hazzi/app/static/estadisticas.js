/* estadisticas.js. logica de la pagina de estadisticas.
   separado de common.js, compartido por todas las paginas, porque esta
   logica es exclusiva de /estadisticas. principio de responsabilidad unica. */

let charts = [];
let ULTIMOS_EVENTOS = [];
let ULTIMOS_RIESGO = [];
let ULTIMOS_TOTAL_TIENDAS = 0;
// los 5 tipos que se analizan en detalle mas abajo. una sola lista,
// reusada por los kpis de arriba, la linea de tiempo, el loop de
// secciones y el pdf. si se agrega una fuente nueva se agrega aca y se
// propaga sola, es dry
const TIPOS_ANALIZADOS = ['sismo', 'incendio', 'volcan', 'meteorologico', 'alerta'];
function destruirCharts() { charts.forEach(c => c && c.destroy()); charts = []; }
function nuevoChart(canvas, cfg) { const c = new Chart(canvas, cfg); charts.push(c); return c; }

function cuenta(arr, key) {
  const m = {};
  arr.forEach(x => { const k = key(x); if (k == null || k === '') return; m[k] = (m[k] || 0) + 1; });
  return m;
}
function topN(m, n) { return Object.entries(m).sort((a, b) => b[1] - a[1]).slice(0, n); }
function claveDia(fecha) {
  // fecha viene "DD-MM-YYYY HH:MM hrs", clave ordenable YYYY-MM-DD
  const p = fecha.slice(0, 10).split('-');
  return `${p[2]}-${p[1]}-${p[0]}`;
}
function scrollA(id) {
  const el = document.getElementById(id);
  if (!el) return;
  el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  el.classList.add('flash');
  setTimeout(() => el.classList.remove('flash'), 1000);
}

// usado por las tarjetas kpi de arriba de todo. si la seccion a la que
// apuntan es un acordeon cerrado, primero lo abre y recien ahi hace
// scroll. si se hace al reves, el scroll apunta a la altura vieja,
// colapsada en 0, y el contenido que se buscaba termina quedando mas
// abajo del viewport. el delay coincide con la transicion de
// .hz-acc-body en styles.css, 0.3s. si se cambia una hay que cambiar la otra
function abrirYScroll(id) {
  const el = document.getElementById(id);
  if (!el) return;
  const yaAbierto = !el.classList.contains('hz-acc') || el.classList.contains('abierto');
  if (!yaAbierto) {
    el.classList.add('abierto');
    const head = el.querySelector('.hz-acc-head');
    if (head) head.setAttribute('aria-expanded', 'true');
  }
  setTimeout(() => scrollA(id), yaAbierto ? 0 : 320);
}

// delegado y no por elemento. las secciones se reconstruyen enteras en
// cada refresco con innerHTML, asi que un listener puesto directo
// sobre el boton se perderia al primer refresh. puesto en document,
// sobrevive para siempre
document.addEventListener('click', (e) => {
  const head = e.target.closest('.hz-acc-head');
  if (!head) return;
  const acc = head.closest('.hz-acc');
  if (!acc) return;
  const abierto = acc.classList.toggle('abierto');
  head.setAttribute('aria-expanded', String(abierto));
});

// extractores de datos especificos por tipo, a partir de texto libre
function magnitudDe(e) {
  const m = (e.titulo || '').match(/M(\d+(\.\d+)?)/) || (e.detalle || '').match(/Magnitud\s+(\d+(\.\d+)?)/);
  return m ? parseFloat(m[1]) : null;
}
function hectareasDe(e) {
  const m = (e.detalle || '').match(/([\d.,]+)\s*ha/);
  return m ? parseFloat(m[1].replace(',', '.')) : 0;
}
function tipoAvisoDe(e) {
  const m = (e.titulo || '').match(/\(([^)]+)\)/);
  return m ? m[1] : 'Aviso';
}
function fenomenoDe(e) { return (e.titulo || '').split(' (')[0]; }

// tarjetas kpi de arriba de todo
function pintarKPIs(d, ev) {
  const cont = document.getElementById('kpis');
  cont.innerHTML = '';
  const riesgo = (d.tiendas_en_riesgo || []).length;
  const regiones = new Set(ev.map(e => e.region).filter(Boolean)).size;
  const kpi = (valor, etiqueta, color, delay, onClick) => {
    const div = document.createElement('div');
    div.className = 'hz-card' + (onClick ? ' clickable' : '');
    div.style.setProperty('--accent', color);
    div.style.animationDelay = delay + 's';
    if (onClick) { div.tabIndex = 0; div.setAttribute('role', 'button'); }
    div.innerHTML = `<p class="num" style="color:${color}">0</p><p class="lbl">${etiqueta}</p>`;
    if (onClick) {
      div.addEventListener('click', onClick);
      div.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onClick(); } });
    }
    cont.appendChild(div);
    animateCount(div.querySelector('.num'), valor);
  };
  // "total eventos" y "activos ahora" ya los dice el hero de arriba, es
  // el mismo numero. no repetirlos aca, es informacion duplicada sin agregar nada
  kpi(riesgo, 'Tiendas en riesgo', '#dc2626', 0, () => abrirYScroll('sec-sucursales'));
  kpi(regiones, 'Regiones afectadas', '#7c3aed', .05);
  TIPOS_ANALIZADOS.forEach((tp, i) => {
    const n = ev.filter(e => e.tipo === tp).length;
    const m = TIPO_META[tp];
    kpi(n, m.corto, m.color, .1 + i * .05, () => abrirYScroll('sec-' + tp));
  });
}

// panorama general
function pintarGeneral(d, ev) {
  const porTipo = cuenta(ev, e => e.tipo);
  nuevoChart(document.getElementById('ch-tipo'), {
    type: 'doughnut',
    data: {
      labels: Object.keys(porTipo).map(nombreTipo),
      datasets: [{ data: Object.values(porTipo), backgroundColor: Object.keys(porTipo).map(t => (TIPO_META[t] || {}).color || '#64748b') }],
    },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } },
  });

  const orden = ['roja', 'naranja', 'amarilla', 'verde', 'info'];
  const porSev = d.por_severidad || {};
  nuevoChart(document.getElementById('ch-sev'), {
    type: 'bar',
    data: { labels: orden, datasets: [{ label: 'Eventos', data: orden.map(s => porSev[s] || 0), backgroundColor: orden.map(s => SEV_META[s].color) }] },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } },
  });

  const porReg = topN(cuenta(ev, e => e.region), 8);
  nuevoChart(document.getElementById('ch-region'), {
    type: 'bar',
    data: { labels: porReg.map(x => x[0]), datasets: [{ label: 'Eventos', data: porReg.map(x => x[1]), backgroundColor: '#0036CF' }] },
    options: { indexAxis: 'y', responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { beginAtZero: true, ticks: { precision: 0 } } } },
  });

  // linea de tiempo. eventos por dia, una serie por tipo
  const conFecha = ev.filter(e => e.fecha);
  const dias = [...new Set(conFecha.map(e => claveDia(e.fecha)))].sort();
  const tipos = TIPOS_ANALIZADOS;
  const datasets = tipos.map(tp => ({
    label: nombreTipo(tp), borderColor: TIPO_META[tp].color, backgroundColor: TIPO_META[tp].color + '33',
    fill: true, tension: .3,
    data: dias.map(dia => conFecha.filter(e => e.tipo === tp && claveDia(e.fecha) === dia).length),
  }));
  nuevoChart(document.getElementById('ch-linea'), {
    type: 'line',
    data: { labels: dias.map(x => x.split('-').slice(1).reverse().join('-')), datasets },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } },
      scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } },
  });
}

// barra hero. resumen de marca, identidad walmart, mismo componente
// que usan tiendas eventos e historial. consistencia visual entre todas las paginas
function pintarHero(ev) {
  const total = document.getElementById('hero-total');
  if (!total) return;
  total.textContent = ev.length;
  const cont = document.getElementById('hero-chips');
  const conteo = { roja: 0, naranja: 0, amarilla: 0 };
  ev.forEach(e => { if (conteo[e.severidad] !== undefined) conteo[e.severidad]++; });
  const ORDEN = [['roja', 'Rojas'], ['naranja', 'Naranjas'], ['amarilla', 'Amarillas']];
  cont.innerHTML = ORDEN.map(([sev, label]) => {
    const c = (SEV_META[sev] || SEV_META.info).color;
    return `<span class="hz-hero-chip"><span class="dot" style="background:${c}"></span>${conteo[sev]} ${label}</span>`;
  }).join('');
}

// color de marca por formato de tienda, para los graficos de la
// seccion de sucursales. metaFormato en common.js devuelve blanco
// para lider y central mayorista, pensado para el cartel del mapa
// sobre fondo de color. aca el fondo es blanco asi que se necesita
// una paleta propia que si se vea
function colorFormato(nombre) {
  const PALETA = {
    'Lider': '#0036CF',
    'Express de Lider': '#1c8fc9',
    'Superbodega Acuenta': '#dc2626',
    'Central Mayorista': '#d97706',
  };
  return PALETA[nombre] || '#64748b';
}

// impacto en la red de tiendas, para decisiones operativas.
// a diferencia de las secciones por catastrofe, esta no viene de
// ULTIMOS_EVENTOS sino del cruce evento contra tienda que ya hace el
// backend, d.tiendas_en_riesgo, ver stores.py stores_at_risk. no se
// recalcula nada en el frontend
function pintarSucursales(d) {
  const cont = document.getElementById('sec-sucursales');
  if (!cont) return;
  const riesgo = d.tiendas_en_riesgo || [];
  const totalTiendas = d.total_tiendas || 0;
  cont.style.setProperty('--accent', '#0036CF');

  const colaboradores = riesgo.reduce((a, t) => a + (t.colaboradores || 0), 0);
  const tieneColaboradores = riesgo.some(t => t.colaboradores != null);
  const pct = totalTiendas ? ((riesgo.length / totalTiendas) * 100).toFixed(1) : '0.0';
  const criticas = riesgo.filter(t => t.severidad === 'roja').length;

  const statsHtml = [
    statHtml(riesgo.length, `Sucursales en riesgo (de ${totalTiendas})`),
    statHtml(`${pct}%`, 'De la red total'),
    statHtml(criticas, 'En riesgo critico (roja)'),
    statHtml(tieneColaboradores ? colaboradores.toLocaleString('es-CL') : 's/d', 'Colaboradores potencialmente expuestos'),
  ].join('');

  const chartsCfg = [
    { id: 'suc-formato', title: 'Por formato de tienda', build(canvas) {
      const porFormato = cuenta(riesgo, t => metaFormato(t).nombre);
      const labels = Object.keys(porFormato);
      nuevoChart(canvas, { type: 'doughnut', data: { labels, datasets: [{ data: Object.values(porFormato), backgroundColor: labels.map(colorFormato) }] },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } } });
    } },
    { id: 'suc-sev', title: 'Por severidad del riesgo', build(canvas) {
      const porSev = cuenta(riesgo, t => t.severidad);
      const orden = Object.keys(porSev);
      nuevoChart(canvas, { type: 'doughnut', data: { labels: orden, datasets: [{ data: orden.map(s => porSev[s]), backgroundColor: orden.map(s => SEV_META[s].color) }] },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } } });
    } },
    { id: 'suc-comuna', title: 'Top comunas con sucursales en riesgo', build(canvas) {
      const porComuna = topN(cuenta(riesgo, t => t.comuna), 8);
      nuevoChart(canvas, { type: 'bar', data: { labels: porComuna.map(x => x[0]), datasets: [{ label: 'Sucursales', data: porComuna.map(x => x[1]), backgroundColor: '#0036CF' }] },
        options: { indexAxis: 'y', responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { beginAtZero: true, ticks: { precision: 0 } } } } });
    } },
    { id: 'suc-dist', title: 'Distancia al evento mas cercano', build(canvas) {
      // los tramos se calculan sobre los datos reales y no con topes
      // fijos. ahora el area depende del evento, un sismo mayor
      // alcanza cientos de km y una comuna en alerta apenas unos pocos,
      // asi que un ultimo tramo "20-30 km" dejaria fuera del grafico a media red
      const dentro = riesgo.filter(t => t.distancia_km === 0).length;
      const fuera = riesgo.filter(t => t.distancia_km > 0).map(t => t.distancia_km);
      const paso = Math.ceil(Math.max(10, ...fuera) / 4);
      const bins = dentro ? [['En la zona', dentro]] : [];
      for (let i = 0; i < 4; i++) {
        const desde = i * paso, hasta = (i + 1) * paso;
        bins.push([`${desde}-${hasta} km`, fuera.filter(d => d > desde && d <= hasta).length]);
      }
      nuevoChart(canvas, { type: 'bar', data: { labels: bins.map(b => b[0]), datasets: [{ label: 'Sucursales', data: bins.map(b => b[1]), backgroundColor: '#7c3aed' }] },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } } });
    } },
  ];

  // ranking operativo. las sucursales que necesitan atencion primero,
  // mas grave y mas cerca del evento. pensado para copiar y pegar en un reporte
  const top10 = riesgo.slice()
    .sort((a, b) => (RANK_SEV[a.severidad] ?? 9) - (RANK_SEV[b.severidad] ?? 9) || a.distancia_km - b.distancia_km)
    .slice(0, 10);
  const tablaTop = top10.length ? `
    <div style="overflow-x:auto"><table class="hz-table" style="font-size:.82rem">
      <thead><tr><th>Formato</th><th>Comuna</th><th>Evento cercano</th><th>Distancia</th><th>Severidad</th>${tieneColaboradores ? '<th>Colaboradores</th>' : ''}</tr></thead>
      <tbody>${top10.map(t => `<tr>
        <td class="font-semibold">${escHtml(metaFormato(t).nombre)}</td>
        <td>${escHtml(t.comuna)}</td>
        <td>${eventoCercanoCelda(t)}</td>
        <td>${t.distancia_km} km</td>
        <td>${badgeSev(t.severidad)}</td>
        ${tieneColaboradores ? `<td>${escHtml(t.colaboradores ?? '\u2014')}</td>` : ''}
      </tr>`).join('')}</tbody>
    </table></div>` : '<p class="text-sm text-slate-500">Sin sucursales en riesgo por ahora -- ninguna cae dentro del area afectada por un evento severo.</p>';

  const porComunaTop = topN(cuenta(riesgo, t => t.comuna), 1);
  const insight = !riesgo.length
    ? 'Ninguna sucursal esta dentro del area afectada por un evento severo en este momento.'
    : `<b>${riesgo.length}</b> sucursal(es) en riesgo` +
      (tieneColaboradores ? ` que suman <b>${colaboradores.toLocaleString('es-CL')}</b> colaboradores potencialmente expuestos` : '') +
      `. La comuna mas critica es <b>${escHtml(porComunaTop[0] ? porComunaTop[0][0] : 's/d')}</b>` +
      (criticas ? ` y hay <b>${criticas}</b> sucursal(es) en riesgo CRITICO (alerta roja) que deberian priorizarse.` : ', sin sucursales en riesgo critico por ahora.');

  const abierta = cont.classList.contains('abierto');
  cont.innerHTML = `
    <button type="button" class="hz-acc-head" aria-expanded="${abierta}" aria-controls="body-sucursales">
      <div class="cat-header" style="margin-bottom:0">
        <div class="cat-ic"><svg width="22" height="22" viewBox="0 0 24 24"><path fill="#fff" d="M4 8h16l-1.3 11.1a2 2 0 0 1-2 1.9H7.3a2 2 0 0 1-2-1.9L4 8z"/><path fill="none" stroke="#fff" stroke-width="2" d="M8 8V6a4 4 0 0 1 8 0v2"/></svg></div>
        <div>
          <div class="cat-title">Sucursales cerca de eventos severos</div>
          <div class="cat-sub">Que sucursales estan cerca de un evento severo ahora mismo, con que formato, en que comuna y cuantos colaboradores potencialmente expuestos.</div>
        </div>
      </div>
      ${chevronSvg()}
    </button>
    <div class="hz-acc-body" id="body-sucursales">
      <div class="hz-acc-inner"><div class="hz-acc-pad">
        <div class="grid grid-cols-2 md:grid-cols-4 gap-2 mb-3">${statsHtml}</div>
        <div class="grid md:grid-cols-2 gap-3 mb-3">
          ${chartsCfg.map(c => `<div class="chart-card"><h4>${c.title}</h4><div style="height:230px"><canvas id="${c.id}"></canvas></div></div>`).join('')}
        </div>
        <div class="insight-box"><span>${insight}</span></div>
        <h4 class="font-bold text-sm mt-4 mb-2 text-slate-700">Top 10 sucursales que requieren atencion prioritaria</h4>
        ${tablaTop}
      </div></div>
    </div>`;
  chartsCfg.forEach(c => c.build(document.getElementById(c.id)));
}

// construccion de una seccion por catastrofe
function statHtml(v, l) { return `<div class="mini-stat"><div class="v">${v}</div><div class="l">${l}</div></div>`; }

const CATEGORIAS = {
  sismo: {
    desc: 'Sismos de los ultimos 7 dias (M3.5+) dentro del cuadrante de Chile continental, vigentes y archivados. Los menores a M4.0 se registran como contexto para ver secuencias sismicas, pero no generan alerta operativa.',
    stats(ev) {
      const mags = ev.map(magnitudDe).filter(m => m != null);
      // el umbral de alerta es m4.0, ver normalize.py UMBRAL_ALERTA_SISMO.
      // debajo de eso es sismicidad de fondo, no impacto operativo
      const conAlerta = mags.filter(m => m >= 4.0).length;
      const max = mags.length ? Math.max(...mags) : 0;
      const prom = mags.length ? (mags.reduce((a, b) => a + b, 0) / mags.length) : 0;
      return [statHtml(ev.length, 'Total sismos'), statHtml(conAlerta, 'Con alerta (M4.0+)'),
        statHtml(prom.toFixed(1), 'Magnitud promedio'), statHtml(max.toFixed(1), 'Magnitud maxima')];
    },
    charts(ev) {
      return [
        { id: 'sismo-dia', title: 'Sismos por dia', build(canvas) {
          const porDia = cuenta(ev.filter(e => e.fecha), e => claveDia(e.fecha));
          const dias = Object.keys(porDia).sort();
          nuevoChart(canvas, { type: 'line', data: { labels: dias.map(d => d.split('-').slice(1).reverse().join('-')),
            datasets: [{ label: 'Sismos', data: dias.map(d => porDia[d]), borderColor: '#dc2626', backgroundColor: 'rgba(220,38,38,.15)', fill: true, tension: .3 }] },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } } });
        } },
        { id: 'sismo-mag', title: 'Distribucion por magnitud', build(canvas) {
          const bins = [['3.5-4.0', '#16a34a'], ['4.0-5.0', '#d97706'], ['5.0-6.0', '#ea580c'], ['6.0+', '#dc2626']];
          const mags = ev.map(magnitudDe).filter(m => m != null);
          const cuentas = [
            mags.filter(m => m >= 3.5 && m < 4).length, mags.filter(m => m >= 4 && m < 5).length,
            mags.filter(m => m >= 5 && m < 6).length, mags.filter(m => m >= 6).length,
          ];
          nuevoChart(canvas, { type: 'bar', data: { labels: bins.map(b => b[0]), datasets: [{ label: 'Sismos', data: cuentas, backgroundColor: bins.map(b => b[1]) }] },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } } });
        } },
      ];
    },
    insight(ev) {
      if (!ev.length) return 'Sin sismos registrados en los ultimos 7 dias.';
      const mags = ev.map(e => ({ e, m: magnitudDe(e) })).filter(x => x.m != null).sort((a, b) => b.m - a.m);
      const mayor = mags[0];
      const base = mayor
        ? `El sismo mas fuerte fue de <b>M${mayor.m}</b> (${escHtml(mayor.e.titulo.split(' - ')[1] || mayor.e.titulo)}).`
        : 'Datos de magnitud no disponibles.';
      // secuencia sismica. varios sismos en una misma zona es la senal
      // que justifica registrar los menores a m4.0, un enjambre puede
      // preceder a un evento mayor. se avisa solo si hay algo que mirar
      const porZona = topN(cuenta(ev, e => e.region), 1);
      const secuencia = porZona[0] && porZona[0][1] >= 3
        ? ` <b>Posible secuencia sismica:</b> ${porZona[0][1]} sismos en <b>${escHtml(porZona[0][0])}</b> -- vale la pena seguirla de cerca.`
        : '';
      const menores = mags.filter(x => x.m < 4.0).length;
      const nota = menores ? ` ${menores} son de solo registro (M<4.0), sin impacto operativo.` : '';
      return base + secuencia + nota;
    },
  },
  incendio: {
    desc: 'Incendios forestales activos y recientes reportados a nivel nacional.',
    stats(ev) {
      const activos = ev.filter(e => e.estado && e.estado.startsWith('Activo')).length;
      const controlados = ev.filter(e => e.estado === 'Controlado').length;
      const ha = ev.reduce((a, e) => a + hectareasDe(e), 0);
      return [statHtml(ev.length, 'Total incendios'), statHtml(activos, 'En combate'),
        statHtml(controlados, 'Controlados'), statHtml(ha.toLocaleString('es-CL'), 'Hectareas afectadas')];
    },
    charts(ev) {
      return [
        { id: 'inc-estado', title: 'Por estado', build(canvas) {
          const porEstado = cuenta(ev, e => e.estado || 'Desconocido');
          const colores = Object.keys(porEstado).map(k => k.startsWith('Activo') ? '#dc2626' : k === 'Controlado' ? '#d97706' : '#64748b');
          nuevoChart(canvas, { type: 'doughnut', data: { labels: Object.keys(porEstado), datasets: [{ data: Object.values(porEstado), backgroundColor: colores }] },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } } });
        } },
        { id: 'inc-region', title: 'Top regiones con incendios', build(canvas) {
          const porReg = topN(cuenta(ev, e => e.region), 8);
          nuevoChart(canvas, { type: 'bar', data: { labels: porReg.map(x => x[0]), datasets: [{ label: 'Incendios', data: porReg.map(x => x[1]), backgroundColor: '#ea580c' }] },
            options: { indexAxis: 'y', responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { beginAtZero: true, ticks: { precision: 0 } } } } });
        } },
      ];
    },
    insight(ev) {
      if (!ev.length) return 'No hay incendios forestales activos reportados por CONAF en este momento.';
      const porReg = topN(cuenta(ev, e => e.region), 1);
      const activos = ev.filter(e => e.estado && e.estado.startsWith('Activo')).length;
      return `${activos} incendio(s) en combate ahora mismo. La region mas afectada es <b>${escHtml(porReg[0] ? porReg[0][0] : 's/d')}</b>.`;
    },
  },
  volcan: {
    desc: 'Volcanes con alerta tecnica vigente (se excluyen los volcanes en alerta verde/normal).',
    stats(ev) {
      const roja = ev.filter(e => e.severidad === 'roja').length;
      const naranja = ev.filter(e => e.severidad === 'naranja').length;
      const amarilla = ev.filter(e => e.severidad === 'amarilla').length;
      return [statHtml(ev.length, 'Volcanes en alerta'), statHtml(roja, 'Alerta roja'),
        statHtml(naranja, 'Alerta naranja'), statHtml(amarilla, 'Alerta amarilla')];
    },
    charts(ev) {
      return [
        { id: 'vol-nivel', title: 'Por nivel de alerta', build(canvas) {
          const porNivel = cuenta(ev, e => e.severidad);
          nuevoChart(canvas, { type: 'doughnut', data: { labels: Object.keys(porNivel), datasets: [{ data: Object.values(porNivel), backgroundColor: Object.keys(porNivel).map(s => SEV_META[s].color) }] },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } } });
        } },
        { id: 'vol-region', title: 'Volcanes en alerta por region', build(canvas) {
          const porReg = topN(cuenta(ev, e => e.region), 8);
          nuevoChart(canvas, { type: 'bar', data: { labels: porReg.map(x => x[0]), datasets: [{ label: 'Volcanes', data: porReg.map(x => x[1]), backgroundColor: '#b91c1c' }] },
            options: { indexAxis: 'y', responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { beginAtZero: true, ticks: { precision: 0 } } } } });
        } },
      ];
    },
    insight(ev) {
      if (!ev.length) return 'Todos los volcanes monitoreados estan en alerta verde (normal) - sin novedad.';
      const criticos = ev.filter(e => e.severidad === 'roja' || e.severidad === 'naranja');
      if (criticos.length) return `<b>${criticos.length}</b> volcan(es) con alerta roja/naranja: ${criticos.map(e => escHtml(e.titulo.replace('Volcan ', ''))).join(', ')}.`;
      return `${ev.length} volcan(es) en alerta amarilla (vigilancia). Ninguno en nivel critico.`;
    },
  },
  meteorologico: {
    desc: 'Alertas y alarmas meteorologicas vigentes por zona geografica.',
    stats(ev) {
      const alarmas = ev.filter(e => e.severidad === 'roja').length;
      const alertas = ev.filter(e => e.severidad === 'amarilla').length;
      return [statHtml(ev.length, 'Total'), statHtml(alarmas, 'Alarmas (roja)'),
        statHtml(alertas, 'Alertas (amarilla)')];
    },
    charts(ev) {
      return [
        { id: 'met-tipo', title: 'Por nivel', build(canvas) {
          const porTipo = cuenta(ev, tipoAvisoDe);
          const colorPorNivel = { Alerta: '#d97706', Alarma: '#dc2626' };
          nuevoChart(canvas, { type: 'doughnut', data: { labels: Object.keys(porTipo), datasets: [{ data: Object.values(porTipo), backgroundColor: Object.keys(porTipo).map(k => colorPorNivel[k] || '#64748b') }] },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } } });
        } },
        { id: 'met-fenomeno', title: 'Fenomenos mas frecuentes', build(canvas) {
          const porFen = topN(cuenta(ev, fenomenoDe), 8);
          nuevoChart(canvas, { type: 'bar', data: { labels: porFen.map(x => x[0]), datasets: [{ label: 'Zonas', data: porFen.map(x => x[1]), backgroundColor: '#2563eb' }] },
            options: { indexAxis: 'y', responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { beginAtZero: true, ticks: { precision: 0 } } } } });
        } },
      ];
    },
    insight(ev) {
      if (!ev.length) return 'Sin alertas ni alarmas meteorologicas vigentes por ahora.';
      const porFen = topN(cuenta(ev, fenomenoDe), 1);
      const zonas = new Set(ev.map(e => e.region).filter(Boolean)).size;
      return `El fenomeno mas frecuente es <b>${escHtml(porFen[0][0])}</b>, afectando <b>${zonas}</b> zona(s) del pais.`;
    },
  },
  alerta: {
    desc: 'Alertas de emergencia declaradas por SENAPRED (Servicio Nacional de Prevencion y Respuesta ante Desastres), una fila por comuna afectada.',
    stats(ev) {
      const distintas = new Set(ev.map(e => e.titulo)).size;
      const comunas = new Set(ev.map(e => e.comuna).filter(Boolean)).size;
      const rojas = ev.filter(e => e.severidad === 'roja').length;
      const amarillas = ev.filter(e => e.severidad === 'amarilla').length;
      return [statHtml(distintas, 'Alertas distintas'), statHtml(comunas, 'Comunas afectadas'),
        statHtml(rojas, 'Comunas en roja'), statHtml(amarillas, 'Comunas en amarilla')];
    },
    charts(ev) {
      return [
        { id: 'alerta-sev', title: 'Por severidad (comunas)', build(canvas) {
          const porSev = cuenta(ev, e => e.severidad);
          const orden = Object.keys(porSev);
          nuevoChart(canvas, { type: 'doughnut', data: { labels: orden, datasets: [{ data: orden.map(s => porSev[s]), backgroundColor: orden.map(s => SEV_META[s].color) }] },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } } });
        } },
        { id: 'alerta-comuna', title: 'Comunas mas mencionadas', build(canvas) {
          const porComuna = topN(cuenta(ev, e => e.comuna || e.region), 8);
          nuevoChart(canvas, { type: 'bar', data: { labels: porComuna.map(x => x[0]), datasets: [{ label: 'Alertas', data: porComuna.map(x => x[1]), backgroundColor: '#7c3aed' }] },
            options: { indexAxis: 'y', responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { beginAtZero: true, ticks: { precision: 0 } } } } });
        } },
      ];
    },
    insight(ev) {
      if (!ev.length) return 'SENAPRED no tiene alertas de emergencia vigentes en este momento.';
      const criticas = ev.filter(e => e.severidad === 'roja');
      const porComuna = topN(cuenta(ev, e => e.comuna || e.region), 1);
      const comunaTop = porComuna[0] ? porComuna[0][0] : 's/d';
      if (criticas.length) return `<b>${criticas.length}</b> comuna(s) con alerta ROJA vigente -- revisar cobertura de sucursales cercanas cuanto antes. Comuna mas mencionada en general: <b>${escHtml(comunaTop)}</b>.`;
      return `Sin alertas rojas por ahora. La comuna con mas alertas vigentes es <b>${escHtml(comunaTop)}</b>.`;
    },
  },
};

// chevron reusado por todos los acordeones armados en js, cat-section
// y sucursales. el de panorama general vive directo en el html estatico
function chevronSvg() {
  return '<svg class="hz-acc-chevron" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>';
}

function seccionCategoria(tipo, ev) {
  const cfg = CATEGORIAS[tipo];
  const meta = TIPO_META[tipo];
  const cont = document.getElementById('sec-' + tipo);
  cont.style.setProperty('--accent', meta.color);
  const chartsCfg = cfg.charts(ev);
  const abierta = cont.classList.contains('abierto');
  const cuerpoId = 'body-' + tipo;
  cont.innerHTML = `
    <button type="button" class="hz-acc-head" aria-expanded="${abierta}" aria-controls="${cuerpoId}">
      <div class="cat-header" style="margin-bottom:0">
        <div class="cat-ic"><svg width="22" height="22" viewBox="0 0 24 24">${glyphTipo(tipo)}</svg></div>
        <div>
          <div class="cat-title">${meta.label} <span class="text-xs font-normal text-slate-400">(fuente ${meta.fuente})</span></div>
          <div class="cat-sub">${cfg.desc}</div>
        </div>
      </div>
      ${chevronSvg()}
    </button>
    <div class="hz-acc-body" id="${cuerpoId}">
      <div class="hz-acc-inner"><div class="hz-acc-pad">
        <div class="grid grid-cols-2 md:grid-cols-4 gap-2 mb-3">${cfg.stats(ev).join('')}</div>
        <div class="grid md:grid-cols-2 gap-3 mb-3">
          ${chartsCfg.map(c => `<div class="chart-card"><h4>${c.title}</h4><div style="height:230px"><canvas id="${c.id}"></canvas></div></div>`).join('')}
        </div>
        <div class="insight-box"><span>${cfg.insight(ev)}</span></div>
      </div></div>
    </div>`;
  chartsCfg.forEach(c => c.build(document.getElementById(c.id)));
}

// carga principal.
// los sismos menores a m4.0 no pasan por vigentes, van directo al
// historial, ver historial.py. y los que si son alerta duran pocas
// horas ahi. asi que una estadistica sismica hecha solo con
// /api/events mostraria casi nada. esta seccion necesita las dos
// fuentes unidas
function unirConHistorial(vigentes, archivados) {
  const clave = e => `${e.source}|${e.titulo}|${e.fecha}`;
  const vistos = new Set(vigentes.map(clave));
  return vigentes.concat(archivados.filter(e => !vistos.has(clave(e))));
}

async function cargar(refrescar = false) {
  const estado = document.getElementById('estado');
  const btn = document.getElementById('refrescar');
  if (refrescar) btn.classList.add('girando');
  estado.textContent = 'Cargando...';
  try {
    const d = await fetchEvents(refrescar);
    const ev = d.eventos || [];
    // el historial es una lectura de db barata, y ya quedo al dia con
    // el fetchEvents de arriba porque registrar_ciclo corre dentro de /api/events
    let archivados = [];
    try {
      archivados = (await fetchHistorial()).eventos || [];
    } catch (err) {
      console.warn('No se pudo leer el historial; estadisticas solo con eventos vigentes', err);
    }
    ULTIMOS_EVENTOS = ev;
    ULTIMOS_RIESGO = d.tiendas_en_riesgo || [];
    ULTIMOS_TOTAL_TIENDAS = d.total_tiendas || 0;
    estado.textContent = `${ev.length} eventos - actualizado ${new Date().toLocaleTimeString('es-CL')}`;
    destruirCharts();
    aplicarTemaCharts();
    pintarHero(ev);
    pintarKPIs(d, ev);
    pintarGeneral(d, ev);
    pintarSucursales(d);
    const conHistorial = unirConHistorial(ev, archivados);
    TIPOS_ANALIZADOS.forEach(tp => {
      // solo los sismos miran el historial. para el resto "vigente" es
      // justamente lo que interesa, un incendio apagado no es novedad
      const fuente = tp === 'sismo' ? conHistorial : ev;
      seccionCategoria(tp, fuente.filter(e => e.tipo === tp));
    });
  } catch (e) {
    console.error('Error en estadisticas:', e);
    estado.textContent = 'Error al cargar: ' + e.message + ' (revisa la consola F12 para detalle)';
  } finally {
    btn.classList.remove('girando');
  }
}
document.getElementById('refrescar').addEventListener('click', () => cargar(true));
document.addEventListener('temacambio', () => cargar(false));
cargar();

// exportar csv y pdf
function exportarCSV() {
  if (!ULTIMOS_EVENTOS.length) return;
  // exporta los eventos vigentes, lo que se ve arriba. los sismos
  // menores no estan aca a proposito. nunca pasan por vigentes, viven
  // en el historial
  const filas = ULTIMOS_EVENTOS.map(e => ({
    fecha: e.fecha || '', tipo: nombreTipo(e.tipo), fuente: e.source, titulo: e.titulo,
    severidad: e.severidad, region: e.region || '', comuna: e.comuna || '',
    estado: e.estado || (e.activa ? 'Activa' : 'Finalizada'),
  }));
  descargarCSV(`estadisticas_hazard_${new Date().toISOString().slice(0, 10)}.csv`, filas);
}

function exportarPDF() {
  if (!ULTIMOS_EVENTOS.length) return;
  const ev = ULTIMOS_EVENTOS;
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  const startY = pdfEncabezado(doc, 'Agente Hazzi - Resumen de Estadisticas',
    `Total: ${ev.length} eventos  |  Generado: ${new Date().toLocaleString('es-CL')}`);

  const filasTipo = TIPOS_ANALIZADOS.map(tp => {
    const sub = ev.filter(e => e.tipo === tp);
    const activos = sub.filter(e => e.activa).length;
    const porReg = topN(cuenta(sub, e => e.region || e.comuna), 1);
    return [nombreTipo(tp), sub.length, activos, TIPO_META[tp].fuente, porReg[0] ? porReg[0][0] : 's/d'];
  });
  doc.autoTable({
    startY,
    head: [['Catastrofe', 'Total', 'Activos', 'Fuente', 'Region/comuna mas afectada']],
    body: filasTipo,
    styles: { fontSize: 9, cellPadding: 3 },
    headStyles: { fillColor: [0, 54, 207], textColor: 255, fontStyle: 'bold' },
    alternateRowStyles: { fillColor: [239, 242, 255] },
  });

  const porReg = topN(cuenta(ev, e => e.region), 10);
  doc.autoTable({
    startY: doc.lastAutoTable.finalY + 8,
    head: [['Top regiones con eventos', 'Cantidad']],
    body: porReg.map(x => [x[0], x[1]]),
    styles: { fontSize: 9, cellPadding: 3 },
    headStyles: { fillColor: [0, 54, 207], textColor: 255, fontStyle: 'bold' },
    alternateRowStyles: { fillColor: [239, 242, 255] },
  });

  // tabla operativa. sucursales que necesitan atencion prioritaria,
  // mismo ranking que se ve en pantalla, ver pintarSucursales. pensada
  // para imprimir y repartir al equipo de operaciones
  if (ULTIMOS_RIESGO.length) {
    const colaboradoresTotal = ULTIMOS_RIESGO.reduce((a, t) => a + (t.colaboradores || 0), 0);
    const top10 = ULTIMOS_RIESGO.slice()
      .sort((a, b) => (RANK_SEV[a.severidad] ?? 9) - (RANK_SEV[b.severidad] ?? 9) || a.distancia_km - b.distancia_km)
      .slice(0, 10);
    const y = doc.lastAutoTable.finalY + 10;
    doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.setTextColor(30, 41, 59);
    doc.text(`Sucursales en riesgo: ${ULTIMOS_RIESGO.length} de ${ULTIMOS_TOTAL_TIENDAS}  \u00b7  Colaboradores potencialmente expuestos: ${colaboradoresTotal.toLocaleString('es-CL')}`, 14, y);
    doc.autoTable({
      startY: y + 4,
      head: [['Formato', 'Comuna', 'Evento cercano', 'Distancia', 'Severidad']],
      body: top10.map(t => [metaFormato(t).nombre, t.comuna, eventoCercanoTexto(t), `${t.distancia_km} km`, t.severidad]),
      styles: { fontSize: 8, cellPadding: 2 },
      headStyles: { fillColor: [220, 38, 38], textColor: 255, fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [254, 242, 242] },
    });
  }

  doc.save(`estadisticas_hazard_${new Date().toISOString().slice(0, 10)}.pdf`);
}
document.getElementById('exportar-csv').addEventListener('click', exportarCSV);
document.getElementById('exportar-pdf').addEventListener('click', exportarPDF);
