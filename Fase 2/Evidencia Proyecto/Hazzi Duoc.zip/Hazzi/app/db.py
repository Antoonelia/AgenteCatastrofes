"""motor de base de datos compartido. sqlite por defecto.

todos los modulos que necesitan guardar algo importan este mismo engine en
vez de armar el suyo. la url vive en una variable de entorno asi que el
dia que haya sql corporativo se cambia sin tocar codigo. ver
integracion_sql.md.
"""
from __future__ import annotations

import os
from pathlib import Path

from sqlalchemy import create_engine, event

_DEFAULT_URL = f"sqlite:///{Path(__file__).parent.parent / 'data' / 'hazard.db'}"
DATABASE_URL = os.environ.get("DATABASE_URL", _DEFAULT_URL)

# busy_timeout mas generoso que el default de sqlite3 (5s): con el panel
# admin, el recolector de fuentes y los tests pegandole a la misma base,
# dos escrituras que se cruzan no deberian fallar (o colgarse sin
# explicacion) de entrada -- deberian esperar un rato razonable primero.
# WAL deja que una escritura no bloquee una lectura en curso: sin esto,
# un GET mientras alguien guardaba ajustes podia quedar esperando el
# lock y dar la sensacion de que la pantalla "se quedo pegada".
_es_sqlite = DATABASE_URL.startswith("sqlite")

engine = create_engine(
    DATABASE_URL,
    future=True,
    connect_args={"timeout": 15} if _es_sqlite else {},
)

if _es_sqlite:
    @event.listens_for(engine, "connect")
    def _activar_wal(conexion_dbapi, _registro):
        cursor = conexion_dbapi.cursor()
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA busy_timeout=15000")
        cursor.close()
