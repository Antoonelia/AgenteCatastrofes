"""endpoints exclusivos del rol admin_usuarios: altas/bajas de usuarios,
asignacion de roles, cambio de clave y lectura de la bitacora de
auditoria.

separado de admin_api.py a proposito, misma razon de siempre: son roles
distintos (ver usuarios.py) y mezclar su superficie de escritura en un
solo archivo volveria a juntar lo que antonella pidio separar.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from . import auditoria, sesiones, usuarios, visitas

router = APIRouter(prefix="/api/usuarios")

_requiere_admin_usuarios = sesiones.requiere_rol("admin_usuarios")


class UsuarioEntrada(BaseModel):
    rut: str
    nombre: str
    clave: str
    roles: list[str]


class UsuarioEdicion(BaseModel):
    """el rut no entra aca a proposito: no se edita, ver usuarios.editar."""
    nombre: str
    roles: list[str]
    clave: str | None = None  # si viene vacio/None, la clave actual no se toca


class RolEntrada(BaseModel):
    rol: str


class ActivoEntrada(BaseModel):
    activo: bool


class ClaveEntrada(BaseModel):
    clave: str


@router.get("", dependencies=[Depends(_requiere_admin_usuarios)])
def listar_usuarios():
    return JSONResponse({"usuarios": usuarios.listar(), "roles_disponibles": list(usuarios.ROLES)})


@router.post("", dependencies=[Depends(_requiere_admin_usuarios)])
def crear_usuario(datos: UsuarioEntrada, quien: dict = Depends(_requiere_admin_usuarios)):
    try:
        nuevo = usuarios.crear(datos.rut, datos.nombre, datos.clave, datos.roles)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    auditoria.registrar(quien, "crear_usuario", {"rut_enmascarado": nuevo["rut_enmascarado"], "roles": nuevo["roles"]})
    return JSONResponse({"ok": True, "usuario": nuevo})


@router.put("/{id_usuario}", dependencies=[Depends(_requiere_admin_usuarios)])
def editar_usuario(id_usuario: int, datos: UsuarioEdicion, quien: dict = Depends(_requiere_admin_usuarios)):
    """edita nombre y roles de una cuenta, y de paso su clave si vino una
    nueva. una sola llamada desde el mismo popup que crea usuarios, ver
    admin-usuarios.html."""
    try:
        actualizado = usuarios.editar(id_usuario, datos.nombre, datos.roles)
        if datos.clave:
            usuarios.cambiar_clave(id_usuario, datos.clave)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    auditoria.registrar(quien, "editar_usuario", {
        "id": id_usuario, "nombre": actualizado["nombre"], "roles_resultantes": actualizado["roles"],
        "clave_cambiada": bool(datos.clave),
    })
    return JSONResponse({"ok": True, "usuario": actualizado})


@router.delete("/{id_usuario}", dependencies=[Depends(_requiere_admin_usuarios)])
def eliminar_usuario(id_usuario: int, quien: dict = Depends(_requiere_admin_usuarios)):
    """borra una cuenta por completo. no se puede borrar la propia cuenta
    con la que estas conectada -- te dejaria sin sesion valida a mitad de
    la accion y es facil de hacer por error con el menu de 3 puntitos."""
    if quien.get("id") == id_usuario:
        raise HTTPException(status_code=400, detail="No puedes eliminar tu propia cuenta mientras estas conectado con ella.")
    try:
        borrado = usuarios.eliminar(id_usuario)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    auditoria.registrar(quien, "eliminar_usuario", {
        "rut_enmascarado": borrado["rut_enmascarado"], "nombre": borrado["nombre"], "roles": borrado["roles"],
    })
    return JSONResponse({"ok": True})


@router.post("/{id_usuario}/roles", dependencies=[Depends(_requiere_admin_usuarios)])
def agregar_rol(id_usuario: int, datos: RolEntrada, quien: dict = Depends(_requiere_admin_usuarios)):
    """suma un rol a una cuenta que ya existe. una persona puede terminar
    con admin Y admin_usuarios a la vez -- queda trazado aca, en
    roles_resultantes, exactamente para que se pueda auditar quien tiene
    acceso a los dos paneles."""
    try:
        actualizado = usuarios.agregar_rol(id_usuario, datos.rol)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    auditoria.registrar(quien, "agregar_rol_usuario", {
        "id": id_usuario, "rol_agregado": datos.rol, "roles_resultantes": actualizado["roles"],
    })
    return JSONResponse({"ok": True, "usuario": actualizado})


@router.delete("/{id_usuario}/roles/{rol}", dependencies=[Depends(_requiere_admin_usuarios)])
def quitar_rol(id_usuario: int, rol: str, quien: dict = Depends(_requiere_admin_usuarios)):
    try:
        actualizado = usuarios.quitar_rol(id_usuario, rol)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    auditoria.registrar(quien, "quitar_rol_usuario", {
        "id": id_usuario, "rol_quitado": rol, "roles_resultantes": actualizado["roles"],
    })
    return JSONResponse({"ok": True, "usuario": actualizado})


@router.put("/{id_usuario}/activo", dependencies=[Depends(_requiere_admin_usuarios)])
def cambiar_activo(id_usuario: int, datos: ActivoEntrada, quien: dict = Depends(_requiere_admin_usuarios)):
    try:
        actualizado = usuarios.cambiar_activo(id_usuario, datos.activo)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    accion = "activar_usuario" if datos.activo else "desactivar_usuario"
    auditoria.registrar(quien, accion, {"id": id_usuario})
    return JSONResponse({"ok": True, "usuario": actualizado})


@router.put("/{id_usuario}/clave", dependencies=[Depends(_requiere_admin_usuarios)])
def cambiar_clave(id_usuario: int, datos: ClaveEntrada, quien: dict = Depends(_requiere_admin_usuarios)):
    """resetea la clave de una cuenta, propia o ajena. es la unica via de
    recuperacion si alguien se equivoca al tipear su clave al crearla --
    no hay autoservicio de "olvide mi clave" todavia. el valor nuevo
    nunca se guarda en la auditoria, solo el hecho de que cambio."""
    try:
        usuarios.cambiar_clave(id_usuario, datos.clave)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    auditoria.registrar(quien, "cambiar_clave_usuario", {"id": id_usuario})
    return JSONResponse({"ok": True})


@router.get("/auditoria", dependencies=[Depends(_requiere_admin_usuarios)])
def leer_auditoria(limite: int = 50):
    return JSONResponse({"acciones": auditoria.listar(min(limite, 1000))})


@router.get("/visitas", dependencies=[Depends(_requiere_admin_usuarios)])
def leer_visitas(limite: int = 10):
    """las ultimas personas que entraron por la puerta "Monitorear" (solo
    nombre, sin cuenta), sin duplicados. ver visitas.py."""
    return JSONResponse({"visitas": visitas.ultimas(max(1, min(limite, 100)))})
