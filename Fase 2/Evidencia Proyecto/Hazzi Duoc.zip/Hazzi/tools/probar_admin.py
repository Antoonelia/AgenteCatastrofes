"""Prueba E2E manual de la API de admin (requiere el server corriendo Y
un usuario de rol "admin" ya creado, ver tools/crear_admin.py).

No entra en `python -m tests` porque necesita un servidor levantado y
una cuenta real; el resto de la suite corre sin red ni procesos
externos. Se corre a mano cuando se toca admin_api.py, sesiones.py o
auth_api.py:

    .venv\\Scripts\\python.exe tools\\crear_admin.py 11111111-1 "Admin Demo" "claveSegura123" admin
    .venv\\Scripts\\python.exe tools\\probar_admin.py 11111111-1 claveSegura123
"""
from __future__ import annotations

import http.cookiejar
import json
import sys
import urllib.error
import urllib.request

BASE = "http://127.0.0.1:8000"

_jar = http.cookiejar.CookieJar()
_opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(_jar))


def pedir(metodo, ruta, cuerpo=None):
    """Devuelve (status, json). No lanza en errores HTTP: los reporta.
    La cookie de sesion viaja sola gracias a _jar una vez logueado."""
    datos = json.dumps(cuerpo).encode() if cuerpo is not None else None
    req = urllib.request.Request(BASE + ruta, data=datos, method=metodo)
    req.add_header("Content-Type", "application/json")
    try:
        with _opener.open(req, timeout=90) as r:
            return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")


def main() -> int:
    if len(sys.argv) < 3:
        print("Uso: probar_admin.py <rut> <clave>")
        return 2
    rut, clave = sys.argv[1], sys.argv[2]
    fallos = 0

    def check(nombre, ok, extra=""):
        nonlocal fallos
        if not ok:
            fallos += 1
        print(f"  {'OK  ' if ok else 'FAIL'} {nombre}{(' -> ' + str(extra)) if extra and not ok else ''}")

    print("\n-- Lectura sin sesion --")
    st, d = pedir("GET", "/api/admin/ajustes")
    check("se puede leer sin sesion", st == 200, st)
    check("trae los 4 umbrales", len(d.get("ajustes", [])) == 4, len(d.get("ajustes", [])))
    check("trae los 4 grupos de radios", len(d.get("radios", [])) == 4)

    print("\n-- Escritura sin sesion --")
    st, _ = pedir("PUT", "/api/admin/ajustes", cuerpo={"magnitud_minima": 5.0})
    check("sin sesion devuelve 401", st == 401, st)

    print("\n-- Login --")
    st, d = pedir("POST", "/api/auth/login", cuerpo={"rut": "11111111-9", "clave": "incorrecta"})
    check("rut/clave invalidos devuelve 401", st == 401, st)
    st, d = pedir("POST", "/api/auth/login", cuerpo={"rut": rut, "clave": clave})
    check("login correcto responde 200", st == 200, st)
    check("devuelve el rol admin", "admin" in d.get("usuario", {}).get("roles", []), d)

    print("\n-- Validacion --")
    st, d = pedir("PUT", "/api/admin/ajustes", cuerpo={"magnitud_minima": 99})
    check("rechaza fuera de rango", st == 400, st)
    check("el error explica el rango", "entre" in str(d.get("detail", "")), d.get("detail"))
    st, _ = pedir("PUT", "/api/admin/ajustes", cuerpo={"inventado": 1})
    check("rechaza clave desconocida", st == 400, st)
    st, _ = pedir("PUT", "/api/admin/ajustes", cuerpo={"ventana_dias": 3, "magnitud_minima": 99})
    check("lote invalido se rechaza entero", st == 400, st)
    _, d = pedir("GET", "/api/admin/ajustes")
    ventana = next(a for a in d["ajustes"] if a["clave"] == "ventana_dias")
    check("el valor valido del lote NO se guardo", ventana["valor"] == 7, ventana["valor"])

    print("\n-- Guardar y persistir --")
    st, d = pedir("PUT", "/api/admin/ajustes", cuerpo={"magnitud_minima": 4.8})
    check("guarda un valor valido", st == 200, st)
    check("devuelve el valor nuevo", d.get("valores", {}).get("magnitud_minima") == 4.8)
    _, d = pedir("GET", "/api/admin/ajustes")
    mag = next(a for a in d["ajustes"] if a["clave"] == "magnitud_minima")
    check("al releer sigue guardado", mag["valor"] == 4.8, mag["valor"])
    check("queda marcado como modificado", mag["modificado"] is True)

    print("\n-- Bitacora de auditoria --")
    st, d = pedir("GET", "/api/usuarios/auditoria")
    check("un admin operativo NO puede leer la bitacora (es de admin_usuarios)", st == 403, st)

    print("\n-- Restablecer --")
    st, _ = pedir("POST", "/api/admin/ajustes/restablecer")
    check("restablece", st == 200, st)
    _, d = pedir("GET", "/api/admin/ajustes")
    mag = next(a for a in d["ajustes"] if a["clave"] == "magnitud_minima")
    check("vuelve al default 3.5", mag["valor"] == 3.5, mag["valor"])
    check("ya no figura como modificado", mag["modificado"] is False)

    print("\n-- Accion manual --")
    st, d = pedir("POST", "/api/admin/refrescar")
    check("dispara la recoleccion", st == 200, st)

    print("\n-- Logout --")
    st, _ = pedir("POST", "/api/auth/logout")
    check("logout responde 200", st == 200, st)
    st, _ = pedir("PUT", "/api/admin/ajustes", cuerpo={"magnitud_minima": 5.0})
    check("tras logout la escritura vuelve a rechazarse", st == 401, st)

    print(f"\n{'TODO OK' if not fallos else str(fallos) + ' FALLO(S)'}\n")
    return 1 if fallos else 0


if __name__ == "__main__":
    sys.exit(main())
