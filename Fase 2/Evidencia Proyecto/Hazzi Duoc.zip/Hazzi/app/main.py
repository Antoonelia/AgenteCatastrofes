"""monitor de catastrofes. walmart chile. api mas servidor web con fastapi."""
from __future__ import annotations

import asyncio
import os
import time
from concurrent.futures import Future, ThreadPoolExecutor
from contextlib import asynccontextmanager
from pathlib import Path
from threading import Lock

from fastapi import Cookie, Depends, FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from . import admin_api, ai_client, auth_api, clima, desastres_globales, diagnostico, dotacion, historial, instalaciones, notificador, sesiones, usuarios, usuarios_api
from .dedup import deduplicar_meteorologicos, deduplicar_sismos
from .fetcher import fetch_many
from .normalize import es_registro, marcar_registros
from .retention import filtrar_eventos
from .sources import REGISTRY, SOURCES_META, conaf, csn, dmc, senapred, sernageomin, usgs
from .stores import build_stores, eventos_con_impacto, stores_at_risk, tiendas_de_evento

_CACHE: dict = {"ts": 0.0, "data": None}

# _recolectar sale a 6 fuentes externas que son conaf sernageomin dmc
# usgs csn y senapred via powershell mas proxy corporativo. medido
# entre 6 y 60 mas segundos por ciclo, muy variable porque depende de
# la latencia de cada api de gobierno. antes /api/events corria esto
# en el hilo del request cada vez que la cache vencia o cuando el
# mapa pedia refrescar=true, cosa que hace solo con el auto refresco
# cada 60 segundos. eso dejaba al usuario esperando hasta 75 segundos.
# ver el timeout del fetch en common.js. ahora un bucle de background
# (ver _bucle_actualizacion) mantiene _cache tibia por su cuenta. el
# request nunca paga ese costo, solo lee lo que ya esta calculado
_REFRESH_INTERVAL = 60  # segundos, igual al auto refresco que ya tenia el mapa
_REFRESH_ESPERA_MAXIMA = 2.0  # techo de espera si piden refrescar=true. deja margen bajo el objetivo de 3 segundos
_REFRESH_EXECUTOR = ThreadPoolExecutor(max_workers=1, thread_name_prefix="hazzi-refresh")
_REFRESH_LOCK = Lock()
_REFRESH_FUTURE: Future | None = None


def _actualizar_cache_en_hilo() -> None:
    """corre _recolectar, que es bloqueante y de red, y guarda el
    resultado en _cache.

    solo debe ejecutarse dentro de _refresh_executor. nunca en el
    hilo de un request ni en el event loop. ver _disparar_refresco."""
    datos = _recolectar()
    _CACHE["data"] = datos
    _CACHE["ts"] = time.time()


def _disparar_refresco() -> Future:
    """arranca una recoleccion en background si no hay una en vuelo.

    devuelve el future en curso, nuevo o el que ya estaba corriendo,
    asi quien llama puede esperarlo con un timeout acotado o ninguno
    sin bloquear al resto del server ni disparar recolecciones
    duplicadas cuando el boton "actualizar" se aprieta mientras otra
    ya esta corriendo."""
    global _REFRESH_FUTURE
    with _REFRESH_LOCK:
        if _REFRESH_FUTURE is None or _REFRESH_FUTURE.done():
            _REFRESH_FUTURE = _REFRESH_EXECUTOR.submit(_actualizar_cache_en_hilo)
        return _REFRESH_FUTURE


async def _bucle_actualizacion() -> None:
    """mantiene _cache tibia para siempre sin que ningun request pague
    el costo de salir a las 6 fuentes externas. ver el comentario
    junto a _refresh_interval. arranca en el startup del server (ver
    lifespan) y nunca termina. cualquier excepcion de un ciclo no debe
    tumbar el bucle."""
    while True:
        try:
            await asyncio.wrap_future(_disparar_refresco())
        except Exception:  # noqa: BLE001 un ciclo fallido no debe matar el bucle
            pass
        await asyncio.sleep(_REFRESH_INTERVAL)


@asynccontextmanager
async def _lifespan(app: FastAPI):
    if not usuarios.existe_alguno():
        print(
            "\n[hazzi] todavia no hay ningun usuario de administracion creado.\n"
            "        el panel admin y el de usuarios quedan inaccesibles hasta\n"
            "        que exista al menos un admin_usuarios. crea el primero con:\n"
            "        .venv\\Scripts\\python.exe tools\\crear_admin.py\n"
        )
    tarea = asyncio.create_task(_bucle_actualizacion())
    try:
        yield
    finally:
        tarea.cancel()


app = FastAPI(title="Agente Hazzi - Walmart Chile", lifespan=_lifespan)

_STATIC = Path(__file__).parent / "static"


class _StaticSinPaginas(StaticFiles):
    """sirve /static (js, css, imagenes) pero nunca paginas html: todas se
    entregan por sus rutas (/inicio, /admin...), y las de admin exigen
    sesion y rol. sin esto bastaba pedir /static/admin.html para saltarse
    la guarda. los .js y .css de admin no son secretos, el dato real
    vive detras de la api, que ya valida el rol.

    se normaliza el nombre antes de mirar la extension porque en windows
    "admin.html.", "admin.html " y "admin.html::$DATA" abren el mismo
    archivo que "admin.html"."""

    async def get_response(self, path: str, scope):
        nombre = Path(path).name.lower().split(":", 1)[0].rstrip(". ")
        if nombre.endswith((".html", ".htm")):
            raise HTTPException(status_code=404)
        return await super().get_response(path, scope)


app.mount("/static", _StaticSinPaginas(directory=_STATIC), name="static")


@app.middleware("http")
async def _cabeceras_de_seguridad(request: Request, call_next):
    respuesta = await call_next(request)
    respuesta.headers.setdefault("X-Content-Type-Options", "nosniff")
    respuesta.headers.setdefault("X-Frame-Options", "DENY")
    # strict-origin-when-cross-origin (el default de los navegadores): a otros
    # dominios solo viaja el origen, nunca la ruta. same-origin lo quitaba por
    # completo y los servidores de teselas del mapa (OpenStreetMap) rechazan
    # con "Access blocked" toda peticion sin referer
    respuesta.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    return respuesta


# fuentes que salen a internet via powershell. todas menos senapred,
# que usa aws appsync directo (ver senapred_client.py). cada una
# expone urls_requeridas para que _urls_powershell las pida todas
# juntas en un solo proceso (ver fetcher.fetch_many) en vez de una vez
# por fuente
_FUENTES_POWERSHELL = (conaf, sernageomin, dmc, usgs, csn)


def _urls_powershell() -> list[str]:
    urls: list[str] = []
    for mod in _FUENTES_POWERSHELL:
        urls.extend(mod.urls_requeridas())
    return urls


def _agregar_dotacion(tiendas_riesgo: list[dict]) -> None:
    """enriquece cada tienda en riesgo con su dotacion de colaboradores.

    usa el modelo de estimacion por formato de tienda, que es la
    fuente de datos definitiva para esta version del proyecto. ver
    dotacion.py. si la base de datos no esta disponible por cualquier
    motivo simplemente no agrega el campo. no debe tumbar el resto
    del calculo de riesgo."""
    try:
        dotacion.asegurar_datos(build_stores())
        por_direccion = dotacion.obtener_todas()
    except Exception:  # noqa: BLE001
        return
    for t in tiendas_riesgo:
        clave = dotacion.clave(t.get("direccion", ""), t.get("formato", ""))
        info = por_direccion.get(clave)
        if info:
            t["colaboradores"] = info["cantidad_colaboradores"]
            t["colaboradores_estimado"] = bool(info["es_estimado"])


# url publica del dashboard, opcional. si esta configurada las
# alertas que salen por teams o whatsapp incluyen un boton o link
# "ver en hazzi" (ver notificador.alerta_desde_tiendas). sin ella la
# alerta sale igual, solo sin el link. no es un requisito para
# notificar, es un extra
_BASE_URL = os.environ.get("HAZZI_BASE_URL", "")


def _notificar_eventos(eventos: list[dict], tiendas: list[dict], total_en_riesgo: int) -> None:
    """dispara una notificacion por cada evento que afecta al menos una
    tienda. ver notificador.py.

    hasta esta funcion el modulo notificador.py existia completo y
    probado con 18 tests pero nadie lo llamaba desde el ciclo real de
    recoleccion. quedaba pendiente en
    docs/wellbeing/04-notificaciones.md. el canal se elige solo con
    la variable de entorno notificador (ver ese modulo). sin
    configurar nada, notificar usa "consola" y no manda nada de
    verdad.

    la clave de identidad reusa historial.clave_evento, la misma que
    ya usa el historial, en vez de inventar una nueva. sin esto un
    titulo que cambia solo entre ciclos, por ejemplo senapred
    agregandole el fenomeno detectado a mitad de vida de la alerta,
    generaria una clave distinta en cada ciclo de 60 segundos y la
    ventana anti repeticion de notificador.py nunca se activaria.

    total_en_riesgo es el total global de tiendas en riesgo en este
    ciclo, que es len(tiendas_riesgo) ya deduplicado. una tienda que
    cae en el radio de dos eventos cuenta una sola vez ahi. se le pasa
    a cada alerta en vez de dejar que cada una muestre sus propias
    tiendas afectadas. mandar una alerta con 45 tiendas y otra con 9
    cuando el total real sin duplicados es 46 es mas confuso que util.
    antonella lo pidio despues de toparse con ese numero que no
    cuadraba.

    es best effort por evento. un fallo en uno no debe frenar los
    demas ni tumbar el ciclo de recoleccion. notificar ya no lanza
    excepcion por su cuenta, pero armar la alerta si podria, si un
    evento viene con datos raros."""
    for e in eventos:
        afectadas = tiendas_de_evento(e, tiendas)
        if not afectadas:
            continue
        try:
            evento_con_id = {**e, "id": historial.clave_evento(e)}
            alerta = notificador.alerta_desde_tiendas(
                evento_con_id, afectadas, _BASE_URL, total_en_riesgo=total_en_riesgo
            )
            notificador.notificar(alerta)
        except Exception:  # noqa: BLE001 un evento raro no puede tumbar el ciclo
            pass


def _recolectar() -> dict:
    eventos: list[dict] = []
    errores: dict[str, str] = {}
    _inicio = time.time()
    # cuantos eventos trajo cada fuente antes de deduplicar y filtrar.
    # es lo unico que distingue "la fuente no contesta" de "no hay
    # emergencias", que en el dashboard se ven igual. ver diagnostico.py
    _crudos_por_fuente: dict[str, int] = {}

    # descarga en bloque. todas las fuentes powershell (ver
    # _fuentes_powershell) se piden en un solo proceso, en paralelo
    # con senapred, que usa aws appsync, un transporte totalmente
    # distinto. asi el arranque de powershell.exe (unos 1.5 a 2
    # segundos medido) se paga una vez por ciclo entero, no una vez
    # por fuente. antes esto hacia que /api/events?refrescar=true
    # tardara 8 mas segundos. cada fuente sigue sabiendo pedir su
    # propia url si el lote falla. ver fetcher.fetch_many y cada
    # sources/*.py
    prefetched: dict[str, str] = {}
    with ThreadPoolExecutor(max_workers=2) as pool:
        fut_prefetch = pool.submit(fetch_many, _urls_powershell())
        fut_senapred = pool.submit(senapred.fetch_events)
        try:
            prefetched = fut_prefetch.result()
        except Exception as exc:  # noqa: BLE001
            errores["prefetch"] = str(exc)[:150]
        try:
            _senapred = [e.to_dict() for e in fut_senapred.result()]
            _crudos_por_fuente["SENAPRED"] = len(_senapred)
            eventos.extend(_senapred)
        except Exception as exc:  # noqa: BLE001
            errores["SENAPRED"] = str(exc)[:150]

    for nombre, fn in REGISTRY.items():
        if nombre == "SENAPRED":
            continue  # ya se corrio arriba en paralelo con el prefetch
        try:
            _de_fuente = [e.to_dict() for e in fn(prefetched)]
            _crudos_por_fuente[nombre] = len(_de_fuente)
            eventos.extend(_de_fuente)
        except Exception as exc:  # noqa: BLE001
            errores[nombre] = str(exc)[:150]

    # sismos aparecen en usgs y csn a la vez. quitar duplicados. gana el csn
    eventos = deduplicar_sismos(eventos)

    # meteorologicos. si dmc y senapred reportan la misma alerta,
    # mismo fenomeno mas region, quitar duplicados. gana senapred que
    # es la fuente oficial
    eventos = deduplicar_meteorologicos(eventos)

    # sismos chicos bajo m4. sismicidad de fondo. no pasan por
    # vigentes en ningun momento. se apartan aca y se archivan directo
    # mas abajo
    eventos = marcar_registros(eventos)
    registros = [e for e in eventos if es_registro(e)]
    eventos = [e for e in eventos if not es_registro(e)]

    # retencion. descartar lo que ya ocurrio y perdio relevancia por tipo y edad
    vigentes = filtrar_eventos(eventos)

    # todo sismo que la fuente trajo pero que no quedo vigente igual
    # se guarda. su ventana de vigencia es corta, entre 12 y 48 horas
    # segun magnitud, y la fuente entrega los ultimos 7 dias, asi que
    # un m5.2 de anteayer llegaria ya vencido. sin esto no se
    # archivaria nunca. justo los sismos fuertes, que son los que
    # importan, no dejarian rastro en el historial
    _vigentes = {id(e) for e in vigentes}
    registros += [e for e in eventos if e.get("tipo") == "sismo" and id(e) not in _vigentes]
    eventos = vigentes

    # verdes fuera. no son el foco del sistema, ni mapa ni tabla ni
    # contadores. se descartan aca, en el unico punto de recoleccion,
    # para que ninguna fuente tenga que saberlo por su cuenta
    eventos = [e for e in eventos if e.get("severidad") != "verde"]

    # cruce con tiendas para ver cuales quedan en riesgo. de paso se
    # descarta cualquier evento que no tenga ninguna sucursal cerca.
    # si no afecta al negocio no le interesa a la vista operativa,
    # osea mapa tabla y contadores
    tiendas_riesgo: list[dict] = []
    total_tiendas = 0
    try:
        # build_stores da la base de lider ya cacheada. instalaciones.aplicar
        # le superpone las correcciones manuales y suma oficinas cds y
        # plantas. operativas deja fuera las cerradas porque alertar
        # por un local vacio es ruido. ver estados en instalaciones.py
        tiendas = instalaciones.operativas(instalaciones.aplicar(build_stores()))
        total_tiendas = len(tiendas)
        antes_de_tiendas = eventos
        eventos = eventos_con_impacto(eventos, tiendas)
        # el historial es otra cosa. un evento real como un sismo m4.5
        # no deja de haber pasado solo porque no habia ninguna tienda
        # cerca. tratarlo como registro, igual que un sismo bajo m4
        # visto mas arriba, es lo que corresponde. entra directo al
        # historial como contexto en vez de mostrarse en la vista
        # operativa. ojo: no se puede meter en vigentes porque
        # registrar_ciclo marca eso como vigente en true en la base,
        # que es justo lo que excluye a un evento del historial (que
        # solo muestra vigente en false). ese fue el bug la primera
        # vez que se intento este fix
        sin_tienda_cerca = {id(e) for e in antes_de_tiendas} - {id(e) for e in eventos}
        registros += [e for e in antes_de_tiendas if id(e) in sin_tienda_cerca]
        tiendas_riesgo = stores_at_risk(eventos, tiendas)
        _agregar_dotacion(tiendas_riesgo)
        _notificar_eventos(eventos, tiendas, len(tiendas_riesgo))
    except Exception as exc:  # noqa: BLE001
        errores["tiendas"] = str(exc)

    # historial. ver historial.py. archiva lo que dejo de estar
    # vigente, guarda los registros que nunca pasan por vigentes y
    # purga lo vencido. es best effort. si la base no esta disponible
    # no debe tumbar /api/events
    try:
        historial.registrar_ciclo(eventos, registros)
    except Exception:  # noqa: BLE001
        pass

    # id estable por evento. reusa clave_evento, la misma llave que ya
    # usa historial/notificador para no confundir un aviso que sigue
    # vigente con uno nuevo entre ciclos. antes /api/events no traia
    # ningun id y el front no tenia forma de recordar "ya vi este
    # evento" sin inventar una clave fragil a partir del titulo
    for e in eventos:
        e["id"] = historial.clave_evento(e)

    # resumen por severidad para los dashboards sobre los eventos ya filtrados
    resumen: dict[str, int] = {}
    for e in eventos:
        resumen[e["severidad"]] = resumen.get(e["severidad"], 0) + 1

    # best effort. el diagnostico observa al sistema, no puede romperlo
    try:
        diagnostico.registrar(
            duracion_s=time.time() - _inicio,
            por_fuente=_crudos_por_fuente,
            errores=errores,
            total_vigentes=len(eventos),
            tiendas_en_riesgo=len(tiendas_riesgo),
        )
    except Exception:  # noqa: BLE001
        pass

    return {
        "total": len(eventos),
        "por_severidad": resumen,
        "fuentes": SOURCES_META,
        "eventos": eventos,
        "tiendas_en_riesgo": tiendas_riesgo,
        "total_tiendas": total_tiendas,
        "errores": errores,
    }


@app.get("/api/events")
def events(refrescar: bool = False):
    if _CACHE["data"] is None:
        # primerisima vez desde que arranco el server. todavia no hay
        # nada que devolver asi que si o si hay que esperar una
        # recoleccion. el bucle de background (ver _bucle_actualizacion)
        # ya la dispara solo, esto nada mas se sube al mismo future en
        # vez de duplicarla
        _disparar_refresco().result()
    elif refrescar:
        # mejor esfuerzo. si la recoleccion en curso, o una nueva si
        # no habia ninguna, termina rapido se devuelve fresca. si no,
        # se devuelve la cache tal cual esta, nunca mas vieja que
        # _refresh_interval, en vez de bloquear al usuario los 6 a 60
        # mas segundos que puede tardar salir a las fuentes externas.
        # ver fetcher.py
        try:
            _disparar_refresco().result(timeout=_REFRESH_ESPERA_MAXIMA)
        except Exception:  # noqa: BLE001 timeout o error. nos quedamos con la cache
            pass
    return JSONResponse(_CACHE["data"])


@app.get("/api/historial")
def historial_eventos():
    try:
        return JSONResponse({"eventos": historial.obtener_historial()})
    except Exception as exc:  # noqa: BLE001
        return JSONResponse({"error": str(exc)}, status_code=503)


@app.get("/api/historias/global")
def historias_global():
    # separado de /api/events a proposito. ver desastres_globales.py:
    # gdacs no entra al pipeline domestico, asi que no comparte cache ni
    # refresco de fondo con el. siempre 200, el error si lo hay viaja
    # adentro del cuerpo para que la historia se pinte en gris en vez de
    # romper el resto del inicio
    return JSONResponse(desastres_globales.obtener())


@app.get("/api/clima")
def clima_endpoint(comuna: str | None = None, lat: float | None = None, lon: float | None = None):
    """comuna y temperatura para el chip de inicio.

    se puede pedir por nombre de comuna, el camino normal donde el
    usuario la elige de la lista, o por coordenadas. la
    geolocalizacion del navegador esta bloqueada por politica
    corporativa de chrome en esta red, por eso el camino principal es
    la comuna. pero el de coordenadas queda listo por si algun dia se
    habilita.

    la consulta la hace el backend y no el navegador porque en la red
    corporativa el front no llega directo a internet. ver fetcher.py."""
    try:
        if comuna:
            return JSONResponse(clima.clima_de_comuna(comuna))
        if lat is None or lon is None:
            return JSONResponse({"error": "indica una comuna o lat/lon"}, status_code=422)
        if not (-90 <= lat <= 90 and -180 <= lon <= 180):
            return JSONResponse({"error": "coordenadas fuera de rango"}, status_code=422)
        return JSONResponse(clima.clima_actual(lat, lon))
    except ValueError as exc:
        return JSONResponse({"error": str(exc)}, status_code=404)
    except Exception as exc:  # noqa: BLE001
        return JSONResponse({"error": str(exc)}, status_code=503)


@app.get("/api/clima-regiones")
def clima_regiones_endpoint():
    """clima actual con temperatura e icono de las 16 regiones de
    chile de una sola pasada. lo usa el cartel de clima por region del
    mapa. ver mapa.html pintarClimaRegiones. nunca falla del todo. una
    region sin datos queda con sus campos en none y no tumba a las
    otras 15."""
    try:
        return JSONResponse(clima.clima_regiones())
    except Exception as exc:  # noqa: BLE001
        return JSONResponse({"error": str(exc)}, status_code=503)


@app.get("/api/comunas")
def comunas():
    """comunas elegibles en el chip de clima. las que tienen tienda."""
    try:
        return JSONResponse(clima.comunas_disponibles())
    except Exception as exc:  # noqa: BLE001
        return JSONResponse({"error": str(exc)}, status_code=503)


@app.get("/api/stores")
def stores():
    """instalaciones para el mapa. lider corregido mas altas manuales.

    sin las cerradas, por la misma razon que en el calculo de riesgo.
    no tiene sentido dibujar en el mapa operativo un local que ya no
    opera."""
    try:
        return JSONResponse(instalaciones.operativas(instalaciones.aplicar(build_stores())))
    except Exception as exc:  # noqa: BLE001
        return JSONResponse({"error": str(exc)}, status_code=503)


@app.get("/api/resumen-ejecutivo")
def resumen_ejecutivo():
    """resumen en lenguaje natural del estado nacional generado con ia.

    reutiliza el ultimo calculo cacheado por /api/events y no
    dispara una recoleccion nueva. ver ai_client.py. por defecto
    corre en modo mock sin llamar a ningun servicio externo. si se
    configura gemini_api_key y ai_provider en gemini usa un llm real,
    degradando a mock si algo falla."""
    datos = _CACHE["data"] or _recolectar()
    resultado = ai_client.resumen_ejecutivo(
        datos.get("por_severidad", {}),
        datos.get("total", 0),
        datos.get("tiendas_en_riesgo", []),
    )
    return JSONResponse(resultado)


@app.get("/api/diagnostico", dependencies=[Depends(sesiones.requiere_rol("admin"))])
def diagnostico_endpoint():
    """salud interna del sistema para la pantalla de admin. solo lectura."""
    try:
        return JSONResponse(diagnostico.resumen())
    except Exception as exc:  # noqa: BLE001
        return JSONResponse({"error": str(exc)}, status_code=503)


@app.get("/")
def portada():
    """puerta de entrada para elegir monitorear o administrar.

    monitorear sigue sin pedir cuenta (ver sesion.js y visitas.py).
    administrar ahora exige rut + clave reales contra usuarios.py, con
    sesion server-side (ver sesiones.py y auth_api.py). la proteccion
    real vive ahi, no en el navegador."""
    return FileResponse(_STATIC / "portada.html")


@app.get("/inicio")
def index():
    return FileResponse(_STATIC / "index.html")


@app.get("/mapa")
def mapa_page():
    return FileResponse(_STATIC / "mapa.html")


@app.get("/tiendas")
def tiendas_page():
    return FileResponse(_STATIC / "tiendas.html")


@app.get("/eventos")
def eventos_page():
    return FileResponse(_STATIC / "eventos.html")


@app.get("/historial")
def historial_page():
    return FileResponse(_STATIC / "historial.html")


@app.get("/estadisticas")
def estadisticas_page():
    return FileResponse(_STATIC / "estadisticas.html")


def _pagina_con_rol(archivo: str, rol: str):
    """pantalla que solo se entrega con sesion valida y el rol pedido.
    sin sesion va a la portada, con sesion pero sin el rol va a /inicio:
    mismo destino que ya usaba exigirSesion en el navegador, pero ahora
    lo decide el servidor y no se puede saltar editando sessionStorage.
    no-store: la respuesta depende de la cookie, no debe quedar en cache."""

    def _handler(hazzi_sesion: str | None = Cookie(default=None)):
        usuario = sesiones.obtener_usuario(hazzi_sesion)
        if usuario is None:
            return RedirectResponse("/", status_code=302)
        if rol not in usuario["roles"]:
            return RedirectResponse("/inicio", status_code=302)
        return FileResponse(_STATIC / archivo, headers={"Cache-Control": "no-store"})

    return _handler


app.add_api_route("/admin", _pagina_con_rol("admin.html", "admin"), methods=["GET"])
app.add_api_route("/admin/ajustes", _pagina_con_rol("admin-ajustes.html", "admin"), methods=["GET"])
app.add_api_route("/admin/instalaciones", _pagina_con_rol("admin-instalaciones.html", "admin"), methods=["GET"])
app.add_api_route("/admin/usuarios", _pagina_con_rol("admin-usuarios.html", "admin_usuarios"), methods=["GET"])


# login/logout/sesion actual (auth_api.py) y alta/baja de usuarios mas
# bitacora de auditoria (usuarios_api.py). separados de admin_api.py
# porque responden a un rol distinto, admin_usuarios, ver usuarios.py
app.include_router(auth_api.router)
app.include_router(usuarios_api.router)

# endpoints de administracion para leer y editar umbrales y refrescar
# fuentes. viven en admin_api.py. se les inyecta el disparador de
# recoleccion para evitar un import circular con este modulo
admin_api.montar(app, _disparar_refresco)
