"""regression test. un evento sin impacto en tiendas no debe
desaparecer del historial, solo de la vista operativa (mapa, tabla,
contadores).

caso real que motiva esto: un sismo m4.5 real, "69 km al e de
quillagua" en pleno desierto de atacama, paso todos los filtros de
retencion (reciente, por sobre el umbral de alerta), pero como ninguna
tienda cae en su radio de dano potencial, eventos_con_impacto lo
descartaba antes de que historial.registrar_ciclo llegara a verlo.
resultado: el sismo desaparecia del sistema entero, ni siquiera
quedaba registrado en el historial, contradiciendo la razon de ser del
propio historial. ver su docstring, que dice que sirve de contexto
para ver secuencias sismicas, independientemente de si afecta o no a
una tienda.

este test reemplaza a mano, sin pytest, porque el runner casero de
tests no soporta fixtures, todas las fuentes externas (red, db) para
poder correr _recolectar de punta a punta y verificar que el sismo si
llegue a historial.registrar_ciclo aunque no llegue a la lista de
eventos vigentes que ve el frontend."""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime

from app import area as area_mod
from app import main as main_mod
from app.normalize import Event

_FMT = "%d-%m-%Y %H:%M hrs"
_TITULO_SISMO = "M4.5 - 69 km al E de Quillagua"

# quillagua, desierto de atacama. sin ninguna tienda cerca, a proposito
_LAT_SISMO, _LON_SISMO = -21.413, -68.923
# una tienda bien lejos, santiago. no debe caer en el radio de dano del sismo
_TIENDA_LEJANA = {
    "formato": "Lider", "comuna": "Santiago", "direccion": "Test 123",
    "region": "Metropolitana", "lat": -33.45, "lon": -70.65, "precision": "direccion",
}


def _ahora_chile_str() -> str:
    """igual que retention.py _ahora_cl pero formateada, asi el test no
    depende de en que zona horaria este configurado el reloj de la
    maquina que lo corre."""
    try:
        from zoneinfo import ZoneInfo
        ahora = datetime.now(ZoneInfo("America/Santiago")).replace(tzinfo=None)
    except Exception:  # noqa: BLE001
        ahora = datetime.now()
    return ahora.strftime(_FMT)


def _sismo_quillagua() -> Event:
    return Event(
        source="CSN",
        tipo="sismo",
        titulo=_TITULO_SISMO,
        severidad="amarilla",
        lat=_LAT_SISMO,
        lon=_LON_SISMO,
        fecha=_ahora_chile_str(),  # "ahora" en hora de chile. pasa retencion sin importar donde corra el test
        detalle="Magnitud 4.5",
        area=area_mod.por_sismo(4.5),
    )


@contextmanager
def _parcheado(obj, nombre, valor_nuevo):
    """reemplaza obj.nombre por valor_nuevo y lo restaura al salir, aunque falle."""
    original = getattr(obj, nombre)
    setattr(obj, nombre, valor_nuevo)
    try:
        yield
    finally:
        setattr(obj, nombre, original)


def test_sismo_sin_tienda_cerca_igual_llega_al_historial():
    capturado: dict = {}

    def _fake_registrar_ciclo(vigentes, registros=None):
        capturado["vigentes"] = vigentes
        capturado["registros"] = registros or []

    # una sola fuente "real", el sismo de quillagua, un event y no un dict
    # porque main.py llama .to_dict() el mismo por cada item que devuelve
    # una fuente. el resto de las fuentes y toda salida a red o db quedan
    # reemplazadas para poder correr _recolectar de punta a punta sin
    # internet
    with _parcheado(main_mod, "REGISTRY", {"CSN": lambda prefetched: [_sismo_quillagua()]}), \
         _parcheado(main_mod, "fetch_many", lambda urls: {}), \
         _parcheado(main_mod.senapred, "fetch_events", lambda: []), \
         _parcheado(main_mod, "build_stores", lambda: [_TIENDA_LEJANA]), \
         _parcheado(main_mod, "_agregar_dotacion", lambda tiendas_riesgo: None), \
         _parcheado(main_mod.historial, "registrar_ciclo", _fake_registrar_ciclo):
        resultado = main_mod._recolectar()

    # la vista operativa, mapa tabla y contadores, no debe mostrarlo.
    # ninguna tienda esta en riesgo real
    assert not any(e["titulo"] == _TITULO_SISMO for e in resultado["eventos"]), \
        "el sismo sin tiendas cerca no deberia aparecer en la vista operativa"

    # pero el historial si debe haberlo recibido. ese es el fix
    todo_lo_que_vio_historial = capturado["vigentes"] + capturado["registros"]
    assert any(e["titulo"] == _TITULO_SISMO for e in todo_lo_que_vio_historial), \
        "el sismo debe llegar al historial aunque no afecte a ninguna tienda"
