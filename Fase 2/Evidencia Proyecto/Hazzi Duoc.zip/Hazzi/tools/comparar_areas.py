"""Comparativa vieja-vs-nueva sobre casos reales del historial.

Hoy hay pocos eventos vigentes, asi que la comparacion se hace sobre eventos
que YA ocurrieron (guardados en el historial) mas casos sinteticos de sismo,
para poder ver el efecto del cambio en cada tipo de evento.
"""
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from app import area, historial
from app.stores import _alcance, build_stores, haversine

tiendas = build_stores()


def comparar(e, etiqueta):
    viejo = sum(1 for t in tiendas if haversine(e["lat"], e["lon"], t["lat"], t["lon"]) <= 30)
    nuevo = sum(1 for t in tiendas if _alcance(e, t) is not None)
    a = e.get("area") or {}
    desc = f"poligono({len(a['anillos'])})" if a.get("forma") == "poligono" else f"{a.get('radio_km', 30)} km"
    flecha = "=" if viejo == nuevo else ("^" if nuevo > viejo else "v")
    print(f"{etiqueta:<46} {desc:<14} {viejo:>5} {flecha:^3} {nuevo:<5}")


print(f"{'caso':<46} {'area nueva':<14} {'viejo':>5} {'':^3} {'nuevo':<5}")
print("-" * 78)

# --- Sismos: el caso mas claro, el radio depende de la magnitud -------------
# Epicentro real frente a Valparaiso, variando solo la magnitud.
for mag in (4.2, 5.4, 6.5, 7.4, 8.2):
    e = {"lat": -33.05, "lon": -71.62, "area": area.por_sismo(mag)}
    comparar(e, f"sismo M{mag} frente a Valparaiso")

print()
# --- Incendios: hectareas reales que informa CONAF --------------------------
for ha, activo in ((5.0, True), (120.0, True), (3000.0, True), (120.0, False)):
    e = {"lat": -33.05, "lon": -71.5, "area": area.por_incendio(ha, activo)}
    estado = "en combate" if activo else "controlado"
    comparar(e, f"incendio {ha:.0f} ha ({estado}) cerca de Valparaiso")

print()
# --- Volcanes ---------------------------------------------------------------
for sev in ("amarilla", "naranja", "roja"):
    e = {"lat": -33.05, "lon": -71.5, "area": area.por_volcan(sev)}
    comparar(e, f"volcan en alerta {sev}")

print()
# --- Alertas SENAPRED reales del historial: la comuna vs el circulo ---------
try:
    previos = [h for h in historial.obtener_historial() if h.get("lat") and h.get("area")]
except Exception as exc:  # noqa: BLE001
    previos = []
    print(f"(historial no disponible: {exc})")
for h in previos[:12]:
    comparar(h, f"{h['tipo']}: {(h.get('comuna') or h.get('region') or '')[:34]}")
if not previos:
    print("(sin eventos con area en el historial todavia -- se llenara en los proximos ciclos)")
