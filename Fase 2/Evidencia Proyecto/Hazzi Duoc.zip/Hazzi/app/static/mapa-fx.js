/* mapa-fx.js. efectos visuales amigables al hacer click en una alerta del
   mapa: lluvia, hojas al viento, nieve, temblor, ascuas, humo de volcan, sol
   de alerta por calor.
   100% cosmetico. si algo aca falla nunca debe romper el mapa ni el modal.
   separado de mapa.html, ya al limite de tamano, para mantener cohesion.

   ojo: el shake y el glow se aplican a #map y no a .map-wrap, porque
   .map-wrap ya trae la clase .reveal con su propia animacion de entrada,
   fadeUp. si le pisamos el animation shorthand con otra animacion el
   fade-in se corta y se reinicia al terminar el efecto, el mapa se borra
   y reaparece. #map no tiene animacion propia asi que ahi el shake no
   choca con nada. */

const _PATRONES_FENOMENO = [
  ["viento", /viento|ventisca|vendaval/i],
  ["nieve", /nieve|nevada|nival/i],
  ["calor", /calor|temperatura|caluroso|t[eé]rmic/i],
  ["lluvia", /lluvia|precipita|chubasco|marejada|temporal/i],
];

function _fenomenoDeEvento(e) {
  if (!e) return null;
  const directo = (e.fenomeno || "").toLowerCase().trim();
  if (directo) return directo;
  const texto = [e.titulo, e.detalle, e.riesgo, e.contenido, e.descripcion]
    .filter(Boolean)
    .join(" ");
  for (const [nombre, patron] of _PATRONES_FENOMENO) {
    if (patron.test(texto)) return nombre;
  }
  return null;
}


let _fxTimers = [];
function _fxLimpiarTimers() {
  _fxTimers.forEach(clearTimeout);
  _fxTimers = [];
}

// se llama al cerrar el modal o antes de disparar un efecto nuevo, para
// que no queden particulas de una alerta anterior mezcladas con la siguiente
function limpiarEfectoAlerta() {
  _fxLimpiarTimers();
  const layer = document.getElementById("fx-layer");
  if (layer) layer.innerHTML = "";
  const mapa = document.getElementById("map");
  if (mapa) mapa.classList.remove("fx-temblor", "fx-glow-rojo");
}

function _fxEl(clase) {
  const el = document.createElement("div");
  el.className = clase;
  return el;
}

function _fxGota(layer) {
  const g = _fxEl("fx-gota");
  g.style.left = Math.random() * 100 + "vw";
  // lluvia a pedido, que se note. rango de duracion mas corto para que
  // la caida sea mas rapida y delay mas apretado para que, sumado a la
  // cantidad de gotas, se vea densa y torrencial
  g.style.animationDuration = (0.4 + Math.random() * 0.3) + "s";
  g.style.animationDelay = Math.random() * 0.9 + "s";
  layer.appendChild(g);
}

// tinte de atmosfera sobre todo el mapa, usado por lluvia fuerte y calor,
// para que el efecto se sienta ademas de verse. es una capa de color de
// fondo, sin bloquear clicks porque fx-layer entero ya es pointer-events none
function _fxTinte(layer, clase) {
  layer.appendChild(_fxEl(clase));
}

// card de referencia para que el sol nazca justo ahi. el modal de detalle
// si esta abierto, abrirDetalle lo muestra antes de llamar a
// dispararEfectoAlerta asi que ya esta en el dom, y si no el popup del
// marcador que este visible. si no hay ninguna devuelve null y _fxSol cae
// a un centro por defecto
function _cardReferencia() {
  const modal = document.getElementById("modal");
  if (modal && !modal.classList.contains("hidden")) {
    const box = modal.querySelector(".modal-box");
    if (box) return box.getBoundingClientRect();
  }
  const popup = document.querySelector(".leaflet-popup");
  return popup ? popup.getBoundingClientRect() : null;
}

// sol chico mas rayos girando mas tinte calido. nace pegado al borde
// izquierdo de la card de la alerta, sale hacia la izquierda y vuelve a
// esconderse detras de ella en un viaje de 5 segundos, ver la animacion
// fx-sol-viaje en mapa.html. el 5100 de abajo en dispararEfectoAlerta
// tiene que ir de la mano con la duracion de esa animacion, si se cambia
// una se cambia la otra
function _fxSol(layer) {
  _fxTinte(layer, "fx-calor-tinte");
  const wrap = _fxEl("fx-sol-wrap");
  const rect = _cardReferencia();
  const x = rect ? rect.left : window.innerWidth * 0.5;
  const y = rect ? rect.top + rect.height / 2 : window.innerHeight * 0.3;
  wrap.style.setProperty("--sol-x", x + "px");
  wrap.style.setProperty("--sol-y", y + "px");
  wrap.appendChild(_fxEl("fx-rayo"));
  wrap.appendChild(_fxEl("fx-sol"));
  layer.appendChild(wrap);
}

// alertas senapred de tipo alerta. a diferencia del sol de calor esto no
// viaja por la pantalla, aparece de golpe con un pop estilo comic, ver
// @keyframes fx-excl-pop en mapa.html, ya posicionado afuera de la card en
// diagonal arriba izquierda desde su esquina superior izquierda. misma
// direccion general que el sol, hacia la izquierda, pero mas corto y en
// diagonal, y sin nunca pisar la card. por eso el ancla es rect.top, el
// borde superior, no el centro vertical como el sol. son directamente dos
// signos de exclamacion sin fondo circular, coloreados segun severidad,
// amarillo para amarilla y rojo para roja, con un brillo mas tenue que el
// del sol de calor, ver .fx-excl en mapa.html
function _fxExclamacion(layer, color, glow) {
  const wrap = _fxEl("fx-excl-wrap");
  const rect = _cardReferencia();
  const x = rect ? rect.left : window.innerWidth * 0.5;
  const y = rect ? rect.top : window.innerHeight * 0.3;
  wrap.style.setProperty("--sol-x", x + "px");
  wrap.style.setProperty("--sol-y", y + "px");
  wrap.style.setProperty("--excl-color", color);
  wrap.style.setProperty("--excl-glow", glow);
  const bola = _fxEl("fx-excl");
  bola.innerHTML = '<svg viewBox="0 0 40 24">'
    + '<rect x="9.5" y="1" width="5" height="13.5" rx="2.5"/><circle cx="12" cy="19.5" r="2.8"/>'
    + '<rect x="25.5" y="1" width="5" height="13.5" rx="2.5"/><circle cx="28" cy="19.5" r="2.8"/>'
    + '</svg>';
  wrap.appendChild(bola);
  layer.appendChild(wrap);
}

// hojas volando con el viento. forma de hoja hecha con css, sin emojis,
// color variable entre verde y ambar para que se vean distintas entre si
function _fxHoja(layer) {
  const h = _fxEl("fx-hoja");
  h.style.top = Math.random() * 80 + "vh";
  h.style.background = Math.random() < 0.5
    ? "linear-gradient(135deg, #86efac, #16a34a)"
    : "linear-gradient(135deg, #fcd34d, #b45309)";
  h.style.setProperty("--giro", (720 + Math.random() * 360) + "deg");
  h.style.setProperty("--sube", (Math.random() * 40 - 60) + "vh");
  h.style.animationDuration = (1.8 + Math.random() * 1.4) + "s";
  h.style.animationDelay = Math.random() * 1 + "s";
  layer.appendChild(h);
}

function _fxCopo(layer) {
  const c = _fxEl("fx-copo");
  c.style.left = Math.random() * 100 + "vw";
  c.style.setProperty("--drift", (Math.random() * 60 - 30) + "px");
  c.style.animationDuration = (2.5 + Math.random() * 2) + "s";
  c.style.animationDelay = Math.random() * 1.5 + "s";
  layer.appendChild(c);
}

function _fxAscua(layer) {
  const a = _fxEl("fx-ascua");
  a.style.left = Math.random() * 100 + "vw";
  a.style.setProperty("--drift", (Math.random() * 50 - 25) + "px");
  a.style.animationDuration = (1.4 + Math.random() * 1) + "s";
  a.style.animationDelay = Math.random() * 1 + "s";
  layer.appendChild(a);
}

// humo saliendo del volcan. puffs grises que crecen y se desvanecen al subir
function _fxHumo(layer) {
  const h = _fxEl("fx-humo");
  h.style.left = (30 + Math.random() * 40) + "vw";   // concentrado hacia el centro
  h.style.setProperty("--drift", (Math.random() * 60 - 30) + "px");
  h.style.animationDuration = (2.2 + Math.random() * 1.6) + "s";
  h.style.animationDelay = Math.random() * 1.4 + "s";
  layer.appendChild(h);
}

// efecto segun el fenomeno meteorologico normalizado que manda el backend,
// ver fenomeno.py: viento, nieve, calor, lluvia como fallback. compartido
// por los eventos meteorologico de dmc y las alertas senapred que traen
// fenomeno detectado. una alerta amarilla por viento se ve y se anima
// igual sea quien sea la fuente que la reporto. devuelve la duracion de
// limpieza en milisegundos
function _fxPorFenomeno(layer, fenomeno) {
  if (fenomeno === "viento") {
    for (let i = 0; i < 14; i++) _fxHoja(layer);
  } else if (fenomeno === "nieve") {
    for (let i = 0; i < 28; i++) _fxCopo(layer);
  } else if (fenomeno === "calor") {
    _fxSol(layer);
    return 5100;   // el viaje del sol, fx-sol-viaje en mapa.html, dura 5s justos
  } else {
    // lluvia, marejada u otro fenomeno sin animacion propia. lluvia por
    // defecto, bien densa a pedido, tinte mas hartas gotas, para que no
    // pase piola
    _fxTinte(layer, "fx-lluvia-tinte");
    for (let i = 0; i < 110; i++) _fxGota(layer);
  }
  return 3200;
}

// dispara el efecto correspondiente segun el tipo de catastrofe del
// evento e. se llama al clickear el marcador de la alerta en el mapa, y
// de nuevo al abrir el detalle, para que se sienta continuo
function dispararEfectoAlerta(e) {
  limpiarEfectoAlerta();
  const layer = document.getElementById("fx-layer");
  if (!layer || !e) return;
  const mapa = document.getElementById("map");
  const fenomeno = _fenomenoDeEvento(e);
  const esRoja = e.severidad === "roja";
  let duracionLimpieza = 3200;   // default. el efecto de calor la pisa mas abajo

  if (esRoja && mapa) mapa.classList.add("fx-glow-rojo");

  if (e.tipo === "sismo") {
    if (mapa) {
      mapa.classList.add("fx-temblor");
      _fxTimers.push(setTimeout(() => mapa.classList.remove("fx-temblor"), 650));
    }
  } else if (e.tipo === "incendio") {
    for (let i = 0; i < 18; i++) _fxAscua(layer);
  } else if (e.tipo === "volcan") {
    for (let i = 0; i < 16; i++) _fxHumo(layer);
    if (mapa) mapa.classList.add("fx-glow-rojo");
  } else if (e.tipo === "meteorologico" || (e.tipo === "alerta" && fenomeno)) {
    // evento meteorologico de dmc, o alerta senapred causada por un
    // fenomeno meteorologico, viento calor etc. misma animacion para
    // ambos casos, da lo mismo quien la reporte, si es viento se ve
    // como viento. el color de severidad, amarilla o roja, ya se ve en
    // la card o el marcador, no hace falta duplicarlo en el efecto
    duracionLimpieza = _fxPorFenomeno(layer, fenomeno);
  } else if (e.tipo === "alerta") {
    // alerta senapred sin fenomeno meteorologico identificado. dos signos
    // de exclamacion coloreados segun severidad, apareciendo con un pop
    // estilo comic, ver _fxExclamacion, dura 1.8s, fx-excl-pop en
    // mapa.html. el resto de las severidades, naranja verde info, se
    // quedan sin efecto por ahora
    if (e.severidad === "roja") {
      _fxExclamacion(layer, "#dc2626", "rgba(220,38,38,.55)");
      duracionLimpieza = 2000;
    } else if (e.severidad === "amarilla") {
      _fxExclamacion(layer, "#f59e0b", "rgba(245,158,11,.55)");
      duracionLimpieza = 2000;
    }
  }

  _fxTimers.push(setTimeout(limpiarEfectoAlerta, duracionLimpieza));
}
