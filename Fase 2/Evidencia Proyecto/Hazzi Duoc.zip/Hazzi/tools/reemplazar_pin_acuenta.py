"""un uso puntual: reemplaza pin-acuenta.png por la foto real del letrero
"SuperBodega aCuenta" que antonella dejo en Downloads, a pedido suyo del
29-09-2026 (solo el pin de acuenta, ningun otro formato).

mismo criterio de recorte que ya usa cortar_pines.py para los otros tres
pines: bbox por canal alpha mas 14px de margen parejo, para que el
drop-shadow (glow) del pin no quede pegado al borde. la foto que dejo ya
venia con fondo transparente real (alpha 0..255), asi que getbbox()
funciona directo, sin necesitar el fallback de "no es casi blanco".

a diferencia de los otros pines, que son arte 3d tipo gota bastante
parejo en ancho y alto, esta foto es un letrero completo con su poste
hasta la base, mucho mas alto que ancho. eso es intencional, la pidio
asi. pinTienda en mapa.html ancla el pin por su punta inferior centrada,
y la base del poste en esta foto cae mas o menos centrada tambien, asi
que el ancla sigue funcionando bien pese a la proporcion distinta."""
from __future__ import annotations

from pathlib import Path

from PIL import Image

ORIGEN = Path.home() / "Downloads" / "acuenta.png"
DESTINO = Path(__file__).resolve().parent.parent / "app" / "static" / "logos" / "pin-acuenta.png"
PADDING = 14


def main() -> None:
    im = Image.open(ORIGEN).convert("RGBA")
    bbox = im.getbbox()
    if bbox:
        x0, y0, x1, y1 = bbox
        x0 = max(0, x0 - PADDING)
        y0 = max(0, y0 - PADDING)
        x1 = min(im.width, x1 + PADDING)
        y1 = min(im.height, y1 + PADDING)
        im = im.crop((x0, y0, x1, y1))
    im.save(DESTINO)
    print(f"pin-acuenta.png: {im.size} -> {DESTINO}")
    print(f"pinRatio nuevo: {im.width} / {im.height} = {im.width / im.height:.4f}")


if __name__ == "__main__":
    main()
