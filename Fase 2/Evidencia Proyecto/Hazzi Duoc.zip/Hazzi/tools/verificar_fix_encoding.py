"""Confirma el fix del encoding: CSN en vivo con las tildes bien, y que las
fuentes JSON (que ya andaban bien) sigan andando."""
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from app.sources import conaf, csn, dmc

MALAS = ("Ã", "Â", "â€")

print("=== CSN (fetch.ps1 via fetch_text) ===")
eventos = csn.fetch_events()
con_acento = [e for e in eventos if not (e.titulo or "").isascii()]
rotos = [e for e in eventos if any(m in (e.titulo or "") for m in MALAS)]
print(f"eventos: {len(eventos)}  con acentos: {len(con_acento)}  rotos: {len(rotos)}")
for e in con_acento[:6]:
    print(f"   {e.titulo}")

print()
print("=== fuentes JSON (no deben haberse roto) ===")
for nombre, fn in (("CONAF", conaf.fetch_events), ("DMC", dmc.fetch_events)):
    try:
        evs = fn()
        print(f"{nombre}: {len(evs)} eventos, sin excepcion")
    except Exception as exc:  # noqa: BLE001
        print(f"{nombre}: FALLO -- {exc}")
