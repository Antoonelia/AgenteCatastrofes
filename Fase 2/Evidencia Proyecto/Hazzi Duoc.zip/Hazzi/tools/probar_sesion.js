/* Tests de sesion.js con Node (hay node v24 instalado, no hace falta browser).
 *
 * Se corre:  node tools\probar_sesion.js
 *
 * Simula sessionStorage/localStorage/location y carga sesion.js real, para
 * verificar el comportamiento que decide QUE VE cada rol.
 */
"use strict";

const fs = require("fs");
const path = require("path");
const vm = require("vm");

const RUTA = path.join(__dirname, "..", "app", "static", "sesion.js");

function almacenFalso() {
  const datos = new Map();
  return {
    getItem: (k) => (datos.has(k) ? datos.get(k) : null),
    setItem: (k, v) => datos.set(k, String(v)),
    removeItem: (k) => datos.delete(k),
    _datos: datos,
  };
}

/** Carga sesion.js en un contexto limpio y devuelve el sandbox. */
function cargar() {
  const ctx = {
    sessionStorage: almacenFalso(),
    localStorage: almacenFalso(),
    location: { href: "/inicio", replace(u) { this.href = u; } },
    fetch: async () => ({ ok: true, json: async () => ({}) }),
    console,
  };
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(RUTA, "utf8"), ctx);
  return ctx;
}

let fallos = 0;
function check(nombre, ok, extra) {
  if (!ok) fallos++;
  console.log(`  ${ok ? "OK  " : "FAIL"} ${nombre}${!ok && extra !== undefined ? " -> " + extra : ""}`);
}

console.log("\n-- Sin sesion --");
{
  const c = cargar();
  check("no hay sesion al arrancar", c.sesionActual() === null);
  check("no es admin", c.esAdmin() === false);
  check("la clave viene vacia", c.claveAdmin() === "");
  c.exigirSesion();
  check("el guardia manda a la portada", c.location.href === "/", c.location.href);
}

console.log("\n-- Usuario de monitoreo --");
{
  const c = cargar();
  check("inicia sesion", c.iniciarSesion("Ana Perez", "usuario") === true);
  check("guarda el nombre", c.sesionActual().nombre === "Ana Perez");
  check("NO es admin", c.esAdmin() === false);
  check("la etiqueta dice Monitoreo", c.etiquetaRol() === "Monitoreo", c.etiquetaRol());
  check("el header lee el mismo nombre", c.localStorage.getItem("userName") === "Ana Perez");

  c.location.href = "/inicio";
  c.exigirSesion();
  check("puede entrar a paginas normales", c.location.href === "/inicio");

  c.location.href = "/admin";
  c.exigirSesion({ admin: true });
  check("NO puede entrar al admin", c.location.href === "/inicio", c.location.href);
}

console.log("\n-- Administrador --");
{
  const c = cargar();
  c.iniciarSesion("Antonella Orellana", "admin", "la-clave");
  check("es admin", c.esAdmin() === true);
  check("la etiqueta dice Administrador", c.etiquetaRol() === "Administrador");
  check("conserva la clave para la API", c.claveAdmin() === "la-clave");

  c.location.href = "/admin";
  c.exigirSesion({ admin: true });
  check("entra al admin sin rebotes", c.location.href === "/admin");
}

console.log("\n-- Ascender de usuario a admin --");
{
  const c = cargar();
  c.iniciarSesion("Ana Perez", "usuario");
  check("asciende conservando el nombre", c.ascenderAAdmin("clave-ok") === true);
  check("ahora es admin", c.esAdmin() === true);
  check("el nombre no cambio", c.sesionActual().nombre === "Ana Perez");
}

console.log("\n-- Cerrar sesion --");
{
  const c = cargar();
  c.iniciarSesion("Ana Perez", "admin", "x");
  c.cerrarSesion();
  check("se borra la sesion", c.sesionActual() === null);
  check("vuelve a la portada", c.location.href === "/");
  check("recuerda el ultimo nombre para prellenar", c.ultimoNombre() === "Ana Perez");
}

console.log("\n-- Entradas invalidas --");
{
  const c = cargar();
  check("rechaza nombre vacio", c.iniciarSesion("   ", "usuario") === false);
  check("rechaza rol inventado", c.iniciarSesion("Ana", "superusuario") === false);
  check("sigue sin sesion", c.sesionActual() === null);
  check("no se puede ascender sin sesion", c.ascenderAAdmin("x") === false);
}

console.log("\n-- Sesion corrupta --");
{
  const c = cargar();
  c.sessionStorage.setItem("hazziSesion", "{no es json");
  check("json roto no revienta", c.sesionActual() === null);
  c.sessionStorage.setItem("hazziSesion", JSON.stringify({ nombre: "X", rol: "root" }));
  check("rol invalido se descarta", c.sesionActual() === null);
  c.sessionStorage.setItem("hazziSesion", JSON.stringify({ rol: "admin" }));
  check("sin nombre se descarta", c.sesionActual() === null);
  check("y por lo tanto no es admin", c.esAdmin() === false);
}

console.log("\n-- La sesion NO sobrevive al cierre del navegador --");
{
  const c = cargar();
  c.iniciarSesion("Ana Perez", "admin", "x");
  // Nueva pestana/navegador: sessionStorage se vacia, localStorage no.
  const c2 = cargar();
  c2.localStorage._datos.set("hazziUltimoNombre", "Ana Perez");
  check("hay que volver a entrar", c2.sesionActual() === null);
  check("pero el nombre queda prellenado", c2.ultimoNombre() === "Ana Perez");
}

console.log(`\n${fallos ? fallos + " FALLO(S)" : "TODO OK"}\n`);
process.exit(fallos ? 1 : 0);
