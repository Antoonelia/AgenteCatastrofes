"""area afectada por evento. que cada tipo use su geometria real y no 30 km fijos.

el caso que motiva todo esto es que antes cualquier evento afectaba un
circulo de 30 km. estos tests fijan que un m4 y un m7 ya no midan lo
mismo, que un incendio de 10 ha no borre media region, y lo mas
importante que una alerta de senapred cubra la comuna real declarada y
no un circulo inventado."""
from __future__ import annotations

from app import area

# providencia. comuna chica de unos 4 km. el circulo de 30 km la desbordaba por lejos
_PROVIDENCIA = [[
    [-70.6362, -33.4498], [-70.5822, -33.4498],
    [-70.5822, -33.4081], [-70.6362, -33.4081], [-70.6362, -33.4498],
]]
_CENTRO_PROV = (-33.4290, -70.6092)


def test_radio_sismo_escala_con_la_magnitud():
    """un m4.2 y un m7.5 no pueden afectar el mismo territorio."""
    r = [area.por_sismo(m)["radio_km"] for m in (4.2, 5.5, 6.5, 7.5, 8.8)]
    assert r == sorted(r), f"los radios deben crecer con la magnitud: {r}"
    assert r[0] == 20.0 and r[-1] == 500.0, r
    assert len(set(r)) == len(r), "cada tramo de magnitud debe dar un radio distinto"


def test_sismo_sin_magnitud_usa_criterio_medio():
    a = area.por_sismo(None)
    assert a["radio_km"] == 50.0
    assert "no informada" in a["motivo"]


def test_incendio_chico_no_arrasa_una_region():
    """10 ha son unos 0.18 km de fuego. antes le pintabamos 30 km."""
    a = area.por_incendio(10.0, activo=True)
    assert a["radio_km"] < 10.0, f"un incendio de 10 ha no puede cubrir {a['radio_km']} km"
    margen = area._MARGEN_INCENDIO_KM[True]
    assert a["radio_km"] > margen, "pero debe incluir el margen operativo por humo/caminos"


def test_incendio_controlado_tiene_menos_margen_que_uno_en_combate():
    activo = area.por_incendio(50.0, activo=True)["radio_km"]
    apagado = area.por_incendio(50.0, activo=False)["radio_km"]
    assert activo > apagado, "un incendio en combate puede crecer; uno controlado no"


def test_incendio_grande_da_area_mayor_que_uno_chico():
    assert area.por_incendio(5000.0, True)["radio_km"] > area.por_incendio(5.0, True)["radio_km"]


def test_volcan_usa_radio_de_exclusion_por_nivel_de_alerta():
    assert area.por_volcan("amarilla")["radio_km"] == 5.0
    assert area.por_volcan("naranja")["radio_km"] == 15.0
    assert area.por_volcan("roja")["radio_km"] == 30.0


def test_volcan_con_perimetro_real_de_senapred_le_gana_al_generico():
    """si senapred declaro un perimetro puntual para el volcan (ver
    sources/senapred_volcanes.py) ese dato real vale mas que la tabla
    generica por nivel de alerta."""
    a = area.por_volcan("amarilla", perimetro_km=2.0)
    assert a["radio_km"] == 2.0
    assert "SENAPRED" in a["motivo"]


def test_volcan_sin_perimetro_declarado_usa_el_generico_igual():
    a = area.por_volcan("roja", perimetro_km=None)
    assert a["radio_km"] == 30.0


def test_tienda_dentro_del_poligono_de_la_comuna_esta_afectada():
    a = area.por_anillos(_PROVIDENCIA, "Comuna de Providencia")
    assert area.contiene(a, *_CENTRO_PROV, -33.43, -70.61)


def test_tienda_fuera_de_la_comuna_no_esta_afectada():
    """el corazon del cambio. a 12 km del centro el circulo de 30 km
    la marcaba afectada. el contorno real de la comuna no."""
    a = area.por_anillos(_PROVIDENCIA, "Comuna de Providencia")
    lejos = (-33.32, -70.61)  # unos 12 km al norte. fuera de providencia
    assert not area.contiene(a, *_CENTRO_PROV, *lejos)
    assert area.haversine(*_CENTRO_PROV, *lejos) < 30.0, "y sin embargo cae dentro de los 30 km viejos"


def test_margen_de_alerta_roja_no_se_confunde_con_area_afectada():
    """cerca no es lo mismo que afectada. el margen existe pero se reporta aparte."""
    base = area.por_anillos(_PROVIDENCIA, "Comuna de Providencia")
    con_margen = area.con_margen(base, area.MARGEN_ALERTA_ROJA_KM, "Cercania a comuna en Alerta Roja")
    justo_afuera = (-33.395, -70.61)  # como 1.5 km del borde norte

    assert not area.contiene(base, *_CENTRO_PROV, *justo_afuera), "sin margen: no esta afectada"
    d = area.distancia_km(con_margen, *_CENTRO_PROV, *justo_afuera)
    assert d is not None and d > 0, "con margen: entra, pero a distancia > 0 (no esta dentro)"
    assert area.distancia_km(con_margen, *_CENTRO_PROV, -33.43, -70.61) == 0.0, \
        "dentro de la comuna la distancia es 0: ahi si esta afectada"


def test_poligono_vacio_no_genera_area_falsa():
    assert area.por_anillos([], "sin datos") is None
    assert area.por_anillos([[[0, 0], [1, 1]]], "linea, no area") is None
    assert not area.contiene(None, -33.4, -70.6, -33.4, -70.6)


def test_evento_multizona_cubre_todos_sus_anillos():
    """la dmc publica avisos con zonas separadas. se verifico que uno traia 3 anillos."""
    lejano = [[[-72.0, -38.0], [-71.5, -38.0], [-71.5, -37.5], [-72.0, -37.5], [-72.0, -38.0]]]
    a = area.por_anillos(_PROVIDENCIA + lejano, "Aviso DMC multizona")
    assert area.contiene(a, *_CENTRO_PROV, -33.43, -70.61), "primera zona"
    assert area.contiene(a, *_CENTRO_PROV, -37.75, -71.75), "segunda zona, a 500 km de la primera"
