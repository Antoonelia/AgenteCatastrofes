"""cliente http minimo para probar la app de fastapi de punta a punta.

TestClient de starlette pide httpx, y httpx no se puede instalar en este
entorno (el proxy corporativo bloquea la descarga). en vez de sumar una
dependencia por 40 lineas, se le habla a la app directo por ASGI: se arma
el scope, se llama a la app y se junta lo que responde. no corre el
lifespan, asi que tampoco arranca el recolector de fuentes ni sale a
internet.

uso:

    from ._asgi import pedir
    r = pedir("GET", "/admin")
    assert r.status == 302 and r.headers["location"] == "/"
"""
from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass, field
from urllib.parse import urlsplit


@dataclass
class Respuesta:
    status: int
    headers: dict[str, str]
    cuerpo: bytes
    cookies_nuevas: dict[str, str] = field(default_factory=dict)

    def json(self):
        return json.loads(self.cuerpo.decode("utf-8"))


def pedir(metodo: str, ruta: str, *, json_body=None, cookies: dict | None = None,
          cliente: tuple[str, int] = ("127.0.0.1", 50000)) -> Respuesta:
    # import tardio: app.main arma la app al importarse y los tests que no
    # hablan http no tienen por que pagar ese costo
    from app.main import app

    partes = urlsplit(ruta)
    cabeceras = [(b"host", b"testserver")]
    cuerpo = b""
    if json_body is not None:
        cuerpo = json.dumps(json_body).encode("utf-8")
        cabeceras.append((b"content-type", b"application/json"))
        cabeceras.append((b"content-length", str(len(cuerpo)).encode()))
    if cookies:
        cabeceras.append((b"cookie", "; ".join(f"{k}={v}" for k, v in cookies.items()).encode()))

    scope = {
        "type": "http", "asgi": {"version": "3.0"}, "http_version": "1.1",
        "method": metodo, "scheme": "http", "path": partes.path,
        "raw_path": partes.path.encode(), "query_string": partes.query.encode(),
        "root_path": "", "headers": cabeceras, "client": cliente, "server": ("testserver", 80),
    }
    estado: dict = {"status": 0, "headers": [], "cuerpo": b""}
    enviado = False

    async def recibir():
        nonlocal enviado
        if not enviado:
            enviado = True
            return {"type": "http.request", "body": cuerpo, "more_body": False}
        return {"type": "http.disconnect"}

    async def enviar(mensaje):
        if mensaje["type"] == "http.response.start":
            estado["status"] = mensaje["status"]
            estado["headers"] = mensaje["headers"]
        elif mensaje["type"] == "http.response.body":
            estado["cuerpo"] += mensaje.get("body", b"")

    asyncio.run(app(scope, recibir, enviar))

    headers: dict[str, str] = {}
    cookies_nuevas: dict[str, str] = {}
    for k, v in estado["headers"]:
        nombre, valor = k.decode().lower(), v.decode()
        if nombre == "set-cookie":
            par = valor.split(";", 1)[0]
            clave, _, dato = par.partition("=")
            cookies_nuevas[clave] = dato
        else:
            headers[nombre] = valor
    return Respuesta(estado["status"], headers, estado["cuerpo"], cookies_nuevas)
