param([Parameter(Mandatory=$true)][string]$UrlsB64)

# las urls llegan codificadas en base64. ver fetcher.py fetch_many. pasar
# un array de strings por linea de comandos via -File no funciona en
# windows powershell porque solo toma el primer valor y el resto rompe
# con "no se encuentra ningun parametro de posicion". base64 tambien
# evita problemas de comillas y comas dentro de las urls, por ejemplo
# conaf trae comas en el query string
$json = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($UrlsB64))
# ojo: "$json | ConvertFrom-Json" via pipeline devuelve mal el array en
# windows powershell 5.1. lo junta todo en un solo string separado por
# espacios en vez de parsear el json. con -InputObject explicito anda
# bien, verificado. el @() fuerza array aunque sea una sola url
$Urls = ConvertFrom-Json -InputObject $json

# version en lote de fetch.ps1. descarga varias urls en un solo proceso
# de powershell, en paralelo puertas adentro con un runspace pool. el
# costo real medido no es la descarga en si, que es rapida, sino el
# arranque de powershell.exe, unos 1.5 a 2 segundos por proceso. pedir
# 12 urls por separado paga ese arranque 12 veces. esto lo paga una
# sola vez para todo el lote. ver fetcher.py fetch_many
[System.Net.WebRequest]::DefaultWebProxy.Credentials = [System.Net.CredentialCache]::DefaultCredentials
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$headers = @{
    'User-Agent'      = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
    'Accept'          = 'text/html,application/xhtml+xml,application/json,*/*'
    'Accept-Language' = 'es-CL,es;q=0.9'
}

$traer = {
    param($Url, $Headers)
    try {
        $r = Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec 40 -Headers $Headers
        # mismo fix que fetch.ps1. bytes crudos mas utf-8 explicito, nunca
        # $r.Content, porque powershell adivina mal la codificacion cuando
        # la fuente no declara el charset en el header http. ver el
        # comentario alla
        $c = [System.Text.Encoding]::UTF8.GetString($r.RawContentStream.ToArray())
        [PSCustomObject]@{ Url = $Url; Content = $c }
    } catch {
        # una url que falla no debe tumbar el lote. se marca con content
        # vacio y quien llama, que es fetcher.py, sabe que debe
        # reintentarla sola
        [PSCustomObject]@{ Url = $Url; Content = $null }
    }
}

$pool = [runspacefactory]::CreateRunspacePool(1, [Math]::Max(1, $Urls.Count))
$pool.Open()
try {
    $tareas = foreach ($u in $Urls) {
        $ps = [powershell]::Create()
        $ps.RunspacePool = $pool
        [void]$ps.AddScript($traer).AddArgument($u).AddArgument($headers)
        [PSCustomObject]@{ Trabajo = $ps; Handle = $ps.BeginInvoke() }
    }
    $mapa = @{}
    foreach ($t in $tareas) {
        $res = $t.Trabajo.EndInvoke($t.Handle)
        $t.Trabajo.Dispose()
        if ($res -and $res.Count -gt 0) { $mapa[[string]$res[0].Url] = $res[0].Content }
    }
} finally {
    $pool.Close()
    $pool.Dispose()
}

Write-Output ($mapa | ConvertTo-Json -Depth 4 -Compress)
