# Sprint 1 — Wellbeing / Pilar Social

Material de levantamiento de requerimientos con el equipo de Anyelina.

| Archivo | Cuándo usarlo |
|---|---|
| [`01-guion-reunion.md`](01-guion-reunion.md) | **Antes y durante.** Agenda, 21 preguntas, trampas a evitar |
| [`02-plantilla-captura.md`](02-plantilla-captura.md) | **Durante.** Tipear acá en vivo, no en prosa |
| [`03-plantilla-historias.md`](03-plantilla-historias.md) | **Después.** Convertir dolores en historias. Trae 5 candidatas |
| [`04-notificaciones.md`](04-notificaciones.md) | Canales fuera del navegador (Teams / WhatsApp). Implementa HU-02 |

## El contexto en tres líneas

Hazzi hoy sabe **dónde** ocurre una catástrofe, **qué tiendas** afecta y
**cuántas personas** trabajan ahí (estimado, vía `app/dotacion.py`).

El pilar social necesita saber **quiénes son y cómo están**.

Ese salto es todo el proyecto — y cruza la frontera del dato personal.

## La restricción que manda

Cualquier cosa que identifique asociados cae bajo la **Ley 21.719** (vigencia plena:
diciembre 2026, dentro del horizonte de este proyecto). Domicilio, salud y situación
socioeconómica son **datos sensibles**.

**Estrategia:** construir primero todo lo que funciona con **agregados**
(conteos, no nombres). Entrega valor real, es defendible ante el tribunal, y no
queda bloqueado esperando permisos.
