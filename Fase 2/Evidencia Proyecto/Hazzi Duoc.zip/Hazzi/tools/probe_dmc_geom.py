"""Sonda: cuanto pesa la geometria real de la DMC y cuanto se puede simplificar."""
import json

from app.fetcher import fetch_json

B = (
    "https://services3.arcgis.com/CNzkI2T3GmfwkaAR/arcgis/rest/services/"
    "Meteochile_AAA_Avisos_Zonas/FeatureServer/0/query"
    "?where=1=1&outFields=*&returnCentroid=true&returnGeometry=true&outSR=4326&f=json"
)

for off in ("", "&maxAllowableOffset=0.005", "&maxAllowableOffset=0.02", "&maxAllowableOffset=0.05"):
    d = fetch_json(B + off)
    fs = d.get("features", [])
    pts = sum(len(r) for f in fs for r in f.get("geometry", {}).get("rings", []))
    print(f"{off or 'full':<28} feats={len(fs):<3} puntos={pts:<6} KB={len(json.dumps(d)) / 1024:.1f}")

d = fetch_json(B)
print()
for f in d["features"]:
    a = f["attributes"]
    rings = f["geometry"]["rings"]
    print(f" - {a['tipo']:<8} | {a['fenomeno']:<28} | anillos={len(rings)} | {a['zona_real'][:55]}")
