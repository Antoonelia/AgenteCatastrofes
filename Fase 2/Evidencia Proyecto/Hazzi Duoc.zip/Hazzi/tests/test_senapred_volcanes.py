"""enriquecimiento de volcanes: cruzar sernageomin con los comunicados
volcanicos de senapred para sacarles fecha real y perimetro de
seguridad declarado.

caso real que motiva esto (27-09-2026): sernageomin lista al complejo
volcanico nevados de chillan en alerta amarilla pero su feed arcgis no
trae ni fecha del ultimo cambio ni perimetro de seguridad -- esos datos
solo existen en un comunicado de prensa de senapred (api graphql,
eventosByDate con type: "Evento", distinto del type: "Alerta" que ya
usa sources/senapred.py) que dice textualmente que se modifica el
perimetro pasando de 1 kilometro alrededor del crater activo a 2
kilometros alrededor del Centro de Emision 3 (CE3)."""
from __future__ import annotations
from contextlib import contextmanager

from app.sources import senapred_volcanes as mod
from app.sources.senapred_volcanes import _perimetro_km, _POR_ACTIVIDAD_DE, eventos_volcanicos, nombre_base

TITULO_REAL = (
    "Se modifica per\u00edmetro de seguridad para las comunas de Pinto y "
    "Coihueco por actividad del Complejo Volc\u00e1nico Nevados de Chill\u00e1n"
)

CONTENIDO_REAL = (
    "<p>...con potencial afectaci\u00f3n en un radio referencial de 2 kil\u00f3metros, "
    "donde los peligros asociados...modifica el Per\u00edmetro de Seguridad para las "
    "comunas de Pinto y Coihueco pasando de 1 kil\u00f3metro alrededor del cr\u00e1ter "
    "activo a 2 kil\u00f3metros alrededor del Centro de Emisi\u00f3n 3 (CE3)</p>"
)


@contextmanager
def _parcheado(obj, nombre, valor_nuevo):
    """reemplaza obj.nombre por valor_nuevo y lo restaura al salir, aunque falle."""
    original = getattr(obj, nombre)
    setattr(obj, nombre, valor_nuevo)
    try:
        yield
    finally:
        setattr(obj, nombre, original)


def test_nombre_base_saca_el_prefijo_y_las_tildes():
    # asi se cruza el nombre exacto que da sernageomin (con su prefijo
    # segun tipo de formacion) contra el que repite senapred en el
    # titulo de sus comunicados
    assert nombre_base("Complejo Volc\u00e1nico Nevados de Chill\u00e1n") == "nevados de chillan"
    assert nombre_base("Volc\u00e1n Villarrica") == "villarrica"
    assert nombre_base("Grupo Volc\u00e1nico Carr\u00e1n-Los Venados") == "carran-los venados"


def test_el_nombre_del_volcan_se_extrae_del_titulo():
    m = _POR_ACTIVIDAD_DE.search(TITULO_REAL)
    assert m is not None
    assert nombre_base(m.group(1)) == "nevados de chillan"


def test_un_titulo_sin_actividad_volcanica_no_matchea():
    # un sismo o un incendio no debe confundirse con un comunicado
    # volcanico solo porque comparte alguna palabra
    assert _POR_ACTIVIDAD_DE.search("Sismo de menor intensidad en la Regi\u00f3n de Coquimbo") is None
    assert _POR_ACTIVIDAD_DE.search("Incendio Estructural, Comuna de Quilicura (Cierre del evento)") is None


def test_perimetro_prioriza_pasando_de_x_a_y_sobre_el_valor_nuevo():
    # cuando hay una modificacion el valor que manda es el nuevo (el
    # que sigue a la "a"), no el viejo que se reemplaza
    assert _perimetro_km(CONTENIDO_REAL) == 2.0


def test_perimetro_cae_al_radio_referencial_si_no_hay_modificacion():
    texto = "es esperable...con potencial afectaci\u00f3n en un radio referencial de 3 kil\u00f3metros del crater"
    assert _perimetro_km(texto) == 3.0


def test_perimetro_cae_a_declaracion_simple_como_ultimo_recurso():
    texto = "se declara el Per\u00edmetro de Seguridad de 5 kil\u00f3metros para la comuna de pinto"
    assert _perimetro_km(texto) == 5.0


def test_sin_ningun_numero_de_kilometros_el_perimetro_es_none():
    assert _perimetro_km("se cierra el evento sin cambios en el perimetro vigente") is None


def test_eventos_volcanicos_devuelve_vacio_si_la_red_falla():
    # best effort. sernageomin.py debe poder seguir mostrando sus
    # volcanes aunque esta consulta aparte falle por completo
    def _explota(*a, **kw):
        raise RuntimeError("sin conexion")

    with _parcheado(mod, "graphql", _explota):
        assert eventos_volcanicos() == {}


def test_eventos_volcanicos_arma_fecha_y_perimetro_desde_items_crudos():
    items_falsos = {
        "data": {
            "eventosByDate": {
                "items": [
                    {
                        "titulo": TITULO_REAL,
                        "fechaHora": "2026-09-27T13:06:40.4040-03:00",
                        "contenido": CONTENIDO_REAL,
                    },
                    {
                        "titulo": "Sismo de menor intensidad en la Regi\u00f3n de Coquimbo",
                        "fechaHora": "2026-09-24T14:34:10.1010-03:00",
                        "contenido": "<p>sin relacion con volcanes</p>",
                    },
                ]
            }
        }
    }
    with _parcheado(mod, "graphql", lambda *a, **kw: items_falsos):
        out = eventos_volcanicos()

    assert list(out.keys()) == ["nevados de chillan"]
    assert out["nevados de chillan"]["fecha"] == "27-09-2026 13:06 hrs"
    assert out["nevados de chillan"]["perimetro_km"] == 2.0


def test_eventos_volcanicos_se_queda_con_el_mas_nuevo_por_volcan():
    # eventosByDate viene ordenado desc. si el mismo volcan aparece dos
    # veces debe ganar el primero que se encuentra, que es el mas reciente
    items_falsos = {
        "data": {
            "eventosByDate": {
                "items": [
                    {
                        "titulo": "Se declara Alerta por actividad del Volc\u00e1n Villarrica",
                        "fechaHora": "2026-09-28T10:00:00.000-03:00",
                        "contenido": "radio referencial de 4 kil\u00f3metros",
                    },
                    {
                        "titulo": "Monitoreo por actividad del Volc\u00e1n Villarrica",
                        "fechaHora": "2026-09-20T08:00:00.000-03:00",
                        "contenido": "radio referencial de 2 kil\u00f3metros",
                    },
                ]
            }
        }
    }
    with _parcheado(mod, "graphql", lambda *a, **kw: items_falsos):
        out = eventos_volcanicos()

    assert out["villarrica"]["fecha"] == "28-09-2026 10:00 hrs"
    assert out["villarrica"]["perimetro_km"] == 4.0
