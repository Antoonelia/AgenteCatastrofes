"""Por que tiendas.html no revierte limpio? Aislar el caracter culpable."""
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

crudo = Path("app/static/tiendas.html").read_bytes().decode("utf-8").lstrip("\ufeff")

try:
    crudo.encode("cp1252")
    print("cp1252: codifica OK")
except UnicodeEncodeError as exc:
    malo = crudo[exc.start:exc.end]
    print(f"cp1252 FALLA en pos {exc.start}: {malo!r} (U+{ord(malo[0]):04X})")
    print("contexto:", repr(crudo[max(0, exc.start - 70):exc.start + 70]))
    print()
    # Cuantos caracteres distintos no son representables en cp1252?
    fuera = sorted({c for c in crudo if not c.isascii() and _no_cp1252(c)}) if False else None

fuera = []
for c in sorted(set(crudo)):
    if c.isascii():
        continue
    try:
        c.encode("cp1252")
    except UnicodeEncodeError:
        fuera.append(c)
print(f"caracteres no representables en cp1252: {[(c, hex(ord(c))) for c in fuera]}")
for c in fuera:
    i = crudo.find(c)
    print(f"  {c!r} en pos {i}: {crudo[max(0, i - 80):i + 80]!r}")
