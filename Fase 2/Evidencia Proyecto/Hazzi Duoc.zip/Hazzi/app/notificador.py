"""notificador. capa de abstraccion para avisar fuera del navegador.

mismo patron que ai_client.py y dotacion.py. el resto del sistema
llama a notificar sin saber por donde sale el mensaje. el canal se
elige con la variable de entorno notificador sin tocar una linea de
codigo.

notificador=consola (por defecto) imprime al log con cero permisos.
notificador=teams manda por el webhook de un canal de microsoft teams.
notificador=whatsapp usa la whatsapp cloud api de meta.

por que existe: hasta ahora las notificaciones de hazzi vivian enteras
en el navegador con la funcion notificar de common.js y localstorage.
si nadie tiene la pestana abierta nadie se entera. un sismo a las 3 am
le grita a una pantalla apagada. este modulo saca el aviso del
navegador.

sobre whatsapp y los grupos: la cloud api de meta es estrictamente 1 a
1 y no existe endpoint para postear en un grupo. para notificaciones
de una sola via eso da igual porque se manda el mismo template a cada
numero de la lista y el destinatario recibe exactamente lo mismo. lo
que no se hace aca es usar librerias no oficiales como
whatsapp-web.js baileys o pywhatkit que automatizan la sesion personal
de alguien. violan los terminos de servicio de whatsapp se rompen con
cada actualizacion del protocolo y convertirian el telefono de un
asociado en un bot corporativo. no es una limitacion tecnica es una
decision.

privacidad: este modulo manda agregados como cuantas tiendas y
cuantas comunas, nunca datos identificatorios de asociados. ver
docs/wellbeing/README.md. cualquier cosa nominal cae bajo la ley
21.719 y no sale por este canal."""
from __future__ import annotations

import base64
import hashlib
import json
import os
import struct
import urllib.parse
import zlib
import urllib.request
from dataclasses import dataclass, field, replace

from . import notificador_estado as _estado

NOTIFICADOR = os.environ.get("NOTIFICADOR", "consola")

# teams. url del webhook entrante del canal en canal > conectores > incoming webhook
TEAMS_WEBHOOK_URL = os.environ.get("TEAMS_WEBHOOK_URL", "")

# whatsapp cloud api de meta. requiere cuenta meta business verificada
# un numero dedicado que no tenga whatsapp normal instalado y una
# plantilla aprobada por meta. no se puede improvisar el texto de una
# alerta tiene que estar aprobada de antes. ver
# docs/wellbeing/04-notificaciones.md
WHATSAPP_TOKEN = os.environ.get("WHATSAPP_TOKEN", "")
WHATSAPP_PHONE_ID = os.environ.get("WHATSAPP_PHONE_ID", "")
WHATSAPP_TEMPLATE = os.environ.get("WHATSAPP_TEMPLATE", "alerta_hazzi")
WHATSAPP_IDIOMA = os.environ.get("WHATSAPP_IDIOMA", "es")
WHATSAPP_API_URL = "https://graph.facebook.com/v21.0"

# lista de distribucion. numeros en formato internacional sin el signo
# mas separados por coma. por ejemplo
# whatsapp_destinatarios=56911112222,56933334444
WHATSAPP_DESTINATARIOS = [
    n.strip() for n in os.environ.get("WHATSAPP_DESTINATARIOS", "").split(",") if n.strip()
]

_TIMEOUT = 10  # segundos. ningun canal puede colgar el ciclo de recoleccion

# severidades que ameritan avisar fuera del dashboard. las verdes son
# registro puro y no justifican interrumpir a nadie fuera de horario.
# amarilla hacia arriba, osea amarilla naranja y roja, si notifica a
# pedido explicito de antonella el 24-09-2026. es configurable porque
# el umbral es una decision del negocio no tecnica
SEVERIDADES_QUE_NOTIFICAN = {
    s.strip().lower()
    for s in os.environ.get("NOTIFICAR_DESDE", "roja,naranja,amarilla").split(",")
    if s.strip()
}


@dataclass(frozen=True)
class Alerta:
    """un aviso listo para salir por cualquier canal.

    clave es la identidad del evento y no del aviso puntual. dos
    alerta con la misma clave son el mismo hecho real y se comparan
    entre si para saber si de verdad cambio algo desde el ultimo
    aviso. ver _clasificar mas abajo. ya no incluye la severidad
    porque una escalada de severidad es justamente uno de los cambios
    que se detectan, no una identidad distinta."""

    clave: str
    titulo: str
    cuerpo: str
    severidad: str = "amarilla"
    url: str = ""
    datos: dict = field(default_factory=dict)


@dataclass
class Resultado:
    """que paso al intentar enviar. nunca se lanza excepcion hacia afuera."""

    enviado: bool
    canal: str
    detalle: str = ""
    destinatarios: int = 0


# proveedores. cada uno recibe una alerta y devuelve un resultado.
# ninguno lanza excepcion porque un canal caido no puede tumbar el
# ciclo de recoleccion de eventos


def _post_json(url: str, payload: dict, headers: dict | None = None) -> tuple[bool, str]:
    """post de json compartido por todos los proveedores http. asi no se repite el mismo codigo tres veces."""
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json", **(headers or {})},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
            return 200 <= resp.status < 300, f"HTTP {resp.status}"
    except Exception as exc:  # noqa: BLE001 el canal no puede romper el sistema
        return False, f"{type(exc).__name__}: {exc}"


_COLORES_HEX = {
    # mismos colores que ya usa el resto de hazzi. ver las variables
    # roja naranja amarilla verde de styles.css. es consistencia
    # visual con el dashboard no una paleta inventada aparte solo
    # para teams
    "roja": "dc2626",
    "naranja": "ea580c",
    "amarilla": "d97706",
    "verde": "16a34a",
}
_EMOJI_SEVERIDAD = {
    # triangulo de peligro no logo de empresa a pedido explicito. el
    # mismo simbolo para todas las severidades porque el color ya lo
    # distingue el fondo. ver _fondo_color. se probo con un triangulo
    # rojo solido para roja pero se camuflaba contra el fondo rojo con
    # poco contraste y "no se distingue" fue el feedback en vivo. el
    # signo de advertencia amarillo con borde y "!" negros si
    # contrasta bien contra cualquier fondo de color, roja incluida
    "roja": "\u26A0\uFE0F",
    "naranja": "\u26A0\uFE0F",
    "amarilla": "\u26A0\uFE0F",
    "verde": "\u2705",  # fallback. verde no deberia notificar nunca
}


def _png_solido(hex_color: str) -> bytes:
    """png valido de 1x1 pixel de un color solido armado a mano. sin
    pillow ni ningun asset externo. cero dependencias nuevas cero red.

    es el truco estandar para forzar un fondo de color exacto en una
    adaptive card. el estilo nativo de container como attention o
    warning lo define el tema de teams no nosotros y sale siempre en
    un tono pastel muy palido. no alcanzaba para lo que pidio
    antonella que era "mas colorido, no tan opaco"."""
    hex_color = hex_color.lstrip("#")
    r, g, b = (int(hex_color[i : i + 2], 16) for i in (0, 2, 4))

    def _chunk(tag: bytes, data: bytes) -> bytes:
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data))

    firma = b"\x89PNG\r\n\x1a\n"
    ihdr = struct.pack(">IIBBBBB", 1, 1, 8, 2, 0, 0, 0)  # 1x1 pixel, 8 bits, color rgb
    idat = zlib.compress(b"\x00" + bytes((r, g, b)))
    return firma + _chunk(b"IHDR", ihdr) + _chunk(b"IDAT", idat) + _chunk(b"IEND", b"")


def _fondo_color(severidad: str) -> str:
    """data uri en base64 del png de 1x1 del color de esa severidad."""
    hex_color = _COLORES_HEX.get(severidad, "6B7280")
    return "data:image/png;base64," + base64.b64encode(_png_solido(hex_color)).decode("ascii")


def _enviar_consola(alerta: Alerta) -> Resultado:
    """proveedor por defecto. imprime y ya. cero permisos cero red.

    no es un placeholder. en desarrollo y en la defensa de tesis es
    el modo correcto porque se ve exactamente que se habria mandado
    sin mandar nada."""
    print(
        f"[NOTIFICADOR:{alerta.severidad.upper()}] {alerta.titulo}\n"
        f"                {alerta.cuerpo}"
        + (f"\n                {alerta.url}" if alerta.url else "")
    )
    return Resultado(enviado=True, canal="consola", detalle="impreso", destinatarios=1)


def _encabezado_teams(alerta: Alerta, emoji: str) -> dict:
    """cabecera de la tarjeta con el triangulo mas el titulo sobre
    fondo solido segun severidad. ver _fondo_color. sin logo de
    empresa a pedido explicito porque el triangulo ya comunica de
    sobra que es una alerta."""
    # el titulo generico trae el prefijo "[SEVERIDAD] " que tambien usan
    # whatsapp y consola porque no tienen ningun color visual. y si es
    # una actualizacion tambien trae "[ACTUALIZACION] " antes que eso.
    # ver _con_cambio. los dos sobran en teams porque el triangulo y el
    # fondo de color ya dicen de que severidad es y el fact "que
    # cambio" de mas abajo ya deja claro que es una actualizacion
    titulo_mostrado = alerta.titulo
    if titulo_mostrado.startswith("[ACTUALIZACION] "):
        titulo_mostrado = titulo_mostrado[len("[ACTUALIZACION] ") :]
    prefijo = f"[{alerta.severidad.upper()}] "
    if titulo_mostrado.startswith(prefijo):
        titulo_mostrado = titulo_mostrado[len(prefijo) :]
    return {
        "type": "Container",
        "bleed": True,
        "backgroundImage": {"url": _fondo_color(alerta.severidad), "fillMode": "Cover"},
        "items": [
            {
                "type": "ColumnSet",
                "columns": [
                    {
                        "type": "Column",
                        "width": "auto",
                        "verticalContentAlignment": "Center",
                        "items": [{"type": "TextBlock", "text": emoji, "size": "ExtraLarge"}],
                    },
                    {
                        "type": "Column",
                        "width": "stretch",
                        "verticalContentAlignment": "Center",
                        "items": [
                            {
                                "type": "TextBlock",
                                "text": titulo_mostrado,
                                "weight": "Bolder",
                                "size": "Large",
                                "wrap": True,
                                "color": "Light",
                            }
                        ],
                    },
                ],
            }
        ],
    }


def _payload_teams(alerta: Alerta) -> dict:
    """arma una adaptive card envuelta en attachments.

    no es el formato messagecard viejo de los conectores clasicos de
    teams (office 365 connectors). microsoft los esta retirando y el
    flujo real que se probo en produccion se arma con la app
    workflows (power automate) con la plantilla "enviar alertas de
    webhook a un canal". esa plantilla usa la accion "post card in a
    chat or channel" que exige una adaptive card real con
    type: adaptivecard adentro de un attachments, que es el mismo
    formato que usa bot framework para adjuntar tarjetas. mandar solo
    un texto plano (el intento inicial) hace que el flujo falle con
    "attachments is null" y tumbe el paso de publicar. verificado en
    vivo contra el flujo real con captura del error incluida.

    diseno: cabecera con triangulo de peligro mas fondo solido segun
    severidad, y el cuerpo en una de dos formas segun que tan
    estructurada venga la alerta. si datos trae tiendas, porque viene
    de alerta_desde_tiendas, se arma una tabla factset con comunas
    tiendas en riesgo fuente y fecha en ese orden, que es mas facil de
    leer de un vistazo que una oracion larga y es justo lo que pidio
    antonella. las comunas van todas sin truncar, a diferencia de
    cuerpo que si trunca para whatsapp y consola. si no viene asi,
    osea es una alerta generica armada a mano, se muestra cuerpo tal
    cual para no perder informacion de casos que no pasan por ese
    helper."""
    emoji = _EMOJI_SEVERIDAD.get(alerta.severidad, "\u26A0\uFE0F")
    datos = alerta.datos or {}

    cuerpo_tarjeta: list = [_encabezado_teams(alerta, emoji)]

    if "tiendas" in datos:
        facts = []
        if datos.get("cambio"):
            facts.append({"title": "Que cambio", "value": datos["cambio"]})
        if datos.get("comunas_lista"):
            facts.append({"title": "Comunas", "value": ", ".join(datos["comunas_lista"])})
        facts.append({"title": "Tiendas en riesgo", "value": str(datos["tiendas"])})
        if datos.get("fuente"):
            facts.append({"title": "Fuente", "value": datos["fuente"]})
        if datos.get("fecha"):
            facts.append({"title": "Fecha", "value": str(datos["fecha"])})
        cuerpo_tarjeta.append({"type": "FactSet", "facts": facts, "spacing": "Medium"})
    else:
        cuerpo_tarjeta.append({"type": "TextBlock", "text": alerta.cuerpo, "wrap": True, "spacing": "Medium"})

    tarjeta: dict = {
        "type": "AdaptiveCard",
        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
        "version": "1.4",
        "body": cuerpo_tarjeta,
    }
    if alerta.url:
        tarjeta["actions"] = [{"type": "Action.OpenUrl", "title": "\U0001F5FA\uFE0F Ver en Hazzi", "url": alerta.url}]
    return {"attachments": [{"contentType": "application/vnd.microsoft.card.adaptive", "content": tarjeta}]}


def _enviar_teams(alerta: Alerta) -> Resultado:
    """webhook de workflows (power automate) sobre un canal de teams."""
    if not TEAMS_WEBHOOK_URL:
        return Resultado(False, "teams", "falta TEAMS_WEBHOOK_URL")
    ok, detalle = _post_json(TEAMS_WEBHOOK_URL, _payload_teams(alerta))
    return Resultado(ok, "teams", detalle, destinatarios=1 if ok else 0)


def _payload_whatsapp(numero: str, alerta: Alerta) -> dict:
    """arma el mensaje de plantilla para un destinatario.

    meta exige una plantilla preaprobada con parametros posicionales.
    no se puede mandar texto libre a alguien que no escribio en las
    ultimas 24 horas. la plantilla alerta_hazzi espera 3 parametros
    que son titulo cuerpo y severidad."""
    def _param(texto: str) -> dict:
        # meta rechaza saltos de linea y tabs dentro de un parametro
        return {"type": "text", "text": " ".join(texto.split())[:1024]}

    return {
        "messaging_product": "whatsapp",
        "to": numero,
        "type": "template",
        "template": {
            "name": WHATSAPP_TEMPLATE,
            "language": {"code": WHATSAPP_IDIOMA},
            "components": [
                {
                    "type": "body",
                    "parameters": [
                        _param(alerta.titulo),
                        _param(alerta.cuerpo),
                        _param(alerta.severidad),
                    ],
                }
            ],
        },
    }


def _enviar_whatsapp(alerta: Alerta) -> Resultado:
    """whatsapp cloud api. manda el mismo mensaje a cada numero de la lista.

    no hay envio a grupos en la api oficial. ver el docstring del
    modulo. para una notificacion de una sola via el resultado es
    equivalente porque cada persona de la lista recibe el mismo
    aviso."""
    if not (WHATSAPP_TOKEN and WHATSAPP_PHONE_ID):
        return Resultado(False, "whatsapp", "falta WHATSAPP_TOKEN o WHATSAPP_PHONE_ID")
    if not WHATSAPP_DESTINATARIOS:
        return Resultado(False, "whatsapp", "falta WHATSAPP_DESTINATARIOS")

    url = f"{WHATSAPP_API_URL}/{WHATSAPP_PHONE_ID}/messages"
    cabeceras = {"Authorization": f"Bearer {WHATSAPP_TOKEN}"}
    entregados, fallos = 0, []
    for numero in WHATSAPP_DESTINATARIOS:
        ok, detalle = _post_json(url, _payload_whatsapp(numero, alerta), cabeceras)
        if ok:
            entregados += 1
        else:
            # el numero se trunca en el log porque es dato personal de contacto
            fallos.append(f"...{numero[-4:]}: {detalle}")

    # exito parcial cuenta como exito. que un numero este mal dado no
    # puede invalidar el aviso que si llego a los otros once
    return Resultado(
        enviado=entregados > 0,
        canal="whatsapp",
        detalle=f"{entregados}/{len(WHATSAPP_DESTINATARIOS)} entregados"
        + (f" | fallos: {'; '.join(fallos)}" if fallos else ""),
        destinatarios=entregados,
    )


_PROVEEDORES = {
    "consola": _enviar_consola,
    "teams": _enviar_teams,
    "whatsapp": _enviar_whatsapp,
}


# punto de entrada unico


def _datos_estado(alerta: Alerta) -> dict:
    """la huella del estado de un evento para comparar entre ciclos.

    ojo: usa tiendas_propias, que son las de este evento, y no
    tiendas, que puede venir pisado por el total global deduplicado.
    ver alerta_desde_tiendas. si se comparara contra el total global
    un evento sin cambios propios se veria "modificado" cada vez que
    otro evento simultaneo le sumara o restara tiendas al total.

    tema fenomeno y area_hash amplian la comparacion mas alla de lo
    que le pasa a una tienda walmart. ver el docstring de
    notificador_estado.py."""
    datos = alerta.datos or {}
    return {
        "comunas": datos.get("comunas_lista", []),
        "tiendas": datos.get("tiendas_propias", datos.get("tiendas", 0)),
        "tema": datos.get("tema", ""),
        "fenomeno": datos.get("fenomeno", ""),
        "area_hash": datos.get("area_hash", ""),
        "tipo": datos.get("tipo_evento", ""),
    }


def _con_cambio(alerta: Alerta, descripcion: str) -> Alerta:
    """copia la alerta con la descripcion del cambio antepuesta al
    mensaje y disponible en datos["cambio"] para que un canal con
    formato propio, como _payload_teams, la muestre sin tener que
    parsear texto libre."""
    return replace(
        alerta,
        titulo=f"[ACTUALIZACION] {alerta.titulo}",
        cuerpo=f"{descripcion}. {alerta.cuerpo}",
        datos={**alerta.datos, "cambio": descripcion},
    )


def notificar(alerta: Alerta, forzar: bool = False) -> Resultado:
    """manda la alerta por el canal configurado. nunca lanza excepcion.

    aplica dos filtros antes de enviar en este orden. primero
    severidad: solo las que estan en severidades_que_notifican.
    segundo novedad: solo si el evento es nuevo o cambio de verdad
    desde el ultimo aviso (ver _clasificar). nunca por simple paso del
    tiempo.

    excepcion para sismos a pedido explicito de antonella el
    25-09-2026: un sismo ya paso, no esta "evolucionando" como una
    alerta de inundacion. que el catalogo lo revise despues con un
    epicentro mas preciso o una magnitud distinta en 0.2 no es una
    novedad real. es la misma noticia con mas precision. por eso un
    sismo se avisa una sola vez para siempre. ni una revision de
    magnitud ni un cambio de area ni una escalada de severidad lo
    vuelven a disparar. el resto de los tipos de evento si siguen la
    regla normal de arriba.

    forzar en true saltea todo lo anterior y lo usa el boton de
    prueba del dashboard."""
    if not forzar:
        if alerta.severidad.lower() not in SEVERIDADES_QUE_NOTIFICAN:
            return Resultado(False, NOTIFICADOR, f"severidad '{alerta.severidad}' no notifica")
        estado = _datos_estado(alerta)
        if estado["tipo"] == "sismo":
            if _estado.existe(alerta.clave):
                return Resultado(False, NOTIFICADOR, "sismo ya avisado (no se repite por revision)")
            tipo, descripcion = "nueva", ""
        else:
            tipo, descripcion = _estado.clasificar(
                alerta.clave, alerta.severidad, estado["comunas"], estado["tiendas"],
                tema=estado["tema"], fenomeno=estado["fenomeno"],
                area_hash=estado["area_hash"],
            )
        if tipo == "sin_cambios":
            return Resultado(False, NOTIFICADOR, "sin cambios desde el ultimo aviso")
        if tipo == "modificada":
            alerta = _con_cambio(alerta, descripcion)

    proveedor = _PROVEEDORES.get(NOTIFICADOR, _enviar_consola)
    resultado = proveedor(alerta)
    if resultado.enviado:
        estado = _datos_estado(alerta)
        _estado.guardar(
            alerta.clave, alerta.severidad, estado["comunas"], estado["tiendas"],
            tema=estado["tema"], fenomeno=estado["fenomeno"],
            area_hash=estado["area_hash"],
        )
    return resultado


def reiniciar_memoria() -> None:
    """limpia el estado de eventos notificados. solo para tests."""
    _estado.reiniciar()


# traduccion de eventos a alertas


def _plural(n: int, singular: str, plural: str) -> str:
    return f"{n} {singular if n == 1 else plural}"


def _hash_area(evento: dict) -> str:
    """huella corta del poligono de cobertura del campo area de un
    evento. vacio si no trae area. sirve para notar un cambio de
    cobertura aunque ninguna tienda entre o salga del calculo. ver
    notificador_estado.py."""
    area = evento.get("area")
    if not area:
        return ""
    try:
        return hashlib.sha1(json.dumps(area, sort_keys=True).encode("utf-8")).hexdigest()[:16]
    except Exception:  # noqa: BLE001 un area rara no puede romper la alerta
        return ""


def alerta_desde_tiendas(
    evento: dict, tiendas: list[dict], base_url: str = "", total_en_riesgo: int | None = None
) -> Alerta:
    """convierte un evento mas sus tiendas en riesgo en una sola alerta consolidada.

    una sola alerta con 9 comunas adentro, nunca 9 alertas. mismo
    criterio que ya usa la campana del dashboard. ver
    static/mapa.html. un canal que manda nueve mensajes por un mismo
    frente se silencia y despues no sirve para la alerta roja que si
    importa.

    total_en_riesgo, si se pasa, reemplaza a len(tiendas) como el
    numero que se muestra de "tiendas en riesgo". existe porque una
    tienda puede caer en el radio de mas de un evento activo a la vez.
    mostrar 45 tiendas en una alerta y 9 en otra, cuando el total real
    sin duplicados es 46, es confuso porque parece que no suman.
    main.py le pasa el total global ya deduplicado para que todas las
    alertas de un mismo ciclo muestren el mismo numero, consistente
    con lo que ve el dashboard. sin este parametro, por ejemplo en los
    tests, se sigue usando len(tiendas)."""
    comunas = sorted({t.get("comuna", "") for t in tiendas if t.get("comuna")})
    personas = sum(t.get("cantidad_colaboradores") or 0 for t in tiendas)
    titulo = evento.get("titulo") or "Evento sin titulo"
    severidad = (evento.get("severidad") or "amarilla").lower()
    cantidad_tiendas = len(tiendas) if total_en_riesgo is None else total_en_riesgo

    comunas_texto = ""
    if comunas:
        comunas_texto = ", ".join(comunas[:5]) + (f" y {len(comunas) - 5} mas" if len(comunas) > 5 else "")

    partes = [_plural(cantidad_tiendas, "tienda en riesgo", "tiendas en riesgo")]
    if comunas_texto:
        partes.append(f"Comunas: {comunas_texto}")
    if personas:
        # "estimado" no es adorno. la dotacion viene del modelo por
        # formato de tienda y no de una nomina real. ver dotacion.py.
        # quien lea esto en el telefono tiene que saber que no es un
        # conteo de personas reales
        partes.append(f"~{personas} asociados (estimado)")

    return Alerta(
        # solo la identidad del evento. la severidad ya no va aca
        # porque una escalada de severidad es un cambio que se detecta
        # y describe, no una identidad nueva. ver notificar y _clasificar
        clave=str(evento.get("id") or titulo),
        titulo=f"[{severidad.upper()}] {titulo}",
        cuerpo=". ".join(partes) + ".",
        severidad=severidad,
        url=urllib.parse.urljoin(base_url, "/mapa") if base_url else "",
        datos={
            "tiendas": cantidad_tiendas,
            "tiendas_propias": len(tiendas),  # ver _datos_estado. el fingerprint usa esto y no el total global
            "comunas": len(comunas),
            "comunas_texto": comunas_texto,
            "comunas_lista": comunas,
            "personas_estimadas": personas,
            "fuente": evento.get("source", ""),
            "fecha": evento.get("fecha", ""),
            "tema": evento.get("tema") or "",
            "fenomeno": evento.get("fenomeno") or "",
            "area_hash": _hash_area(evento),
            "tipo_evento": evento.get("tipo") or "",
        },
    )
