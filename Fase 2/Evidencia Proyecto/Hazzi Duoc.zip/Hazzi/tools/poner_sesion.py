"""Inserta sesion.js + el guardia de sesion en las paginas internas.

Se corre UNA vez (es idempotente: detecta si ya esta puesto). Existe como
script y no como 8 ediciones a mano para que la version del cache-buster y
la forma del guardia queden identicas en todas las paginas -- justo el tipo
de detalle que se desincroniza cuando se copia y pega.
"""
from __future__ import annotations

import io
import re
from pathlib import Path

STATIC = Path(__file__).parent.parent / "app" / "static"
VERSION_COMMON = "v=44"
VERSION_SESION = "v=1"

# Cada pagina interna con su guardia. El admin exige rol de administrador y,
# si no lo tiene, cae al dashboard en vez de a la portada (ya esta logueado,
# solo no le corresponde esa seccion).
PAGINAS = {
    "index.html": "exigirSesion();",
    "mapa.html": "exigirSesion();",
    "tiendas.html": "exigirSesion();",
    "eventos.html": "exigirSesion();",
    "historial.html": "exigirSesion();",
    "estadisticas.html": "exigirSesion();",
    "admin.html": "exigirSesion({ admin: true });",
    "admin-ajustes.html": "exigirSesion({ admin: true });",
}


def main() -> int:
    tocados = 0
    for nombre, guardia in PAGINAS.items():
        ruta = STATIC / nombre
        if not ruta.exists():
            print(f"  FALTA {nombre}")
            continue

        texto = io.open(ruta, encoding="utf-8").read()
        if "sesion.js" in texto:
            print(f"  ya estaba  {nombre}")
            continue

        bloque = (
            f'<script src="/static/sesion.js?{VERSION_SESION}"></script>\n'
            f"  <script>{guardia}</script>\n"
            f'  <script src="/static/common.js?{VERSION_COMMON}"></script>'
        )
        nuevo, n = re.subn(
            r'<script src="/static/common\.js\?v=\d+"></script>', bloque, texto, count=1
        )
        if not n:
            print(f"  SIN MATCH  {nombre}")
            continue

        io.open(ruta, "w", encoding="utf-8").write(nuevo)
        tocados += 1
        print(f"  OK         {nombre}")

    print(f"\n{tocados} pagina(s) actualizada(s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
