"""limitador de intentos en memoria, ventana deslizante.

sirve para dos cosas: frenar la fuerza bruta contra el login (se cuentan
solo los intentos fallidos) y poner un techo al registro de visitas de
monitoreo, que es publico y escribe en la base (se cuenta cada llamada).

vive en memoria a proposito: hazzi corre como un solo proceso (ver
COMO-LEVANTAR.md), asi que no hace falta redis ni una tabla. si el
proceso se reinicia los contadores vuelven a cero, que para un bloqueo de
unos minutos es un costo aceptable. si algun dia corren varios workers,
cada uno llevaria su propia cuenta y habria que mover esto a la base.
"""
from __future__ import annotations

import time
from collections import deque
from threading import Lock

_MAX_CLAVES = 10_000  # tope de memoria: claves distintas que se recuerdan a la vez


class Limitador:
    def __init__(self, maximo: int, ventana_s: int):
        self.maximo = maximo
        self.ventana_s = ventana_s
        self._eventos: dict[str, deque[float]] = {}
        self._lock = Lock()

    def _podar(self, clave: str, ahora: float) -> deque[float]:
        cola = self._eventos.get(clave)
        if cola is None:
            return deque()
        while cola and cola[0] <= ahora - self.ventana_s:
            cola.popleft()
        if not cola:
            self._eventos.pop(clave, None)
        return cola

    def espera(self, clave: str) -> int:
        """segundos que faltan para poder reintentar, 0 si no esta bloqueado."""
        ahora = time.monotonic()
        with self._lock:
            cola = self._podar(clave, ahora)
            if len(cola) < self.maximo:
                return 0
            return max(1, int(cola[0] + self.ventana_s - ahora) + 1)

    def registrar(self, clave: str) -> None:
        ahora = time.monotonic()
        with self._lock:
            if clave not in self._eventos and len(self._eventos) >= _MAX_CLAVES:
                # lleno: se descartan las claves ya vencidas antes de aceptar otra
                for k in list(self._eventos):
                    self._podar(k, ahora)
                if len(self._eventos) >= _MAX_CLAVES:
                    return
            self._eventos.setdefault(clave, deque()).append(ahora)

    def limpiar(self, clave: str) -> None:
        with self._lock:
            self._eventos.pop(clave, None)
