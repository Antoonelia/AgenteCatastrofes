"""tests de sesiones.py: crear, validar, expirar y cerrar una sesion.

usa usuarios.py para tener una cuenta real detras de la sesion, ver
_aislar_motor.py para el porque ambos modulos comparten el mismo
engine temporal: una sesion sin su usuario detras no sirve de nada.
"""
from __future__ import annotations

from datetime import datetime, timedelta

from fastapi import HTTPException
from sqlalchemy import update

from app import sesiones, usuarios

from ._aislar_motor import motor_temporal_para

RUT = "11111111-1"


def _crear_usuario(rol="admin"):
    return usuarios.crear(RUT, "Ana Soto", "claveSegura123", rol)


def test_crear_sesion_y_obtener_usuario():
    with motor_temporal_para(usuarios, sesiones):
        creado = _crear_usuario()
        token = sesiones.crear(creado["id"])
        usuario = sesiones.obtener_usuario(token)
        assert usuario is not None
        assert usuario["nombre"] == "Ana Soto"
        assert usuario["roles"] == ["admin"]


def test_token_invalido_no_devuelve_usuario():
    with motor_temporal_para(usuarios, sesiones):
        assert sesiones.obtener_usuario("token-que-no-existe") is None


def test_sin_token_no_devuelve_usuario():
    with motor_temporal_para(usuarios, sesiones):
        assert sesiones.obtener_usuario(None) is None


def test_sesion_vencida_no_vale():
    with motor_temporal_para(usuarios, sesiones):
        creado = _crear_usuario()
        token = sesiones.crear(creado["id"])
        with sesiones.engine.begin() as conn:
            conn.execute(
                update(sesiones.sesiones_tabla)
                .where(sesiones.sesiones_tabla.c.token == token)
                .values(expira_en=datetime.now() - timedelta(minutes=1))
            )
        assert sesiones.obtener_usuario(token) is None


def test_cerrar_sesion_la_invalida():
    with motor_temporal_para(usuarios, sesiones):
        creado = _crear_usuario()
        token = sesiones.crear(creado["id"])
        sesiones.cerrar(token)
        assert sesiones.obtener_usuario(token) is None


def test_desactivar_el_usuario_invalida_sus_sesiones_vivas():
    """una sesion no debe sobrevivir a la baja del usuario."""
    with motor_temporal_para(usuarios, sesiones):
        creado = _crear_usuario()
        token = sesiones.crear(creado["id"])
        usuarios.cambiar_activo(creado["id"], False)
        assert sesiones.obtener_usuario(token) is None


# --- dependencia requiere_rol ---------------------------------------------

def test_requiere_rol_deja_pasar_el_rol_correcto():
    with motor_temporal_para(usuarios, sesiones):
        creado = _crear_usuario(rol="admin_usuarios")
        token = sesiones.crear(creado["id"])
        dependencia = sesiones.requiere_rol("admin_usuarios")
        usuario = dependencia(hazzi_sesion=token)
        assert usuario["roles"] == ["admin_usuarios"]


def test_requiere_rol_rechaza_sin_sesion_con_401():
    with motor_temporal_para(usuarios, sesiones):
        dependencia = sesiones.requiere_rol("admin")
        try:
            dependencia(hazzi_sesion=None)
            assert False, "debia lanzar HTTPException"
        except HTTPException as exc:
            assert exc.status_code == 401


def test_requiere_rol_rechaza_rol_equivocado_con_403():
    with motor_temporal_para(usuarios, sesiones):
        creado = _crear_usuario(rol="admin")
        token = sesiones.crear(creado["id"])
        dependencia = sesiones.requiere_rol("admin_usuarios")
        try:
            dependencia(hazzi_sesion=token)
            assert False, "debia lanzar HTTPException"
        except HTTPException as exc:
            assert exc.status_code == 403


def test_requiere_rol_deja_pasar_a_quien_tiene_ambos_roles():
    """una cuenta con admin Y admin_usuarios pasa cualquiera de los dos
    guardias. decision de antonella: una persona puede tener acceso a
    los dos paneles a la vez."""
    with motor_temporal_para(usuarios, sesiones):
        creado = _crear_usuario(rol=["admin", "admin_usuarios"])
        token = sesiones.crear(creado["id"])
        assert sesiones.requiere_rol("admin")(hazzi_sesion=token)["id"] == creado["id"]
        assert sesiones.requiere_rol("admin_usuarios")(hazzi_sesion=token)["id"] == creado["id"]
