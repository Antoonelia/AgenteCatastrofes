"""fetcher: sale a internet a traves del proxy corporativo de walmart.

python directo con requests o urllib falla con error 407 por el proxy
autenticado. la solucion que funciona es delegar la peticion a powershell
que autentica el proxy con las credenciales de la sesion de windows.

requisito: estar en la vpn de walmart o wifi eagle con sesion de windows
iniciada."""
from __future__ import annotations

import base64
import json
import subprocess
from pathlib import Path

_PS1 = Path(__file__).parent / "fetch.ps1"
_PS1_MANY = Path(__file__).parent / "fetch_many.ps1"


def fetch_text(url: str) -> str:
    """descarga el contenido de una url usando powershell y el proxy corporativo."""
    result = subprocess.run(
        [
            "powershell",
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(_PS1),
            "-Url",
            url,
        ],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=60,
    )
    if result.returncode != 0:
        raise RuntimeError(f"fetch fallo para {url}: {(result.stderr or '').strip()}")
    return result.stdout


def fetch_json(url: str) -> dict:
    """descarga y parsea json."""
    return json.loads(fetch_text(url))


def fetch_many(urls: list[str]) -> dict[str, str | None]:
    """descarga varias urls en un solo proceso de powershell. ver fetch_many.ps1.

    el arranque de powershell es el costo real de cada fetch_text individual
    no la descarga en si. pedir doce urls por separado paga ese arranque doce
    veces. esto lo paga una sola vez para todo el lote. las urls que fallen
    quedan como none y quien llama cae de vuelta a fetch_text o fetch_json
    para esa url sola.

    devuelve un diccionario vacio si el proceso en lote falla completo. todas
    las fuentes deben poder seguir funcionando con su fallback de siempre."""
    if not urls:
        return {}
    # base64 porque pasar un array por linea de comandos no funciona bien en
    # windows powershell y algunas urls traen comas que romperian un
    # formato tipo a,b,c
    payload = base64.b64encode(json.dumps(urls).encode("utf-8")).decode("ascii")
    result = subprocess.run(
        [
            "powershell",
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(_PS1_MANY),
            "-UrlsB64",
            payload,
        ],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=90,
    )
    if result.returncode != 0:
        raise RuntimeError(f"fetch_many fallo: {(result.stderr or '').strip()[:200]}")
    try:
        crudo = json.loads(result.stdout)
    except json.JSONDecodeError:
        return {}
    return crudo if isinstance(crudo, dict) else {}


def json_de(url: str, prefetched: dict[str, str | None] | None) -> dict:
    """json de una url. del lote prefetcheado si esta ahi si no la pide sola.
    lo comparten todas las fuentes arcgis para no repetir el mismo fallback
    en cada una."""
    crudo = (prefetched or {}).get(url)
    return json.loads(crudo) if crudo else fetch_json(url)


def text_de(url: str, prefetched: dict[str, str | None] | None) -> str | None:
    """texto de una url ya prefetcheada o none si no vino en el lote."""
    return (prefetched or {}).get(url)
