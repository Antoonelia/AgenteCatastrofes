"""diagnostico. que tan bien esta funcionando hazzi por dentro.

guarda un registro liviano de los ultimos ciclos de recoleccion para
que la pantalla de admin pueda responder tres preguntas sin adivinar.
las 6 fuentes estan respondiendo. cuando fue la ultima recoleccion y
cuanto tardo. como esta configurado el sistema ahora mismo.

por que existe: _recolectar en main.py ya juntaba los errores por
fuente pero los devolvia en el json de /api/events y ahi morian porque
nadie los miraba. una fuente de gobierno puede estar caida durante
horas y el dashboard se ve perfecto solo que con menos eventos. este
modulo hace visible esa diferencia entre "chile esta tranquilo" y "la
fuente no contesta" que a simple vista son identicas y significan
cosas opuestas.

el estado vive en memoria a proposito. es diagnostico operativo no dato
de negocio. si el server reinicia se pierde y esta bien. persistirlo
significaria una tabla migraciones y limpieza periodica para algo que
solo sirve mientras el proceso esta vivo."""
from __future__ import annotations

import os
import time
from collections import deque
from dataclasses import dataclass, field

from .sources import SOURCES_META

MAX_CICLOS = 30  # cuantos ciclos de recoleccion se recuerdan. a 60
# segundos por ciclo son unos 30 minutos de historia que alcanza para ver
# si una fuente se esta cayendo de a ratos

ARRANQUE = time.time()


@dataclass(frozen=True)
class Ciclo:
    """lo que paso en una recoleccion."""

    ts: float
    duracion_s: float
    por_fuente: dict[str, int] = field(default_factory=dict)
    errores: dict[str, str] = field(default_factory=dict)
    total_vigentes: int = 0
    tiendas_en_riesgo: int = 0


_CICLOS: deque[Ciclo] = deque(maxlen=MAX_CICLOS)


def registrar(
    duracion_s: float,
    por_fuente: dict[str, int],
    errores: dict[str, str],
    total_vigentes: int,
    tiendas_en_riesgo: int,
) -> None:
    """anota un ciclo de recoleccion. lo llama _recolectar en main.py."""
    _CICLOS.append(
        Ciclo(
            ts=time.time(),
            duracion_s=round(duracion_s, 2),
            por_fuente=dict(por_fuente),
            errores=dict(errores),
            total_vigentes=total_vigentes,
            tiendas_en_riesgo=tiendas_en_riesgo,
        )
    )


def reiniciar() -> None:
    """borra la historia de ciclos. solo para tests."""
    _CICLOS.clear()


# estado por fuente. tres estados posibles y la distincion entre los
# dos ultimos es el punto de todo el modulo. sin_datos y ok se ven
# igual en el dashboard porque hay pocos eventos pero significan cosas
# opuestas

ESTADO_OK = "ok"  # respondio y trajo eventos
ESTADO_SIN_DATOS = "sin_datos"  # respondio bien pero cero eventos
ESTADO_ERROR = "error"  # no se pudo consultar


def _estado_fuente(nombre: str, ciclo: Ciclo | None) -> dict:
    # la ficha descriptiva como organismo tipo que trae y sitio sale tal
    # cual de sources_meta en vez de copiarse aca. el catalogo de fuentes
    # se describe una sola vez en sources/__init__.py y esta pantalla
    # solo le suma el estado operativo del ultimo ciclo
    meta = SOURCES_META.get(nombre, {})
    base = {
        "fuente": nombre,
        "cubre": meta.get("cubre", ""),
        "organismo": meta.get("organismo", ""),
        "tipo": meta.get("tipo", ""),
        "trae": meta.get("trae", ""),
        "sitio": meta.get("sitio", ""),
        "eventos": 0,
        "detalle": "",
    }

    if ciclo is None:
        return {**base, "estado": ESTADO_SIN_DATOS, "detalle": "sin recolecciones todavia"}

    # un fallo del prefetch en bloque afecta a las 5 fuentes que salen
    # por powershell no solo a una. mostrarlo unicamente como "prefetch"
    # esconderia la causa real de que 5 fuentes esten en cero
    error = ciclo.errores.get(nombre) or (
        ciclo.errores.get("prefetch") if nombre != "SENAPRED" else None
    )
    if error:
        return {**base, "estado": ESTADO_ERROR, "detalle": error}

    cantidad = ciclo.por_fuente.get(nombre, 0)
    if cantidad == 0:
        return {
            **base,
            "estado": ESTADO_SIN_DATOS,
            "detalle": "respondio sin eventos (normal si no hay emergencias)",
        }
    return {**base, "estado": ESTADO_OK, "eventos": cantidad}


def _fallos_recientes(nombre: str) -> int:
    """en cuantos de los ciclos recordados fallo esta fuente.

    una fuente que falla 1 de 30 veces tuvo un hipo. una que falla 25
    de 30 esta caida aunque justo el ultimo ciclo le haya salido bien."""
    return sum(
        1
        for c in _CICLOS
        if c.errores.get(nombre) or (c.errores.get("prefetch") if nombre != "SENAPRED" else None)
    )


# configuracion visible


def _enmascarar(url: str) -> str:
    """oculta credenciales de una url de conexion antes de mostrarla.

    una database_url de sqlite es inofensiva pero el dia que apunte a
    un sql corporativo va a traer usuario y clave. esta pantalla es
    justo donde alguien sacaria una captura para pegarla en un ticket."""
    if "@" not in url:
        return url
    esquema, _, resto = url.partition("://")
    credenciales, _, servidor = resto.rpartition("@")
    usuario = credenciales.split(":")[0] if credenciales else ""
    return f"{esquema}://{usuario}:***@{servidor}" if esquema else f"{usuario}:***@{servidor}"


def configuracion() -> list[dict]:
    """como esta configurado el sistema ahora mismo.

    se lee del entorno en cada llamada sin cachear para que refrescar
    la pantalla muestre la verdad y no un valor congelado al importar
    el modulo."""
    from . import ai_client, notificador
    from .db import DATABASE_URL

    ia_real = ai_client.AI_PROVIDER == "gemini" and bool(ai_client.GEMINI_API_KEY)
    return [
        {
            "clave": "Proveedor de IA",
            "valor": ai_client.AI_PROVIDER,
            "nota": "respuestas reales" if ia_real else "modo reglas, sin LLM",
            "degradado": not ia_real,
        },
        {
            "clave": "Canal de notificaciones",
            "valor": notificador.NOTIFICADOR,
            "nota": "solo imprime al log"
            if notificador.NOTIFICADOR == "consola"
            else "envia fuera del navegador",
            "degradado": notificador.NOTIFICADOR == "consola",
        },
        {
            "clave": "Severidades que notifican",
            "valor": ", ".join(sorted(notificador.SEVERIDADES_QUE_NOTIFICAN)) or "(ninguna)",
            "nota": "las demas solo se ven en el dashboard",
            "degradado": not notificador.SEVERIDADES_QUE_NOTIFICAN,
        },
        {
            "clave": "Base de datos",
            "valor": _enmascarar(DATABASE_URL),
            "nota": "SQLite local" if DATABASE_URL.startswith("sqlite") else "motor externo",
            "degradado": False,
        },
        {
            "clave": "Dotacion por tienda",
            "valor": "estimada por formato",
            "nota": "no es nomina real (ver app/dotacion.py)",
            "degradado": True,
        },
        {
            "clave": "Salida a internet",
            "valor": "PowerShell + proxy corporativo",
            "nota": "requiere sesion de Windows iniciada: impide operacion 24/7",
            "degradado": True,
        },
    ]


# resumen para la ui


def _formato_duracion(segundos: float) -> str:
    minutos, seg = divmod(int(segundos), 60)
    horas, minutos = divmod(minutos, 60)
    dias, horas = divmod(horas, 24)
    if dias:
        return f"{dias}d {horas}h"
    if horas:
        return f"{horas}h {minutos}m"
    if minutos:
        return f"{minutos}m {seg}s"
    return f"{seg}s"


def resumen() -> dict:
    """todo lo que la pantalla de admin necesita en una sola llamada."""
    ultimo = _CICLOS[-1] if _CICLOS else None
    fuentes = [_estado_fuente(n, ultimo) for n in SOURCES_META]
    for f in fuentes:
        f["fallos_recientes"] = _fallos_recientes(f["fuente"])

    duraciones = [c.duracion_s for c in _CICLOS]
    caidas = sum(1 for f in fuentes if f["estado"] == ESTADO_ERROR)

    return {
        "generado": time.time(),
        "uptime": _formato_duracion(time.time() - ARRANQUE),
        "uptime_s": round(time.time() - ARRANQUE),
        "fuentes": fuentes,
        "fuentes_ok": sum(1 for f in fuentes if f["estado"] == ESTADO_OK),
        "fuentes_error": caidas,
        "fuentes_total": len(fuentes),
        # si hay fuentes caidas lo que muestra el dashboard es una foto
        # incompleta. eso tiene que decirse no deducirse
        "confiable": caidas == 0,
        "ciclos_registrados": len(_CICLOS),
        "ultimo_ciclo": {
            "hace_s": round(time.time() - ultimo.ts) if ultimo else None,
            "duracion_s": ultimo.duracion_s if ultimo else None,
            "eventos_vigentes": ultimo.total_vigentes if ultimo else 0,
            "tiendas_en_riesgo": ultimo.tiendas_en_riesgo if ultimo else 0,
        }
        if ultimo
        else None,
        "duracion_promedio_s": round(sum(duraciones) / len(duraciones), 2) if duraciones else None,
        "duracion_maxima_s": max(duraciones) if duraciones else None,
        "configuracion": configuracion(),
        "historial_ciclos": [
            {
                "hace_s": round(time.time() - c.ts),
                "duracion_s": c.duracion_s,
                "eventos": c.total_vigentes,
                "errores": len(c.errores),
            }
            for c in reversed(_CICLOS)
        ],
    }
