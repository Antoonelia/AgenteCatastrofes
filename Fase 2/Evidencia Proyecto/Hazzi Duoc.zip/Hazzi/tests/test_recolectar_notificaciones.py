"""regression. el ciclo de recoleccion debe llamar a
notificador.notificar para cada evento severo que afecte al menos una
tienda. ver main.py _notificar_eventos.

motivo: notificador.py existia completo y probado, ver
test_notificador.py con 18 tests, pero nadie lo llamaba desde
_recolectar. quedaba anotado como pendiente en
docs/wellbeing/04-notificaciones.md, "enganchar notificar al bucle de
main.py". este test fija que la conexion real quede hecha, sin repetir
las pruebas de canal filtros y anti repeticion que ya cubre
test_notificador.py."""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime

from app import area as area_mod
from app import main as main_mod
from app.normalize import Event

_FMT = "%d-%m-%Y %H:%M hrs"
_TITULO_SISMO = "M6.2 - 30 km al O de Valparaiso"

_TIENDA_CERCA = {
    "formato": "Lider", "comuna": "Valparaiso", "direccion": "Test 1",
    "region": "Valparaiso", "lat": -33.03, "lon": -71.61, "precision": "direccion",
}
_TIENDA_LEJOS = {
    "formato": "Lider", "comuna": "Arica", "direccion": "Test 2",
    "region": "Arica y Parinacota", "lat": -18.47, "lon": -70.31, "precision": "direccion",
}


def _ahora_chile_str() -> str:
    """igual que retention.py _ahora_cl pero formateada, para que el
    test pase la ventana de retencion sin depender de la zona horaria
    de la maquina."""
    try:
        from zoneinfo import ZoneInfo
        ahora = datetime.now(ZoneInfo("America/Santiago")).replace(tzinfo=None)
    except Exception:  # noqa: BLE001
        ahora = datetime.now()
    return ahora.strftime(_FMT)


def _sismo_valparaiso() -> Event:
    return Event(
        source="CSN",
        tipo="sismo",
        titulo=_TITULO_SISMO,
        severidad="roja",
        lat=-33.05,
        lon=-71.62,
        fecha=_ahora_chile_str(),
        detalle="Magnitud 6.2",
        area=area_mod.por_sismo(6.2),
    )


@contextmanager
def _parcheado(obj, nombre, valor_nuevo):
    original = getattr(obj, nombre)
    setattr(obj, nombre, valor_nuevo)
    try:
        yield
    finally:
        setattr(obj, nombre, original)


def test_un_evento_severo_con_tienda_cerca_dispara_una_notificacion():
    llamadas = []

    def _fake_notificar(alerta, forzar=False):
        llamadas.append(alerta)

    with _parcheado(main_mod, "REGISTRY", {"CSN": lambda prefetched: [_sismo_valparaiso()]}), \
         _parcheado(main_mod, "fetch_many", lambda urls: {}), \
         _parcheado(main_mod.senapred, "fetch_events", lambda: []), \
         _parcheado(main_mod, "build_stores", lambda: [_TIENDA_CERCA, _TIENDA_LEJOS]), \
         _parcheado(main_mod.instalaciones, "aplicar", lambda tiendas: tiendas), \
         _parcheado(main_mod.instalaciones, "operativas", lambda tiendas: tiendas), \
         _parcheado(main_mod, "_agregar_dotacion", lambda tiendas_riesgo: None), \
         _parcheado(main_mod.historial, "registrar_ciclo", lambda *a, **k: None), \
         _parcheado(main_mod.notificador, "notificar", _fake_notificar):
        main_mod._recolectar()

    assert len(llamadas) == 1, "debia disparar exactamente una alerta para el sismo"
    alerta = llamadas[0]
    assert alerta.severidad == "roja"
    assert "tienda" in alerta.cuerpo.lower()


def test_un_evento_sin_ninguna_tienda_cerca_no_notifica():
    llamadas = []

    def _fake_notificar(alerta, forzar=False):
        llamadas.append(alerta)

    with _parcheado(main_mod, "REGISTRY", {"CSN": lambda prefetched: [_sismo_valparaiso()]}), \
         _parcheado(main_mod, "fetch_many", lambda urls: {}), \
         _parcheado(main_mod.senapred, "fetch_events", lambda: []), \
         _parcheado(main_mod, "build_stores", lambda: [_TIENDA_LEJOS]), \
         _parcheado(main_mod.instalaciones, "aplicar", lambda tiendas: tiendas), \
         _parcheado(main_mod.instalaciones, "operativas", lambda tiendas: tiendas), \
         _parcheado(main_mod, "_agregar_dotacion", lambda tiendas_riesgo: None), \
         _parcheado(main_mod.historial, "registrar_ciclo", lambda *a, **k: None), \
         _parcheado(main_mod.notificador, "notificar", _fake_notificar):
        main_mod._recolectar()

    assert not llamadas, "sin tiendas cerca no debe dispararse ninguna alerta"
