"""Crea un usuario de administracion directo en la base de datos, sin
necesitar el server levantado. Es el reemplazo de "definir ADMIN_KEY":
ahora hace falta al menos un admin_usuarios para poder gestionar el
resto de las cuentas.

Una cuenta puede tener mas de un rol a la vez (ej. admin y
admin_usuarios juntos): se acepta una lista separada por comas.

Uso interactivo:

    .venv\\Scripts\\python.exe tools\\crear_admin.py

O con argumentos (util para scripts/CI):

    .venv\\Scripts\\python.exe tools\\crear_admin.py 12345678-9 "Ana Soto" "claveSegura123" admin_usuarios
    .venv\\Scripts\\python.exe tools\\crear_admin.py 12345678-9 "Ana Soto" "claveSegura123" admin,admin_usuarios
"""
from __future__ import annotations

import getpass
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app import usuarios  # noqa: E402


def _pedir(etiqueta: str, oculto: bool = False) -> str:
    return (getpass.getpass(etiqueta) if oculto else input(etiqueta)).strip()


def main() -> int:
    if len(sys.argv) >= 5:
        rut, nombre, clave, roles_crudo = sys.argv[1:5]
    else:
        print("-- Crear usuario de administracion --\n")
        rut = _pedir("RUT (ej. 12345678-9): ")
        nombre = _pedir("Nombre y apellido: ")
        clave = _pedir("Clave (minimo 8 caracteres): ", oculto=True)
        roles_crudo = _pedir(
            f"Rol(es), separados por coma si son varios ({' / '.join(usuarios.ROLES)}): "
        ) or "admin_usuarios"

    roles = [r.strip() for r in roles_crudo.split(",") if r.strip()]

    try:
        creado = usuarios.crear(rut, nombre, clave, roles)
    except ValueError as exc:
        print(f"\nError: {exc}")
        return 1

    print(f"\nListo. Usuario creado: {creado['nombre']} ({creado['rut_enmascarado']}), roles: {', '.join(creado['roles'])}.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
