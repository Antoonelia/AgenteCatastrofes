# Notificaciones fuera del navegador

Guía de `app/notificador.py`: qué hace, cómo se activa cada canal y qué
trámite real implica WhatsApp.

---

## El problema que resuelve

Hasta ahora las notificaciones de Hazzi vivían enteras en el navegador
(`notificar()` en `static/common.js` + `localStorage`).

**Si nadie tiene la pestaña abierta, nadie se entera.** Un sismo a las 3 AM le
grita a una pantalla apagada.

Esto es exactamente la **HU-02** del backlog de Wellbeing.

---

## La arquitectura: un solo patrón, tres veces

`notificador.py` sigue **el mismo patrón** que `ai_client.py` y `dotacion.py`:
una abstracción con proveedor intercambiable por variable de entorno.

```
NOTIFICADOR=consola    # por defecto - imprime al log, cero permisos
NOTIFICADOR=teams      # webhook de canal de Teams
NOTIFICADOR=whatsapp   # WhatsApp Cloud API de Meta
```

El resto del sistema llama a `notificar(alerta)` y no sabe por dónde sale.
Cambiar de canal = cambiar una variable de entorno, cero código.

> **Para la defensa de tesis:** esto convierte una limitación en una decisión.
> "El canal es intercambiable; hoy opera en Teams porque es el canal corporativo
> sancionado, y WhatsApp queda soportado pero fuera de alcance por las
> restricciones de la API de Meta" suena a arquitectura.
> "No pude conectar WhatsApp" suena a que fallaste. Es el mismo hecho.

---

## Configuración

### `consola` — por defecto, siempre funciona

Cero configuración. Imprime al log lo que habría mandado.

No es un placeholder: en desarrollo y en una demo es el modo correcto — se ve
exactamente qué se habría enviado, sin enviar nada ni gastar un peso.

### `teams` — el recomendado

Microsoft está retirando los Conectores clásicos de Teams (Office 365
Connectors); en tenants ya migrados (Walmart incluido) ni siquiera aparece la
opción. El camino real, probado en producción:

1. Crea un canal **Privado** dentro de un equipo existente (los canales no
   pueden existir sueltos, siempre viven dentro de un equipo) — o, si ni eso
   se puede, un **chat grupal** funciona igual con la plantilla equivalente.
2. Dentro del canal: `...` → **Workflows** → plantilla **"Enviar alertas de
   webhook a un canal"** (o "Post to a chat..." si es un chat grupal) →
   elegí el canal/chat destino → **Crear**.
3. Copiá la URL que te da (un link largo de `powerplatform.com`). Es una
   credencial: nunca la pegues en código ni la commitees.

```powershell
$env:NOTIFICADOR = "teams"
$env:TEAMS_WEBHOOK_URL = "https://.....powerplatform.com/.../invoke?..."
```

Gratis, sancionado en Walmart, ~1 hora de trabajo, sin aprobaciones externas.

> **Detalle que costó una vuelta:** esta plantilla de Workflows usa la acción
> "Post card in a chat or channel", que exige una **Adaptive Card real**
> (`{"type": "AdaptiveCard", ...}`) envuelta en `attachments` — no el
> `MessageCard` clásico ni un `{"text": ...}` suelto. Mandar texto plano hace
> que el flujo falle con `Attachments is null` (verificado en vivo, con
> captura del error de Power Automate). `_payload_teams()` en
> `notificador.py` ya arma el formato correcto.
>
> **Otro detalle que asusta pero es normal:** un canal **Privado** recién
> creado tarda un rato en aprovisionarse por detrás (Microsoft le crea un
> sitio de SharePoint propio de forma asíncrona). Mientras tanto, el primer
> POST al webhook puede quedarse "Ejecutándose..." varios minutos sin fallar
> ni avanzar — no es un error de configuración, es solo que hay que esperar.
> Verificado en vivo: la primera prueba tardó largo rato, pero terminó
> llegándole sola sin tocar nada. Los envíos siguientes al mismo canal ya
> salen casi al instante.

### `whatsapp` — funciona, pero leé la sección del trámite primero

```powershell
$env:NOTIFICADOR = "whatsapp"
$env:WHATSAPP_TOKEN = "EAAG..."
$env:WHATSAPP_PHONE_ID = "123456789012345"
$env:WHATSAPP_DESTINATARIOS = "56911112222,56933334444"
$env:WHATSAPP_TEMPLATE = "alerta_hazzi"
```

Números en formato internacional **sin el `+`**.

### Ajustes comunes a todos los canales

```powershell
$env:NOTIFICAR_DESDE = "roja,naranja,amarilla"   # default: severidades que interrumpen (verde queda afuera)
$env:HAZZI_BASE_URL = "http://127.0.0.1:8000"  # opcional: agrega boton "Ver en Hazzi"
```

No hay variable de ventana anti-repeticion (existio, se saco). El criterio
actual es mas simple y a pedido explicito de Antonella: se avisa un evento
NUEVO, y se vuelve a avisar solo si CAMBIA de verdad (escala/baja de
severidad, suma o saca comunas, o cambia la cantidad de tiendas en riesgo).
Sin cambios, no se repite el aviso sin importar cuanto tiempo pase -- el
canal ya deja todo registrado. Ver app/notificador_estado.py.

---

## WhatsApp: lo que hay que saber antes de prometerlo

### Sobre los grupos

**La Cloud API de Meta es estrictamente 1:1. No existe endpoint para postear
en un grupo.** No es difícil: no está en la API. Meta lo bloquea a propósito
porque los grupos son el vector de spam número uno.

**Pero para este caso de uso da igual.** Una notificación es de una sola vía:
Hazzi avisa, nadie le responde a Hazzi. Un grupo, funcionalmente, es *"estas 12
personas reciben el mismo mensaje"* — y eso es exactamente lo que hace
`WHATSAPP_DESTINATARIOS`. Cada persona recibe lo mismo que recibiría en el grupo.

Lo único que se pierde es que se respondan entre sí en ese hilo. Cosa que van
a hacer en su propio grupo de todos modos.

### El trámite real

| Requisito | Detalle |
|---|---|
| Cuenta Meta Business **verificada** | Documentación legal de la empresa. Semanas |
| Número dedicado | **No puede tener WhatsApp normal instalado** |
| Plantilla preaprobada | Meta revisa y aprueba el texto. Días |
| Opt-in de cada destinatario | Consentimiento registrado y demostrable |
| Método de pago | Se cobra por conversación iniciada |

**Lo de la plantilla es lo que más sorprende:** no podés improvisar el texto de
una alerta. Fuera de la ventana de 24 horas solo se pueden mandar plantillas
aprobadas de antemano, con parámetros posicionales. Por eso el código arma
`{{1}} {{2}} {{3}}` y no un texto libre.

### La plantilla a registrar en Meta

Nombre: `alerta_hazzi` · Categoría: **Utility** · Idioma: **es**

```
{{1}}

{{2}}

Severidad: {{3}}
Revisa el detalle en Hazzi.
```

Los tres parámetros que manda el código, en orden: **título**, **cuerpo**, **severidad**.

### Lo que NO se hizo, y por qué

Vas a encontrar `whatsapp-web.js`, `Baileys`, `pywhatkit`. Prometen mandar a
grupos, gratis, en diez líneas. **Están descartadas deliberadamente:**

- Automatizan la **sesión personal de alguien** — hay que escanear un QR con un
  celular real. Sería el WhatsApp de un asociado convertido en bot corporativo
- Violan los Términos de Servicio de WhatsApp. Meta banea el número, no la app
- Se rompen solas con cada actualización del protocolo
- Un canal no sancionado transportando información de emergencias en Walmart es
  una conversación con Compliance que no querés tener

Frente a un tribunal, "usé una librería que viola los ToS" te lo preguntan.

---

## Las dos protecciones que evitan el desastre

El bucle de recolección corre **cada 60 segundos** (`_REFRESH_INTERVAL` en
`main.py`). Sin defensas, un sistema frontal activo 6 horas manda el mismo aviso
**360 veces**. El equipo silencia el canal el primer día y después no se entera
de la alerta roja que sí importa.

### 1. Filtro por severidad

`amarilla` hacia arriba interrumpe (amarilla, naranja, roja -- configurable con
`NOTIFICAR_DESDE`, a pedido explicito de Antonella el 2026-09-24). Solo las
**verdes** se quedan afuera: son registro puro, se ven en el dashboard y no
justifican sacar a nadie de la cama.

### 2. Novedad/cambio, nunca un recordatorio

La misma `clave` (la identidad del evento) no se reenvía si nada cambió desde
el último aviso -- y a diferencia del diseño original, **no hay ventana de
tiempo**: no se repite ni aunque pasen dias, porque el canal ya deja todo
registrado (decision de Antonella, 2026-09-24, reemplazando el diseño
anterior de "ventana de 3h" que mandaba un recordatorio periodico).

Se vuelve a avisar SOLO si el evento es nuevo, o si cambió de verdad:
escaló/bajó de severidad, se sumaron o sacaron comunas, o cambió la cantidad
de tiendas en riesgo. El mensaje de la actualización dice explicitamente QUE
cambió (prefijo "[ACTUALIZACION]" + descripción, ver app/notificador_estado.py).

Tres detalles finos que están en los tests:

- **La clave YA NO incluye la severidad.** Es solo la identidad del evento;
  una escalada de severidad es uno de los cambios que se detectan, no una
  identidad de aviso distinta.
- **Un envío fallido no marca la alerta como avisada.** Si el canal estaba
  caído, el próximo ciclo reintenta. El error inverso —dar por avisada una
  alerta que nunca salió— es el caro.
- **El estado persiste en SQL, no en memoria.** Si el server reinicia, no se
  repiten avisos de eventos que ya se notificaron y no cambiaron -- antes
  vivía en memoria a propósito y un restart hacía que TODO se viera "nunca
  avisado" (bug real reportado en vivo, corregido el mismo día).

### 3. Consolidación

`alerta_desde_tiendas()` arma **una** alerta con 9 comunas adentro, nunca 9
alertas. Mismo criterio que ya usaba la campana del dashboard.

### 4. El numero de "tiendas en riesgo" es el TOTAL global, no el del evento

Una misma tienda puede caer en el radio de **dos eventos activos a la vez**.
Si cada alerta mostrara "sus propias" tiendas, dos avisos podrian decir "45" y
"9" en el mismo minuto cuando el total real (sin duplicados) es "46" -- los
numeros no suman entre si y es mas confuso que util. Por eso `main.py` le pasa
a **cada** alerta el mismo `total_en_riesgo` (el `len(tiendas_riesgo)` ya
deduplicado de ese ciclo), y todas las alertas de un mismo ciclo -- Teams,
dashboard, lo que sea -- muestran el mismo numero. Las notificaciones del
navegador (`static/mapa.html`) siguen el mismo criterio: solo el total actual,
nunca un listado de nombres de sucursales.

---

## Uso

```python
from app import notificador

alerta = notificador.alerta_desde_tiendas(evento, tiendas_del_evento, base_url, total_en_riesgo=len(tiendas_riesgo))
resultado = notificador.notificar(alerta)
```

`notificar()` **nunca lanza excepción**. Un canal caido no puede tumbar el ciclo
de recoleccion de eventos -- eso seria cambiar un problema de notificacion por
uno de monitoreo.

---

## Privacidad

Este módulo manda **agregados**: cuántas tiendas, cuántas comunas, cuántos
asociados estimados. **Nunca nombres, teléfonos ni datos identificatorios.**

- El conteo de personas siempre sale marcado como **"(estimado)"** — viene del
  modelo por formato de tienda de `dotacion.py`, no de una nómina real. Quien lo
  lea en el teléfono tiene que saberlo.
- Los números de destinatario se truncan en los logs de error (`...2222`).
- Cualquier cosa nominal cae bajo la **Ley 21.719** y no sale por este canal.
  Ver [`README.md`](README.md).

---

## Tests

```powershell
.venv\Scripts\python.exe -m tests
```

Tests en `tests/test_notificador.py` + `tests/test_notificador_estado.py`, sin
tocar la red. Cubren los filtros, la deteccion de novedad/cambio, la
consolidacion, el total global de tiendas y el armado de los payloads de
Teams (incluida la tarjeta con logo, emoji y tabla de datos) y de Meta.

---

## Pendiente

- [x] Enganchar `notificar()` al bucle de `main.py` -- ver `_notificar_eventos()`,
      llamado desde `_recolectar()` por cada evento que afecta al menos una
      tienda. Cubierto por `tests/test_recolectar_notificaciones.py`.
- [ ] Endpoint de prueba para disparar una alerta desde el dashboard
- [ ] Decidir el canal definitivo **con el equipo de Wellbeing**, no antes

> En la reunión no preguntes *"¿quieren WhatsApp?"* — todo el mundo dice que sí.
> Preguntá **"¿dónde miran ustedes cuando pasa algo a las 3 de la mañana?"**.
> Si la respuesta honesta es un grupo de WhatsApp, eso es un hallazgo que vale
> para la tesis: significa que el canal corporativo no está resolviendo el problema.
