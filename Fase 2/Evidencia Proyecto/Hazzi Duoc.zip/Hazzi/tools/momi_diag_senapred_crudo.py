import sys
sys.path.insert(0, ".")
from app.senapred_client import graphql
from app.sources.senapred import _QUERY, _LIMIT

res = graphql(_QUERY, {"type": "Alerta", "sortDirection": "DESC", "limit": _LIMIT})
items = (res.get("data") or {}).get("alertasByDate", {}).get("items", []) or []
print("total items crudos (sin filtrar por isActive ni severidad):", len(items))
for a in items:
    print(
        "isActive=", a.get("isActive"),
        "| isDeleted=", a.get("isDeleted"),
        "| fecha=", a.get("fechaHora"),
        "| titulo=", (a.get("titulo") or "")[:90],
    )
