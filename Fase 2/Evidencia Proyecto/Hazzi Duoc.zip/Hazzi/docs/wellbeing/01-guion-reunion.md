# Guion — Reunión 1 de levantamiento · Equipo Wellbeing (Anyelina)

**Objetivo del sprint:** *"Solución a las necesidades del equipo Wellbeing por pilar social."*
**Objetivo de ESTA reunión:** salir con **problemas priorizados**, no con una lista de features.

> Regla de oro: si salís de la reunión con una lista de pantallas que te pidieron,
> la reunión falló. Si salís con 3 momentos de dolor concretos y quién los sufre,
> la reunión fue un éxito.

---

## 0 · Antes de entrar (15 min de prep)

| Chequeo | Estado |
|---|---|
| Hazzi corriendo en `127.0.0.1:8000`, con eventos reales cargados |  |
| Pestañas abiertas: Inicio, Mapa, Tiendas |  |
| Este guion impreso o en segunda pantalla |  |
| `02-plantilla-captura.md` abierto para tipear en vivo |  |
| Alguien grabando o tomando nota (idealmente NO vos sola) |  |

**Confirmá quién viene.** Necesitás al menos uno de cada:
- Quien **decide** (Anyelina o su jefatura) → define prioridad
- Quien **ejecuta** en terreno cuando hay una emergencia → define la realidad
- Quien **tiene los datos** de asociados (HRIS / People) → define lo que es posible

Si solo viene la capa que decide, vas a levantar deseos, no procesos.

---

## 1 · Agenda (60 min)

| Min | Bloque | Quién habla |
|---|---|---|
| 0–5 | Encuadre: qué es Hazzi hoy y qué NO es | Vos |
| 5–12 | **Demo muda** de 5 min | Vos |
| 12–35 | **El día de la catástrofe** — reconstruir el proceso real | Ellos (80%) |
| 35–48 | Dolores: qué se rompe, qué cuesta caro | Ellos |
| 48–55 | Priorización en vivo | Todos |
| 55–60 | Cierre: acuerdos, datos pendientes, próxima fecha | Vos |

---

## 2 · Encuadre (leé esto casi textual)

> "Hazzi hoy detecta catástrofes en Chile en tiempo real desde 6 fuentes oficiales,
> las cruza contra las tiendas de Walmart y dice **qué locales están en riesgo y
> cuántas personas trabajan en ellos**.
>
> Lo que Hazzi **no** sabe hoy es qué pasa con **las personas** después de eso.
> Para eso los necesito a ustedes. En esta hora no quiero que me pidan pantallas
> — quiero que me cuenten qué hacen ustedes un día que tiembla."

Esto hace dos cosas: baja la ansiedad de "otro sistema más" y les da permiso
explícito de hablar de proceso en vez de software.

---

## 3 · Demo muda (5 min, cronometrados)

Mostrás. **No explicás features.** Cerrás la boca y dejás que reaccionen.

1. **Inicio** → "así se ve un día cualquiera"
2. **Mapa** → un evento real, el campo de calor, las tiendas alrededor
3. **Tiendas** → la tabla con tiendas en riesgo **y la columna de dotación**

Y entonces la única pregunta del bloque:

> **"¿Qué es lo primero que harían ustedes si vieran esta pantalla un día real?"**

Anotá la respuesta **literal**. Esa frase suele ser la historia de usuario #1.

---

## 4 · El bloque que importa: reconstruir el día real (23 min)

No preguntes "¿qué necesitan?". Preguntá por **el último evento que vivieron**.
La gente es pésima imaginando sistemas y excelente recordando caos.

### Arranque
> "Pensemos en la última emergencia real que les tocó. ¿Cuál fue?"

*(Sismo, incendio forestal, sistema frontal, aluvión… dejá que elijan ellos.)*

### Cadena de preguntas — seguí el orden, es cronológico

**Cómo se enteran**
1. ¿Cómo se enteraron de que estaba pasando? ¿Por quién?
2. ¿Cuánto pasó entre el evento y que ustedes supieran?
3. ¿Se enteraron antes o después que la prensa? *(pregunta incómoda a propósito)*

**A quién buscan**
4. ¿Cuál fue la primera pregunta que se hicieron sobre las personas?
5. ¿Cómo supieron **qué asociados** estaban en la zona afectada?
6. ¿Los que estaban en turno, o también los que viven ahí y estaban en su casa?
   *(← esta distinción es enorme y casi nadie la tiene resuelta)*
7. ¿De dónde sacaron esa lista? ¿Cuánto tardaron en tenerla?

**Cómo los contactan**
8. ¿Quién llama a quién? ¿Hay un árbol de contacto o se improvisa?
9. ¿Qué pasa cuando alguien no contesta?
10. ¿Cómo registran quién ya respondió y quién no? *(¿Excel? ¿WhatsApp? ¿memoria?)*

**Qué hacen con la respuesta**
11. Si un asociado dice "estoy mal / perdí mi casa", ¿qué se activa exactamente?
12. ¿Quién autoriza esa ayuda? ¿Cuánto demora?
13. ¿Cómo le hacen seguimiento a esa persona los días siguientes?

**Hacia afuera**
14. ¿El pilar social incluye a la **comunidad** alrededor de la tienda, o solo a asociados?
15. ¿Hay donaciones, acopio, albergue? ¿Quién los coordina?

**Cierre del bloque**
16. ¿Qué reporte les pidieron después? ¿A quién? ¿Cuánto costó armarlo?

> Si algo se pone interesante, la única pregunta que necesitás es **"¿y entonces
> qué pasó?"** repetida hasta el aburrimiento. Ahí aparecen los dolores de verdad.

---

## 5 · Dolores y costo (13 min)

17. De todo eso que me contaron, **¿qué parte los hizo perder más tiempo?**
18. ¿Qué parte los hizo quedar mal frente a alguien?
19. ¿Qué cosa hoy **no saben** y les gustaría saber?
20. Si esto vuelve a pasar mañana, **¿qué es lo primero que quisieran tener listo?**
21. ¿Hay algo que YA funciona bien y que **no** hay que tocar?
    *(pregunta anti-desastre: evita que rompas un proceso que les sirve)*

---

## 6 · Priorización en vivo (7 min)

Escribí los dolores que salieron en post-its / pizarra digital. Después:

> **"Si Hazzi solo pudiera resolver UNO de estos para el próximo evento real,
> ¿cuál salva más?"**

Pediles que ordenen **ellos**. Que la priorización tenga sus huellas digitales,
no las tuyas — así el backlog no se renegocia en la reunión 3.

Anotá el top 3. Eso **es** tu Sprint 1.

---

## 7 · Cierre (5 min)

Cerrá con estas cuatro cosas, sin excepción:

1. **Devolución en voz alta.** "Escuché que lo más caro es X, que hoy lo resuelven
   con Y, y que quieren Z. ¿Lo entendí bien?" → corrigen ahí mismo, gratis.
2. **Pedido de datos.** ¿Quién es el dueño del dato de asociados? ¿Nombre y apellido?
3. **Compromiso tuyo.** "En N días les traigo esto escrito como historias de usuario
   para que las validen." Fijá la fecha ahí, en vivo.
4. **Próxima reunión agendada** antes de colgar. Las reuniones que se agendan
   "por correo después" no existen.

---

## 8 · Las tres trampas de esta reunión

**Trampa 1 — Te van a pedir un botón.**
Alguien va a decir "yo quiero un botón que mande un WhatsApp a todos".
No digas ni sí ni no. Decí: **"¿y qué problema resolvería ese botón?"**
El botón es su solución; vos necesitás su problema.

**Trampa 2 — Datos personales de asociados. Esto es serio.**
Casi todo el pilar social necesita saber **quién** es la persona, no cuántas son.
Eso es dato personal, y parte es **dato sensible** (salud, domicilio, situación
socioeconómica). La Ley 21.719 de Chile entra en vigencia plena en **diciembre 2026**
— o sea, dentro del horizonte de este proyecto.

No frenes la conversación con esto, pero **preguntá y anotá**:
- ¿Quién es el dueño legal de ese dato hoy?
- ¿Hay alguien de Legal / Compliance / DPO que deba estar en la próxima reunión?

> Una demo que muestra nombres reales de asociados damnificados en una pantalla
> es un problema, no un logro. Esto se diseña con datos anonimizados o de prueba
> hasta que Legal diga lo contrario.

**Trampa 3 — Alcance infinito.**
"Pilar social" puede significar cinco cosas distintas *(asociados afectados,
comunidad, salud mental, voluntariado, ayuda económica)*. Si al minuto 40 están
hablando de las cinco, cortá:

> "Me encantan las cinco. Para el Sprint 1 necesito que elijan una.
> ¿Cuál de estas, si la resolvemos, cambia más un día real?"

---

## 9 · Lo que Hazzi ya te regala (tu ventaja injusta)

Llevá esto en la cabeza. Cuando pidan algo, chequeá si ya está medio construido:

| Ya existe en Hazzi | Sirve al pilar social para… |
|---|---|
| Detección en vivo desde 6 fuentes oficiales | Enterarse antes que la prensa |
| Geolocalización de tiendas + cálculo de riesgo | Saber **dónde** mirar primero |
| **Dotación por tienda** (`dotacion.py`) | Dimensionar **cuántas personas** hay expuestas |
| Historial de eventos | Reportes post-evento sin armarlos a mano |
| Resumen ejecutivo con IA (`ai_client.py`) | Comunicar hacia arriba en 1 clic |
| Mapa de calor por zona | Priorizar territorio |

| NO existe (y es donde vive el Sprint 1) |
|---|
| Identidad de las personas — hoy solo hay un **número estimado**, no un listado |
| Cualquier canal de contacto o confirmación de "estoy bien" |
| Registro de necesidades, ayudas o seguimiento |
| Integración con HRIS / People |
| Cualquier cosa de comunidad, donaciones o voluntariado |

> **El gap central, en una frase:** Hazzi hoy sabe que *"en esa tienda hay ~48 personas"*.
> El pilar social necesita saber *"quiénes son y cómo están"*. Ese salto es
> el proyecto entero — y es el que cruza la línea de datos personales.
