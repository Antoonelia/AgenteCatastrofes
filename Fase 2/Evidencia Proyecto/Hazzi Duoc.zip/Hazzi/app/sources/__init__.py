"""registro de fuentes. cada modulo expone fetch_events que devuelve una
lista de eventos."""
from __future__ import annotations

from . import conaf, csn, dmc, senapred, sernageomin, usgs

REGISTRY = {
    "CONAF": conaf.fetch_events,
    "SERNAGEOMIN": sernageomin.fetch_events,
    "DMC": dmc.fetch_events,
    "USGS": usgs.fetch_events,
    "CSN": csn.fetch_events,
    "SENAPRED": senapred.fetch_events,
}

# metadatos para la ui. es la unica fuente de verdad del catalogo de
# fuentes. la pantalla de admin arma sus tarjetas desde aca asi que con
# describir una fuente nueva aca ya aparece sola en la ui sin tocar html.
#
# el campo tipo no es decorativo. es la clave con la que el front le
# pide color y simbolo a tipo_meta en common.js que ya existia para el
# mapa y las estadisticas. sin eso habria que elegir un color por fuente
# a mano y el mismo sismo terminaria pintado distinto segun la pantalla.
SOURCES_META = {
    "CONAF": {
        "nombre": "CONAF",
        "cubre": "Incendios forestales",
        "organismo": "Corporación Nacional Forestal",
        "tipo": "incendio",
        "trae": "Focos activos, su estado de combate y hectáreas afectadas.",
        "sitio": "https://www.conaf.cl",
    },
    "SERNAGEOMIN": {
        "nombre": "SERNAGEOMIN",
        "cubre": "Actividad volcánica",
        "organismo": "Servicio Nacional de Geología y Minería",
        "tipo": "volcan",
        "trae": "Nivel de alerta técnica por volcán. Los verdes no generan evento.",
        "sitio": "https://www.sernageomin.cl",
    },
    "DMC": {
        "nombre": "DMC",
        "cubre": "Meteorología (alertas y alarmas)",
        "organismo": "Dirección Meteorológica de Chile",
        "tipo": "meteorologico",
        "trae": "Avisos, alertas y alarmas por viento, lluvia y temperaturas extremas.",
        "sitio": "https://www.meteochile.gob.cl",
    },
    "USGS": {
        "nombre": "USGS",
        "cubre": "Sismos (terremotos) en Chile",
        "organismo": "United States Geological Survey",
        "tipo": "sismo",
        "trae": "Sismos con epicentro en Chile. Respaldo internacional del CSN.",
        "sitio": "https://earthquake.usgs.gov",
    },
    "CSN": {
        "nombre": "CSN",
        "cubre": "Sismos (Centro Sismológico Nacional, Chile)",
        "organismo": "Centro Sismológico Nacional, Universidad de Chile",
        "tipo": "sismo",
        "trae": "Sismos localizados en Chile. Es la referencia oficial del país.",
        "sitio": "https://www.sismologia.cl",
    },
    "SENAPRED": {
        "nombre": "SENAPRED",
        "cubre": "Alertas oficiales de emergencia y evacuación",
        "organismo": "Servicio Nacional de Prevención y Respuesta ante Desastres",
        "tipo": "alerta",
        "trae": "Alertas oficiales y órdenes de evacuación. La fuente más crítica.",
        "sitio": "https://senapred.cl",
    },
}
