"""sernageomin. volcanes con alerta tecnica. arcgis featureserver publico.

los nombres de campo vienen truncados o con acento asi que se buscan por
prefijo en vez de por nombre exacto."""
from __future__ import annotations

from .. import area as area_mod
from ..fetcher import json_de
from ..normalize import Event, num
from . import senapred_volcanes

URL = (
    "https://services3.arcgis.com/uZrwedu11XCCdHk1/arcgis/rest/services/"
    "volcanes_categorizadas_por_peligro/FeatureServer/0/query"
    "?where=1=1&outFields=*&returnGeometry=false&outSR=4326&f=json"
)

_SEVERIDAD = {
    "rojo": "roja",
    "naranja": "naranja",
    "amarillo": "amarilla",
    "verde": "verde",
}


def _pick(attrs: dict, prefix: str):
    """devuelve el primer valor cuya clave empiece con el prefijo sin
    importar mayusculas."""
    pl = prefix.lower()
    for k, v in attrs.items():
        if k.lower().startswith(pl):
            return v
    return None


def urls_requeridas() -> list[str]:
    """urls que necesita esta fuente. se piden todas juntas con las demas."""
    return [URL]


def fetch_events(prefetched: dict[str, str] | None = None) -> list[Event]:
    data = json_de(URL, prefetched)

    # solo los volcanes que de verdad tienen alerta (no verde) importan
    # aca, asi que se filtran primero. la consulta aparte a senapred
    # (fecha real + perimetro de seguridad declarado, ver
    # senapred_volcanes.py) es una llamada de red extra que este feed
    # arcgis no necesita para nada mas -- pedirla igual cuando no hay
    # ningun volcan con alerta seria trabajo desperdiciado en cada
    # ciclo, ya que casi siempre los ~45 volcanes de chile estan en
    # verde
    activos = []
    for feat in data.get("features", []):
        a = feat.get("attributes", {})
        nivel = (str(_pick(a, "Nivel_de_A") or "")).strip().lower()
        if nivel in ("", "verde"):
            continue  # un monitor de catastrofes no lista los ~45 volcanes normales
        activos.append((a, nivel))

    if not activos:
        return []

    # best effort. si esto falla o no encuentra nada para un volcan en
    # particular sigue mostrandose igual, solo sin fecha ni perimetro
    # real -- exactamente como se comportaba antes de que esto existiera
    volcanicos = senapred_volcanes.eventos_volcanicos()

    eventos: list[Event] = []
    for a, nivel in activos:
        severidad = _SEVERIDAD.get(nivel, "info")
        extra = volcanicos.get(senapred_volcanes.nombre_base(_pick(a, "Nombre") or ""), {})
        eventos.append(
            Event(
                source="SERNAGEOMIN",
                tipo="volcan",
                titulo=f"Volcan {_pick(a, 'Nombre') or 'S/N'}",
                severidad=severidad,
                region=_pick(a, "Regi"),
                lat=num(_pick(a, "Latitud")),
                lon=num(_pick(a, "Longitud")),
                fecha=extra.get("fecha"),  # ultimo comunicado real de senapred. none si no hay cruce
                estado=f"Alerta {nivel.capitalize()} vigente",
                activa=True,
                detalle=f"Alerta {nivel.capitalize()} | {_pick(a, 'Tipo_de_vo') or ''}".strip(" |"),
                # el perimetro real declarado por senapred le gana al
                # radio generico por nivel de alerta. ver area.por_volcan
                area=area_mod.por_volcan(severidad, perimetro_km=extra.get("perimetro_km")),
            )
        )
    return eventos
