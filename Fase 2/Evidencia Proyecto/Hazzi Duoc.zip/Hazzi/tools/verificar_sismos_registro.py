"""Verificacion E2E contra la API en vivo: reglas de sismos.

Uso:  .venv\\Scripts\\python.exe -m tools.verificar_sismos_registro
"""
import json
import re
import urllib.request

BASE = "http://127.0.0.1:8000"


def _get(path):
    with urllib.request.urlopen(BASE + path, timeout=120) as r:
        return json.load(r)


def _mag(e):
    m = re.match(r"M([\d.]+)", (e.get("titulo") or "").strip())
    return float(m.group(1)) if m else None


def main():
    d = _get("/api/events?refrescar=true")
    eventos = d.get("eventos", [])
    vigentes = [e for e in eventos if e.get("tipo") == "sismo"]
    archivados = [e for e in _get("/api/historial").get("eventos", []) if e.get("tipo") == "sismo"]

    print(f"eventos vigentes ....... {len(eventos)}  (sismos: {len(vigentes)})")
    print(f"sismos en historial .... {len(archivados)}")

    print("\nSismos VIGENTES (deben ser todos M4.0+):")
    for e in sorted(vigentes, key=lambda x: -(_mag(x) or 0)):
        print(f"  M{_mag(e)}  {e['titulo']}  ({e.get('fecha')})")
    for e in vigentes:
        assert (_mag(e) or 0) >= 4.0, f"un M<4.0 no puede estar vigente: {e['titulo']}"

    print("\nSismos en HISTORIAL (los menores van directo aca):")
    for e in sorted(archivados, key=lambda x: -(_mag(x) or 0))[:15]:
        print(f"  M{_mag(e)}  {e['titulo']}  ({e.get('fecha')})")

    menores = [e for e in archivados if (_mag(e) or 9) < 4.0]
    mayores = [e for e in archivados if (_mag(e) or 0) >= 4.0]
    print(f"\n>>> sismos M<4.0 archivados: {len(menores)}")
    print(f">>> sismos M4.0+ archivados: {len(mayores)}  {[f'M{_mag(e)}' for e in mayores]}")
    assert menores, "los sismos menores deberian estar llegando al historial"
    assert mayores, "los sismos fuertes ya vencidos tambien deben dejar rastro"

    # Ningun registro puede haber generado tiendas en riesgo.
    titulos = {e["titulo"] for e in menores}
    culpables = [t for t in d.get("tiendas_en_riesgo", []) if t.get("evento") in titulos]
    assert not culpables, f"un sismo menor no puede poner tiendas en riesgo: {culpables}"
    print("    ningun sismo menor genera tiendas en riesgo  OK")

    # Coherencia de contadores.
    assert d.get("total") == len(eventos), "'total' debe coincidir con los eventos devueltos"
    assert "verde" not in (d.get("por_severidad") or {}), \
        "no deberia quedar ningun evento verde entre los vigentes"
    print(f"    contadores coherentes (total={d['total']}, {d.get('por_severidad')})  OK")


main()
