"""tests de area.tabla_de_radios. la vista de radios del admin.

separado de test_area.py porque no prueba geometria sino el contrato
con la pantalla. que los numeros que se muestran salgan de las
constantes reales y no de una copia escrita a mano en el html."""
from __future__ import annotations

from app import area


def _filas(titulo):
    grupo = next(g for g in area.tabla_de_radios() if g["titulo"] == titulo)
    return {f["caso"]: f["radio_km"] for f in grupo["filas"]}


def test_los_radios_salen_de_las_constantes_no_de_una_copia():
    """si manana se ajusta un radio la pantalla tiene que seguirlo sola."""
    sismos = _filas("Sismos")
    for tope, radio in area._RADIO_SISMO_KM:
        assert radio in sismos.values(), f"falta el radio {radio} de M<{tope}"
    assert sismos["M8.0 o mayor"] == area._RADIO_SISMO_MAXIMO
    assert sismos["Magnitud no informada"] == area._RADIO_SISMO_SIN_MAGNITUD


def test_los_tramos_de_magnitud_no_dejan_huecos():
    """cada tramo arranca donde termina el anterior."""
    casos = [f["caso"] for f in
             next(g for g in area.tabla_de_radios() if g["titulo"] == "Sismos")["filas"]]
    assert casos[0].startswith("M4.0")
    assert "M4.0 - M4.9" in casos
    assert "M5.0 - M5.9" in casos
    assert "M8.0 o mayor" in casos


def test_el_radio_crece_con_la_magnitud():
    sismos = _filas("Sismos")
    assert sismos["M4.0 - M4.9"] < sismos["M5.0 - M5.9"] < sismos["M6.0 - M6.9"]
    assert sismos["M6.0 - M6.9"] < sismos["M7.0 - M7.9"] < sismos["M8.0 o mayor"]


def test_un_incendio_en_combate_tiene_mas_margen_que_uno_controlado():
    incendios = _filas("Incendios")
    assert incendios["En combate (margen)"] > incendios["Controlado (margen)"]


def test_los_radios_de_volcan_escalan_con_el_nivel_de_alerta():
    volcanes = _filas("Volcanes")
    assert volcanes["Alerta amarilla"] < volcanes["Alerta naranja"] < volcanes["Alerta roja"]


def test_estan_los_cuatro_tipos_de_evento():
    titulos = [g["titulo"] for g in area.tabla_de_radios()]
    assert titulos == ["Sismos", "Incendios", "Volcanes", "Alertas SENAPRED"]


def test_todos_los_radios_son_positivos():
    for g in area.tabla_de_radios():
        for f in g["filas"]:
            assert f["radio_km"] > 0, f"{g['titulo']}/{f['caso']} con radio invalido"
