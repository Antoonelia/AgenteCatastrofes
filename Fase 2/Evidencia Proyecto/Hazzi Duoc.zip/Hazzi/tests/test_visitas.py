"""tests de visitas.py: dedup por nombre y orden por mas reciente."""
from __future__ import annotations

from app import visitas

from ._aislar_motor import motor_temporal_para


def test_registrar_una_visita():
    with motor_temporal_para(visitas):
        visitas.registrar("Juan Perez")
        lista = visitas.ultimas()
        assert len(lista) == 1
        assert lista[0]["nombre"] == "Juan Perez"


def test_la_misma_persona_entrando_varias_veces_no_se_duplica():
    with motor_temporal_para(visitas):
        for _ in range(4):
            visitas.registrar("Juan Perez")
        lista = visitas.ultimas()
        assert len(lista) == 1


def test_nombre_vacio_se_ignora():
    with motor_temporal_para(visitas):
        visitas.registrar("   ")
        assert visitas.ultimas() == []


def test_orden_por_mas_reciente():
    with motor_temporal_para(visitas):
        visitas.registrar("Primera Persona")
        visitas.registrar("Segunda Persona")
        visitas.registrar("Primera Persona")  # vuelve a entrar, sube al tope
        lista = visitas.ultimas()
        assert lista[0]["nombre"] == "Primera Persona"
        assert lista[1]["nombre"] == "Segunda Persona"


def test_respeta_el_limite():
    with motor_temporal_para(visitas):
        for i in range(5):
            visitas.registrar(f"Persona {i}")
        assert len(visitas.ultimas(n=3)) == 3
