param([Parameter(Mandatory=$true)][string]$Url)

# autenticacion transparente contra el proxy corporativo de walmart. evita el error 407
[System.Net.WebRequest]::DefaultWebProxy.Credentials = [System.Net.CredentialCache]::DefaultCredentials
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

try {
    # user-agent de navegador real. algunas fuentes, por ejemplo csn detras
    # de cloudflare, devuelven 403 sin esto
    $headers = @{
        'User-Agent'      = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
        'Accept'          = 'text/html,application/xhtml+xml,application/json,*/*'
        'Accept-Language' = 'es-CL,es;q=0.9'
    }
    $r = Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec 40 -Headers $headers
    # no se usa $r.Content directamente. cuando la fuente no declara el
    # charset en el header http, por ejemplo el csn manda "Content-Type:
    # text/html" a secas con el charset=utf-8 escondido en un meta del body
    # que Invoke-WebRequest -UseBasicParsing no mira, powershell adivina la
    # codificacion y a veces adivina mal. el resultado es que cada tilde
    # queda partida en dos caracteres, por ejemplo "CopiapÃ³" en vez de
    # "Copiapó". levantar los bytes crudos de la respuesta y decodificarlos
    # nosotros mismos como utf-8, que es lo que de verdad manda toda fuente
    # de este proyecto, elimina la adivinanza por completo
    $bytes = $r.RawContentStream.ToArray()
    Write-Output ([System.Text.Encoding]::UTF8.GetString($bytes))
} catch {
    Write-Error $_.Exception.Message
    exit 1
}
