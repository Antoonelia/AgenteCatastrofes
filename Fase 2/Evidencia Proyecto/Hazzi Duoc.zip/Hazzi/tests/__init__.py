"""runner minimo de tests. corre toda funcion test_ de los modulos en tests.

no hay pytest disponible en este entorno y el venv de instalacion de
code puppy no se toca. esto alcanza de sobra para tests de logica pura
y evita sumar una dependencia por algo que son 20 lineas.

uso: python -m tests (desde la carpeta del proyecto)"""
from __future__ import annotations

import importlib
import pkgutil
import sys
import traceback


def main() -> int:
    fallidos = 0
    total = 0
    for mod_info in pkgutil.iter_modules(__path__):
        if not mod_info.name.startswith("test_"):
            continue
        modulo = importlib.import_module(f"{__name__}.{mod_info.name}")
        for nombre in sorted(dir(modulo)):
            if not nombre.startswith("test_"):
                continue
            total += 1
            try:
                getattr(modulo, nombre)()
                print(f"  OK   {mod_info.name}::{nombre}")
            except Exception:  # noqa: BLE001 un test que falla no corta el resto
                fallidos += 1
                print(f"  FAIL {mod_info.name}::{nombre}")
                traceback.print_exc()
    print(f"\n{total - fallidos}/{total} tests OK")
    return 1 if fallidos else 0


if __name__ == "__main__":
    sys.exit(main())
