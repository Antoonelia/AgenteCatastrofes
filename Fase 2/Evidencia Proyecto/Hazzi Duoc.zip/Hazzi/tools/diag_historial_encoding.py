"""El mojibake del historial: viene de la DB o de la fuente en vivo?"""
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from app import historial
from app.sources import csn

MALAS = ("Ã", "Â", "â€")

print("=== HISTORIAL (base de datos) ===")
filas = historial.obtener_historial()
malas = [h for h in filas if any(m in str(h.get(k) or "") for k in ("titulo", "region", "comuna", "detalle") for m in MALAS)]
print(f"registros: {len(filas)}   con simbolos raros: {len(malas)}")
for h in malas[:6]:
    print(f"   {h.get('source'):<10} {h.get('titulo')}")

print()
print("=== CSN EN VIVO (la fuente ahora mismo) ===")
try:
    eventos = csn.fetch_events()
    con_acento = [e for e in eventos if not (e.titulo or "").isascii()]
    rotos = [e for e in eventos if any(m in (e.titulo or "") for m in MALAS)]
    print(f"eventos: {len(eventos)}   con acentos: {len(con_acento)}   rotos: {len(rotos)}")
    for e in con_acento[:6]:
        print(f"   {'ROTO' if any(m in e.titulo for m in MALAS) else 'ok  '} {e.titulo}")
except Exception as exc:  # noqa: BLE001
    print(f"fallo: {exc}")
