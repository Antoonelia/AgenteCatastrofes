"""regresion. una alerta roja o amarilla ampliada a region completa no
debe contarse aparte de la version puntual (comuna o provincia) mas
vieja que ya cubre. caso real capturado en vivo el 24-09-2026: senapred
declaro "alerta roja para la comuna de arauco por desborde" a las 09:24
y horas despues "se modifica cobertura de alerta roja para la region
de biobio por desborde" a las 14:10. es la misma emergencia, solo que
le ampliaron el alcance. antes de este fix retention.py las contaba
como dos alertas rojas vigentes distintas porque agrupaba por comuna y
tema, y arauco no es igual a biobio."""
from __future__ import annotations

from datetime import datetime

from app.retention import filtrar_eventos

_FMT = "%d-%m-%Y %H:%M hrs"
AHORA_CL = datetime.strptime("24-09-2026 15:00 hrs", _FMT)  # fijo, mas nuevo
# que ambos eventos de abajo. se pasa explicitamente a filtrar_eventos para
# que estos tests no se rompan solos con el paso de los dias. ver
# retention.py filtrar_eventos

ALERTA_ARAUCO = {
    "source": "SENAPRED", "tipo": "alerta", "severidad": "roja",
    "comuna": "Arauco", "region": "Biobío", "tema": "por desborde",
    "titulo": "Se declara Alerta Roja por desborde",
    "fecha": "24-09-2026 09:24 hrs",
}
ALERTA_BIOBIO_REGIONAL = {
    "source": "SENAPRED", "tipo": "alerta", "severidad": "roja",
    "comuna": "Biobío", "region": "Biobío", "tema": "por desborde",
    "titulo": "Se modifica cobertura de Alerta Roja por desborde (Lluvia)",
    "fecha": "24-09-2026 14:10 hrs",
}

# alerta de otra region mas tema. no debe verse afectada por el fix
ALERTA_CAUTIN = {
    "source": "SENAPRED", "tipo": "alerta", "severidad": "roja",
    "comuna": "Provincia de Cautín", "region": "La Araucanía",
    "tema": "por desborde para la provincia de cautín",
    "titulo": "Se declara Alerta Roja por desborde",
    "fecha": "24-09-2026 08:26 hrs",
}


def test_la_declaracion_regional_mas_nueva_reemplaza_a_la_comuna_mas_vieja():
    vigentes = filtrar_eventos([ALERTA_ARAUCO, ALERTA_BIOBIO_REGIONAL], ahora=AHORA_CL)
    assert vigentes == [ALERTA_BIOBIO_REGIONAL]


def test_una_alerta_de_otra_region_y_tema_no_se_pisa():
    vigentes = filtrar_eventos([ALERTA_ARAUCO, ALERTA_BIOBIO_REGIONAL, ALERTA_CAUTIN], ahora=AHORA_CL)
    assert ALERTA_CAUTIN in vigentes
    assert ALERTA_ARAUCO not in vigentes
    assert len(vigentes) == 2


def test_una_alerta_puntual_mas_nueva_que_la_regional_no_se_descarta():
    """si la version puntual es la mas reciente, y la region quedo
    vieja, no hay por que descartarla. solo se supera lo que es mas
    viejo que la declaracion regional, nunca al reves."""
    arauco_mas_nueva = {**ALERTA_ARAUCO, "fecha": "24-09-2026 20:00 hrs"}
    ahora = datetime.strptime("24-09-2026 21:00 hrs", _FMT)  # mas nueva que arauco_mas_nueva
    vigentes = filtrar_eventos([arauco_mas_nueva, ALERTA_BIOBIO_REGIONAL], ahora=ahora)
    assert arauco_mas_nueva in vigentes
    assert ALERTA_BIOBIO_REGIONAL in vigentes


def test_la_propia_declaracion_regional_no_se_autodescarta():
    """sanity check. una unica alerta regional, sola, sigue vigente."""
    assert filtrar_eventos([ALERTA_BIOBIO_REGIONAL], ahora=AHORA_CL) == [ALERTA_BIOBIO_REGIONAL]
