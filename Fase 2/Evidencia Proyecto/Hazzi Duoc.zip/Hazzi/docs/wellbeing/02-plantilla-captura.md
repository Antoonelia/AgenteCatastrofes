# Captura en vivo — Reunión Wellbeing

**Fecha:** ____________  **Duración real:** ______
**Asistentes:** (nombre — rol — ¿decide / ejecuta / tiene el dato?)
- 
- 
- 

**Ausencia notable:** ____________________________________
*(si falta el dueño del dato de asociados, anotalo: condiciona todo)*

---

## A · Reacción a la demo

> Pregunta: "¿Qué es lo primero que harían si vieran esta pantalla un día real?"

**Frase textual (no la parafrasees):**
> ""

**Otras reacciones espontáneas:**
- 

---

## B · El evento que reconstruimos

**Cuál fue:** ____________  **Cuándo:** ____________

### Línea de tiempo real

| Momento | Qué pasó | Quién | Herramienta usada | Tardó |
|---|---|---|---|---|
| Ocurre el evento | | | | — |
| Se enteran | | | | |
| Identifican zona | | | | |
| Arman lista de gente | | | | |
| Contactan | | | | |
| Registran respuestas | | | | |
| Activan ayuda | | | | |
| Seguimiento | | | | |
| Reporte final | | | | |

> Las celdas de **"Herramienta usada"** que digan *WhatsApp*, *Excel*, *llamadas*
> o *memoria* son tu backlog. Marcalas.

---

## C · Dolores detectados

Un dolor por fila. **Verbatim** en la primera columna: las palabras de ellos valen
más que tu resumen.

| # | Frase textual | Quién lo sufre | Cuánto cuesta (tiempo/riesgo) | ¿Hazzi puede? |
|---|---|---|---|---|
| D1 | | | | |
| D2 | | | | |
| D3 | | | | |
| D4 | | | | |
| D5 | | | | |

---

## D · Priorización que hicieron ELLOS

| Puesto | Dolor | Quién lo eligió | Por qué (su argumento) |
|---|---|---|---|
| 1 | | | |
| 2 | | | |
| 3 | | | |

---

## E · Lo que NO hay que tocar

*(Procesos que ya les funcionan. Romperlos es la forma más rápida de perder al usuario.)*
- 

---

## F · Datos: quién tiene qué

| Dato que necesitaríamos | ¿Existe? | Dueño | Sistema | ¿Es dato personal/sensible? |
|---|---|---|---|---|
| Nómina por tienda | | | | Sí |
| Domicilio del asociado | | | | **Sensible** |
| Teléfono de contacto | | | | Sí |
| Turno / quién estaba en el local | | | | Sí |
| Contacto de emergencia | | | | Sí |
| Situación socioeconómica | | | | **Sensible** |
| | | | | |

**¿Apareció Legal / Compliance / DPO en la conversación?** Sí / No
**Nombre del contacto de datos:** ____________________

---

## G · Alcance: qué entra y qué no

Marcá lo que **ellos** confirmaron como parte del pilar social:

- [ ] Asociados afectados (estado, contacto, confirmación de bienestar)
- [ ] Apoyo a la comunidad (donaciones, acopio, albergues)
- [ ] Salud mental y contención post-evento
- [ ] Voluntariado corporativo
- [ ] Beneficios y ayuda económica al damnificado
- [ ] Otro: ____________________

**Lo elegido para Sprint 1:** ____________________
**Explícitamente fuera de Sprint 1:** ____________________

> Escribir lo que queda **afuera** vale tanto como lo que queda adentro.
> Es tu defensa cuando en la reunión 3 aparezca "¿y esto no estaba?".

---

## H · Citas para el informe de tesis

Frases textuales que justifican el proyecto. Oro puro para el capítulo de
levantamiento de requerimientos — y para defender decisiones ante el tribunal.

> ""
> — ____________, rol

> ""
> — ____________, rol

---

## I · Acuerdos y próximos pasos

| Qué | Quién | Para cuándo |
|---|---|---|
| Enviar historias de usuario redactadas | Antonella | |
| Conseguir contacto de dueño de datos | | |
| Confirmar si Legal debe participar | | |
| Próxima reunión | | |

---

## J · Post-reunión — hacelo el MISMO día

Tu memoria se degrada en horas, no en días.

- [ ] Pasar en limpio esta captura **antes de dormir**
- [ ] Convertir cada dolor D1..Dn en historia de usuario (`03-plantilla-historias.md`)
- [ ] Marcar cuáles se apoyan en lo que Hazzi **ya** tiene (sección 9 del guion)
- [ ] Enviar el resumen por correo: *"esto entendí, corríjanme"* → deja rastro escrito
- [ ] `git commit` de los documentos
