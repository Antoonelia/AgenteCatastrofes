"""Migracion puntual: recalcula las claves del historial con la identidad nueva.

Las claves guardadas en eventos_historial se generaron con la logica vieja
(que incluia campos que la fuente reescribe -- ver app/historial.py). Con la
regla nueva, varias filas colapsan en la MISMA clave: tipicamente el fantasma
archivado y su version vigente, que siempre fueron el mismo evento real.

Al colapsar gana la fila VIGENTE: si el evento sigue vivo, no puede figurar
como archivado en el Historial -- que es exactamente el sintoma que se
reporto. Entre dos filas del mismo estado, gana la mas reciente.

Es idempotente: correrla de nuevo sobre una tabla ya migrada no cambia nada.
Uso:  .venv\\Scripts\\python.exe -m tools.migrar_claves_historial   (desde Hazard/)
"""
from __future__ import annotations

import json

from sqlalchemy import delete, insert, select

from app.db import engine
from app.historial import clave_evento, historial_tabla, init_schema


def main() -> None:
    init_schema()
    with engine.begin() as conn:
        filas = conn.execute(select(historial_tabla)).mappings().all()

        # Se queda una fila por clave nueva: vigente primero, luego la mas reciente.
        mejor: dict[str, dict] = {}
        for f in filas:
            clave = clave_evento(json.loads(f["datos"]))
            actual = mejor.get(clave)
            if actual is None or (f["vigente"], f["ultima_vez_vigente"]) > (
                actual["vigente"], actual["ultima_vez_vigente"]
            ):
                mejor[clave] = dict(f)

        conn.execute(delete(historial_tabla))
        for clave, f in mejor.items():
            conn.execute(insert(historial_tabla).values(
                clave=clave,
                datos=f["datos"],
                vigente=f["vigente"],
                ultima_vez_vigente=f["ultima_vez_vigente"],
            ))

    print(f"{len(filas)} filas -> {len(mejor)} tras aplicar la identidad nueva")
    for clave, f in sorted(mejor.items(), key=lambda kv: kv[1]["vigente"]):
        estado = "VIGENTE " if f["vigente"] else "archivado"
        print(f"  {estado}  {clave}")


if __name__ == "__main__":
    main()
