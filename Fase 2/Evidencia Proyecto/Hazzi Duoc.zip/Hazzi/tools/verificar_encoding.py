"""Verificacion: el texto visible quedo IGUAL al de antes del bug de encoding.

Compara cada .html contra su version en git anterior al commit del area
(HEAD~1), ignorando unicamente los cambios que si queriamos (el ?v=NN y los
textos que tocamos a proposito). Si algun caracter acentuado no coincide, se
reporta.
"""
import re
import subprocess
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

SOSPECHOSAS = ("Ã", "Â", "â€", "\ufffd")


def previo(ruta: str) -> str:
    # HEAD, no HEAD~1: el ultimo commit ya tiene el mojibake reparado (ver
    # commit 8240954). Comparar contra HEAD~1 compararia contra la version
    # ROTA y marcaria como "perdidos" los caracteres que arreglamos a proposito.
    out = subprocess.run(["git", "show", f"HEAD:Hazard/{ruta}"],
                         capture_output=True, check=False).stdout
    return out.decode("utf-8").lstrip("\ufeff")


todo_ok = True
for f in sorted(Path("app/static").glob("*.html")):
    crudo = f.read_bytes()
    txt = crudo.decode("utf-8")
    base = previo(f.as_posix())

    bom = crudo[:3] == b"\xef\xbb\xbf"
    restos = {m: txt.count(m) for m in SOSPECHOSAS if m in txt}

    # Los acentos y simbolos no-ASCII de antes deben seguir estando igual.
    acentos_antes = sorted({c for c in base if not c.isascii()})
    acentos_ahora = sorted({c for c in txt if not c.isascii()})
    perdidos = set(acentos_antes) - set(acentos_ahora)
    nuevos = set(acentos_ahora) - set(acentos_antes)

    estado = "OK"
    if bom or restos or perdidos or nuevos:
        estado = "REVISAR"
        todo_ok = False
    print(f"  {estado:<8} {f.name:<22} BOM={'si' if bom else 'no':<3} "
          f"no-ascii: {''.join(acentos_ahora)}")
    if restos:
        print(f"           restos de mojibake: {restos}")
    if perdidos:
        print(f"           caracteres PERDIDOS: {sorted(perdidos)}")
    if nuevos:
        print(f"           caracteres NUEVOS: {sorted(nuevos)}")

print()
print("TODO LIMPIO" if todo_ok else "HAY ARCHIVOS QUE REVISAR")
sys.exit(0 if todo_ok else 1)
