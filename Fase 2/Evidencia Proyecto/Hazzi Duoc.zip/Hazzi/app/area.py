"""area afectada por un evento. la geometria real no un circulo inventado.

antes todo evento afectaba un circulo de 30 km viniera de donde viniera.
eso era falso en las dos direcciones a la vez. providencia mide unos 4
km de punta a punta asi que le pintabamos una alerta 7 veces mas grande
que la comuna. natales mide unos 470 km asi que dejabamos fuera el 94%
del territorio realmente afectado. el mismo numero para las dos.

este modulo es el unico lugar donde vive la regla de cuanto abarca cada
evento. cada fuente aporta el dato crudo que ella conoce la magnitud las
hectareas el nivel de alerta el poligono que ya publica y aca se
traduce a un area. las fuentes no deciden. si algun dia cambia un radio
se cambia aca y no hay que salir a buscarlo por seis archivos.

un area es un diccionario serializable a json que viaja al frontend tal
cual con dos formas posibles.

    forma circulo con radio_km clase y motivo
    forma poligono con anillos clase y motivo

el circulo se centra en el lat lon del propio evento asi que no se repite.

clase distingue dos cosas que no son lo mismo y que el mapa pinta
distinto. afectada es el area que la fuente declara afectada. es un
hecho. potencial es el margen de cercania que agregamos nosotros.
todavia no esta afectada pero podria estarlo. se muestra siempre
marcada como tal para no inflar la emergencia. fue un pedido explicito:
que se exponga que podria ser un area afectada que aun no esta afectada
pero podria serlo por cercania."""
from __future__ import annotations

import math
from typing import Optional

# sismos
# radio de dano potencial no de hasta donde se siente. un m7 se percibe
# a 1000 km pero a esa distancia no rompe nada y avisar seria puro
# ruido. la referencia es la distancia hasta la que suele alcanzarse
# intensidad mercalli 6 o mas que es el umbral donde empieza el dano
# real: caida de mercaderia de gondola grietas corte de suministros. el
# area crece mucho mas rapido que la magnitud porque la escala es
# logaritmica.
#
# se lee como: bajo esta magnitud exclusive el radio es este
_RADIO_SISMO_KM = (
    (5.0, 20.0),    # 4.0 a 4.9 se siente fuerte. dano casi nulo
    (6.0, 50.0),    # 5.0 a 5.9 dano ligero en construccion vulnerable
    (7.0, 120.0),   # 6.0 a 6.9 dano moderado. el primer nivel que preocupa
    (8.0, 300.0),   # 7.0 a 7.9 dano severo en un area extensa
)
_RADIO_SISMO_MAXIMO = 500.0      # m8.0 o mas. el terremoto del 2010 fue m8.8
_RADIO_SISMO_SIN_MAGNITUD = 50.0  # no se pudo leer la magnitud. criterio medio

# incendios
# el fuego en si es diminuto. 10 hectareas son apenas 180 m de radio.
# pintar 30 km era absurdo pero quedarse solo con el area quemada
# tambien engana porque un incendio forestal corta caminos llena de
# humo y gatilla evacuaciones mucho mas alla de donde llega la llama.
# el punto medio es el radio real del fuego mas un margen operativo que
# depende de si sigue vivo o no
_MARGEN_INCENDIO_KM = {
    True: 2.0,   # en combate. puede crecer. mas humo y cortes de ruta
    False: 0.5,  # controlado. ya no avanza pero queda el humo y el camino cortado
}
_HA_A_KM2 = 0.01

# volcanes. radios de exclusion que declara sernageomin segun el nivel
# de alerta tecnica
_RADIO_VOLCAN_KM = {
    "amarilla": 5.0,
    "naranja": 15.0,
    "roja": 30.0,
}

MARGEN_ALERTA_ROJA_KM = 5.0  # margen de cercania para alertas rojas de
# senapred. ver clase potencial


def tabla_de_radios() -> list[dict]:
    """los radios del motor en formato legible para la pantalla de admin.

    se lee de las constantes de arriba no las repite. si algun dia se
    ajusta un radio la pantalla lo refleja sola. duplicar estos numeros
    en el html seria exactamente el problema que ya se elimino con la
    magnitud minima.

    estos valores no son editables desde el admin a proposito. cada uno
    tiene una justificacion tecnica escrita como la intensidad mercalli
    o los radios de exclusion de sernageomin que no se puede validar
    con un rango numerico. se muestran para explicar el modelo no para
    tocarlos al vuelo."""
    grupos = []

    filas_sismo = []
    piso = 4.0
    for tope, radio in _RADIO_SISMO_KM:
        filas_sismo.append({"caso": f"M{piso:.1f} - M{tope - 0.1:.1f}", "radio_km": radio})
        piso = tope
    filas_sismo.append({"caso": f"M{piso:.1f} o mayor", "radio_km": _RADIO_SISMO_MAXIMO})
    filas_sismo.append({"caso": "Magnitud no informada", "radio_km": _RADIO_SISMO_SIN_MAGNITUD})
    grupos.append({
        "titulo": "Sismos",
        "nota": (
            "Radio de dano POTENCIAL, no de hasta donde se siente: un M7 se "
            "percibe a 1000 km pero a esa distancia no rompe nada. La "
            "referencia es la distancia hasta la que suele alcanzarse "
            "intensidad Mercalli VI+, el umbral donde empieza el dano real "
            "(caida de mercaderia de gondola, grietas, cortes de suministro)."
        ),
        "filas": filas_sismo,
    })

    grupos.append({
        "titulo": "Incendios",
        "nota": (
            "El fuego en si es diminuto (10 hectareas son 180 m de radio), "
            "pero corta caminos, llena de humo y gatilla evacuaciones mucho "
            "mas alla de la llama. Se usa el radio real del fuego mas un "
            "margen operativo segun si sigue activo."
        ),
        "filas": [
            {"caso": "En combate (margen)", "radio_km": _MARGEN_INCENDIO_KM[True]},
            {"caso": "Controlado (margen)", "radio_km": _MARGEN_INCENDIO_KM[False]},
        ],
    })

    grupos.append({
        "titulo": "Volcanes",
        "nota": "Radios de exclusion oficiales de SERNAGEOMIN segun nivel de alerta tecnica.",
        "filas": [
            {"caso": f"Alerta {nivel}", "radio_km": radio}
            for nivel, radio in _RADIO_VOLCAN_KM.items()
        ],
    })

    grupos.append({
        "titulo": "Alertas SENAPRED",
        "nota": "Margen de cercania que marca una tienda como potencialmente afectada.",
        "filas": [{"caso": "Alerta roja (margen)", "radio_km": MARGEN_ALERTA_ROJA_KM}],
    })

    return grupos


def _circulo(radio_km: float, motivo: str, clase: str = "afectada") -> dict:
    return {"forma": "circulo", "radio_km": round(radio_km, 2), "clase": clase, "motivo": motivo}


def por_sismo(mag: Optional[float]) -> dict:
    """area de dano potencial de un sismo segun su magnitud."""
    if mag is None:
        return _circulo(_RADIO_SISMO_SIN_MAGNITUD, "Radio estimado (magnitud no informada)")
    for tope, radio in _RADIO_SISMO_KM:
        if mag < tope:
            return _circulo(radio, f"Radio de dano potencial para M{mag}")
    return _circulo(_RADIO_SISMO_MAXIMO, f"Radio de dano potencial para M{mag}")


def por_incendio(hectareas: Optional[float], activo: bool) -> dict:
    """area de un incendio. el fuego real mas un margen operativo por
    humo cortes de camino y evacuacion. ver _MARGEN_INCENDIO_KM."""
    margen = _MARGEN_INCENDIO_KM[bool(activo)]
    if not hectareas or hectareas <= 0:
        return _circulo(
            margen,
            f"Radio de resguardo de {margen:.1f} km (superficie quemada no informada)",
        )
    radio_fuego = math.sqrt(hectareas * _HA_A_KM2 / math.pi)
    total = radio_fuego + margen
    return _circulo(
        total,
        f"Radio de resguardo de {total:.1f} km ({hectareas:.1f} hectareas quemadas "
        f"mas margen de seguridad por humo y cortes de camino)",
    )


def por_volcan(severidad: str, perimetro_km: Optional[float] = None) -> dict:
    """radio de exclusion volcanica. real si senapred lo declaro, generico si no.

    sernageomin (nivel de alerta tecnica) y senapred (perimetro de
    seguridad puntual, ver sources/senapred_volcanes.py) son dos
    fuentes distintas que hablan del mismo volcan. cuando senapred
    declaro un perimetro real para este volcan ese numero es la
    verdad de terreno y le gana a la tabla generica por nivel de
    alerta, exactamente el mismo criterio que ya usa retention.py con
    vigencia_hasta: un dato explicito de la fuente siempre le gana a
    una heuristica. la tabla por nivel sigue siendo necesaria como
    fallback porque no todo volcan con alerta tiene un comunicado de
    perimetro vigente, y porque sin internet igual hay que poder
    dibujar algo."""
    if perimetro_km and perimetro_km > 0:
        return _circulo(perimetro_km, f"Perimetro de seguridad declarado por SENAPRED ({perimetro_km:.0f} km)")
    radio = _RADIO_VOLCAN_KM.get(severidad, _RADIO_VOLCAN_KM["amarilla"])
    return _circulo(radio, f"Radio de exclusion SERNAGEOMIN (alerta {severidad})")


def con_margen(area: Optional[dict], km: float, motivo: str) -> Optional[dict]:
    """agrega un anillo de cercania alrededor de un area ya afectada.

    el margen no se suma al area afectada. se guarda aparte etiquetado
    como potencial. una tienda que cae ahi todavia no esta afectada
    pero esta lo bastante cerca como para prepararse. mezclarlos
    inflaria la emergencia y haria que el sistema informe como
    afectado algo que no lo esta."""
    if not area or km <= 0:
        return area
    return {**area, "margen_km": round(km, 2), "margen_motivo": motivo}


def por_anillos(anillos: list, motivo: str, clase: str = "afectada") -> Optional[dict]:
    """area a partir de la geometria real que publica la fuente.

    anillos viene en formato arcgis o geojson. una lista de anillos
    cada uno una lista de pares lon lat. un evento puede tener varios
    anillos inconexos porque la dmc publica avisos que cubren zonas
    separadas del pais."""
    limpios = [a for a in (anillos or []) if a and len(a) >= 3]
    if not limpios:
        return None
    return {"forma": "poligono", "anillos": limpios, "clase": clase, "motivo": motivo}


def _shoelace(anillo: list) -> tuple[float, float, float]:
    """area con signo y centroide de un poligono simple. formula shoelace.

    devuelve area signada cx y cy. anillo viene como una lista de pares
    lon lat. si el area sale cero porque los puntos son casi colineales
    o el poligono es degenerado cae a un promedio simple de vertices.
    mejor una aproximacion basta que una division por cero."""
    area2 = 0.0
    cx = 0.0
    cy = 0.0
    n = len(anillo)
    for i in range(n):
        x0, y0 = anillo[i][0], anillo[i][1]
        x1, y1 = anillo[(i + 1) % n][0], anillo[(i + 1) % n][1]
        cruce = x0 * y1 - x1 * y0
        area2 += cruce
        cx += (x0 + x1) * cruce
        cy += (y0 + y1) * cruce
    area = area2 / 2.0
    if area == 0:
        lons = [p[0] for p in anillo]
        lats = [p[1] for p in anillo]
        return 0.0, sum(lons) / len(lons), sum(lats) / len(lats)
    return area, cx / (6 * area), cy / (6 * area)


def centroide_poligono(anillos: list | None) -> Optional[tuple[float, float]]:
    """centro geometrico de una zona afectada. no un punto arbitrario.

    sirve para ubicar el pin de un evento en el medio visual del area
    que se dibuja en el mapa en vez de en lo que devuelva el
    geocodificador de turno que puede ser cualquier punto de referencia
    de la comuna no necesariamente su centro.

    si el area tiene varios anillos inconexos como islas o fragmentos
    costeros se usa el de mayor superficie porque es el que mejor
    representa el medio a simple vista. devuelve lat y lon o none si no
    hay anillos utilizables."""
    utiles = [a for a in (anillos or []) if a and len(a) >= 3]
    if not utiles:
        return None
    mejor = max(utiles, key=lambda an: abs(_shoelace(an)[0]))
    _, cx, cy = _shoelace(mejor)
    return (cy, cx)


# geometria. saber si un punto cae dentro del area y a que distancia
_R_TIERRA_KM = 6371.0


def haversine(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """distancia en km entre dos puntos sobre la superficie terrestre."""
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * _R_TIERRA_KM * math.asin(math.sqrt(a))


def _punto_en_anillo(lat: float, lon: float, anillo: list) -> bool:
    """ray casting. cuenta cruces de una semirrecta contra los lados del anillo."""
    dentro = False
    n = len(anillo)
    j = n - 1
    for i in range(n):
        xi, yi = anillo[i][0], anillo[i][1]
        xj, yj = anillo[j][0], anillo[j][1]
        if (yi > lat) != (yj > lat):
            corte_x = xi + (lat - yi) * (xj - xi) / (yj - yi)
            if lon < corte_x:
                dentro = not dentro
        j = i
    return dentro


def _km_a_segmento(lat: float, lon: float, a: list, b: list) -> float:
    """distancia de un punto al segmento a-b proyectando a un plano local.

    a escala de comuna o region el error de la proyeccion es
    despreciable y evita resolver geodesicas para cada uno de los
    cientos de lados que puede tener un poligono."""
    klat = 111.32                                  # km por grado de latitud
    klon = 111.32 * math.cos(math.radians(lat))    # los meridianos se juntan hacia el polo
    px, py = lon * klon, lat * klat
    ax, ay = a[0] * klon, a[1] * klat
    bx, by = b[0] * klon, b[1] * klat
    dx, dy = bx - ax, by - ay
    largo2 = dx * dx + dy * dy
    if largo2 == 0:
        return math.hypot(px - ax, py - ay)
    t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / largo2))
    return math.hypot(px - (ax + t * dx), py - (ay + t * dy))


def distancia_km(area: Optional[dict], lat_ev: Optional[float], lon_ev: Optional[float],
                 lat: float, lon: float) -> Optional[float]:
    """km desde un punto hasta el borde del area. cero si esta dentro none si queda fuera.

    devolver none y no un numero grande es a proposito. quien llama
    solo tiene que preguntar si es none para saber si el punto esta
    afectado sin volver a comparar contra ningun umbral suelto por ahi."""
    if not area:
        return None
    if area["forma"] == "circulo":
        if lat_ev is None or lon_ev is None:
            return None
        d = haversine(lat_ev, lon_ev, lat, lon)
        return round(d, 1) if d <= area["radio_km"] else None

    anillos = area.get("anillos") or []
    if any(_punto_en_anillo(lat, lon, an) for an in anillos):
        return 0.0
    margen = area.get("margen_km") or 0.0
    if margen <= 0:
        return None
    mejor = min(
        (_km_a_segmento(lat, lon, an[i - 1], an[i]) for an in anillos for i in range(len(an))),
        default=None,
    )
    return round(mejor, 1) if mejor is not None and mejor <= margen else None


def contiene(area: Optional[dict], lat_ev: Optional[float], lon_ev: Optional[float],
             lat: float, lon: float) -> bool:
    """true si el punto esta dentro del area afectada o de su margen."""
    return distancia_km(area, lat_ev, lon_ev, lat, lon) is not None
