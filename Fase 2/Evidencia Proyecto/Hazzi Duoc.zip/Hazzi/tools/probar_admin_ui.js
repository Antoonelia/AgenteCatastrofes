/*
 * Prueba de humo de las pantallas de admin SIN navegador.
 *
 * Por que existe: el bug que rompio /admin fue un `SyntaxError` (una funcion
 * `cargar` renombrada por accidente a `pintarConfig`, con `await` dentro de
 * una funcion no-async). Un error de PARSEO no rompe una parte de la pagina:
 * impide que el bloque <script> entero se ejecute, y la pantalla queda muerta
 * y muda. Ningun test de Python podia verlo, porque el backend respondia 200
 * perfecto todo el tiempo.
 *
 * Que verifica por pantalla, en orden de que tan temprano falla:
 *   1. Cada bloque <script> parsea.
 *   2. Todo id que el JS pide con getElementById existe en el HTML.
 *   3. El script corre de punta a punta contra el API REAL, con un DOM de
 *      mentira, y efectivamente ESCRIBE en los contenedores. Que no lance
 *      no significa que haya pintado: eso es lo que mide el paso 4.
 *
 * Uso:  node tools\probar_admin_ui.js [http://127.0.0.1:8000]
 */
'use strict';

const fs = require('fs');
const path = require('path');

const BASE = process.argv[2] || 'http://127.0.0.1:8000';
const DIR_ESTATICO = path.join(__dirname, '..', 'app', 'static');

// Las dos pantallas del admin. `endpoint` es el que la pagina consulta al
// cargar, y `pintan` son los contenedores que TIENEN que quedar con algo
// adentro.
const PANTALLAS = [
  {
    nombre: '/admin (Estado del sistema)',
    archivo: 'admin.html',
    endpoint: '/api/diagnostico',
    pintan: ['grid-config', 'cfg-resumen', 'grid-fuentes', 'estado'],
  },
  {
    nombre: '/admin/ajustes (Deteccion)',
    archivo: 'admin-ajustes.html',
    endpoint: '/api/admin/ajustes',
    pintan: ['campos', 'radios', 'acceso', 'estado'],
  },
];

let fallos = 0;
const ok = (m) => console.log('  OK   ' + m);
const mal = (m) => { fallos++; console.log('  FALLA ' + m); };

// Un DOM minimo: solo lo que estos scripts tocan. No es jsdom y no pretende
// serlo -- alcanza para detectar "no pinto nada", que es el sintoma que importa.
function nodoFalso(id) {
  return {
    id,
    _html: '',
    textContent: '',
    value: '',
    checked: false,
    disabled: false,
    dataset: {},
    classList: { add() {}, remove() {}, toggle() {}, contains: () => false },
    style: {},
    addEventListener() {},
    querySelectorAll: () => [],
    querySelector: () => null,
    closest() { return nodoFalso('closest'); },
    set innerHTML(v) { this._html = String(v); },
    get innerHTML() { return this._html; },
  };
}

async function probar(pantalla) {
  console.log(`\n${'='.repeat(64)}\n  ${pantalla.nombre}\n${'='.repeat(64)}`);

  const html = fs.readFileSync(path.join(DIR_ESTATICO, pantalla.archivo), 'utf8');
  const bloques = (html.match(/<script>[\s\S]*?<\/script>/g) || [])
    .map((b) => b.replace(/^<script>/, '').replace(/<\/script>$/, ''));

  // Los <script src="/static/..."> locales definen cosas que los bloques
  // inline usan (TIPO_META, glyphTipo, exigirSesion). El navegador los corre
  // primero; si aca no se hace lo mismo, el arnes reporta fallas que no existen.
  const dependencias = [...html.matchAll(/<script src="\/static\/([^"?]+)/g)]
    .map((m) => path.join(DIR_ESTATICO, m[1]))
    .filter((f) => fs.existsSync(f))
    .map((f) => fs.readFileSync(f, 'utf8'));

  // --- 1. Sintaxis ----------------------------------------------------------
  console.log('\n[1] Sintaxis de los bloques <script>');
  bloques.forEach((codigo, i) => {
    try {
      new Function(codigo);
      ok(`bloque ${i + 1} parsea`);
    } catch (e) {
      mal(`bloque ${i + 1}: ${e.message}`);
    }
  });

  // --- 2. Los ids que el JS busca existen en el HTML ------------------------
  console.log('\n[2] Contenedores que el JS espera');
  const codigoTotal = bloques.join('\n');
  // admin.html usa getElementById directo; admin-ajustes.html usa el helper
  // `$('id')`. Buscar solo el primero daba "0 ids" en Deteccion -- un chequeo
  // que pasa sin mirar nada es peor que no tenerlo.
  const pedidos = [...new Set([
    ...[...codigoTotal.matchAll(/getElementById\(['"]([^'"]+)['"]\)/g)].map((m) => m[1]),
    ...[...codigoTotal.matchAll(/\$\(['"]([^'"]+)['"]\)/g)].map((m) => m[1]),
  ])];
  const definidos = new Set([...html.matchAll(/id=["']([^"']+)["']/g)].map((m) => m[1]));
  // Los ids construidos por plantilla (campo-${clave}) se crean en runtime:
  // no tienen que existir en el HTML estatico.
  const huerfanos = pedidos.filter((id) => !definidos.has(id) && !id.includes('${'));
  if (pedidos.length === 0) mal('no se detecto ningun id: el patron de busqueda no matchea esta pagina');
  else if (huerfanos.length === 0) ok(`${pedidos.length} ids, todos presentes`);
  else mal('ids que el JS pide y el HTML no tiene: ' + huerfanos.join(', '));

  // --- 3. Ejecucion real contra el API --------------------------------------
  console.log(`\n[3] Ejecucion contra ${BASE}${pantalla.endpoint}`);

  let datos;
  try {
    const r = await fetch(BASE + pantalla.endpoint);
    if (!r.ok) throw new Error('HTTP ' + r.status);
    datos = await r.json();
    ok(`el API responde (${Object.keys(datos).length} claves)`);
  } catch (e) {
    mal(`no se pudo consultar el API: ${e.message}  (esta corriendo el server?)`);
    return;
  }

  const nodos = new Map();
  const documentoFalso = {
    getElementById: (id) => {
      if (!nodos.has(id)) nodos.set(id, nodoFalso(id));
      return nodos.get(id);
    },
    querySelectorAll: () => [],
    querySelector: () => null,
    addEventListener() {},
  };

  const contexto = {
    document: documentoFalso,
    window: { addEventListener() {} },
    console,
    fetch: () => Promise.resolve({ ok: true, status: 200, json: async () => datos }),
    setInterval: () => 0,
    clearInterval: () => {},
    setTimeout: () => 0,
    confirm: () => false,
    localStorage: { getItem: () => null, setItem() {}, removeItem() {} },
    // Sesion de admin simulada: las paginas la exigen y, sin ella, redirigen a
    // la portada sin pintar nada.
    sessionStorage: (() => {
      const guardado = { hazzi_sesion: JSON.stringify({ nombre: 'prueba', rol: 'admin' }) };
      return {
        getItem: (k) => (k in guardado ? guardado[k] : null),
        setItem(k, v) { guardado[k] = String(v); },
        removeItem(k) { delete guardado[k]; },
      };
    })(),
    location: { pathname: '/admin', href: BASE + '/admin', replace() {}, assign() {} },
  };

  const nombres = Object.keys(contexto);
  const valores = Object.values(contexto);
  const precargado = dependencias.join('\n;\n');

  for (let i = 0; i < bloques.length; i++) {
    try {
      // El script llama cargar() al final, que es async: hay que esperar a que
      // la microtask termine antes de mirar el DOM.
      const fn = new Function(...nombres, `return (async () => { ${precargado}\n;\n${bloques[i]} })();`);
      await fn(...valores);
      ok(`bloque ${i + 1} ejecuta sin lanzar`);
    } catch (e) {
      mal(`bloque ${i + 1} lanzo: ${e.message}`);
    }
  }
  await new Promise((r) => setTimeout(r, 50));

  // --- 4. Se pinto algo de verdad? ------------------------------------------
  console.log('\n[4] Se pinto algo de verdad?');
  for (const id of pantalla.pintan) {
    const n = nodos.get(id);
    if (!n) { mal(`nunca se busco #${id}`); continue; }
    const contenido = (n.innerHTML || '') + (n.textContent || '');
    if (contenido.trim().length > 0) ok(`#${id} tiene contenido (${contenido.trim().length} chars)`);
    else mal(`#${id} quedo VACIO`);
  }

  const estado = nodos.get('estado');
  if (estado && /Error al cargar/i.test(estado.textContent || '')) {
    mal('la pagina cayo en su propio catch: ' + estado.textContent);
  }
}

(async () => {
  for (const pantalla of PANTALLAS) await probar(pantalla);
  console.log(fallos === 0 ? '\n=> TODO OK\n' : `\n=> ${fallos} falla(s)\n`);
  process.exit(fallos === 0 ? 0 : 1);
})();
