"""usgs. sismos en chile. api oficial fdsn en formato geojson sin scraping.

se consulta la ventana de los ultimos dias dentro del cuadrante de chile.
la api es publica y estable asi que se prefiere por sobre scrapear el csn."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from .. import ajustes, area as area_mod
from ..fetcher import json_de
from ..normalize import Event, num, ms_to_str, severidad_sismo

_BBOX = {  # cuadrante que cubre chile continental mas norte sur y algo de mar
    "minlatitude": -56.5,
    "maxlatitude": -17.0,
    "minlongitude": -76.0,
    "maxlongitude": -66.0,
}
_BASE = "https://earthquake.usgs.gov/fdsnws/event/1/query"
# la ventana de dias y la magnitud minima se comparten con csn y se editan
# desde el admin. viven en ajustes.py no aca. antes estaban duplicadas en
# las dos fuentes y era justo lo que se queria sacar


def _build_url() -> str:
    dias = ajustes.ventana_dias()
    inicio = (datetime.now(timezone.utc) - timedelta(days=dias)).strftime("%Y-%m-%d")
    params = {
        "format": "geojson",
        "starttime": inicio,
        "minmagnitude": ajustes.magnitud_minima(),
        "orderby": "time",
        **_BBOX,
    }
    query = "&".join(f"{k}={v}" for k, v in params.items())
    return f"{_BASE}?{query}"


def urls_requeridas() -> list[str]:
    """urls que necesita esta fuente. se piden todas juntas con las demas."""
    return [_build_url()]


def fetch_events(prefetched: dict[str, str] | None = None) -> list[Event]:
    data = json_de(_build_url(), prefetched)
    eventos: list[Event] = []
    for feat in data.get("features", []):
        props = feat.get("properties", {})
        coords = (feat.get("geometry") or {}).get("coordinates") or [None, None, None]
        lon, lat = num(coords[0]), num(coords[1])
        prof = num(coords[2]) if len(coords) > 2 else None
        mag = num(props.get("mag"))

        fecha = None
        reciente = False
        ms = props.get("time")
        if ms:  # time viene en epoch milisegundos utc
            fecha = ms_to_str(ms)
            edad_h = (datetime.now(timezone.utc).timestamp() - ms / 1000) / 3600
            reciente = edad_h <= 24

        lugar = props.get("place") or "Sismo"
        detalle = f"Magnitud {mag}" if mag is not None else "Sismo"
        if prof is not None:
            detalle += f" | Profundidad {prof} km"

        eventos.append(
            Event(
                source="USGS",
                tipo="sismo",
                titulo=f"M{mag} - {lugar}" if mag is not None else lugar,
                severidad=severidad_sismo(mag),
                lat=lat,
                lon=lon,
                fecha=fecha,
                estado="Reciente (<24h)" if reciente else "Ocurrido",
                activa=reciente,
                detalle=detalle,
                area=area_mod.por_sismo(mag),
            )
        )
    return eventos
