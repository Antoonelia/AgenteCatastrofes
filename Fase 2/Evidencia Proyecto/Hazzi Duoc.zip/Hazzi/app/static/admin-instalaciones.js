/* admin-instalaciones.js. crud de instalaciones walmart.
 *
 * vive en su propio archivo y no dentro del html como deteccion, porque
 * esta pantalla tiene mapa formulario y tabla. embebido pasaria los 600
 * renglones de html y se volveria imposible de leer.
 *
 * el catalogo de tipos formatos y estados no se declara aca. llega del
 * backend en /api/admin/instalaciones. una sola fuente de verdad,
 * instalaciones.py, para la validacion y para la pantalla.
 */

const SANTIAGO = [-33.45, -70.66];

// simbolo generico de respaldo, solo para "sucursal" cuando todavia no
// hay un formato comercial elegible (catalogo sin cargar). apenas hay
// formato disponible, iconoParaTipo() lo reemplaza por el pin real del
// mapa via metaFormato(), ver mas abajo. oficina/cd/planta nunca caen
// aca: siempre tienen pin real desde TIPO_INST_META
const ICONO_GENERICO = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l1.5-5h15L21 9"/><path d="M4 9v11h16V9"/><path d="M9 20v-6h6v6"/></svg>';

const COLOR_ESTADO = {
  operativa:    { bg: '#dcfce7', fg: '#166534' },
  construccion: { bg: '#fef3c7', fg: '#92400e' },
  remodelacion: { bg: '#dbeafe', fg: '#1e40af' },
  cerrada:      { bg: '#e2e8f0', fg: '#475569' },
};

let CATALOGO = { tipos: [], formatos: [], estados: [] };
let LISTA = [];
let editando = null;      // iid en edicion, o null si es un alta
let tipoSel = 'sucursal';
let marcador = null;
let mapa = null;
let puedeEscribir = true;  // la pagina entera ya exige rol admin, ver exigirSesion arriba

const $ = (id) => document.getElementById(id);

function avisar(msg, error = false) {
  const el = $('estado');
  el.textContent = msg;
  el.className = 'text-sm ' + (error ? 'text-red-600 font-semibold' : 'text-slate-500');
}

// la sesion ya se valido en la portada y exigirSesion({admin:true}) ya
// rebota a quien no tenga el rol. si igual llega un 401/403 (sesion
// vencida mientras la pestana estaba abierta) se manda de vuelta a
// loguearse en vez de mostrar un error que no se puede resolver aca.
function sesionExpiro(r) {
  if (r.status === 401 || r.status === 403) {
    location.href = '/';
    return true;
  }
  return false;
}

/* icono por tipo/formato, reusando el arte real del mapa grande
   (metaFormato en common.js) en vez de dibujos genericos aparte, para
   que lo que se ve aca sea literalmente lo que despues aparece en el
   mapa. una oficina, cd o planta siempre tiene pin propio. una
   sucursal recien empieza generica y pasa a tener pin real apenas hay
   un formato comercial seleccionado (por defecto ya viene uno
   preseleccionado en el <select>, asi que en la practica solo se ve
   generica si el catalogo aun no cargo) */
function iconoParaTipo(clave) {
  if (clave !== 'sucursal') {
    const m = metaFormato({ tipo: clave });
    if (m && m.pin) return `<img src="${m.pin}" alt="" />`;
    return ICONO_GENERICO;
  }
  const formato = $('f-formato') ? $('f-formato').value : '';
  if (!formato) return ICONO_GENERICO;
  const m = metaFormato({ tipo: 'sucursal', formato });
  return m && m.pin ? `<img src="${m.pin}" alt="" />` : ICONO_GENERICO;
}

// icono para una fila ya guardada de la tabla, misma logica que
// iconoParaTipo pero a partir de los datos de la instalacion, no del
// formulario
function iconoParaFila(inst) {
  const m = metaFormato(inst);
  return m && m.pin ? `<img src="${m.pin}" style="width:20px;height:20px;object-fit:contain" alt="" />` : ICONO_GENERICO;
}

/* mapa */

function iniciarMapa() {
  // scrollWheelZoom en true a pedido: antes estaba apagado para que la
  // ruedita del mouse no "secuestrara" el scroll de la pagina al pasar
  // por encima sin querer. ahora que el mapa vive adentro de un popup
  // modal, ese riesgo no existe (el popup ya es la unica cosa en
  // pantalla), asi que se habilita sin ese costo
  mapa = L.map('mapa-inst', { scrollWheelZoom: true }).setView(SANTIAGO, 11);
  // carto (basemaps.cartocdn.com) empezo a pedir api key para light_all,
  // asi que el mini mapa quedaba mostrando el tile de error en vez del
  // mapa. cambiado a openstreetmap directo, la misma fuente que ya usa
  // el mapa grande en mapa.html, sin key y sin ese problema.
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap', maxZoom: 19,
  }).addTo(mapa);
  // click en el mapa tambien mueve el pin. obliga menos a apuntarle al
  // marcador chico, que en pantallas tactiles es incomodo
  mapa.on('click', (e) => ponerPin(e.latlng.lat, e.latlng.lng));
  // leaflet mide el contenedor al crearse. el mapa nace adentro de un
  // modal que arranca escondido (display:none), asi que en ese momento
  // el contenedor mide 0x0 y las teselas quedan mal calculadas. por
  // eso abrirModalForm() vuelve a llamar invalidateSize() cada vez que
  // el popup se muestra, no solo una vez aca al iniciar
  setTimeout(() => mapa.invalidateSize(), 250);
}

// icono animado del pin arrastrable: entra con un rebote y pulsa suave
// en la base (ver .in-marcador-wrap/.in-marcador-pulso en el html), en
// vez de la chinche azul por defecto de leaflet. reusa el pin real del
// tipo/formato elegido cuando existe, y una bolita azul con un rayo
// (SVG) como generico para sucursales sin formato todavia
function iconoMarcadorForm() {
  const m = tipoSel !== 'sucursal'
    ? metaFormato({ tipo: tipoSel })
    : metaFormato({ tipo: 'sucursal', formato: $('f-formato') ? $('f-formato').value : '' });
  if (m && m.pin) {
    const ratio = m.pinRatio || 1;
    const alto = 54;
    const ancho = Math.round(alto * ratio);
    return L.divIcon({
      className: '',
      html: `<div class="in-marcador-wrap"><img src="${m.pin}" style="width:${ancho}px;height:${alto}px;object-fit:contain" /></div>`,
      iconSize: [ancho, alto],
      iconAnchor: [ancho / 2, alto],
    });
  }
  return L.divIcon({
    className: '',
    html: `<div class="in-marcador-wrap"><div class="in-marcador-generico">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M21 3L3 10.5l7 3 3 7L21 3z"/></svg>
    </div></div>`,
    iconSize: [40, 46],
    iconAnchor: [20, 44],
  });
}

// se llama cada vez que cambia el tipo o el formato elegido, para que
// el pin del mini mapa "salte" al nuevo simbolo con el mismo rebote de
// entrada que al crearse
function actualizarIconoMarcador() {
  if (marcador) marcador.setIcon(iconoMarcadorForm());
}

function ponerPin(lat, lon, centrar = false) {
  if (!marcador) {
    marcador = L.marker([lat, lon], { draggable: true, icon: iconoMarcadorForm() }).addTo(mapa);
    marcador.on('dragend', () => {
      const p = marcador.getLatLng();
      mostrarCoords(p.lat, p.lng);
    });
  } else {
    marcador.setLatLng([lat, lon]);
  }
  if (centrar) {
    mapa.invalidateSize();
    mapa.setView([lat, lon], 15);
  }
  mostrarCoords(lat, lon);
}

function mostrarCoords(lat, lon) {
  $('coords').textContent = `${lat.toFixed(5)}, ${lon.toFixed(5)}`;
  // el mini mapa es chico a proposito. este enlace lleva al mapa grande
  // ya centrado ahi, por si hace falta ver el contexto completo de la
  // zona (otras tiendas cerca, cobertura de una alerta, etc)
  const enlace = $('ver-mapa-completo');
  enlace.href = `/?lat=${lat}&lon=${lon}`;
  enlace.classList.remove('hidden');
}

function coordsActuales() {
  if (!marcador) return null;
  const p = marcador.getLatLng();
  return { lat: p.lat, lon: p.lng };
}

/* geocodificar con boton, nunca mientras se escribe. nominatim permite 1
   request por segundo y buscar en cada tecla nos haria bloquear la ip. */
async function buscarDireccion() {
  const dir = $('f-direccion').value.trim();
  const com = $('f-comuna').value.trim();
  if (!dir && !com) { avisar('Escribe una direccion o comuna para buscar.', true); return; }
  const btn = $('btn-buscar-dir');
  const txt = $('btn-buscar-txt');
  btn.disabled = true; txt.textContent = 'Buscando…';
  try {
    const q = encodeURIComponent([dir, com, 'Chile'].filter(Boolean).join(', '));
    const r = await fetch(`https://nominatim.openstreetmap.org/search?q=${q}&format=json&limit=1&countrycodes=cl`);
    const d = await r.json();
    if (!d.length) { avisar('No se encontro esa direccion. Ubica el pin a mano en el mapa.', true); return; }
    ponerPin(parseFloat(d[0].lat), parseFloat(d[0].lon), true);
    avisar('Direccion encontrada. Si el pin no quedo exacto, puedes arrastrarlo hasta el lugar correcto.');
  } catch (e) {
    avisar('No se pudo consultar el geocodificador: ' + e.message, true);
  } finally {
    btn.disabled = false; txt.textContent = 'Buscar';
  }
}

/* formulario */

function pintarTipos() {
  $('tipos').innerHTML = CATALOGO.tipos.map((t) => `
    <button type="button" class="hz-tipo-op" data-tipo="${escHtml(t.clave)}"
            aria-pressed="${t.clave === tipoSel}" title="${escHtml(t.etiqueta)}">
      <span class="hz-tipo-ic">${iconoParaTipo(t.clave)}</span><span>${escHtml(t.etiqueta)}</span>
    </button>`).join('');
  $('tipos').querySelectorAll('[data-tipo]').forEach((b) => {
    b.onclick = () => { tipoSel = b.dataset.tipo; pintarTipos(); aplicarTipo(); actualizarIconoMarcador(); };
  });
}

// el formato solo existe para sucursales, ver pide_formato en el backend
function aplicarTipo() {
  const t = CATALOGO.tipos.find((x) => x.clave === tipoSel);
  $('wrap-formato').classList.toggle('hidden', !(t && t.pide_formato));
}

// punto de color junto al select de estado, mismo color que el chip de
// la tabla (COLOR_ESTADO), para reconocer el estado de un vistazo sin
// tener que leer el texto de la opcion elegida
function actualizarColorEstado() {
  const dot = $('estado-dot');
  if (!dot) return;
  const col = COLOR_ESTADO[$('f-estado').value] || COLOR_ESTADO.operativa;
  dot.style.background = col.fg;
}

// icono + texto del boton eliminar/reincluir. son dos svg fijos, no vale
// la pena armar un tercer helper de iconos solo para esto
const _ICONO_ELIMINAR = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></svg>';
const _ICONO_REINCLUIR = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/></svg>';

function limpiarForm() {
  editando = null;
  tipoSel = 'sucursal';
  ['f-nombre', 'f-comuna', 'f-direccion', 'f-notas'].forEach((id) => { $(id).value = ''; });
  $('f-estado').value = 'operativa';
  $('f-formato').value = CATALOGO.formatos[0] || '';
  $('form-titulo').textContent = 'Nueva instalacion';
  $('form-sub').textContent = 'Elige el tipo para empezar.';
  $('btn-eliminar').classList.add('hidden');
  $('form-error').classList.add('hidden');
  if (marcador) { mapa.removeLayer(marcador); marcador = null; }
  $('coords').textContent = '';
  $('ver-mapa-completo').classList.add('hidden');
  pintarTipos(); aplicarTipo(); actualizarColorEstado();
}

function cargarEnForm(inst) {
  editando = inst.iid;
  tipoSel = inst.tipo || 'sucursal';
  $('f-nombre').value = inst.nombre || '';
  $('f-comuna').value = inst.comuna || '';
  $('f-direccion').value = inst.direccion || '';
  $('f-notas').value = inst.notas || '';
  $('f-estado').value = inst.estado || 'operativa';
  $('f-formato').value = inst.formato || CATALOGO.formatos[0] || '';
  $('form-titulo').textContent = 'Editar instalacion';
  $('form-sub').textContent = inst.excluida
    ? 'Excluida: ya no aparece en el mapa ni en las listas.'
    : inst.origen === 'lider'
      ? 'Viene del buscador de Lider. Lo que edites se guarda como correccion.'
      : 'Instalacion cargada a mano.';
  $('btn-eliminar').classList.remove('hidden');
  // excluida: el boton se vuelve una accion NO destructiva (deshacer
  // la exclusion), asi que cambia de rojo a verde y de texto, en vez
  // de reusar "eliminar" para dos cosas de riesgo tan distinto
  $('btn-eliminar').classList.toggle('in-btn-exito', !!inst.excluida);
  $('btn-eliminar').classList.toggle('in-btn-peligro', !inst.excluida);
  $('btn-eliminar').querySelector('svg').outerHTML = inst.excluida ? _ICONO_REINCLUIR : _ICONO_ELIMINAR;
  $('btn-eliminar-txt').textContent = inst.excluida ? 'Reincluir' : 'Eliminar';
  $('form-error').classList.add('hidden');
  pintarTipos(); aplicarTipo(); actualizarColorEstado();
  if (inst.lat != null && inst.lon != null) ponerPin(inst.lat, inst.lon, true);
  else actualizarIconoMarcador();
}

/* popup de alta/edicion */

function abrirModalForm(inst) {
  if (inst) cargarEnForm(inst); else limpiarForm();
  $('modal-form').classList.remove('hidden');
  // el mapa nacio con el modal escondido (o llevaba rato sin
  // mostrarse), asi que leaflet nunca lo midio bien. invalidateSize
  // recalcula el tamano de las teselas apenas el popup es visible de
  // verdad, y el pequeno delay le da tiempo al navegador a terminar la
  // transicion de layout antes de medir
  setTimeout(() => {
    mapa.invalidateSize();
    if (marcador) mapa.setView(marcador.getLatLng(), mapa.getZoom());
  }, 60);
  setTimeout(() => $('f-nombre').focus(), 80);
}

function cerrarModalForm() {
  $('modal-form').classList.add('hidden');
}

/* tabla */

function filtrada() {
  const q = $('buscar').value.trim().toLowerCase();
  const ft = $('filtro-tipo').value;
  const fe = $('filtro-estado').value;
  const lista = LISTA.filter((i) => {
    if (ft && i.tipo !== ft) return false;
    if (fe && i.estado !== fe) return false;
    if (!q) return true;
    return [i.nombre, i.comuna, i.direccion, i.formato]
      .some((v) => (v || '').toLowerCase().includes(q));
  });

  // favoritas primero, siempre: es literalmente el pedido, "quiero
  // verlas primero en esa lista". dentro de cada grupo (favorita o no)
  // se mantiene el orden anterior: lo editado antes que el resto, y
  // alfabetico al final, para que el resto de la lista no salte de
  // lugar cada vez que alguien marca un favorito nuevo
  return lista.sort((a, b) => {
    if (!!a.favorito !== !!b.favorito) return a.favorito ? -1 : 1;
    if (!!a.editada !== !!b.editada) return a.editada ? -1 : 1;
    if (a.editada && b.editada) return (b.actualizado || 0) - (a.actualizado || 0);
    return (a.nombre || '').localeCompare(b.nombre || '', 'es');
  });
}

function pintarTabla() {
  const lista = filtrada();
  const tb = $('tabla');
  // lista completa, sin recorte: pedido explicito, se quiere ver todo
  $('conteo').textContent = `Total: ${lista.length}`;
  $('vacio').classList.toggle('hidden', lista.length > 0);
  tb.innerHTML = '';

  lista.forEach((i) => {
    const est = CATALOGO.estados.find((e) => e.clave === i.estado) || { etiqueta: i.estado || '—' };
    const col = COLOR_ESTADO[i.estado] || COLOR_ESTADO.operativa;
    const tr = document.createElement('tr');
    // cerrada o excluida: se muestran en gris y tachadas, pero siguen
    // en la lista para poder reabrirlas o reincluirlas. ver .hz-cerrada
    // en el style de la pagina, reusado para ambos casos
    tr.className = 'hz-fila-clic' + (i.estado === 'cerrada' || i.excluida ? ' hz-cerrada' : '');
    tr.onclick = (ev) => {
      // que un clic dentro del menu de 3 puntitos (o el boton que lo
      // abre) no dispare ademas la apertura del formulario completo
      if (ev.target.closest('.hz-kebab-wrap')) return;
      abrirModalForm(i);
    };
    tr.innerHTML = `
      <td>
        <span class="flex items-center gap-2">
          ${i.favorito ? '<img src="/static/logos/spark.webp" alt="Favorito" title="Favorito" width="16" height="16" style="flex:0 0 auto" />' : ''}
          <span style="width:20px;height:20px;color:#0071dc;flex:0 0 auto;display:flex;align-items:center;justify-content:center">${iconoParaFila(i)}</span>
          <span>
            <span class="font-semibold">${escHtml(i.nombre || i.formato || '(sin nombre)')}</span>
            ${i.excluida ? '<span class="hz-chip-origen ml-1" style="background:#fee2e2;color:#b91c1c;border-color:#fecaca">excluida</span>' : ''}
            <br><span class="text-xs text-slate-400">${escHtml(i.direccion || '—')}</span>
          </span>
        </span>
      </td>
      <td class="text-sm">${escHtml(i.comuna || '—')}</td>
      <td><span class="hz-chip-est" style="background:${col.bg};color:${col.fg}">${escHtml(i.excluida ? 'Excluida' : est.etiqueta)}</span></td>
      <td>
        <div class="hz-kebab-wrap">
          <button type="button" class="hz-kebab-btn" data-iid="${escHtml(i.iid)}" aria-haspopup="true" aria-expanded="false" aria-label="Acciones">
            <svg viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>
          </button>
        </div>
      </td>`;
    tb.appendChild(tr);
  });
}

/* ---------- menu de 3 puntitos: un unico elemento "flotante" en vez de
   uno por fila. vive afuera de la tabla (ver #menu-kebab-instalacion en
   el html, junto al boton flotante), asi que nunca lo recorta el
   overflow de la tarjeta ni se destruye cada vez que pintarTabla()
   redibuja las filas -- abrir/cerrar solo mueve este unico elemento,
   actualiza su contenido (favorito/reincluir cambian de texto segun el
   estado de la instalacion) y cambia a que fila apunta. ---------- */

let menuAbiertoIid = null;
const menuKebab = $('menu-kebab-instalacion');

function posicionarMenuKebab(boton) {
  const r = boton.getBoundingClientRect();
  const alto = menuKebab.offsetHeight;
  const ancho = menuKebab.offsetWidth;
  let top = r.bottom + 4;
  if (top + alto > window.innerHeight - 8) top = r.top - alto - 4;
  let left = r.right - ancho;
  if (left < 8) left = 8;
  if (left + ancho > window.innerWidth - 8) left = window.innerWidth - ancho - 8;
  menuKebab.style.top = `${top}px`;
  menuKebab.style.left = `${left}px`;
}

// didactico: la accion de favorito cambia de texto segun el estado
// actual, y eliminar se convierte en "Reincluir" para una tienda de
// Lider ya excluida -- en vez de un generico "activar/desactivar" que
// obliga a leer dos veces
function actualizarContenidoMenuKebab(inst) {
  $('menu-kebab-favorito-txt').textContent = inst.favorito ? 'Sacar de favoritos' : 'Agregar a favoritos';
  $('menu-kebab-eliminar-txt').textContent = inst.excluida ? 'Reincluir' : 'Eliminar';
  [$('menu-kebab-editar'), $('menu-kebab-favorito'), $('menu-kebab-eliminar')].forEach((b) => { b.disabled = !puedeEscribir; });
}

function abrirMenuKebab(boton, iid) {
  if (menuAbiertoIid === iid) { cerrarMenuKebab(); return; }
  const inst = LISTA.find((x) => x.iid === iid);
  if (!inst) return;
  menuAbiertoIid = iid;
  document.querySelectorAll('.hz-kebab-btn').forEach((b) => b.setAttribute('aria-expanded', String(b === boton)));
  actualizarContenidoMenuKebab(inst);
  menuKebab.classList.remove('hidden');
  posicionarMenuKebab(boton);
}

function cerrarMenuKebab() {
  menuAbiertoIid = null;
  document.querySelectorAll('.hz-kebab-btn').forEach((b) => b.setAttribute('aria-expanded', 'false'));
  menuKebab.classList.add('hidden');
}

$('tabla').addEventListener('click', (ev) => {
  const kebabBtn = ev.target.closest('.hz-kebab-btn');
  if (kebabBtn) { ev.stopPropagation(); abrirMenuKebab(kebabBtn, kebabBtn.dataset.iid); }
});

$('menu-kebab-editar').addEventListener('click', () => {
  const inst = LISTA.find((x) => x.iid === menuAbiertoIid);
  cerrarMenuKebab();
  if (inst) abrirModalForm(inst);
});
$('menu-kebab-favorito').addEventListener('click', () => {
  const inst = LISTA.find((x) => x.iid === menuAbiertoIid);
  cerrarMenuKebab();
  if (inst) alternarFavorito(inst);
});
$('menu-kebab-eliminar').addEventListener('click', () => {
  const inst = LISTA.find((x) => x.iid === menuAbiertoIid);
  cerrarMenuKebab();
  if (inst) { editando = inst.iid; onClickBtnEliminar(); }
});

// si se scrollea o se cambia el tamano de ventana con el menu abierto,
// se reposiciona para que siga pegado al boton -- o se cierra si el
// boton ya se salio de la pantalla. captura en fase de captura porque
// "scroll" no burbujea desde un div interno.
function reposicionarOCerrarMenuKebab() {
  if (menuAbiertoIid === null) return;
  const boton = document.querySelector('.hz-kebab-btn[aria-expanded="true"]');
  if (!boton) { cerrarMenuKebab(); return; }
  const r = boton.getBoundingClientRect();
  if (r.bottom < 0 || r.top > window.innerHeight) { cerrarMenuKebab(); return; }
  posicionarMenuKebab(boton);
}
window.addEventListener('scroll', reposicionarOCerrarMenuKebab, true);
window.addEventListener('resize', reposicionarOCerrarMenuKebab);

// favorito se guarda como una correccion mas via PUT, mismo endpoint
// que cualquier otro campo (ver instalaciones.guardar_parche en el
// backend, que ya sabe no marcar "editada" cuando lo unico que cambia
// es este campo). no hace falta pasar por el formulario completo para
// esto, un toggle directo desde el menu alcanza
async function alternarFavorito(inst) {
  try {
    const r = await fetch(`/api/admin/instalaciones/${inst.iid}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ favorito: !inst.favorito }),
    });
    if (sesionExpiro(r)) return;
    const d = await r.json();
    if (!r.ok) { avisar(d.detail || 'No se pudo actualizar favoritos.', true); return; }
    avisar(!inst.favorito ? `"${inst.nombre || inst.formato}" agregada a favoritos.` : `"${inst.nombre || inst.formato}" ya no es favorita.`);
    await cargar();
  } catch (e) {
    avisar('Error de red: ' + e.message, true);
  }
}

/* acceso */

// ya no hay tres modos posibles: esta pagina exige rol admin de
// entrada (exigirSesion({admin:true}) en el html), asi que si se
// llego hasta aca, se puede editar. el banner queda solo como
// contexto visual, no como puerta.
const ACCESO_INFO = {
  ic: 'M9 11V7a3 3 0 0 1 6 0M5 11h14v10H5z',
  t: 'Puedes editar el catalogo',
  d: 'Crear, corregir y eliminar instalaciones. Los cambios entran en la proxima recoleccion (cada 60 s).',
};

function pintarAcceso() {
  $('acceso').innerHTML = `
    <div class="aj-acceso abierto">
      <div class="aj-acceso-ic"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="${ACCESO_INFO.ic}"/></svg></div>
      <div style="flex:1 1 240px">
        <div class="aj-acceso-t">${ACCESO_INFO.t}</div>
        <div class="aj-acceso-d">${ACCESO_INFO.d}</div>
      </div>
    </div>`;
}

/* api */

async function cargar() {
  avisar('Cargando…');
  try {
    const r = await fetch('/api/admin/instalaciones');
    const d = await r.json();
    CATALOGO = d.catalogo;
    LISTA = d.instalaciones;

    if (!$('f-estado').options.length) {
      $('f-estado').innerHTML = CATALOGO.estados.map((e) => `<option value="${escHtml(e.clave)}">${escHtml(e.etiqueta)}</option>`).join('');
      $('f-formato').innerHTML = CATALOGO.formatos.map((f) => `<option value="${escHtml(f)}">${escHtml(f)}</option>`).join('');
      $('filtro-tipo').innerHTML = '<option value="">Todo tipo</option>'
        + CATALOGO.tipos.map((t) => `<option value="${escHtml(t.clave)}">${escHtml(t.etiqueta)}</option>`).join('');
      $('filtro-estado').innerHTML = '<option value="">Todo estado</option>'
        + CATALOGO.estados.map((e) => `<option value="${escHtml(e.clave)}">${escHtml(e.etiqueta)}</option>`).join('');
      pintarTipos(); aplicarTipo(); actualizarColorEstado();
    }

    pintarAcceso();
    pintarTabla();
    avisar('');
  } catch (e) {
    avisar('Error al cargar: ' + e.message, true);
  }
}

function errorForm(msg) {
  const el = $('form-error');
  el.textContent = msg;
  el.classList.remove('hidden');
}

async function guardar(ev) {
  ev.preventDefault();
  $('form-error').classList.add('hidden');

  const c = coordsActuales();
  if (!c) { errorForm('Falta ubicar la instalacion: busca la direccion o haz clic en el mapa.'); return; }

  const datos = {
    nombre: $('f-nombre').value.trim(),
    tipo: tipoSel,
    formato: $('f-formato').value,
    direccion: $('f-direccion').value.trim(),
    comuna: $('f-comuna').value.trim(),
    estado: $('f-estado').value,
    notas: $('f-notas').value.trim(),
    lat: c.lat,
    lon: c.lon,
  };

  const url = editando ? `/api/admin/instalaciones/${editando}` : '/api/admin/instalaciones';
  try {
    const r = await fetch(url, {
      method: editando ? 'PUT' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(datos),
    });
    if (sesionExpiro(r)) return;
    const d = await r.json();
    if (!r.ok) { errorForm(d.detail || 'No se pudo guardar.'); return; }
    const creada = !editando;
    const nombre = datos.nombre;
    limpiarForm();
    cerrarModalForm();
    await cargar();
    // se deja el nombre en el buscador para que la instalacion recien
    // guardada quede a la vista. confirmar con un cartel que desaparece
    // no alcanza, hay que poder verla en la lista
    if (nombre) { $('buscar').value = nombre; pintarTabla(); }
    avisar(creada ? `"${nombre}" creada y visible en la lista.` : `"${nombre}" actualizada.`);
  } catch (e) {
    errorForm('Error de red: ' + e.message);
  }
}

/* eliminar, con confirmacion mediante pop up propio.
 *
 * a proposito NO reusa clave(), la clave que ya quedo guardada en la
 * sesion: se pide reescribirla aca, en el momento de borrar. una
 * sesion de administrador que alguien deja abierta en un pc
 * compartido no deberia alcanzar para borrar algo sin escribir la
 * clave de nuevo. el backend igual la valida con requiere_clave, asi
 * que esto no es la unica barrera, es una segunda a proposito.
 *
 * una tienda de lider no se puede borrar de la base porque el
 * scraping la vuelve a traer cada ciclo (ver instalaciones.aplicar en
 * el backend), asi que "eliminar" ahi significa EXCLUIRLA para
 * siempre, no descartar una correccion. pedido explicito de
 * antonella 29-09-2026: antes el boton decia "Descartar correccion"
 * para esas tiendas y no hacia desaparecer nada, solo volvia a los
 * datos originales -- no era lo que necesitaba. */

function abrirModalEliminar() {
  if (!editando) return;
  const inst = LISTA.find((i) => i.iid === editando);
  const esLider = inst && inst.origen === 'lider';
  $('modal-titulo').textContent = 'Eliminar instalacion';
  $('modal-sub').textContent = (inst && (inst.nombre || inst.formato)) || '';
  $('modal-msg').textContent = esLider
    ? 'Esta tienda no volvera a aparecer en el mapa ni en las listas, aunque el scraping de Lider la siga trayendo. Podras reincluirla despues desde esta misma pantalla.'
    : 'Esta instalacion se borrara por completo. Esta accion no se puede deshacer.';
  $('modal-confirmar').textContent = 'Eliminar';
  $('modal-error').classList.add('hidden');
  $('modal').classList.remove('hidden');
  setTimeout(() => $('modal-confirmar').focus(), 50);
}

function cerrarModalEliminar() {
  $('modal').classList.add('hidden');
}

function errorModal(msg) {
  const el = $('modal-error');
  el.textContent = msg;
  el.classList.remove('hidden');
}

async function confirmarEliminar(ev) {
  ev.preventDefault();
  if (!editando) return;
  const boton = $('modal-confirmar');
  boton.disabled = true;
  const textoOriginal = boton.textContent;
  boton.textContent = 'Eliminando…';
  try {
    const r = await fetch(`/api/admin/instalaciones/${editando}`, { method: 'DELETE' });
    if (sesionExpiro(r)) return;
    const d = await r.json();
    if (!r.ok) {
      errorModal(d.detail || 'No se pudo eliminar.');
      return;
    }
    cerrarModalEliminar();
    cerrarModalForm();
    avisar(d.accion === 'excluida' ? 'Instalacion excluida: no volvera a aparecer en el mapa.' : 'Instalacion eliminada.');
    limpiarForm();
    await cargar();
  } catch (e) {
    errorModal('Error de red: ' + e.message);
  } finally {
    boton.disabled = false;
    boton.textContent = textoOriginal;
  }
}

/* reincluir: deshace una exclusion. no es destructivo, asi que no pasa
 * por el pop up de confirmacion con clave -- reusa clave(), igual que
 * guardar(). el boton que la dispara es el mismo btn-eliminar, solo
 * que cargarEnForm() ya lo dejo en verde y con el texto "Reincluir"
 * cuando la instalacion esta excluida (ver mas arriba). el mismo
 * camino se reusa desde la accion "Reincluir" del menu de 3 puntitos. */

async function reincluirInstalacion() {
  if (!editando) return;
  const boton = $('btn-eliminar');
  boton.disabled = true;
  try {
    const r = await fetch(`/api/admin/instalaciones/${editando}/reincluir`, { method: 'POST' });
    if (sesionExpiro(r)) return;
    const d = await r.json().catch(() => ({}));
    if (!r.ok) { errorForm(d.detail || 'No se pudo reincluir.'); return; }
    avisar('Instalacion reincluida: vuelve a aparecer con sus datos de Lider.');
    limpiarForm();
    cerrarModalForm();
    await cargar();
  } catch (e) {
    errorForm('Error de red: ' + e.message);
  } finally {
    boton.disabled = false;
  }
}

// un solo boton, dos acciones posibles segun el estado actual de la
// instalacion en edicion: eliminar (destructivo, pide clave de nuevo
// en un pop up) o reincluir (no destructivo, directo)
function onClickBtnEliminar() {
  if (!editando) return;
  const inst = LISTA.find((i) => i.iid === editando);
  if (inst && inst.excluida) { reincluirInstalacion(); return; }
  abrirModalEliminar();
}

/* arranque */

iniciarMapa();
$('form').addEventListener('submit', guardar);
$('btn-buscar-dir').addEventListener('click', buscarDireccion);
$('btn-cancelar').addEventListener('click', () => { limpiarForm(); cerrarModalForm(); });
$('btn-eliminar').addEventListener('click', onClickBtnEliminar);
$('btn-fab-nueva').addEventListener('click', () => abrirModalForm(null));
$('f-formato').addEventListener('change', () => { pintarTipos(); actualizarIconoMarcador(); });
$('f-estado').addEventListener('change', actualizarColorEstado);
$('modal-form-cerrar').addEventListener('click', () => { limpiarForm(); cerrarModalForm(); });
$('modal-form').addEventListener('click', (e) => { if (e.target.id === 'modal-form') { limpiarForm(); cerrarModalForm(); } });
$('form-eliminar').addEventListener('submit', confirmarEliminar);
$('modal-cerrar').addEventListener('click', cerrarModalEliminar);
$('modal-cancelar').addEventListener('click', cerrarModalEliminar);
// clic en el fondo oscuro tambien cierra, mismo patron que el modal de
// detalle de evento en mapa.html: solo si el clic fue justo en el fondo,
// no en la tarjeta blanca de encima
$('modal').addEventListener('click', (e) => { if (e.target.id === 'modal') cerrarModalEliminar(); });
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Escape') return;
  if (!$('modal').classList.contains('hidden')) { cerrarModalEliminar(); return; }
  if (!$('modal-form').classList.contains('hidden')) { limpiarForm(); cerrarModalForm(); return; }
  if (menuAbiertoIid !== null) cerrarMenuKebab();
});
// clic en cualquier parte fuera del menu de 3 puntitos (o del menu
// mismo, ahora que vive afuera de la tabla) lo cierra, patron estandar
// de dropdown
document.addEventListener('click', (e) => {
  if (menuAbiertoIid !== null && !e.target.closest('.hz-kebab-wrap') && !e.target.closest('#menu-kebab-instalacion')) {
    cerrarMenuKebab();
  }
});
['buscar', 'filtro-tipo', 'filtro-estado'].forEach((id) => {
  $(id).addEventListener('input', pintarTabla);
});
cargar();
