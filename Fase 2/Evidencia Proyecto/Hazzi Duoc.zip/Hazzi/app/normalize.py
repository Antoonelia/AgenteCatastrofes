"""modelo unificado de evento. toda fuente devuelve una lista de event normalizados."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Optional


SEVERITY_COLOR = {  # color segun severidad para el mapa y la tabla
    "roja": "#dc2626",
    "naranja": "#ea580c",
    "amarilla": "#d97706",
    "verde": "#16a34a",
    "info": "#2563eb",
}


@dataclass
class Event:
    source: str                     # conaf sernageomin dmc csn senapred
    tipo: str                       # incendio volcan meteorologico sismo alerta
    titulo: str
    severidad: str = "info"         # roja naranja amarilla verde info
    region: Optional[str] = None
    comuna: Optional[str] = None
    lat: Optional[float] = None
    lon: Optional[float] = None
    fecha: Optional[str] = None
    estado: Optional[str] = None    # activo controlado finalizado vigente...
    activa: bool = True             # true si la alerta sigue vigente. false si ya paso
    detalle: Optional[str] = None
    fenomeno: Optional[str] = None  # viento nieve calor lluvia. ver fenomeno.py. solo meteorologicos
    mapa: bool = True               # false: solo registro no alerta operativa. ver es_registro
    area: Optional[dict] = None     # zona realmente afectada. ver area.py. none es tamano desconocido
    tema: Optional[str] = None      # causa de una alerta senapred. ver sources/senapred.py
    # distingue alertas de hazards distintos que coinciden en la misma
    # comuna de los estados sucesivos de una misma alerta. ver retention.py
    vigencia_hasta: Optional[str] = None  # fecha explicita dd-mm-yyyy si la fuente la declara
    # le gana a la ventana heuristica de retention.py. none si no la trae

    def color(self) -> str:
        return SEVERITY_COLOR.get(self.severidad, "#2563eb")

    def regiones_agrupadas(self) -> list[str]:
        """todas las regiones oficiales que toca este evento para
        agruparlo bajo los carteles de region del mapa. distinto del
        campo region que puede venir crudo de cada fuente. por ejemplo
        csn manda el lugar del sismo tipo "70 km al so de iquique" no el
        nombre de la region. se vuelve a extraer contra la lista oficial
        probando primero region despues comuna despues el titulo y se
        queda con el primer campo que tenga alguna coincidencia.

        antes se devolvia solo la primera region de ese campo y una
        alerta dmc de un tramo de costa completo quedaba pintada en el
        mapa sobre valparaiso pero ausente de su resumen regional
        mientras que coquimbo si la mostraba. la misma alerta se veia
        distinta segun la region desde la que se consultara. lo reporto
        antonella el 23-09-2026. ahora se devuelven todas las regiones
        encontradas asi el evento aparece en el resumen de cada una de
        las que realmente afecta."""
        from .regiones_cl import regiones_desde_texto

        for candidato in (self.region, self.comuna, self.titulo):
            if not candidato:
                continue
            encontradas = regiones_desde_texto(candidato)
            if encontradas:
                return encontradas
        return []

    def region_agrupada(self) -> Optional[str]:
        """region oficial principal. la primera mencionada de este
        evento. se mantiene aparte de regiones_agrupadas porque hay usos
        que necesitan una sola region por evento. por ejemplo que popup
        regional abrir al tocar el pin de este evento puntual. para el
        resumen completo por region donde un evento puede pertenecer a
        varias usar regiones_agrupadas."""
        regiones = self.regiones_agrupadas()
        return regiones[0] if regiones else None

    def to_dict(self) -> dict:
        from .regiones_cl import texto_numero_region

        d = asdict(self)
        d["color"] = self.color()
        regiones = self.regiones_agrupadas()
        region = regiones[0] if regiones else None
        d["region_agrupada"] = region
        d["regiones_agrupadas"] = regiones
        d["region_numero_texto"] = texto_numero_region(region) if region else ""
        return d


UMBRAL_ALERTA_SISMO = 4.0
# magnitud desde la que un sismo cuenta como alerta operativa. por debajo
# es sismicidad de fondo. chile tiene decenas de sismos chicos por dia y
# ninguno afecta la operacion. vive en un solo lugar porque de aca
# dependen tanto la severidad como el camino que sigue el evento


def es_registro(e: dict) -> bool:
    """true si el evento vale solo como registro y no como alerta operativa.

    un registro no pasa por eventos vigentes. se archiva directo en el
    historial donde queda como contexto y alimenta las estadisticas. por
    ejemplo un sismo menor a m4 que por si solo no amerita alerta pero si
    importa para ver secuencias sismicas como enjambres o replicas.

    la definicion es unica para backend y frontend. el flag viaja como
    mapa en el json y el front lo lee con espreventiva en common.js."""
    return e.get("mapa") is False


def severidad_sismo(mag: Optional[float]) -> str:
    """color o severidad de un sismo segun su magnitud. lo comparten usgs y csn."""
    if mag is None:
        return "info"
    if mag >= 6.0:
        return "roja"
    if mag >= 5.0:
        return "naranja"
    if mag >= UMBRAL_ALERTA_SISMO:
        return "amarilla"
    return "verde"


def marcar_registros(eventos: list[dict]) -> list[dict]:
    """marca como registro los sismos que no ameritan alerta. bajo m4.

    se aplica en un solo punto en main.py y no en cada fuente. csn y
    usgs traen sismos por igual y la regla es la misma para las dos.
    repetirla en cada una seria pedirle a toda fuente nueva que se
    acuerde.

    verde es exactamente el nivel que le da severidad_sismo a los
    sismos bajo el umbral asi que el umbral no se repite aca."""
    for e in eventos:
        if e.get("tipo") == "sismo" and e.get("severidad") == "verde":
            e["mapa"] = False
    return eventos


def num(value) -> Optional[float]:
    """convierte a float de forma segura. none si no se puede."""
    try:
        if value is None or value == "":
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def texto_fecha_cl(s) -> Optional[str]:
    """reformatea una fecha tipo yyyy-mm-dd hh:mm a dd-mm-yyyy hh:mm hrs."""
    from datetime import datetime
    if not s:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M"):
        try:
            return datetime.strptime(str(s).strip(), fmt).strftime("%d-%m-%Y %H:%M hrs")
        except ValueError:
            continue
    return str(s)


def ms_to_str(ms) -> Optional[str]:
    """convierte epoch en milisegundos utc a hora local de chile legible."""
    from datetime import datetime, timezone, timedelta
    try:
        if ms in (None, ""):
            return None
        dt_utc = datetime.fromtimestamp(float(ms) / 1000, tz=timezone.utc)
        try:
            from zoneinfo import ZoneInfo
            dt = dt_utc.astimezone(ZoneInfo("America/Santiago"))
        except Exception:  # noqa: BLE001 - fallback si no hay tzdata
            dt = dt_utc.astimezone(timezone(timedelta(hours=-4)))
        return dt.strftime("%d-%m-%Y %H:%M hrs")
    except (TypeError, ValueError, OSError):
        return None
