"""feed de catastrofes fuera de chile, GDACS (Global Disaster Alert and
Coordination System, programa conjunto de la ONU y la Comision Europea).

a proposito NO vive en sources/ ni entra a REGISTRY. sources/ alimenta
/api/events, que decide alertas activas, sucursales en riesgo y
notificaciones: nada de eso debe enterarse de un terremoto en Taiwan o una
inundacion en India. este modulo es solo para la historia "Mundo" del
inicio, que es informativa, no operativa, asi que vive separado con su
propia cache y su propio endpoint, ver /api/historias/global en main.py.

sin esto un fallo o una lentitud de gdacs.org terminaria contaminando el
pipeline domestico, o peor, sumando poblacion global a las cifras de
sucursales afectadas.

gdacs manda todo en ingles. titulo y pais se traducen al espanol antes
de cachear (ver _traducir_eventos), en un solo proceso de powershell
por lote via fetch_many, no uno por texto. es un adorno, no un
requisito: si la traduccion falla o se acaba la cuota gratis del dia,
el evento se queda en ingles en vez de romper la historia."""
from __future__ import annotations

import json
import time
import urllib.parse
from xml.etree import ElementTree as ET

from .fetcher import fetch_many, fetch_text

URL = "https://www.gdacs.org/xml/rss.xml"
_NS = {"gdacs": "http://www.gdacs.org"}

# gdacs solo tiene 3 niveles, no 4. no hay amarilla en su escala
_ALERTA_A_SEVERIDAD = {"Green": "verde", "Orange": "naranja", "Red": "roja"}

# DR (sequia) queda afuera a proposito: son avisos de una condicion en
# curso que dura meses sin cambiar, no un evento puntual. mezclado con
# temblores e inundaciones reales le resta frescura al feed, que es
# justo lo que se busca con esta historia
_TIPO_GDACS = {"EQ": "sismo", "TC": "ciclon", "FL": "inundacion", "VO": "volcan", "WF": "incendio"}

# el titulo de gdacs siempre arranca con el nivel de alerta en ingles
# ("Orange earthquake...", "Red notification for..."). eso ya se pinta
# aparte como el tag de color de severidad, asi que se saca antes de
# traducir -- si no, el traductor lo arrastra tal cual y arma frases
# raras como "Terremoto de Orange"
_PREFIJOS_ALERTA = ("Green ", "Orange ", "Red ")

_TTL_S = 600  # 10 minutos. no es operativo, no necesita el pulso de 60s del resto
_CACHE: dict = {"data": None, "ts": 0.0}

_MAX_EVENTOS = 10  # una historia no es una tabla. si hay mas, se corta

_TRAD_URL = "https://api.mymemory.translated.net/get?q={}&langpair=en|es"


def _sin_prefijo_alerta(titulo: str) -> str:
    for p in _PREFIJOS_ALERTA:
        if titulo.startswith(p):
            return titulo[len(p):]
    return titulo


def _parsear(xml_text: str) -> list[dict]:
    root = ET.fromstring(xml_text)
    eventos = []
    for item in root.findall(".//item"):
        nivel = (item.findtext("gdacs:alertlevel", namespaces=_NS) or "").strip()
        severidad = _ALERTA_A_SEVERIDAD.get(nivel)
        eventtype = (item.findtext("gdacs:eventtype", namespaces=_NS) or "").strip()
        tipo = _TIPO_GDACS.get(eventtype)
        if severidad is None or severidad == "verde" or tipo is None:
            continue  # ruido: cientos de avisos verdes por semana, o tipos que no cubrimos (sequia)
        eventos.append({
            "id": (item.findtext("guid") or item.findtext("title") or "").strip(),
            "titulo": _sin_prefijo_alerta((item.findtext("title") or "").strip()),
            "pais": (item.findtext("gdacs:country", namespaces=_NS) or "").strip(),
            "tipo": tipo,
            "severidad": severidad,
            "fecha": (item.findtext("pubDate") or "").strip(),
            "url": (item.findtext("link") or "").strip(),
        })
    return eventos[:_MAX_EVENTOS]


def _traducir_lote(textos: list[str]) -> dict[str, str]:
    """traduce una lista de textos ingles->espanol en un solo proceso de
    powershell (fetch_many), no un proceso por texto. best effort: un
    texto que no se pudo traducir simplemente no entra al diccionario;
    quien llama cae de vuelta al texto original en ingles para ese caso"""
    unicos = list(dict.fromkeys(t for t in textos if t))
    if not unicos:
        return {}
    urls = {t: _TRAD_URL.format(urllib.parse.quote(t)) for t in unicos}
    try:
        crudos = fetch_many(list(urls.values()))
    except Exception:
        return {}
    resultado = {}
    for texto, url in urls.items():
        contenido = crudos.get(url)
        if not contenido:
            continue
        try:
            traducido = json.loads(contenido).get("responseData", {}).get("translatedText")
        except (json.JSONDecodeError, AttributeError):
            continue
        # mymemory no devuelve un error http cuando se acaba la cuota
        # gratis del dia: responde 200 con el aviso de cuota metido
        # adentro del mismo campo del texto traducido. sin este chequeo
        # ese aviso en ingles terminaria pintado como si fuera la
        # descripcion real de un sismo
        if traducido and "MYMEMORY WARNING" not in traducido.upper():
            resultado[texto] = traducido
    return resultado


def _traducir_eventos(eventos: list[dict]) -> None:
    """traduce titulo y pais de cada evento a español, en el lugar.
    best effort: cualquier falla aca deja los eventos en ingles en vez
    de propagar la excepcion -- esta historia es la menos critica de
    todas, una traduccion que no llego no debe tumbar nada"""
    if not eventos:
        return
    try:
        pendientes = [e["titulo"] for e in eventos] + [e["pais"] for e in eventos]
        traducciones = _traducir_lote(pendientes)
        for e in eventos:
            e["titulo"] = traducciones.get(e["titulo"], e["titulo"])
            e["pais"] = traducciones.get(e["pais"], e["pais"])
    except Exception:
        pass


def obtener() -> dict:
    """eventos globales relevantes (naranja o rojo), cacheados 10 minutos,
    con titulo y pais ya traducidos al espanol.

    best effort: si gdacs falla o tarda, devuelve una lista vacia con el
    error adentro en vez de propagar la excepcion. esta historia es la
    menos critica de todas, jamas deberia poder tumbar el inicio"""
    ahora = time.time()
    if _CACHE["data"] is not None and ahora - _CACHE["ts"] < _TTL_S:
        return _CACHE["data"]
    try:
        eventos = _parsear(fetch_text(URL))
        _traducir_eventos(eventos)
        resultado = {"eventos": eventos, "error": None}
    except Exception as exc:  # noqa: BLE001 ver docstring
        resultado = {"eventos": [], "error": str(exc)[:150]}
    _CACHE["data"] = resultado
    _CACHE["ts"] = ahora
    return resultado
