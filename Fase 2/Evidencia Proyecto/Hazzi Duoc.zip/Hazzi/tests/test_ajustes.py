"""tests de ajustes.py. umbrales editables del motor.

cada test corre contra una base sqlite temporal propia. ver _aislado.
tocar el hazard.db real desde los tests seria contaminar datos de
verdad."""
from __future__ import annotations

import os
import tempfile
from contextlib import contextmanager
from pathlib import Path

from sqlalchemy import create_engine

from app import ajustes


@contextmanager
def _aislado(**entorno):
    """corre el bloque con una base limpia y opcionalmente variables de entorno.

    restaura engine cache y entorno al salir, pase lo que pase."""
    engine_original = ajustes._engine
    previos = {k: os.environ.get(k) for k in entorno}
    tmp = Path(tempfile.mkdtemp()) / "test_ajustes.db"
    try:
        for k, v in entorno.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        ajustes._engine = create_engine(f"sqlite:///{tmp}", future=True)
        ajustes.invalidar_cache()
        yield
    finally:
        ajustes._engine = engine_original
        for k, v in previos.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        ajustes.invalidar_cache()


def _falla(fn, *args) -> bool:
    try:
        fn(*args)
    except ValueError:
        return True
    return False


# valores por defecto

def test_sin_nada_configurado_usa_los_defaults():
    with _aislado():
        assert ajustes.magnitud_minima() == 3.5
        assert ajustes.ventana_dias() == 7
        assert ajustes.retencion_dias() == 15
        assert ajustes.retencion_dias("sismo") == 7


def test_los_sismos_se_retienen_menos_que_el_resto():
    """la razon de existir de la retencion por tipo. en chile tiembla a diario."""
    with _aislado():
        assert ajustes.retencion_dias("sismo") < ajustes.retencion_dias("incendio")


def test_un_tipo_desconocido_cae_en_la_retencion_general():
    with _aislado():
        assert ajustes.retencion_dias("meteorito") == ajustes.retencion_dias()


# persistencia

def test_lo_guardado_sobrevive_al_reinicio():
    """si no persiste la pantalla de admin es decorativa."""
    with _aislado():
        ajustes.guardar({"magnitud_minima": 5.0})
        ajustes.invalidar_cache()  # simula reiniciar el proceso
        assert ajustes.magnitud_minima() == 5.0


def test_guardar_devuelve_todos_los_valores_vigentes():
    with _aislado():
        vigentes = ajustes.guardar({"ventana_dias": 3})
        assert vigentes["ventana_dias"] == 3
        assert vigentes["magnitud_minima"] == 3.5  # los otros no se tocan


def test_restablecer_vuelve_a_los_defaults():
    with _aislado():
        ajustes.guardar({"magnitud_minima": 6.0, "ventana_dias": 20})
        ajustes.restablecer()
        assert ajustes.magnitud_minima() == 3.5
        assert ajustes.ventana_dias() == 7


def test_guardar_dos_veces_actualiza_en_vez_de_duplicar():
    with _aislado():
        ajustes.guardar({"magnitud_minima": 4.0})
        ajustes.guardar({"magnitud_minima": 4.5})
        assert ajustes.magnitud_minima() == 4.5


# validacion

def test_una_magnitud_fuera_de_rango_se_rechaza():
    with _aislado():
        assert _falla(ajustes.guardar, {"magnitud_minima": 15.0})
        assert _falla(ajustes.guardar, {"magnitud_minima": 0.0})


def test_un_valor_no_numerico_se_rechaza_con_mensaje_claro():
    with _aislado():
        try:
            ajustes.guardar({"magnitud_minima": "muy fuerte"})
        except ValueError as exc:
            assert "Magnitud minima" in str(exc)
        else:
            raise AssertionError("tendria que haber fallado")


def test_una_clave_inventada_se_rechaza():
    with _aislado():
        assert _falla(ajustes.guardar, {"color_favorito": "azul"})


def test_un_guardado_invalido_no_deja_nada_a_medias():
    """todo o nada. si un valor del lote falla no se guarda ninguno."""
    with _aislado():
        assert _falla(ajustes.guardar, {"ventana_dias": 3, "magnitud_minima": 99.0})
        assert ajustes.ventana_dias() == 7  # el valido tampoco entro


def test_los_limites_del_rango_son_validos():
    """inclusivos en ambos extremos. 1.0 y 9.0 tienen que entrar."""
    with _aislado():
        ajustes.guardar({"magnitud_minima": 1.0})
        assert ajustes.magnitud_minima() == 1.0
        ajustes.guardar({"magnitud_minima": 9.0})
        assert ajustes.magnitud_minima() == 9.0


# precedencia. default menor que entorno menor que base

def test_el_entorno_le_gana_al_default():
    with _aislado(AJUSTE_MAGNITUD_MINIMA="4.2"):
        assert ajustes.magnitud_minima() == 4.2


def test_lo_guardado_le_gana_al_entorno():
    with _aislado(AJUSTE_MAGNITUD_MINIMA="4.2"):
        ajustes.guardar({"magnitud_minima": 5.5})
        assert ajustes.magnitud_minima() == 5.5


def test_al_restablecer_se_vuelve_al_entorno_no_al_default():
    with _aislado(AJUSTE_MAGNITUD_MINIMA="4.2"):
        ajustes.guardar({"magnitud_minima": 5.5})
        ajustes.restablecer()
        assert ajustes.magnitud_minima() == 4.2


def test_un_entorno_corrupto_no_voltea_el_sistema():
    """preferible seguir con el default que quedarse sin monitor."""
    with _aislado(AJUSTE_MAGNITUD_MINIMA="cuatro coma dos"):
        assert ajustes.magnitud_minima() == 3.5


def test_un_entorno_fuera_de_rango_se_ignora():
    with _aislado(AJUSTE_VENTANA_DIAS="9999"):
        assert ajustes.ventana_dias() == 7


# declaracion de ajustes. lo que consume la pantalla de admin

def test_cada_ajuste_se_describe_a_si_mismo():
    """el admin arma el formulario desde aca. sin ayuda no hay pantalla util."""
    for d in ajustes.definiciones():
        assert d.etiqueta, f"{d.clave} sin etiqueta"
        assert d.ayuda, f"{d.clave} sin texto de ayuda"
        assert d.minimo < d.maximo, f"{d.clave} con rango imposible"


def test_todos_los_defaults_son_validos_segun_su_propio_rango():
    """un default fuera de su rango seria una trampa silenciosa."""
    for d in ajustes.definiciones():
        assert d.minimo <= d.defecto <= d.maximo, f"{d.clave} tiene default invalido"


def test_la_retencion_se_explica_sin_confundir_con_fecha_de_termino():
    """la retencion cuenta desde que el evento deja de estar vigente.

    no desde su fecha de termino porque pocas fuentes la informan. si
    el texto de ayuda no lo aclara cualquiera lo lee mal."""
    ayuda = {d.clave: d.ayuda for d in ajustes.definiciones()}["retencion_dias"]
    assert "vigente" in ayuda.lower()


def test_no_hay_claves_repetidas():
    claves = [d.clave for d in ajustes.definiciones()]
    assert len(claves) == len(set(claves))
