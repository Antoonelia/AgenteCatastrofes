/* inicio.js. logica de la pagina inicio, el dashboard resumen.
   reutiliza helpers globales de common.js: fetchEvents, SEV_META, RANK_SEV,
   nombreTipo, glyphTipo, fechaVal, _tiempoRel, animateCount, TIPO_META. */

// configuracion de mapeos visuales. una sola fuente de verdad, es dry
const SEV_TAG = {
  roja:     { label: "Alta",  cls: "tag-alta" },
  naranja:  { label: "Media", cls: "tag-media" },
  amarilla: { label: "Baja",  cls: "tag-baja" },
  verde:    { label: "Info",  cls: "tag-seg" },
  info:     { label: "Info",  cls: "tag-seg" },
};
const SEV_ESTADO = {
  roja:     { label: "Activo",     cls: "tag-activo" },
  naranja:  { label: "Activo",     cls: "tag-activo" },
  amarilla: { label: "Monitoreo",  cls: "tag-monit" },
  verde:    { label: "Seguimiento", cls: "tag-seg" },
  info:     { label: "Seguimiento", cls: "tag-seg" },
};
const SEVERAS = ["roja", "naranja", "amarilla"];  // que cuenta como alerta activa
let _datos = null;
let _filtro = "todas";

// utilidades locales
function sevColor(sev) { return (SEV_META[sev] || SEV_META.info).color; }

function horaDe(fecha) {
  const m = (fecha || "").match(/(\d{2}):(\d{2})/);
  return m ? `${m[1]}:${m[2]}` : "—";
}

function iconoCirculo(tipo, sev, size = 22) {
  const c = sevColor(sev);
  const glyph = glyphTipo(tipo).replaceAll("#fff", c);
  return `<span class="row-ic" style="background:${c}1a">
    <svg width="${size}" height="${size}" viewBox="0 0 24 24">${glyph}</svg></span>`;
}

// cuenta cuantas sucursales quedaron en riesgo por un evento, por su
// titulo. revisa todos los eventos vigentes de cada tienda, con
// tiendaTieneEvento en common.js, no solo el mas cercano, para que una
// sucursal con dos o mas alertas encima cuente para cada una de ellas
function sucursalesDe(titulo) {
  return (_datos.tiendas_en_riesgo || []).filter((t) => tiendaTieneEvento(t, titulo)).length;
}

// encabezado. saludo, usa el nombre editable del usuario
function pintarSaludo() {
  const el = document.getElementById("saludo-nombre");
  if (el) el.textContent = getPrimerNombre();
}

// encabezado. fecha y hora
const MESES = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];
const MESES_LARGOS = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto",
  "Septiembre", "Octubre", "Noviembre", "Diciembre"];
function pintarFechaHora() {
  const d = new Date();
  document.getElementById("fecha-hoy").textContent =
    `${d.getDate()} ${MESES[d.getMonth()]} ${d.getFullYear()}`;
  document.getElementById("hora-hoy").textContent =
    `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")} hrs.`;
}

// mini calendario de solo lectura, para ver el mes completo, que cuelga
// del chip de fecha. _calMostrado guarda que mes y anio esta viendo el
// usuario, no necesariamente el actual, ya que puede navegar con las flechas
let _calMostrado = new Date();
function renderCalendario() {
  const anio = _calMostrado.getFullYear();
  const mes = _calMostrado.getMonth();
  document.getElementById("cal-titulo").textContent = `${MESES_LARGOS[mes]} ${anio}`;
  const hoy = new Date();
  const primerDiaSemana = (new Date(anio, mes, 1).getDay() + 6) % 7;   // 0 = lunes
  const diasEnMes = new Date(anio, mes + 1, 0).getDate();
  const diasMesAnterior = new Date(anio, mes, 0).getDate();
  const celdas = [];
  for (let i = primerDiaSemana - 1; i >= 0; i--) celdas.push({ n: diasMesAnterior - i, otro: true });
  for (let d = 1; d <= diasEnMes; d++) {
    celdas.push({ n: d, hoy: d === hoy.getDate() && mes === hoy.getMonth() && anio === hoy.getFullYear() });
  }
  let siguiente = 1;
  while (celdas.length % 7 !== 0) celdas.push({ n: siguiente++, otro: true });
  document.getElementById("cal-dias").innerHTML = celdas.map((c) =>
    `<div class="cal-dia${c.otro ? " cal-otromes" : ""}${c.hoy ? " cal-hoy" : ""}">${c.n}</div>`
  ).join("");
}

// tarjetas de stats
function pintarStats(d) {
  const sev = d.por_severidad || {};
  const eventos = d.eventos || [];
  const severos = eventos.filter((e) => SEVERAS.includes(e.severidad));

  animateCount(document.getElementById("st-alertas"), severos.length);
  animateCount(document.getElementById("st-sucursales"), (d.tiendas_en_riesgo || []).length);
  animateCount(document.getElementById("st-eventos"), contarActivas(eventos));

  const regiones = new Set(severos.map((e) => e.region).filter(Boolean));
  animateCount(document.getElementById("st-regiones"), regiones.size);

  // el card de sucursales afectadas junta el dato crudo con su lectura,
  // porcentaje sobre la red y banda de cobertura, en una sola tarjeta
  const totalT = d.total_tiendas || 0;
  const est = estadoSistema(d.tiendas_en_riesgo, totalT);
  const subSuc = document.getElementById("st-suc-sub");
  if (totalT) {
    subSuc.innerHTML = `${est.cobertura.pct.toFixed(1)}% de ${totalT} \u00b7 Cobertura <span style="color:${est.cobertura.color};font-weight:800">${est.cobertura.label}</span>`;
  } else {
    subSuc.innerHTML = "&nbsp;";
  }

  // card de estado, cruce de severidad x cobertura
  const elE = document.getElementById("st-estado");
  elE.textContent = est.label;
  elE.style.color = est.color;
  elE.style.fontSize = "1.65rem";
  document.getElementById("st-estado-ico").style.background = est.bg;
  document.getElementById("st-estado-svg").setAttribute("stroke", est.color);
  document.getElementById("st-estado-sub").textContent = est.sev
    ? `Alerta ${est.sev} \u00d7 cobertura ${est.cobertura.label.toLowerCase()}`
    : "Sin alertas en sucursales";
}

// panel. alertas activas
function pintarAlertas() {
  const cont = document.getElementById("list-alertas");
  let alertas = (_datos.eventos || []).filter((e) => SEVERAS.includes(e.severidad));
  if (_filtro === "criticas") alertas = alertas.filter((e) => e.severidad === "roja");
  else if (_filtro === "medias") alertas = alertas.filter((e) => ["roja", "naranja"].includes(e.severidad));

  alertas.sort((a, b) => (RANK_SEV[a.severidad] - RANK_SEV[b.severidad]) || (fechaVal(b) - fechaVal(a)));
  alertas = alertas.slice(0, 4);

  if (!alertas.length) {
    cont.innerHTML = '<p class="text-sm text-slate-400 py-6 text-center">Sin alertas activas ahora mismo </p>';
    return;
  }
  // nota de layout: la columna derecha, row-r, solo lleva una linea
  // corta, la hora relativa, misma estructura que usa eventos recientes
  // mas abajo. antes esta columna llevaba ademas "n sucursales
  // afectadas", que podia ser bastante largo. combinado con una fecha
  // larga eso apretaba tanto la columna del titulo que una palabra sin
  // donde partirse se desbordaba y quedaba pisando visualmente la fecha.
  // la nota de sucursales ahora va abajo del titulo y la region, en la
  // columna izquierda, que ya crece libremente, asi ninguna de las dos
  // columnas depende del largo de la otra para verse bien
  cont.innerHTML = alertas.map((e) => {
    const tag = SEV_TAG[e.severidad] || SEV_TAG.info;
    const n = sucursalesDe(e.titulo);
    const nTxt = n > 0
      ? `<div class="row-extra" style="color:${sevColor(e.severidad)}">${n} sucursal${n === 1 ? "" : "es"} afectada${n === 1 ? "" : "s"}</div>`
      : `<div class="row-extra row-extra--muted">Sin sucursales cercanas</div>`;
    return `<a class="row-item" href="/mapa">
      ${iconoCirculo(e.tipo, e.severidad)}
      <div class="row-body">
        <div class="row-t">${escHtml(nombreTipo(e.tipo))} <span class="tag ${tag.cls}">${tag.label}</span></div>
        <div class="row-s">${escHtml(e.region || e.comuna || "Ubicación no especificada")}</div>
        ${nTxt}
      </div>
      <div class="row-r"><div class="row-s font-bold">${_tiempoRel(fechaVal(e))}</div></div>
    </a>`;
  }).join("");
}

// panel. impacto en sucursales, el donut
let _donut = null;
function pintarImpacto() {
  const tiendas = _datos.tiendas_en_riesgo || [];
  const c = { roja: 0, naranja: 0, amarilla: 0 };
  tiendas.forEach((t) => { if (c[t.severidad] !== undefined) c[t.severidad]++; });
  const total = tiendas.length;

  document.getElementById("dn-total").textContent = total;
  document.getElementById("dn-criticas").textContent = c.roja;
  document.getElementById("dn-medias").textContent = c.naranja;
  document.getElementById("dn-leves").textContent = c.amarilla;
  document.getElementById("dn-sin").textContent = 0;

  const box = document.getElementById("box-atencion");
  if (c.roja > 0) {
    box.classList.remove("hidden");
    document.getElementById("box-atencion-txt").innerHTML =
      `<b style="color:#b91c1c">Riesgo ALTO</b> \u2014 ${c.roja} sucursal${c.roja === 1 ? "" : "es"} en rojo requiere${c.roja === 1 ? "" : "n"} atenci\u00f3n inmediata`;
  } else {
    box.classList.add("hidden");
  }

  const data = total > 0 ? [c.roja, c.naranja, c.amarilla] : [0, 0, 1];
  const colors = total > 0 ? ["#dc2626", "#ea580c", "#f59e0b"] : ["#e2e8f0", "#e2e8f0", "#e2e8f0"];
  const cfg = {
    type: "doughnut",
    data: { datasets: [{ data, backgroundColor: colors, borderWidth: 0, cutout: "72%" }] },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { enabled: total > 0 } } },
  };
  if (_donut) { _donut.data = cfg.data; _donut.update(); }
  else _donut = new Chart(document.getElementById("donut-impacto"), cfg);
}

// panel. eventos recientes
function pintarEventos() {
  const cont = document.getElementById("list-eventos");
  const eventos = [...(_datos.eventos || [])].sort((a, b) => fechaVal(b) - fechaVal(a)).slice(0, 4);
  if (!eventos.length) {
    cont.innerHTML = '<p class="text-sm text-slate-400 py-6 text-center">Sin eventos registrados.</p>';
    return;
  }
  cont.innerHTML = eventos.map((e) => {
    const est = SEV_ESTADO[e.severidad] || SEV_ESTADO.info;
    // misma clave que usan eventos.html y mapa.html para identificar la
    // alerta, titulo mas fecha. al llegar al mapa con ?alerta=... abre de
    // una el modal de detalle de este evento, no un mapa generico que
    // hay que buscar
    const clave = (e.titulo || "") + "|" + (e.fecha || "");
    const url = `/mapa?alerta=${encodeURIComponent(clave)}`;
    return `<a class="row-item" href="${url}">
      ${iconoCirculo(e.tipo, e.severidad)}
      <div class="row-body">
        <div class="row-t">${escHtml(nombreTipo(e.tipo))} <span class="tag ${est.cls}">${est.label}</span></div>
        <div class="row-s">${escHtml(e.region || e.comuna || "Ubicación no especificada")}</div>
      </div>
      <div class="row-r"><div class="row-s font-bold">${horaDe(e.fecha)}</div></div>
    </a>`;
  }).join("");
}

// chip de comuna y temperatura.
// la idea original era tomar la ubicacion del navegador, pero la
// politica corporativa de chrome la bloquea para todos los sitios,
// DefaultGeolocationSetting=2, asi que en esta red nunca va a estar
// disponible. en su lugar el usuario elige su comuna de una lista y la
// eleccion queda guardada. la consulta a los servicios externos la hace
// el backend en /api/clima. el front corporativo no sale a internet
// directo, ver fetcher.py
const CLIMA_REFRESCO_MS = 600000;   // 10 minutos, igual que el cache del backend
const CLIMA_COMUNA_KEY = "hz_comuna";
const CLIMA_COMUNA_DEFAULT = "Santiago";

function comunaElegida() {
  return localStorage.getItem(CLIMA_COMUNA_KEY) || CLIMA_COMUNA_DEFAULT;
}

function climaTexto(d) {
  const grados = d.temperatura != null ? `${d.temperatura}\u00b0C` : null;
  // se muestra lo que haya. si una de las dos consultas fallo el chip
  // sigue sirviendo con el dato que si llego
  return [d.lugar, grados].filter(Boolean).join(" \u00b7 ") || null;
}

async function pintarClima() {
  const chip = document.getElementById("chip-clima");
  const texto = document.getElementById("clima-texto");
  if (!chip) return;
  const comuna = comunaElegida();
  try {
    const r = await fetch(`/api/clima?comuna=${encodeURIComponent(comuna)}`);
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    const d = await r.json();
    const t = climaTexto(d);
    if (!t) throw new Error("sin datos");
    texto.textContent = t;
    const detalle = d.descripcion ? `${t} \u00b7 ${d.descripcion}` : t;
    chip.title = `${detalle} \u2014 toca para cambiar de comuna`;
    // el label tiene que decir lo mismo que se ve, o un lector de
    // pantalla seguiria leyendo la invitacion original
    chip.setAttribute("aria-label", `Clima en ${detalle}. Cambiar de comuna`);
  } catch (e) {
    // no se esconde el chip. desaparecer sin decir nada deja al usuario
    // sin saber si la funcion existe o si algo se rompio
    console.warn("No se pudo obtener el clima", e);
    texto.textContent = `${comuna} \u00b7 sin datos`;
    const ayuda = "No se pudo obtener el clima. Toca para reintentar o cambiar de comuna.";
    chip.title = ayuda;
    chip.setAttribute("aria-label", ayuda);
  }
}

// lista de comunas del selector. se pide una sola vez y se reusa. son
// las comunas con tienda, no cambian entre aperturas del menu
let _comunas = null;
async function opcionesComuna() {
  if (_comunas) return _comunas;
  try {
    const r = await fetch("/api/comunas");
    _comunas = r.ok ? await r.json() : [];
  } catch (e) {
    console.warn("No se pudo cargar la lista de comunas", e);
    _comunas = [];
  }
  return _comunas;
}

async function abrirSelectorComuna() {
  const menu = document.getElementById("menu-comuna");
  const lista = document.getElementById("lista-comunas");
  const buscar = document.getElementById("buscar-comuna");
  if (!menu) return;
  const comunas = await opcionesComuna();
  if (!comunas.length) { pintarClima(); return; }   // sin lista, al menos reintenta

  const actual = comunaElegida();
  const pintar = (filtro) => {
    const q = (filtro || "").trim().toLowerCase();
    const visibles = q ? comunas.filter((c) => c.toLowerCase().includes(q)) : comunas;
    lista.innerHTML = visibles.length
      ? visibles.map((c) => `<button type="button" role="option" data-comuna="${escHtml(c)}"
          aria-selected="${c === actual}"
          class="cm w-full text-left px-3 py-1.5 hover:bg-blue-50 ${c === actual ? "font-extrabold" : "font-medium"}"
          style="color:${c === actual ? "#0071dc" : "#334155"}">${escHtml(c)}</button>`).join("")
      : '<p class="px-3 py-2 text-xs text-slate-400">Sin resultados</p>';
  };
  pintar("");
  menu.classList.remove("hidden");
  document.getElementById("chip-clima").setAttribute("aria-expanded", "true");
  buscar.value = "";
  buscar.oninput = () => pintar(buscar.value);
  buscar.focus();
}

function cerrarSelectorComuna() {
  const menu = document.getElementById("menu-comuna");
  if (!menu || menu.classList.contains("hidden")) return;
  menu.classList.add("hidden");
  document.getElementById("chip-clima").setAttribute("aria-expanded", "false");
}

function setupClima() {
  const chip = document.getElementById("chip-clima");
  const menu = document.getElementById("menu-comuna");
  if (!chip || !menu) return;

  chip.addEventListener("click", (e) => {
    e.stopPropagation();
    if (menu.classList.contains("hidden")) abrirSelectorComuna();
    else cerrarSelectorComuna();
  });
  // delegado. la lista se reconstruye entera en cada apertura o
  // filtrado, asi que un listener por boton se perderia al primer tipeo
  menu.addEventListener("click", (e) => {
    e.stopPropagation();
    const opcion = e.target.closest(".cm");
    if (!opcion) return;
    localStorage.setItem(CLIMA_COMUNA_KEY, opcion.dataset.comuna);
    cerrarSelectorComuna();
    pintarClima();
  });
  document.addEventListener("click", cerrarSelectorComuna);
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") cerrarSelectorComuna(); });

  pintarClima();
  setInterval(pintarClima, CLIMA_REFRESCO_MS);
}

// panel. fuentes oficiales. es un catalogo educativo, no un panel de
// estado como el de /admin: aca no importa si una fuente esta caida
// ahora mismo, importa que el publico entienda que existe, que tipo de
// dato trae, y donde verlo de primera mano. los datos salen tal cual de
// SOURCES_META en sources/__init__.py, la misma unica fuente de verdad
// que ya usa /admin, asi que una fuente nueva aparece sola aca tambien
function tarjetaFuenteInfo(f) {
  const meta = TIPO_META[f.tipo] || {};
  const color = meta.color || "#0036CF";
  return `<a class="src-card" style="--accent:${color}" href="${escHtml(f.sitio || "#")}"
      target="_blank" rel="noopener noreferrer"
      aria-label="${escHtml(f.nombre)}: ${escHtml(f.trae || f.cubre)}. Abre el sitio oficial en una pesta\u00f1a nueva">
    <div class="src-top2">
      <span class="src-ic"><svg width="22" height="22" viewBox="0 0 24 24" aria-hidden="true">${glyphTipo(f.tipo)}</svg></span>
      <div style="min-width:0">
        <div class="src-top">
          <span class="src-nombre">${escHtml(f.nombre)}</span>
          <span class="src-chip">${escHtml(meta.corto || f.cubre)}</span>
        </div>
        <div class="src-org">${escHtml(f.organismo)}</div>
      </div>
    </div>
    <p class="src-trae">${escHtml(f.trae || f.cubre)}</p>
    <span class="src-flecha" aria-hidden="true">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"
           stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>
        <polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
      Ir al sitio oficial
    </span>
  </a>`;
}

function pintarFuentes(d) {
  const cont = document.getElementById("grid-fuentes");
  if (!cont) return;
  const fuentes = Object.values(d.fuentes || {});
  cont.innerHTML = fuentes.length
    ? fuentes.map(tarjetaFuenteInfo).join("")
    : '<p class="text-sm text-slate-400 py-6 text-center">No se pudo cargar el cat\u00e1logo de fuentes.</p>';
}

// carga y orquestacion
async function cargar() {
  try {
    _datos = await fetchEvents();
  } catch (e) {
    _datos = { total: 0, por_severidad: {}, eventos: [], tiendas_en_riesgo: [], fuentes: {} };
  }
  pintarStats(_datos);
  pintarAlertas();
  pintarImpacto();
  pintarEventos();
  pintarFuentes(_datos);
  // historias.js. misma data que ya se trajo arriba, sin pedirla de
  // nuevo. se refresca con el resto del inicio, sin timer propio
  if (typeof pintarHistorias === "function") pintarHistorias(_datos);
}

// interacciones
function setupInteracciones() {
  // filtros rapidos
  const btn = document.getElementById("btn-filtros");
  const menu = document.getElementById("menu-filtros");
  btn.addEventListener("click", (e) => {
    e.stopPropagation();
    const abierto = menu.classList.toggle("hidden");
    btn.setAttribute("aria-expanded", String(!abierto));
  });
  document.addEventListener("click", () => menu.classList.add("hidden"));
  menu.querySelectorAll(".ff").forEach((b) => b.addEventListener("click", () => {
    _filtro = b.dataset.filtro;
    menu.classList.add("hidden");
    if (_datos) pintarAlertas();
  }));

  // mini calendario del chip de fecha, de solo lectura, para ver el mes completo
  const calBtn = document.getElementById("btn-calendario");
  const calPanel = document.getElementById("panel-calendario");
  renderCalendario();
  calBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    const abierto = calPanel.classList.toggle("hidden");
    calBtn.setAttribute("aria-expanded", String(!abierto));
    if (!abierto) { _calMostrado = new Date(); renderCalendario(); }   // siempre abre en el mes actual
  });
  calPanel.addEventListener("click", (e) => e.stopPropagation());   // no cerrar al navegar meses
  document.addEventListener("click", () => calPanel.classList.add("hidden"));
  document.getElementById("cal-prev").addEventListener("click", () => {
    _calMostrado.setMonth(_calMostrado.getMonth() - 1);
    renderCalendario();
  });
  document.getElementById("cal-next").addEventListener("click", () => {
    _calMostrado.setMonth(_calMostrado.getMonth() + 1);
    renderCalendario();
  });
  document.getElementById("cal-hoy").addEventListener("click", () => {
    _calMostrado = new Date();
    renderCalendario();
  });

}

document.addEventListener("DOMContentLoaded", () => {
  pintarSaludo();
  pintarFechaHora();
  setInterval(pintarFechaHora, 30000);
  setupInteracciones();
  setupClima();
  cargar();
  setInterval(cargar, 120000);  // refresco suave cada 2 minutos
});

// cuando el usuario edita su nombre en el header, actualiza el saludo al instante
document.addEventListener("nombrecambio", pintarSaludo);
