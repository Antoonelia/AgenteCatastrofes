"""Verificacion E2E: el area real vs el circulo fijo de 30 km, con datos vivos.

Compara, evento por evento, cuantas tiendas quedaban \"en riesgo\" con la regla
vieja (30 km para todo) contra la nueva (el area que declara cada fuente).
"""
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from app.main import _recolectar
from app.stores import _alcance, build_stores, haversine

datos = _recolectar()
tiendas = build_stores()
eventos = datos["eventos"]

print(f"eventos vigentes: {len(eventos)}   tiendas: {len(tiendas)}")
print(f"errores: {datos['errores'] or 'ninguno'}")
print()

con_area = sum(1 for e in eventos if e.get("area"))
print(f"eventos con area propia: {con_area}/{len(eventos)}")
print()

print(f"{'tipo':<14} {'sev':<9} {'area declarada':<52} {'viejo':>6} {'nuevo':>6}")
print("-" * 92)
for e in sorted(eventos, key=lambda x: x["tipo"]):
    a = e.get("area") or {}
    viejo = sum(1 for t in tiendas if haversine(e["lat"], e["lon"], t["lat"], t["lon"]) <= 30)
    nuevo = sum(1 for t in tiendas if _alcance(e, t) is not None)
    if a.get("forma") == "poligono":
        desc = f"poligono ({len(a['anillos'])} zona/s)"
    elif a:
        desc = f"circulo {a['radio_km']} km"
    else:
        desc = "SIN AREA (usa fallback 30 km)"
    marca = "  <-- cambia" if viejo != nuevo else ""
    print(f"{e['tipo']:<14} {e['severidad']:<9} {desc:<52} {viejo:>6} {nuevo:>6}{marca}")

print()
riesgo = datos["tiendas_en_riesgo"]
print(f"tiendas en riesgo (regla nueva): {len(riesgo)}")
for t in riesgo[:10]:
    d = "dentro" if t["distancia_km"] == 0 else f"{t['distancia_km']} km"
    print(f"   [{t.get('clase_riesgo', '?'):<10}] {d:<9} {t['comuna']:<22} {t['evento'][:44]}")
