"""Por que la comuna de Arica trae 705 anillos? Un poligono sano tiene 1 o 2."""
import json
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from app.stores import _load_comunas_cache

cache = _load_comunas_cache()
con_poly = {k: v for k, v in cache.items() if v and v.get("poly")}
print(f"comunas cacheadas: {len(cache)}   con contorno: {len(con_poly)}")
print()

ranking = sorted(con_poly.items(), key=lambda kv: -len(kv[1]["poly"]))
print("Top 8 por cantidad de anillos:")
for nombre, v in ranking[:8]:
    pts = sum(len(a) for a in v["poly"])
    kb = len(json.dumps(v["poly"])) / 1024
    print(f"   {nombre:<24} anillos={len(v['poly']):<5} puntos={pts:<7} {kb:.1f} KB")

peor = ranking[0]
tam = [len(a) for a in peor[1]["poly"]]
print()
print(f"Detalle de '{peor[0]}': anillo mayor={max(tam)} pts, menor={min(tam)} pts")
print(f"   anillos de <=5 puntos: {sum(1 for t in tam if t <= 5)} (islotes/ruido)")
print(f"   peso total del cache: {len(json.dumps(cache)) / 1024:.0f} KB")
