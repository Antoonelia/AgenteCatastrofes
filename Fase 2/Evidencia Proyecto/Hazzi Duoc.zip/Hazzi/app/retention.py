"""reglas de retencion. que eventos siguen siendo relevantes ahora.

filtra del historial y del mapa los eventos que ya ocurrieron y
perdieron importancia segun politicas por tipo. se miden desde la hora
del evento en hora de chile.

sismos: cuanto vive un sismo en eventos vigentes depende de su magnitud
porque el impacto operativo no es lineal. chile es un pais sismico y un
m5 no le hace nada pero un m6.5 si. ver _vida_sismo_horas. los sismos
bajo m4 son sismicidad de fondo y no pasan por vigentes en ningun
momento. van directo al historial.

incendios: apenas la fuente los da por extinguidos dejan de estar
vigentes y pasan al historial que es donde se consulta que paso.

meteorologicos de la dmc: el feed de origen puede quedar desactualizado
varios dias sin avisar. se verifico en vivo que su notebook de
actualizacion a veces no corre a diario. no alcanza con si el feed lo
sigue trayendo sigue vigente. se les pone un techo de horas desde su
ultima actualizacion.

alertas senapred: se vencen por falta de renovacion. si su comuna no
tiene registros recientes la alerta quedo pegada y sale. las verdes que
son preventivas se descartan por completo aparte en main.py y no
llegan ni al historial."""
from __future__ import annotations

import re
from datetime import datetime, timedelta

_FMT = "%d-%m-%Y %H:%M hrs"

# cuanto dura un sismo en eventos vigentes segun su magnitud. se lee
# como hasta esta magnitud exclusive vive estas horas. un m5 se siente
# pero no afecta la operacion. recien sobre m6 hay que sostener la
# atencion por dias. los sismos bajo m4 no entran aca porque nunca
# llegan a vigentes
_VIDA_SISMO_HORAS = (
    (5.1, 12.0),    # 4.0 a 5.0. medio dia
    (6.1, 24.0),    # 5.1 a 6.0. un dia
)
_VIDA_SISMO_MAXIMA = 48.0   # 6.1 en adelante. dos dias
_VIDA_SISMO_SIN_MAGNITUD = 12.0  # no se pudo leer la magnitud. criterio conservador
_MAG_TITULO = re.compile(r"M([\d.]+)")
_MAG_DETALLE = re.compile(r"Magnitud\s+([\d.]+)")

# alerta o alarma dmc. se descarta si su ultima actualizacion tiene mas
# de esto. los avisos meteorologicos chilenos como viento lluvia o
# nieve rara vez duran mas de un par de dias. 72 horas da margen sin
# arrastrar alertas de la semana pasada como si fueran de hoy
_METEO_MAX_H = 72.0

# alerta senapred. sources/senapred.py ya filtra al pedir el feed
# quedandose solo con isActive=true, asi que si un evento llega hasta
# aca es porque la propia senapred sigue diciendo que esta vigente.
# esa bandera es justo lo que su narrativa promete cuando no da fecha
# fija: "vigente hasta que las condiciones lo ameriten". por eso esta
# ventana ya no expira una alerta por la sola antiguedad del ultimo
# aviso -- una inundacion real puede tardar dias en bajar sin que
# senapred emita ni un aviso nuevo, y cortar a las 72h escondia justo
# las rojas mas graves. caso real que este fix corrige: arauco y
# biobio por desborde, 24-09-2026, seguian isActive a las 92-97h y
# hazzi las daba de baja como si hubieran caducado solas.
#
# esto queda entonces como un salvavidas ultimo, no como el corte
# normal: si el feed de senapred se queda atascado y nunca cierra una
# alerta ni la actualiza en 15 dias -- el mismo horizonte que usa el
# historial general del proyecto, ver ajustes.retencion_dias -- recien
# ahi se asume feed roto y se descarta. si senapred declaro hasta
# cuando vale el aviso esa fecha explicita sigue mandando primero y
# esta ventana ni se consulta
_ALERTA_SIN_RENOVACION_H = 24.0 * 15
_FMT_DIA = "%d-%m-%Y"


def _vigente_por_fecha_explicita(vigencia_hasta: str | None, ahora: datetime) -> bool:
    """true si la fuente declaro explicitamente hasta que fecha vale el
    aviso vigente y esa fecha todavia no paso. por ejemplo "fin: 11-09"
    en el boletin dmc citado por senapred. la comparacion es por dia
    porque la fuente no trae hora asi que el aviso vale hasta el final
    del dia declarado no desde las 00:00. false no significa vencida si
    no hay fecha explicita o no se pudo leer. solo quiere decir que hay
    que decidir con la ventana de renovacion de siempre."""
    if not vigencia_hasta:
        return False
    try:
        hasta = datetime.strptime(vigencia_hasta.strip(), _FMT_DIA)
    except ValueError:
        return False
    return ahora.date() <= hasta.date()


def _ahora_cl() -> datetime:
    """hora actual de chile continental como datetime naive para poder comparar."""
    try:
        from zoneinfo import ZoneInfo
        return datetime.now(ZoneInfo("America/Santiago")).replace(tzinfo=None)
    except Exception:  # noqa: BLE001 - fallback si no hay tzdata
        return datetime.utcnow() - timedelta(hours=4)


def _edad_horas(fecha: str | None, ahora: datetime) -> float | None:
    """horas transcurridas desde una fecha dd-mm-yyyy hh:mm hrs. none si no se puede."""
    if not fecha:
        return None
    try:
        dt = datetime.strptime(fecha.strip(), _FMT)
    except ValueError:
        return None
    return (ahora - dt).total_seconds() / 3600.0


def _regiones_lista(e: dict) -> list[str]:
    """las regiones de un evento pueden venir separadas por coma si una
    alerta cruza el limite de dos regiones a la vez. se devuelve como
    lista en minusculas para comparar cada una por separado contra una
    declaracion regional."""
    return [r.strip().lower() for r in (e.get("region") or "").split(",") if r.strip()]


def _magnitud(e: dict) -> float | None:
    m = _MAG_TITULO.match((e.get("titulo") or "").strip())
    if not m:
        m = _MAG_DETALLE.search(e.get("detalle") or "")
    try:
        return float(m.group(1)) if m else None
    except (ValueError, AttributeError):
        return None


def _vida_sismo_horas(mag: float | None) -> float:
    """horas que un sismo sigue vigente segun su magnitud."""
    if mag is None:
        return _VIDA_SISMO_SIN_MAGNITUD
    for tope, horas in _VIDA_SISMO_HORAS:
        if mag < tope:
            return horas
    return _VIDA_SISMO_MAXIMA


def filtrar_eventos(eventos: list[dict], ahora: datetime | None = None) -> list[dict]:
    """aplica las politicas de retencion. devuelve la lista depurada.

    ahora es opcional y solo para tests. permite fijar el presente en
    vez de usar la hora real del sistema asi las fechas de fixture no
    se vuelven viejas solas con el paso de los dias. en produccion
    nunca se pasa. main.py llama filtrar_eventos tal cual sin tocarlo."""
    if ahora is None:
        ahora = _ahora_cl()

    # senapred emite una secuencia de registros por comuna y tema.
    # declara monitoreo baja de nivel cancela. el registro mas reciente
    # de cada combinacion representa su estado actual y los anteriores
    # quedan superados. nos quedamos solo con el mas nuevo por comuna y
    # tema.
    #
    # ojo: agrupar solo por comuna sin el tema fue un bug real. una
    # comuna puede tener dos alertas vigentes de hazards distintos al
    # mismo tiempo por ejemplo una sanitaria y una meteorologica ambas
    # para arica y agrupar solo por comuna las trataba como estados de
    # una misma alerta descartando la mas vieja aunque las dos
    # siguieran activas. tema es la causa declarada como "por viento" o
    # "por alteracion sanitaria" y es estable a traves de los estados
    # de una misma alerta pero distinto entre hazards distintos. por
    # eso separa bien los dos casos
    mas_reciente: dict[tuple[str, str], tuple[dict, float]] = {}
    for e in eventos:
        if e.get("tipo") != "alerta":
            continue
        comuna = (e.get("comuna") or "").strip().lower()
        if not comuna:
            continue
        clave = (comuna, (e.get("tema") or "").strip().lower())
        edad = _edad_horas(e.get("fecha"), ahora)
        if edad is None:
            continue
        prev = mas_reciente.get(clave)
        if prev is None or edad < prev[1]:
            mas_reciente[clave] = (e, edad)
    _keepers = {id(v[0]) for v in mas_reciente.values()}

    # una alerta declarada o modificada a nivel de region completa
    # cuando la comuna es igual a la region deja obsoleta cualquier
    # alerta mas vieja de la misma region y tema que todavia estuviera
    # acotada a una comuna o provincia puntual porque es la misma
    # emergencia y senapred solo le amplio la cobertura.
    #
    # caso real del 24-09-2026: se declara alerta roja para la comuna
    # de arauco por desborde a las 09:24 y despues se modifica
    # cobertura de alerta roja para la region de biobio por desborde a
    # las 14:10. sin este paso retention.py las contaba como dos
    # alertas rojas vigentes porque agrupa por comuna y tema y arauco
    # no es igual a biobio aunque arauco este dentro de biobio. eso
    # inflaba el conteo de alertas activas en uno de mas
    regionales_mas_recientes: dict[tuple[str, str], float] = {}
    for e, edad in mas_reciente.values():
        comuna = (e.get("comuna") or "").strip().lower()
        tema = (e.get("tema") or "").strip().lower()
        regiones = _regiones_lista(e)
        if len(regiones) == 1 and comuna == regiones[0]:
            clave_region = (regiones[0], tema)
            prev = regionales_mas_recientes.get(clave_region)
            if prev is None or edad < prev:
                regionales_mas_recientes[clave_region] = edad

    for e, edad in mas_reciente.values():
        comuna = (e.get("comuna") or "").strip().lower()
        tema = (e.get("tema") or "").strip().lower()
        for region in _regiones_lista(e):
            if comuna == region:
                continue  # es la propia declaracion regional no una puntual
            edad_regional = regionales_mas_recientes.get((region, tema))
            if edad_regional is not None and edad_regional < edad:
                # existe una version mas nueva de la misma emergencia que ya
                # cubre toda la region. esta version puntual quedo superada
                _keepers.discard(id(e))
                break

    vigentes: list[dict] = []
    for e in eventos:
        tipo = e.get("tipo")
        edad = _edad_horas(e.get("fecha"), ahora)

        if tipo == "sismo":
            if edad is not None and edad > _vida_sismo_horas(_magnitud(e)):
                continue  # sismo viejo para su magnitud. fuera

        elif tipo == "incendio":
            if not e.get("activa"):
                continue  # extinguido. ya no es un evento vigente. va al historial

        elif tipo == "meteorologico":
            if edad is not None and edad > _METEO_MAX_H:
                continue  # alerta o alarma dmc sin actualizar hace demasiado. vencida

        elif tipo == "alerta":
            comuna = (e.get("comuna") or "").strip().lower()
            if comuna:
                clave = (comuna, (e.get("tema") or "").strip().lower())
                # solo el registro mas reciente de comuna y tema refleja el
                # estado actual
                if id(e) not in _keepers:
                    continue  # registro superado por uno mas nuevo. fuera
                # si senapred declaro explicitamente hasta cuando vale el
                # aviso y esa fecha no paso ya esta vigente. ni siquiera
                # hace falta mirar la ventana de renovacion que es solo el
                # fallback para cuando no hay fecha explicita
                if _vigente_por_fecha_explicita(e.get("vigencia_hasta"), ahora):
                    pass
                else:
                    edad_ref = mas_reciente[clave][1]
                    if edad_ref is not None and edad_ref > _ALERTA_SIN_RENOVACION_H:
                        continue  # comuna sin actualizacion hace demasiado. vencida
            elif edad is not None and edad > _ALERTA_SIN_RENOVACION_H:
                continue  # alerta sin comuna y muy vieja. vencida

        vigentes.append(e)
    return vigentes
