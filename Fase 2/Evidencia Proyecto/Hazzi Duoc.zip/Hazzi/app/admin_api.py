"""endpoints de administracion. umbrales editables y acciones manuales.

vive aparte de main.py a proposito. main.py ya concentra el ciclo de
recoleccion y la api publica y meterle la superficie de escritura del
admin lo convertiria en un archivo que hace de todo. aca esta todo lo
que modifica estado desde el navegador que es justo lo que conviene
poder auditar de un vistazo y proteger con una sola dependencia.

seguridad: todo lo que escribe pasa por requiere_rol("admin") de
sesiones.py. ya no hay una clave compartida -- cada request de
escritura llega con la sesion de un usuario real (ver usuarios.py y
auth_api.py) y esa misma identidad queda en la bitacora de auditoria.
sin sesion valida no hay escritura posible: falla cerrado, no abierto,
el mismo criterio que ya tenia esto con admin_key, solo que ahora la
identidad detras de cada cambio es trazable a una persona en vez de a
una clave que cualquiera con acceso al deploy puede compartir.

la lectura nunca pide sesion porque el diagnostico no expone nada
sensible y sirve para debug.
"""
from __future__ import annotations

from typing import Callable

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import JSONResponse

from . import ajustes, area, auditoria, instalaciones, sesiones

router = APIRouter(prefix="/api/admin")

_requiere_admin = sesiones.requiere_rol("admin")


# lectura. exige el rol admin: aunque son solo lecturas, ajustes e
# instalaciones (incluidas las excluidas) son datos internos del panel y
# las unicas pantallas que las piden son las de /admin

@router.get("/ajustes", dependencies=[Depends(_requiere_admin)])
def leer_ajustes():
    """umbrales editables mas la tabla de radios de solo lectura para el admin."""
    valores = ajustes.todos()
    return JSONResponse({
        "ajustes": [
            {
                "clave": d.clave,
                "etiqueta": d.etiqueta,
                "ayuda": d.ayuda,
                "unidad": d.unidad,
                "minimo": d.minimo,
                "maximo": d.maximo,
                "defecto": d.defecto,
                "entero": d.tipo is int,
                "valor": valores[d.clave],
                "modificado": valores[d.clave] != d.defecto,
            }
            for d in ajustes.definiciones()
        ],
        "radios": area.tabla_de_radios(),
    })


@router.get("/instalaciones", dependencies=[Depends(_requiere_admin)])
def leer_instalaciones():
    """lista final entre lider correcciones y altas manuales mas el catalogo.

    el catalogo viaja en la misma respuesta para que el formulario se
    arme solo desde el backend. los tipos formatos y estados se
    declaran una vez en instalaciones.py y la pantalla no tiene su
    propia copia."""
    from .stores import build_stores

    try:
        base = build_stores()
    except Exception:  # noqa: BLE001
        base = []  # sin scraping por vpn caida igual se editan las manuales
    return JSONResponse({
        "catalogo": instalaciones.catalogo(),
        "instalaciones": instalaciones.aplicar(base, incluir_excluidas=True),
    })


# escritura. con sesion de rol admin

@router.post("/instalaciones", dependencies=[Depends(_requiere_admin)])
def crear_instalacion(datos: dict, quien: dict = Depends(_requiere_admin)):
    """alta de una instalacion que no existe en el scraping de lider."""
    try:
        instalacion = instalaciones.crear(datos)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    auditoria.registrar(quien, "crear_instalacion", {"iid": instalacion.get("iid")})
    return JSONResponse({"ok": True, "instalacion": instalacion})


@router.put("/instalaciones/{iid}", dependencies=[Depends(_requiere_admin)])
def editar_instalacion(iid: str, datos: dict, quien: dict = Depends(_requiere_admin)):
    """corrige una instalacion. en las de lider guarda solo el parche."""
    from .stores import build_stores

    try:
        base = next(
            (t for t in build_stores()
             if instalaciones.iid_de_tienda(t.get("direccion", ""), t.get("formato", "")) == iid),
            None,
        )
    except Exception:  # noqa: BLE001
        base = None
    try:
        instalacion = instalaciones.guardar_parche(iid, datos, base)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    auditoria.registrar(quien, "editar_instalacion", {"iid": iid})
    return JSONResponse({"ok": True, "instalacion": instalacion})


@router.delete("/instalaciones/{iid}", dependencies=[Depends(_requiere_admin)])
def eliminar_instalacion(iid: str, quien: dict = Depends(_requiere_admin)):
    """borra una manual, o excluye para siempre una de lider."""
    try:
        accion = instalaciones.eliminar(iid)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    auditoria.registrar(quien, "eliminar_instalacion", {"iid": iid, "accion": accion})
    return JSONResponse({"ok": True, "accion": accion})


@router.post("/instalaciones/{iid}/reincluir", dependencies=[Depends(_requiere_admin)])
def reincluir_instalacion(iid: str, quien: dict = Depends(_requiere_admin)):
    """deshace una exclusion. la tienda vuelve a aparecer con sus datos
    de lider en el proximo refresco de la pantalla."""
    try:
        instalaciones.reincluir(iid)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    auditoria.registrar(quien, "reincluir_instalacion", {"iid": iid})
    return JSONResponse({"ok": True})


@router.put("/ajustes", dependencies=[Depends(_requiere_admin)])
def guardar_ajustes(cambios: dict, quien: dict = Depends(_requiere_admin)):
    """guarda umbrales. todo o nada. si uno es invalido no se guarda ninguno."""
    try:
        valores = ajustes.guardar(cambios)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    auditoria.registrar(quien, "guardar_ajustes", {"cambios": cambios})
    return JSONResponse({"ok": True, "valores": valores})


@router.post("/ajustes/restablecer", dependencies=[Depends(_requiere_admin)])
def restablecer_ajustes(quien: dict = Depends(_requiere_admin)):
    """vuelve a los valores por defecto o a los del entorno si hay."""
    valores = ajustes.restablecer()
    auditoria.registrar(quien, "restablecer_ajustes")
    return JSONResponse({"ok": True, "valores": valores})


def montar(app, refrescar: Callable[[], None]) -> None:
    """engancha el router a la app.

    refrescar se inyecta desde main.py que es donde vive el ciclo de
    recoleccion para no importar main desde aca y armar un import
    circular. la accion manual de refresco es la unica que pidio
    antonella. limpiar cache es redundante con esto y purgar historial
    ya ocurre sola por retencion."""

    @router.post("/refrescar", dependencies=[Depends(_requiere_admin)])
    def refrescar_fuentes(quien: dict = Depends(_requiere_admin)):
        """dispara una recoleccion sin esperar al ciclo automatico."""
        refrescar()
        auditoria.registrar(quien, "refrescar_fuentes")
        return JSONResponse({"ok": True, "mensaje": "Recoleccion disparada."})

    app.include_router(router)
