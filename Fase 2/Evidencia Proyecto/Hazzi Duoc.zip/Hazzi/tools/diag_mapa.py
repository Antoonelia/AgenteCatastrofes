"""Captura el stack trace REAL del error de carga del mapa.

El QA reporto \"Cannot access 'TODOS_EVENTOS' before initialization\" pero
pintarTiendas() no usa esa variable, asi que hay que ver el stack de verdad
en vez de deducirlo leyendo el archivo.
"""
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from playwright.sync_api import sync_playwright

URL = "http://127.0.0.1:8000/mapa"

with sync_playwright() as p:
    # El navegador que baja Playwright no se puede descargar tras el proxy
    # corporativo (cdn.playwright.dev no resuelve), asi que se usa el Chrome
    # que ya esta instalado en la maquina.
    #
    # El proxy hay que declararlo explicitamente: Leaflet y Tailwind vienen de
    # CDN y sin el fallan con ERR_NAME_NOT_RESOLVED -> 'L is not defined', que
    # parece un bug de la app pero es del entorno de prueba.
    navegador = p.chromium.launch(
        channel="chrome",
        proxy={"server": "http://sysproxy.wal-mart.com:8080", "bypass": "127.0.0.1,localhost"},
    )
    pagina = navegador.new_page()

    errores = []
    pagina.on("pageerror", lambda e: errores.append(("pageerror", str(e))))
    pagina.on("console", lambda m: errores.append(("console." + m.type, m.text)) if m.type == "error" else None)

    pagina.goto(URL, wait_until="networkidle")
    pagina.wait_for_timeout(4000)

    print(f"errores capturados: {len(errores)}")
    for tipo, texto in errores:
        print(f"\n--- {tipo} ---\n{texto}")

    estado = pagina.evaluate("""() => ({
        leaflet: typeof L !== 'undefined',
        eventos: (typeof TODOS_EVENTOS !== 'undefined' && TODOS_EVENTOS) ? TODOS_EVENTOS.length : 'inaccesible',
        capasArea: (typeof capaRadios !== 'undefined' && capaRadios) ? capaRadios.getLayers().length : 'inaccesible',
        marcadores: (typeof capa !== 'undefined' && capa) ? capa.getLayers().length : 'inaccesible',
        filtros: document.querySelectorAll('#filtros-capas label').length,
        textoFiltros: [...document.querySelectorAll('#filtros-capas label')].map(l => l.textContent.trim()),
        estadoUI: (document.querySelector('#estado') || {}).textContent || '',
    })""")
    print("\n=== estado de la pagina ===")
    for k, v in estado.items():
        print(f"  {k}: {v}")

    pagina.screenshot(path="_basecheck/mapa_estado.png", full_page=True)
    navegador.close()
