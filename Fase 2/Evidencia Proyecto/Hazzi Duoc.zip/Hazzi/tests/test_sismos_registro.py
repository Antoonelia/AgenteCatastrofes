"""regresion de las reglas de sismos. que entra a vigentes, cuanto dura y que se archiva.

origen del 08-09-2026: un m3.9 en sierra gorda, antofagasta, no
aparecia en ninguna parte del sistema. la fuente lo traia y pasaba la
retencion pero lo mataban dos filtros seguidos en main.py
_recolectar. la severidad verde, porque severidad_sismo da amarilla
recien desde m4.0, y el cruce con tiendas, porque la sucursal mas
cercana estaba a 89.9 km con un radio de 30. cualquiera de los dos,
solo, ya lo eliminaba.

reglas vigentes definidas por negocio, chile es sismico y un m5 no
afecta la operacion pero un m6.5 si. bajo m4 no pasa por vigentes y va
directo al historial. entre m4.0 y m5.0 dura 12 horas vigente. entre
m5.1 y m6.0 dura 24 horas vigente. desde m6.1 dura 48 horas vigente. en
el historial los sismos se guardan 7 dias y el resto 15."""
from __future__ import annotations

from datetime import timedelta

from app import ajustes
from app.normalize import (
    UMBRAL_ALERTA_SISMO,
    es_registro,
    marcar_registros,
    severidad_sismo,
)
from app.retention import _ahora_cl, _vida_sismo_horas, filtrar_eventos

# datos reales del csn, tal cual venian el 08-09-2026
SIERRA_GORDA = {
    "source": "CSN", "tipo": "sismo", "titulo": "M3.9 - 61 km al SE de Sierra Gorda",
    "severidad": "verde", "region": "61 km al SE de Sierra Gorda",
    "lat": -23.16, "lon": -68.72, "fecha": "08-09-2026 07:33 hrs",
    "estado": "Reciente (<24h)", "activa": True, "detalle": "Magnitud 3.9 Ml",
}


def _sismo(mag: float, horas_atras: float = 0.0) -> dict:
    """un sismo de magnitud mag ocurrido hace horas_atras horas."""
    cuando = (_ahora_cl() - timedelta(hours=horas_atras)).strftime("%d-%m-%Y %H:%M hrs")
    return {
        "source": "CSN", "tipo": "sismo", "titulo": f"M{mag} - Zona de prueba",
        "severidad": severidad_sismo(mag), "region": "Zona de prueba",
        "fecha": cuando, "activa": True, "detalle": f"Magnitud {mag} Ml",
    }


# que es alerta y que es solo registro

def test_el_umbral_de_alerta_es_m4():
    assert UMBRAL_ALERTA_SISMO == 4.0
    assert severidad_sismo(3.9) == "verde"
    assert severidad_sismo(4.0) == "amarilla"


def test_sismo_menor_queda_marcado_como_registro():
    evento = dict(SIERRA_GORDA)
    marcar_registros([evento])
    assert es_registro(evento), "un M3.9 debe quedar como registro, no como alerta"


def test_sismo_con_alerta_no_se_marca_como_registro():
    evento = _sismo(4.9)
    marcar_registros([evento])
    assert not es_registro(evento), "un M4.9 es alerta real: no debe ser registro"


def test_solo_los_sismos_se_marcan():
    """marcar_registros no debe tocar otros tipos que tambien son verdes."""
    alerta_verde = {"tipo": "alerta", "source": "SENAPRED", "severidad": "verde"}
    marcar_registros([alerta_verde])
    assert not es_registro(alerta_verde)


# vida util en eventos vigentes segun magnitud

def test_tabla_de_vida_util_por_magnitud():
    """los cortes exactos definidos por negocio, incluidos los bordes."""
    assert _vida_sismo_horas(4.0) == 12.0
    assert _vida_sismo_horas(5.0) == 12.0
    assert _vida_sismo_horas(5.1) == 24.0
    assert _vida_sismo_horas(6.0) == 24.0
    assert _vida_sismo_horas(6.1) == 48.0
    assert _vida_sismo_horas(7.8) == 48.0


def test_sismo_moderado_dura_12h_y_no_mas():
    assert filtrar_eventos([_sismo(4.5, horas_atras=11)]), "un M4.5 de 11h sigue vigente"
    assert filtrar_eventos([_sismo(4.5, horas_atras=13)]) == [], "pasadas 12h, fuera"


def test_sismo_fuerte_dura_24h():
    assert filtrar_eventos([_sismo(5.5, horas_atras=20)]), "un M5.5 de 20h sigue vigente"
    assert filtrar_eventos([_sismo(5.5, horas_atras=26)]) == [], "pasadas 24h, fuera"


def test_sismo_mayor_dura_48h():
    """el caso que de verdad importa. un m7 tiene que sostenerse dos dias."""
    assert filtrar_eventos([_sismo(7.0, horas_atras=40)]), "un M7 de 40h sigue vigente"
    assert filtrar_eventos([_sismo(7.0, horas_atras=50)]) == [], "pasadas 48h, fuera"


def test_un_sismo_mayor_dura_mas_que_uno_moderado():
    """la regla de negocio en una linea. a mas magnitud mas tiempo en pantalla."""
    assert _vida_sismo_horas(4.5) < _vida_sismo_horas(5.5) < _vida_sismo_horas(6.5)


def test_sismo_sin_magnitud_legible_no_se_pierde():
    """si no se puede leer la magnitud se usa un criterio conservador de 12 horas."""
    raro = {"source": "CSN", "tipo": "sismo", "titulo": "Sismo sin magnitud",
            "severidad": "info", "fecha": _sismo(5.0)["fecha"], "activa": True}
    assert filtrar_eventos([raro]) == [raro]


# todo sismo deja rastro en el historial

def test_un_sismo_fuerte_pero_viejo_no_queda_vigente_pero_debe_archivarse():
    """el hueco que casi se cuela. la fuente entrega 7 dias de sismos
    pero la vigencia dura entre 12 y 48 horas. un m5.2 de anteayer
    llega ya vencido asi que nunca pasa por vigentes, y el historial
    solo archivaba lo que dejaba de estar vigente. resultado: los
    sismos fuertes no dejaban rastro. ver main.py, que manda al
    historial todo sismo que no quedo vigente."""
    viejo = _sismo(5.2, horas_atras=60)
    assert filtrar_eventos([viejo]) == [], "un M5.2 de 60h ya no es vigente (vida: 24h)"
    # replica el reparto que hace main.py _recolectar
    entrada = [viejo, _sismo(5.2, horas_atras=1)]
    vigentes = filtrar_eventos(entrada)
    ids = {id(e) for e in vigentes}
    al_historial = [e for e in entrada if e.get("tipo") == "sismo" and id(e) not in ids]
    assert al_historial == [viejo], "el sismo vencido tiene que irse al historial"


# retencion en el historial

def test_los_sismos_se_guardan_7_dias_y_el_resto_15():
    assert ajustes.retencion_dias("sismo") == 7
    assert ajustes.retencion_dias("incendio") == 15
    assert ajustes.retencion_dias(None) == 15
    assert ajustes.retencion_dias("sismo") < ajustes.retencion_dias(None)
