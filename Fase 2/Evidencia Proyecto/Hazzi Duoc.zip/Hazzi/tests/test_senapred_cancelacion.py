"""regresion: una alerta senapred no debe seguir mostrandose una vez
que la propia senapred publico su cancelacion.

causa real reportada por antonella el 28-09-2026: hazzi mostraba una
alerta roja de biobio por desborde que ya llevaba 4 dias cerrada.
sources/senapred.py descartaba TODO lo que no viniera con
isActive=true antes de mirarlo, y justo los avisos de cancelacion
vienen con isActive=false -- es su forma normal de marcar que ya
cerraron. asi que el aviso "se cancela alerta roja para la region de
biobio por desborde" nunca se procesaba y la declaracion original
seguia vigente para siempre.

el fix exige lugar Y nivel de severidad iguales entre la alerta y su
cancelacion, no solo el lugar, para no repetir el bug de arica donde
dos alertas de hazards distintos coincidian en la misma comuna al
mismo tiempo (ver retention.py)."""
from __future__ import annotations

from app.normalize import Event
from app.sources.senapred import _cancelaciones, _fue_cancelado

CANCELACION_BIOBIO = {
    "titulo": "Se cancela Alerta Roja para la Región de Biobío por desborde",
    "fechaHora": "2026-09-26T13:23:35.3535-03:00",
    "isActive": False,
    "isDeleted": False,
}

ALERTA_BIOBIO_VIEJA = Event(
    source="SENAPRED", tipo="alerta", titulo="Alerta Roja por desborde",
    severidad="roja", comuna="Biobío", fecha="24-09-2026 14:10 hrs",
)

ALERTA_BIOBIO_AMARILLA_DISTINTA = Event(
    source="SENAPRED", tipo="alerta", titulo="Alerta Amarilla por viento",
    severidad="amarilla", comuna="Biobío", fecha="24-09-2026 14:10 hrs",
)

ALERTA_BIOBIO_ROJA_MAS_NUEVA = Event(
    source="SENAPRED", tipo="alerta", titulo="Nueva Alerta Roja",
    severidad="roja", comuna="Biobío", fecha="27-09-2026 08:00 hrs",
)


def test_la_cancelacion_isactive_false_se_reconoce_por_titulo():
    cancelaciones = _cancelaciones([CANCELACION_BIOBIO])
    assert cancelaciones == [("biobío", "26-09-2026 13:23 hrs", "roja")]


def test_una_alerta_roja_vieja_se_da_de_baja_con_su_cancelacion():
    cancelaciones = _cancelaciones([CANCELACION_BIOBIO])
    assert _fue_cancelado(ALERTA_BIOBIO_VIEJA, cancelaciones) is True


def test_una_alerta_de_otro_nivel_en_la_misma_comuna_no_se_toca():
    """el nivel tiene que coincidir. una amarilla en el mismo lugar no
    se apaga por la cancelacion de la roja. evita repetir el bug de
    arica: dos alertas de hazards distintos en la misma comuna."""
    cancelaciones = _cancelaciones([CANCELACION_BIOBIO])
    assert _fue_cancelado(ALERTA_BIOBIO_AMARILLA_DISTINTA, cancelaciones) is False


def test_una_alerta_mas_nueva_que_la_cancelacion_no_se_toca():
    """si despues de cancelar senapred declaro una alerta roja nueva
    para el mismo lugar, esa es otra emergencia y sigue vigente."""
    cancelaciones = _cancelaciones([CANCELACION_BIOBIO])
    assert _fue_cancelado(ALERTA_BIOBIO_ROJA_MAS_NUEVA, cancelaciones) is False


def test_sin_avisos_de_cancelacion_no_pasa_nada():
    assert _cancelaciones([{"titulo": "Se declara Alerta Roja", "fechaHora": "2026-09-24T14:10:00-03:00", "isActive": True, "isDeleted": False}]) == []


# --- caso real valdivia, 27-09-2026 ---
#
# a diferencia de biobio (una cancelacion "pura", isActive=false, sin
# declarar nada nuevo), senapred a veces cancela y declara otra cosa
# en el mismo aviso, con isActive=true porque el aviso en si sigue
# siendo un item valido: "se cancela alerta roja y declara alerta
# temprana preventiva para la provincia de valdivia por crecida". la
# alerta roja original que cierra fue declarada "por desborde" -- el
# tema-texto no calza (crecida vs desborde). si _fue_cancelado
# comparara por tema en vez de por severidad esto no la habria
# cerrado nunca. el fix es correcto porque nunca mira el tema, solo
# lugar y nivel.
CANCELACION_VALDIVIA_CON_NUEVA_DECLARACION = {
    "titulo": "Se cancela Alerta Roja y declara Alerta Temprana Preventiva para la provincia de Valdivia por crecida",
    "fechaHora": "2026-09-27T22:00:40.4040-03:00",
    "isActive": True,  # ojo: true, no false. distinto del caso biobio
    "isDeleted": False,
}

ALERTA_VALDIVIA_ROJA_POR_DESBORDE = Event(
    source="SENAPRED", tipo="alerta", titulo="Alerta Roja por desborde",
    severidad="roja", comuna="Provincia de Valdivia", fecha="25-09-2026 10:00 hrs",
    tema="por desborde",
)


def test_la_cancelacion_con_isactive_true_tambien_se_reconoce():
    """un aviso que cancela y declara algo nuevo a la vez sigue siendo
    isActive=true porque el item en si es valido. igual debe
    detectarse como cierre de la alerta roja anterior."""
    cancelaciones = _cancelaciones([CANCELACION_VALDIVIA_CON_NUEVA_DECLARACION])
    assert cancelaciones == [("provincia de valdivia", "27-09-2026 22:00 hrs", "roja")]


def test_el_tema_distinto_no_impide_cerrar_la_alerta_vieja():
    """la alerta original es 'por desborde' y la cancelacion habla de
    'por crecida'. el cierre igual aplica porque _fue_cancelado nunca
    compara el tema, solo comuna y severidad."""
    cancelaciones = _cancelaciones([CANCELACION_VALDIVIA_CON_NUEVA_DECLARACION])
    assert _fue_cancelado(ALERTA_VALDIVIA_ROJA_POR_DESBORDE, cancelaciones) is True
