import sys
sys.path.insert(0, ".")
from app.sources import senapred
from app.retention import _ahora_cl, _edad_horas

eventos = [e.to_dict() for e in senapred.fetch_events()]
ahora = _ahora_cl()
print("AHORA CL:", ahora)
print("total crudos:", len(eventos))
for e in eventos:
    edad = _edad_horas(e.get("fecha"), ahora)
    print(
        (e.get("comuna") or "")[:25].ljust(25), "|",
        "tema=", str(e.get("tema"))[:30].ljust(30), "|",
        "fecha=", e.get("fecha"), "|",
        "edad_h=", edad, "|",
        "vig_hasta=", e.get("vigencia_hasta"), "|",
        "sev=", e.get("severidad"),
    )
