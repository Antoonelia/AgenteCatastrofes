"""pruebas http de seguridad: proteccion de pantallas y endpoints de admin,
bloqueo de fuerza bruta en el login, auditoria de intentos fallidos,
logout real y limites del registro publico de visitas.

hablan con la app completa por ASGI (ver _asgi.py), contra una sqlite
temporal compartida (ver _aislar_motor.py).
"""
from __future__ import annotations

import time

from app import auditoria, auth_api, sesiones, usuarios, visitas
from app.limitador import Limitador

from ._aislar_motor import motor_temporal_para
from ._asgi import pedir

RUT = "11111111-1"
CLAVE = "claveSegura123"
PANTALLAS_ADMIN = ["/admin", "/admin/ajustes", "/admin/instalaciones", "/admin/usuarios"]


def _entorno():
    return motor_temporal_para(usuarios, sesiones, auditoria, visitas)


def _sesion_de(rol, rut=RUT):
    creado = usuarios.crear(rut, "Ana Soto", CLAVE, rol)
    return {sesiones.COOKIE_NOMBRE: sesiones.crear(creado["id"])}


def _limpiar_limitadores(*ips, rut=RUT):
    for ip in ips:
        auth_api._LOGIN_POR_IP.limpiar(ip)
        auth_api._VISITA_POR_IP.limpiar(ip)
    auth_api._LOGIN_POR_RUT.limpiar(rut)


# --- pantallas de admin -------------------------------------------------


def test_pantallas_admin_sin_sesion_redirigen_a_portada():
    with _entorno():
        for ruta in PANTALLAS_ADMIN:
            r = pedir("GET", ruta)
            assert r.status == 302, ruta
            assert r.headers["location"] == "/", ruta


def test_pantallas_admin_con_rol_equivocado_redirigen_a_inicio():
    with _entorno():
        solo_usuarios = _sesion_de("admin_usuarios")
        for ruta in ["/admin", "/admin/ajustes", "/admin/instalaciones"]:
            r = pedir("GET", ruta, cookies=solo_usuarios)
            assert (r.status, r.headers["location"]) == (302, "/inicio"), ruta
        solo_admin = _sesion_de("admin", rut="22222222-2")
        r = pedir("GET", "/admin/usuarios", cookies=solo_admin)
        assert (r.status, r.headers["location"]) == (302, "/inicio")


def test_pantallas_admin_con_rol_correcto_se_entregan_sin_cache():
    with _entorno():
        admin = _sesion_de("admin")
        for ruta in ["/admin", "/admin/ajustes", "/admin/instalaciones"]:
            r = pedir("GET", ruta, cookies=admin)
            assert r.status == 200, ruta
            assert r.headers["cache-control"] == "no-store", ruta
        gestor = _sesion_de("admin_usuarios", rut="22222222-2")
        assert pedir("GET", "/admin/usuarios", cookies=gestor).status == 200


def test_static_no_entrega_paginas_html_ni_con_sesion():
    with _entorno():
        admin = _sesion_de("admin")
        for archivo in ["admin.html", "admin-usuarios.html", "admin-ajustes.html", "admin-instalaciones.html"]:
            assert pedir("GET", f"/static/{archivo}").status == 404, archivo
            assert pedir("GET", f"/static/{archivo}", cookies=admin).status == 404, archivo
        assert pedir("GET", "/static/common.js").status == 200


def test_static_no_se_salta_con_trucos_de_nombre_de_windows():
    for ruta in [
        "/static/admin.html.", "/static/admin.html ", "/static/admin.html::$DATA",
        "/static/ADMIN.HTML", "/static/admin.htm", "/static/admin-usuarios.html..",
    ]:
        assert pedir("GET", ruta).status == 404, ruta


def test_pantallas_de_monitoreo_siguen_abiertas():
    for ruta in ["/", "/inicio", "/mapa", "/tiendas", "/eventos", "/historial", "/estadisticas"]:
        assert pedir("GET", ruta).status == 200, ruta


# --- endpoints sensibles ------------------------------------------------


def test_endpoints_sensibles_exigen_sesion_admin():
    with _entorno():
        solo_usuarios = _sesion_de("admin_usuarios")
        for ruta in ["/api/diagnostico", "/api/admin/ajustes", "/api/admin/instalaciones"]:
            assert pedir("GET", ruta).status == 401, ruta
            assert pedir("GET", ruta, cookies=solo_usuarios).status == 403, ruta


def test_bitacora_y_visitas_exigen_admin_usuarios():
    with _entorno():
        admin = _sesion_de("admin")
        for ruta in ["/api/usuarios", "/api/usuarios/auditoria", "/api/usuarios/visitas"]:
            assert pedir("GET", ruta).status == 401, ruta
            assert pedir("GET", ruta, cookies=admin).status == 403, ruta


def test_escrituras_de_admin_exigen_sesion():
    with _entorno():
        assert pedir("PUT", "/api/admin/ajustes", json_body={"magnitud_minima": 4}).status == 401
        assert pedir("POST", "/api/admin/ajustes/restablecer").status == 401
        assert pedir("POST", "/api/admin/refrescar").status == 401


def test_sesion_publica_responde_sin_datos_para_visitante_anonimo():
    with _entorno():
        r = pedir("GET", "/api/auth/yo")
        assert r.status == 200 and r.json() == {"usuario": None}


# --- login: fuerza bruta y auditoria ------------------------------------


def test_login_se_bloquea_tras_5_fallos_y_audita_sin_rut_completo():
    ip = "10.9.0.1"
    with _entorno():
        _limpiar_limitadores(ip)
        usuarios.crear(RUT, "Ana Soto", CLAVE, "admin")
        try:
            for _ in range(5):
                r = pedir("POST", "/api/auth/login", json_body={"rut": RUT, "clave": "mala"}, cliente=(ip, 1))
                assert r.status == 401
            r = pedir("POST", "/api/auth/login", json_body={"rut": RUT, "clave": "mala"}, cliente=(ip, 1))
            assert r.status == 429
            assert int(r.headers["retry-after"]) > 0
            # con la clave correcta tambien: el bloqueo corta el credential stuffing
            r = pedir("POST", "/api/auth/login", json_body={"rut": RUT, "clave": CLAVE}, cliente=(ip, 1))
            assert r.status == 429
            fallidos = [a for a in auditoria.listar() if a["accion"] == "login_fallido"]
            assert len(fallidos) == 5
            assert all(a["rut_enmascarado"] != RUT and "XXX" in a["rut_enmascarado"] for a in fallidos)
        finally:
            _limpiar_limitadores(ip)


def test_login_correcto_reinicia_el_contador_de_fallos():
    ip = "10.9.0.2"
    with _entorno():
        _limpiar_limitadores(ip)
        usuarios.crear(RUT, "Ana Soto", CLAVE, "admin")
        try:
            for _ in range(4):
                assert pedir("POST", "/api/auth/login", json_body={"rut": RUT, "clave": "mala"}, cliente=(ip, 1)).status == 401
            assert pedir("POST", "/api/auth/login", json_body={"rut": RUT, "clave": CLAVE}, cliente=(ip, 1)).status == 200
            for _ in range(4):
                assert pedir("POST", "/api/auth/login", json_body={"rut": RUT, "clave": "mala"}, cliente=(ip, 1)).status == 401
        finally:
            _limpiar_limitadores(ip)


def test_login_con_rut_basura_no_rompe_y_se_audita_enmascarado():
    ip = "10.9.0.3"
    with _entorno():
        _limpiar_limitadores(ip, rut="abc")
        try:
            r = pedir("POST", "/api/auth/login", json_body={"rut": "abc", "clave": "x"}, cliente=(ip, 1))
            assert r.status == 401
            assert auditoria.listar()[0]["accion"] == "login_fallido"
        finally:
            _limpiar_limitadores(ip, rut="abc")


def test_login_rechaza_entradas_gigantes():
    ip = "10.9.0.4"
    with _entorno():
        r = pedir("POST", "/api/auth/login", json_body={"rut": "1" * 50, "clave": "x"}, cliente=(ip, 1))
        assert r.status == 422
        r = pedir("POST", "/api/auth/login", json_body={"rut": RUT, "clave": "x" * 500}, cliente=(ip, 1))
        assert r.status == 422


def test_logout_invalida_el_token_en_el_servidor():
    ip = "10.9.0.5"
    with _entorno():
        _limpiar_limitadores(ip)
        usuarios.crear(RUT, "Ana Soto", CLAVE, "admin")
        try:
            r = pedir("POST", "/api/auth/login", json_body={"rut": RUT, "clave": CLAVE}, cliente=(ip, 1))
            assert r.status == 200
            cookies = {sesiones.COOKIE_NOMBRE: r.cookies_nuevas[sesiones.COOKIE_NOMBRE]}
            assert pedir("GET", "/api/auth/yo", cookies=cookies).json()["usuario"]["nombre"] == "Ana Soto"
            assert pedir("POST", "/api/auth/logout", cookies=cookies).status == 200
            # el token copiado antes del logout ya no sirve
            assert pedir("GET", "/api/auth/yo", cookies=cookies).json() == {"usuario": None}
            assert pedir("GET", "/admin", cookies=cookies).status == 302
        finally:
            _limpiar_limitadores(ip)


# --- visitas de monitoreo (publico) -------------------------------------


def test_visita_acepta_nombre_normal_y_limpia_caracteres_de_control():
    ip = "10.9.1.1"
    with _entorno():
        _limpiar_limitadores(ip)
        try:
            r = pedir("POST", "/api/auth/visita", json_body={"nombre": "Ana\x00 Perez\x1f"}, cliente=(ip, 1))
            assert r.status == 200
            assert visitas.ultimas(5)[0]["nombre"] == "Ana Perez"
        finally:
            _limpiar_limitadores(ip)


def test_visita_rechaza_nombres_demasiado_largos():
    ip = "10.9.1.2"
    with _entorno():
        _limpiar_limitadores(ip)
        try:
            assert pedir("POST", "/api/auth/visita", json_body={"nombre": "A" * 81}, cliente=(ip, 1)).status == 422
            assert visitas.ultimas(5) == []
        finally:
            _limpiar_limitadores(ip)


def test_visita_tiene_techo_por_ip():
    ip = "10.9.1.3"
    with _entorno():
        _limpiar_limitadores(ip)
        try:
            for i in range(30):
                assert pedir("POST", "/api/auth/visita", json_body={"nombre": f"P{i}"}, cliente=(ip, 1)).status == 200
            assert pedir("POST", "/api/auth/visita", json_body={"nombre": "P31"}, cliente=(ip, 1)).status == 429
            # otra ip no se ve afectada
            otra = "10.9.1.4"
            assert pedir("POST", "/api/auth/visita", json_body={"nombre": "Otra"}, cliente=(otra, 1)).status == 200
            _limpiar_limitadores(otra)
        finally:
            _limpiar_limitadores(ip)


# --- cabeceras ------------------------------------------------------------


def test_respuestas_llevan_cabeceras_de_seguridad():
    r = pedir("GET", "/api/auth/yo")
    assert r.headers["x-content-type-options"] == "nosniff"
    assert r.headers["x-frame-options"] == "DENY"
    # no puede ser same-origin: OpenStreetMap bloquea las teselas sin referer
    assert r.headers["referrer-policy"] == "strict-origin-when-cross-origin"


# --- limitador ------------------------------------------------------------


def test_limitador_bloquea_al_llegar_al_maximo_y_se_libera_con_la_ventana():
    lim = Limitador(maximo=2, ventana_s=1)
    assert lim.espera("k") == 0
    lim.registrar("k")
    assert lim.espera("k") == 0
    lim.registrar("k")
    assert lim.espera("k") >= 1
    time.sleep(1.2)
    assert lim.espera("k") == 0


def test_limitador_limpiar_y_claves_independientes():
    lim = Limitador(maximo=1, ventana_s=60)
    lim.registrar("a")
    assert lim.espera("a") > 0
    assert lim.espera("b") == 0
    lim.limpiar("a")
    assert lim.espera("a") == 0
