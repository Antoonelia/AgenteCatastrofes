"""Uso puntual: reemplaza pin-express.png y pin-central.png (Mayorista) por
las fotos reales que Antonella dejo en Downloads, a pedido suyo del
29-09-2026 (mismo dia que el pin de Acuenta, misma tanda de fotos).

Mismo criterio de recorte que ya usa cortar_pines.py y
reemplazar_pin_acuenta.py: bbox por canal alpha mas 14px de margen parejo,
para que el drop-shadow (glow) del pin no quede pegado al borde. Si la foto
no trae transparencia real (alpha siempre 255), getbbox() no recorta nada
util -- en ese caso se usa un fallback simple: recortar el marco casi blanco
alrededor del contenido, asumiendo fondo blanco/casi blanco como el resto de
fotos de fachada que nos ha pasado Antonella.

No se toca acuenta.png ni lider.png, que ya se reemplazaron en sesiones
anteriores.
"""
from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageChops

DOWNLOADS = Path.home() / "Downloads"
LOGOS = Path(__file__).resolve().parent.parent / "app" / "static" / "logos"
PADDING = 14

# (archivo origen en Downloads, archivo destino en app/static/logos)
TRABAJOS = [
    (DOWNLOADS / "express.png", LOGOS / "pin-express.png"),
    (DOWNLOADS / "mayorista.png", LOGOS / "pin-central.png"),
]


def _bbox_contenido(im: Image.Image) -> tuple[int, int, int, int] | None:
    """bbox del contenido real, con fallback para fotos sin canal alpha util."""
    bbox = im.getbbox()
    total = im.width * im.height
    # getbbox() con alpha siempre opaco (255) devuelve el lienzo entero: no
    # sirve de recorte. en ese caso, restar contra un fondo blanco.
    if bbox is None or (bbox == (0, 0, im.width, im.height) and total > 0):
        fondo = Image.new("RGBA", im.size, (255, 255, 255, 255))
        diff = ImageChops.difference(im.convert("RGB"), fondo.convert("RGB"))
        bbox_blanco = diff.getbbox()
        if bbox_blanco:
            return bbox_blanco
    return bbox


def main() -> None:
    for origen, destino in TRABAJOS:
        if not origen.exists():
            print(f"[saltado] no existe {origen}")
            continue
        im = Image.open(origen).convert("RGBA")
        bbox = _bbox_contenido(im)
        if bbox:
            x0, y0, x1, y1 = bbox
            x0 = max(0, x0 - PADDING)
            y0 = max(0, y0 - PADDING)
            x1 = min(im.width, x1 + PADDING)
            y1 = min(im.height, y1 + PADDING)
            im = im.crop((x0, y0, x1, y1))
        im.save(destino)
        print(f"{destino.name}: {im.size} -> {destino}")
        print(f"  pinRatio nuevo: {im.width} / {im.height} = {im.width / im.height:.4f}")


if __name__ == "__main__":
    main()
