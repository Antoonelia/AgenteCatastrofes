"""tests de instalaciones.py. catalogo editable de instalaciones.

cada test corre contra una base sqlite temporal propia, ver _aislado,
igual que test_ajustes.py. tocar el hazard.db real seria contaminar
datos de verdad."""
from __future__ import annotations

import tempfile
from contextlib import contextmanager
from pathlib import Path

from sqlalchemy import create_engine

from app import instalaciones as inst


@contextmanager
def _aislado():
    engine_original = inst._engine
    tmp = Path(tempfile.mkdtemp()) / "test_inst.db"
    try:
        inst._engine = create_engine(f"sqlite:///{tmp}")
        inst.init_schema()
        yield
    finally:
        inst._engine = engine_original


def _tienda(direccion="Av Uno 100", formato="Lider", comuna="Maipu"):
    return {"direccion": direccion, "formato": formato, "comuna": comuna,
            "region": "Metropolitana", "lat": -33.5, "lon": -70.7}


def _manual(**extra):
    base = {"nombre": "CD Lo Aguirre", "tipo": "cd", "comuna": "Pudahuel",
            "direccion": "Camino Lo Boza 100", "lat": -33.45, "lon": -70.85}
    base.update(extra)
    return base


# identidad

def test_el_iid_no_distingue_mayusculas_ni_espacios():
    """lider escribe la misma direccion de formas distintas entre corridas."""
    assert inst.iid_de_tienda("Av Uno 100", "Lider") == inst.iid_de_tienda("  av uno 100 ", "LIDER")


def test_dos_tiendas_del_mismo_centro_comercial_no_colisionan():
    """la direccion sola no es unica. hay dos central mayorista iguales.

    es el mismo motivo por el que dotacion.py combina direccion mas formato."""
    assert inst.iid_de_tienda("Av Uno 100", "Lider") != inst.iid_de_tienda("Av Uno 100", "Express de Lider")


def test_el_iid_sobrevive_a_editar_la_direccion():
    """si el iid cambiara al corregir la direccion el parche quedaria
    huerfano y la tienda perderia su dotacion en silencio."""
    with _aislado():
        iid = inst.iid_de_tienda("Av Uno 100", "Lider")
        inst.guardar_parche(iid, {"direccion": "Av Uno 142 (corregida)"})
        lista = inst.aplicar([_tienda()])
        assert lista[0]["iid"] == iid
        assert lista[0]["direccion"] == "Av Uno 142 (corregida)"


# catalogo

def test_solo_la_sucursal_pide_formato_comercial():
    """una planta productiva no es express."""
    piden = [t.clave for t in inst.TIPOS if t.pide_formato]
    assert piden == ["sucursal"]


def test_los_formatos_calzan_con_los_del_scraping():
    """si no calzaran metaformato en common.js no encontraria su logo."""
    assert "Express de Lider" in inst.FORMATOS
    assert "Superbodega Acuenta" in inst.FORMATOS


def test_no_hay_tipos_ni_estados_repetidos():
    assert len({t.clave for t in inst.TIPOS}) == len(inst.TIPOS)
    assert len({e.clave for e in inst.ESTADOS}) == len(inst.ESTADOS)


# estados y riesgo

def test_una_instalacion_cerrada_no_entra_al_riesgo():
    """alertar por un local vacio es ruido puro."""
    assert inst.cuenta_para_riesgo("cerrada") is False


def test_construccion_y_remodelacion_si_entran_al_riesgo():
    """hay cuadrilla adentro. son justamente las que no estan en lider."""
    assert inst.cuenta_para_riesgo("construccion") is True
    assert inst.cuenta_para_riesgo("remodelacion") is True


def test_un_estado_desconocido_entra_al_riesgo():
    """ante un dato raro conviene alertar de mas, no dejar gente sin monitoreo."""
    assert inst.cuenta_para_riesgo("inventado") is True
    assert inst.cuenta_para_riesgo(None) is True


def test_operativas_filtra_solo_las_cerradas():
    with _aislado():
        creada = inst.crear(_manual(estado="cerrada"))
        lista = inst.aplicar([_tienda()])
        assert len(lista) == 2
        operativas = inst.operativas(lista)
        assert len(operativas) == 1
        assert all(i["iid"] != creada["iid"] for i in operativas)


# parches sobre lider

def test_el_parche_solo_pisa_lo_editado():
    """lo que no se toca se sigue leyendo del scraping para que las
    actualizaciones de lider lleguen igual."""
    with _aislado():
        iid = inst.iid_de_tienda("Av Uno 100", "Lider")
        inst.guardar_parche(iid, {"lat": -33.9, "lon": -70.1})
        fila = inst.aplicar([_tienda()])[0]
        assert fila["lat"] == -33.9
        assert fila["comuna"] == "Maipu"       # sigue viniendo de Lider
        assert fila["nombre"] == "Lider"       # tampoco se toco
        assert fila["editada"] is True
        assert fila["precision"] == "manual"


def test_una_tienda_sin_parche_no_se_marca_como_editada():
    with _aislado():
        fila = inst.aplicar([_tienda()])[0]
        assert fila["editada"] is False
        assert fila["origen"] == inst.ORIGEN_LIDER


def test_corregir_no_duplica_la_tienda():
    with _aislado():
        iid = inst.iid_de_tienda("Av Uno 100", "Lider")
        inst.guardar_parche(iid, {"lat": -33.9})
        assert len(inst.aplicar([_tienda()])) == 1


def test_eliminar_una_tienda_de_lider_la_excluye_para_siempre():
    """pedido de antonella 29-09-2026: eliminar una de lider ya no solo
    descarta la correccion y la devuelve a su dato original -- la saca
    del todo de la lista, aunque el scraping la siga trayendo."""
    with _aislado():
        iid = inst.iid_de_tienda("Av Uno 100", "Lider")
        inst.guardar_parche(iid, {"lat": -33.9})
        assert inst.eliminar(iid) == "excluida"
        assert inst.aplicar([_tienda()]) == []


def test_eliminar_una_tienda_de_lider_sin_parche_previo_tambien_la_excluye():
    """no hace falta haberla editado antes para poder excluirla."""
    with _aislado():
        iid = inst.iid_de_tienda("Av Uno 100", "Lider")
        assert inst.eliminar(iid) == "excluida"
        assert inst.aplicar([_tienda()]) == []


def test_excluida_no_aparece_ni_con_incluir_excluidas_en_el_riesgo():
    """incluir_excluidas es solo para listarla en el admin, operativas()
    igual la deja afuera porque aplicar() por defecto ya la saco."""
    with _aislado():
        iid = inst.iid_de_tienda("Av Uno 100", "Lider")
        inst.eliminar(iid)
        assert inst.aplicar([_tienda()], incluir_excluidas=True)[0]["excluida"] is True
        assert inst.operativas(inst.aplicar([_tienda()])) == []


def test_reincluir_devuelve_la_tienda_a_la_lista_con_su_dato_original():
    with _aislado():
        iid = inst.iid_de_tienda("Av Uno 100", "Lider")
        inst.eliminar(iid)
        inst.reincluir(iid)
        fila = inst.aplicar([_tienda()])[0]
        assert fila["lat"] == -33.5
        assert fila["excluida"] is False


def test_reincluir_algo_que_no_esta_excluido_falla():
    with _aislado():
        try:
            inst.reincluir("l000000000000")
        except ValueError:
            return
        raise AssertionError("reincluir algo no excluido deberia fallar")


def test_un_parche_vacio_se_rechaza():
    with _aislado():
        try:
            inst.guardar_parche("l123", {})
        except ValueError:
            return
        raise AssertionError("un parche sin cambios deberia rechazarse")


def test_guardar_dos_veces_actualiza_en_vez_de_duplicar():
    with _aislado():
        iid = inst.iid_de_tienda("Av Uno 100", "Lider")
        inst.guardar_parche(iid, {"lat": -33.9})
        inst.guardar_parche(iid, {"lat": -33.8})
        assert len(inst.todas()) == 1
        assert inst.aplicar([_tienda()])[0]["lat"] == -33.8


# favoritos

def test_favoritear_una_tienda_de_lider_no_la_marca_como_editada():
    """favorito es una marca personal, no una correccion de dato. no
    debe disparar el chip 'editada' que es para datos corregidos."""
    with _aislado():
        iid = inst.iid_de_tienda("Av Uno 100", "Lider")
        inst.guardar_parche(iid, {"favorito": True})
        fila = inst.aplicar([_tienda()])[0]
        assert fila["favorito"] is True
        assert fila["editada"] is False
        assert fila["nombre"] == "Lider"   # nada mas se toco


def test_una_tienda_sin_parche_no_es_favorita():
    with _aislado():
        assert inst.aplicar([_tienda()])[0]["favorito"] is False


def test_desfavoritear_quita_la_marca():
    with _aislado():
        iid = inst.iid_de_tienda("Av Uno 100", "Lider")
        inst.guardar_parche(iid, {"favorito": True})
        inst.guardar_parche(iid, {"favorito": False})
        assert inst.aplicar([_tienda()])[0]["favorito"] is False


def test_favorito_convive_con_una_correccion_real():
    """favoritear una tienda que ya tenia una correccion de verdad no
    le quita el chip de editada."""
    with _aislado():
        iid = inst.iid_de_tienda("Av Uno 100", "Lider")
        inst.guardar_parche(iid, {"lat": -33.9})
        inst.guardar_parche(iid, {"favorito": True})
        fila = inst.aplicar([_tienda()])[0]
        assert fila["favorito"] is True
        assert fila["editada"] is True
        assert fila["lat"] == -33.9


def test_una_instalacion_manual_puede_marcarse_favorita():
    with _aislado():
        creada = inst.crear(_manual(favorito=True))
        fila = inst.aplicar([])[0]
        assert fila["favorito"] is True
        assert creada["favorito"] is True


# altas manuales

def test_se_crea_una_instalacion_que_lider_no_lista():
    with _aislado():
        creada = inst.crear(_manual())
        assert creada["iid"].startswith("m")
        assert creada["origen"] == inst.ORIGEN_MANUAL
        lista = inst.aplicar([])
        assert len(lista) == 1 and lista[0]["tipo"] == "cd"


def test_una_instalacion_manual_convive_con_las_de_lider():
    with _aislado():
        inst.crear(_manual())
        assert len(inst.aplicar([_tienda()])) == 2


def test_un_cd_no_guarda_formato_comercial():
    with _aislado():
        creada = inst.crear(_manual(tipo="cd", formato="Lider"))
        assert creada["formato"] == ""


def test_una_sucursal_manual_si_guarda_su_formato():
    with _aislado():
        creada = inst.crear(_manual(tipo="sucursal", formato="Express de Lider"))
        assert creada["formato"] == "Express de Lider"


def test_eliminar_una_manual_la_borra_de_verdad():
    with _aislado():
        creada = inst.crear(_manual())
        assert inst.eliminar(creada["iid"]) == "eliminada"
        assert inst.aplicar([]) == []


def test_eliminar_algo_inexistente_avisa():
    with _aislado():
        try:
            inst.eliminar("nada")
        except ValueError:
            return
        raise AssertionError("deberia avisar que no existe")


# validacion

def test_no_se_crea_una_instalacion_sin_ubicacion():
    """sin coordenadas no se puede calcular riesgo. es el dato central."""
    with _aislado():
        try:
            inst.crear({"nombre": "Sin pin", "comuna": "Maipu", "tipo": "cd"})
        except ValueError:
            return
        raise AssertionError("deberia exigir lat/lon")


def test_no_se_crea_sin_nombre_ni_comuna():
    with _aislado():
        for falta in ("nombre", "comuna"):
            datos = _manual()
            datos[falta] = ""
            try:
                inst.crear(datos)
            except ValueError:
                continue
            raise AssertionError(f"deberia exigir {falta}")


def test_un_tipo_inventado_se_rechaza():
    with _aislado():
        try:
            inst.crear(_manual(tipo="castillo"))
        except ValueError:
            return
        raise AssertionError("deberia rechazar un tipo fuera del catalogo")


def test_un_estado_inventado_se_rechaza():
    with _aislado():
        try:
            inst.crear(_manual(estado="hibernando"))
        except ValueError:
            return
        raise AssertionError("deberia rechazar un estado fuera del catalogo")


def test_un_formato_inventado_se_rechaza():
    with _aislado():
        try:
            inst.crear(_manual(tipo="sucursal", formato="Hipermercado Marte"))
        except ValueError:
            return
        raise AssertionError("deberia rechazar un formato fuera del catalogo")


def test_coordenadas_fuera_de_chile_se_rechazan():
    """ataja un pin arrastrado fuera del mapa o lat/lon invertidas."""
    with _aislado():
        for lat, lon in ((40.7, -74.0), (-33.5, 2.3)):
            try:
                inst.crear(_manual(lat=lat, lon=lon))
            except ValueError:
                continue
            raise AssertionError(f"deberia rechazar {lat},{lon}")


def test_una_coordenada_no_numerica_se_rechaza():
    with _aislado():
        try:
            inst.crear(_manual(lat="por ahi"))
        except ValueError:
            return
        raise AssertionError("deberia rechazar texto en lat")


def test_sin_base_de_datos_el_sistema_sigue_operando():
    """si sql falla se opera solo con lider en vez de caerse."""
    engine_original = inst._engine
    try:
        inst._engine = create_engine("sqlite:////ruta/que/no/existe/x.db")
        assert inst.todas() == {}
        assert len(inst.aplicar([_tienda()])) == 1
    finally:
        inst._engine = engine_original
