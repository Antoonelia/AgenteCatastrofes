"""tests del notificador. filtros, deteccion de novedad y cambio, y armado de mensajes.

nada de red aca. lo que se prueba es la logica que decide si se manda
y que se manda, que es donde estan los bugs caros. spam al equipo de
emergencias, o peor, una alerta roja silenciada.

la deteccion de novedad y cambio persiste en sql, ver
notificador_estado.py. cada test que la ejercita corre contra una base
sqlite temporal propia, mismo criterio que test_ajustes.py _aislado.
tocar el hazard.db real desde los tests dejaria sin efecto la
proteccion anti spam real mientras corre la suite."""
from __future__ import annotations

import tempfile
from contextlib import contextmanager
from pathlib import Path

from sqlalchemy import create_engine

from app import notificador as n


def _alerta(clave="e1", severidad="roja"):
    return n.Alerta(clave=clave, titulo="Sismo", cuerpo="3 tiendas", severidad=severidad)


@contextmanager
def _db_aislada():
    """swap del engine de notificador_estado.py a una sqlite temporal,
    restaurado pase lo que pase. ver el docstring del modulo."""
    original = n._estado._engine
    tmp = Path(tempfile.mkdtemp()) / "test_notificador.db"
    n._estado._engine = create_engine(f"sqlite:///{tmp}", future=True)
    try:
        yield
    finally:
        n._estado._engine = original


def _con_consola(fn):
    """corre fn con el proveedor de consola, base temporal y memoria limpia."""
    original = n.NOTIFICADOR
    n.NOTIFICADOR = "consola"
    with _db_aislada():
        n.reiniciar_memoria()
        try:
            return fn()
        finally:
            n.NOTIFICADOR = original


# filtro por severidad


def test_severidad_roja_notifica():
    assert _con_consola(lambda: n.notificar(_alerta(severidad="roja")).enviado)


def test_severidad_verde_no_notifica():
    """una alerta verde no justifica interrumpir a nadie. se ve en el dashboard."""
    assert not _con_consola(lambda: n.notificar(_alerta(severidad="verde")).enviado)


def test_severidad_amarilla_notifica_por_defecto():
    """a pedido explicito. amarilla hacia arriba notifica, solo verde queda afuera."""
    assert _con_consola(lambda: n.notificar(_alerta(severidad="amarilla")).enviado)


def test_forzar_ignora_el_filtro_de_severidad():
    """el boton de prueba tiene que poder mandar cualquier cosa."""
    assert _con_consola(lambda: n.notificar(_alerta(severidad="verde"), forzar=True).enviado)


# novedad y cambio. solo avisa lo nuevo o lo modificado, nunca un recordatorio


def test_la_misma_alerta_no_se_manda_dos_veces():
    """el bucle corre cada 60 segundos. sin esto serian 360 mensajes en 6 horas."""
    def caso():
        primera = n.notificar(_alerta())
        segunda = n.notificar(_alerta())
        return primera.enviado, segunda.enviado

    primera, segunda = _con_consola(caso)
    assert primera
    assert not segunda


def test_sin_cambios_no_se_repite_aunque_pase_mucho_tiempo():
    """a pedido explicito de antonella se saco el recordatorio periodico,
    antes cada 3 horas. si el estado no cambio no se vuelve a avisar sin
    importar cuanto tiempo pase, a diferencia del diseno anterior que lo
    hacia igual pasada la ventana."""
    def caso():
        alerta = _alerta()
        n.notificar(alerta)
        # reescribe el timestamp guardado bien atras en el tiempo, simula
        # que pasaron dias, pero deja el estado (severidad, comunas,
        # tiendas) igual
        n._estado.guardar(alerta.clave, alerta.severidad, [], 0, ahora=0.0)
        return n.notificar(_alerta()).enviado

    assert not _con_consola(caso)


def test_eventos_distintos_se_mandan_por_separado():
    def caso():
        return n.notificar(_alerta(clave="a")).enviado, n.notificar(_alerta(clave="b")).enviado

    a, b = _con_consola(caso)
    assert a and b


def test_escalar_de_amarilla_a_roja_vuelve_a_avisar():
    """mismo evento, severidad nueva. es un cambio real, tiene que sonar de nuevo."""
    def caso():
        amarilla = n.notificar(_alerta(clave="e1", severidad="amarilla"))
        roja = n.notificar(_alerta(clave="e1", severidad="roja"))
        return amarilla.enviado, roja.enviado

    amarilla, roja = _con_consola(caso)
    assert amarilla and roja


def test_agregar_una_comuna_es_una_modificacion():
    """aunque la severidad no cambie, sumar una comuna es una modificacion real."""
    def caso():
        evento = {"id": "m2", "titulo": "Sistema frontal", "severidad": "roja"}
        n.notificar(n.alerta_desde_tiendas(evento, _tiendas("Arica")))
        return n.notificar(n.alerta_desde_tiendas(evento, _tiendas("Arica", "Iquique"))).enviado

    assert _con_consola(caso)


def test_modificacion_avisa_con_la_descripcion_del_cambio_en_el_mensaje():
    """antonella: cuando es una modificacion el mensaje tiene que decir cual fue."""
    capturadas = []

    def _fake(alerta):
        capturadas.append(alerta)
        return n.Resultado(True, "fake")

    original_notificador = n.NOTIFICADOR
    n._PROVEEDORES["fake"] = _fake
    n.NOTIFICADOR = "fake"
    with _db_aislada():
        n.reiniciar_memoria()
        try:
            evento = {"id": "m3", "titulo": "Alerta roja", "severidad": "roja"}
            n.notificar(n.alerta_desde_tiendas(evento, _tiendas("Arica")))
            n.notificar(n.alerta_desde_tiendas(evento, _tiendas("Arica", "Iquique")))
        finally:
            n.NOTIFICADOR = original_notificador
            del n._PROVEEDORES["fake"]

    assert len(capturadas) == 2
    nueva, modificada = capturadas
    assert "[ACTUALIZACION]" not in nueva.titulo
    assert "cambio" not in nueva.datos
    assert "[ACTUALIZACION]" in modificada.titulo
    assert "Tiendas en riesgo" in modificada.datos["cambio"]
    assert modificada.datos["cambio"] in modificada.cuerpo


def test_cambio_en_el_total_global_no_es_un_falso_positivo_de_modificacion():
    """el fingerprint de cambio usa las tiendas propias del evento, ver
    notificador._datos_estado, no el total global deduplicado. si usara
    el total un evento sin cambios propios se veria "modificado" cada
    vez que otro evento simultaneo le sumara tiendas al conteo
    compartido."""
    def caso():
        evento = {"id": "g1", "titulo": "Sismo", "severidad": "roja"}
        primera = n.notificar(n.alerta_desde_tiendas(evento, _tiendas("Arica"), total_en_riesgo=10))
        segunda = n.notificar(n.alerta_desde_tiendas(evento, _tiendas("Arica"), total_en_riesgo=46))
        return primera.enviado, segunda.enviado

    primera, segunda = _con_consola(caso)
    assert primera and not segunda


def test_un_envio_fallido_no_marca_la_alerta_como_avisada():
    """si el canal esta caido el proximo ciclo tiene que reintentar."""
    original = n.NOTIFICADOR
    n.NOTIFICADOR = "whatsapp"  # sin credenciales, falla
    with _db_aislada():
        n.reiniciar_memoria()
        try:
            assert not n.notificar(_alerta()).enviado
            tipo, _ = n._estado.clasificar("e1", "roja", [], 0)
            assert tipo == "nueva"  # nunca se guardo estado. el envio fallo
        finally:
            n.NOTIFICADOR = original


# consolidacion. una alerta por evento, no una por tienda


def _tiendas(*comunas):
    return [{"comuna": c, "cantidad_colaboradores": 10} for c in comunas]


def test_nueve_comunas_son_una_sola_alerta():
    evento = {"id": "s1", "titulo": "Sistema frontal", "severidad": "naranja"}
    alerta = n.alerta_desde_tiendas(evento, _tiendas(*[f"Comuna{i}" for i in range(9)]))
    assert alerta.datos["tiendas"] == 9
    assert alerta.datos["comunas"] == 9
    assert "y 4 mas" in alerta.cuerpo  # muestra 5 y resume el resto


def test_el_conteo_de_personas_se_marca_como_estimado():
    """la dotacion viene de un modelo, no de una nomina. nunca se muestra pelada."""
    evento = {"id": "s2", "titulo": "Incendio", "severidad": "roja"}
    alerta = n.alerta_desde_tiendas(evento, _tiendas("Renca", "Quilicura"))
    assert "~20 asociados" in alerta.cuerpo
    assert "estimado" in alerta.cuerpo


def test_la_clave_es_la_identidad_del_evento_sin_la_severidad():
    """la clave ya no incluye la severidad. una escalada es un cambio
    que se detecta comparando estados, ver
    test_escalar_de_amarilla_a_roja_vuelve_a_avisar en la seccion de
    arriba, no una identidad de aviso distinta."""
    evento = {"id": "s3", "titulo": "Sismo", "severidad": "amarilla"}
    a1 = n.alerta_desde_tiendas(evento, _tiendas("Arica"))
    a2 = n.alerta_desde_tiendas({**evento, "severidad": "roja"}, _tiendas("Arica"))
    assert a1.clave == a2.clave == "s3"


def test_singular_y_plural_de_tiendas():
    evento = {"id": "s4", "titulo": "Sismo", "severidad": "roja"}
    una = n.alerta_desde_tiendas(evento, _tiendas("Arica"))
    varias = n.alerta_desde_tiendas(evento, _tiendas("Arica", "Iquique"))
    assert "1 tienda en riesgo" in una.cuerpo
    assert "2 tiendas en riesgo" in varias.cuerpo


def test_total_en_riesgo_reemplaza_el_conteo_del_evento():
    """el numero que se muestra tiene que ser el total global deduplicado,
    no el de este evento en particular. ver el docstring de
    alerta_desde_tiendas para el caso real que lo motivo, 45 en una
    alerta y 9 en otra con un total de 46."""
    evento = {"id": "s5", "titulo": "Sismo", "severidad": "roja"}
    alerta = n.alerta_desde_tiendas(evento, _tiendas("Arica", "Iquique"), total_en_riesgo=46)
    assert "46 tiendas en riesgo" in alerta.cuerpo
    assert alerta.datos["tiendas"] == 46


def test_sin_total_en_riesgo_usa_el_conteo_del_evento():
    """compatibilidad. sin el parametro nuevo se comporta como siempre."""
    evento = {"id": "s6", "titulo": "Sismo", "severidad": "roja"}
    alerta = n.alerta_desde_tiendas(evento, _tiendas("Arica", "Iquique"))
    assert "2 tiendas en riesgo" in alerta.cuerpo
    assert alerta.datos["tiendas"] == 2


# whatsapp. armado del payload sin red


def test_payload_whatsapp_usa_plantilla():
    """meta no acepta texto libre fuera de la ventana de 24 horas. siempre template."""
    payload = n._payload_whatsapp("56911112222", _alerta())
    assert payload["messaging_product"] == "whatsapp"
    assert payload["type"] == "template"
    assert payload["to"] == "56911112222"
    assert len(payload["template"]["components"][0]["parameters"]) == 3


def test_payload_whatsapp_aplana_saltos_de_linea():
    """meta rechaza el salto de linea dentro de un parametro de plantilla."""
    alerta = n.Alerta(clave="x", titulo="a\nb", cuerpo="c\n\nd", severidad="roja")
    params = n._payload_whatsapp("569", alerta)["template"]["components"][0]["parameters"]
    assert all("\n" not in p["text"] for p in params)


def test_whatsapp_sin_credenciales_falla_limpio():
    """sin configuracion no revienta. devuelve un resultado que explica que falta.

    fuerza las credenciales a vacio explicitamente, no asume que el
    ambiente este limpio. si alguna maquina tiene whatsapp_token
    configurado de verdad, por ejemplo para probar en vivo, este test
    no puede terminar mandando un whatsapp real. bug real: la version
    anterior asumia el ambiente limpio y con teams_webhook_url seteado
    de verdad, el test hermano mandaba un teams real cada vez que
    corria la suite completa. ver el commit siguiente."""
    token, phone = n.WHATSAPP_TOKEN, n.WHATSAPP_PHONE_ID
    n.WHATSAPP_TOKEN, n.WHATSAPP_PHONE_ID = "", ""
    try:
        resultado = n._enviar_whatsapp(_alerta())
    finally:
        n.WHATSAPP_TOKEN, n.WHATSAPP_PHONE_ID = token, phone
    assert not resultado.enviado
    assert "falta" in resultado.detalle


def test_teams_sin_webhook_falla_limpio():
    """mismo cuidado que arriba. fuerza el webhook a vacio, no asume
    que el ambiente no lo tenga configurado. ver el docstring de
    test_whatsapp_sin_credenciales_falla_limpio. este era justo el
    test que mandaba un teams real a produccion cada vez que corria la
    suite en una maquina con teams_webhook_url seteada."""
    original = n.TEAMS_WEBHOOK_URL
    n.TEAMS_WEBHOOK_URL = ""
    try:
        resultado = n._enviar_teams(_alerta())
    finally:
        n.TEAMS_WEBHOOK_URL = original
    assert not resultado.enviado
    assert "falta" in resultado.detalle


# teams. armado de la adaptive card sin red.
#
# motivo del test: el primer intento mandaba un texto plano al webhook
# de workflows (power automate) y el flujo se caia con "attachments is
# null", verificado en vivo contra un flujo real. la plantilla "enviar
# alertas de webhook a un canal" exige una adaptive card real adentro
# de attachments, no texto plano


def test_payload_teams_envuelve_una_adaptive_card_en_attachments():
    payload = n._payload_teams(_alerta(severidad="roja"))
    adjunto = payload["attachments"][0]
    assert adjunto["contentType"] == "application/vnd.microsoft.card.adaptive"
    tarjeta = adjunto["content"]
    assert tarjeta["type"] == "AdaptiveCard"  # justo lo que power automate exige


def test_payload_teams_fondo_de_color_cambia_segun_severidad():
    """el fondo ya no usa el estilo palido de adaptive cards. es un png
    de color solido generado a mano, ver notificador._fondo_color,
    distinto para cada severidad."""
    roja = n._payload_teams(_alerta(severidad="roja"))
    verde = n._payload_teams(_alerta(severidad="verde"))
    fondo_roja = roja["attachments"][0]["content"]["body"][0]["backgroundImage"]["url"]
    fondo_verde = verde["attachments"][0]["content"]["body"][0]["backgroundImage"]["url"]
    assert fondo_roja.startswith("data:image/png;base64,")
    assert fondo_roja != fondo_verde


def test_payload_teams_agrega_boton_solo_si_hay_url():
    alerta = n.Alerta(clave="x", titulo="a", cuerpo="b", severidad="roja", url="https://hazzi/mapa")
    con_url = n._payload_teams(alerta)["attachments"][0]["content"]
    sin_url = n._payload_teams(_alerta())["attachments"][0]["content"]
    assert con_url["actions"][0]["url"] == "https://hazzi/mapa"
    assert "actions" not in sin_url


def test_payload_teams_usa_factset_cuando_hay_datos_de_tiendas():
    """lo que pidio antonella. tiendas comunas y asociados en tabla, no en texto corrido."""
    evento = {"id": "e1", "titulo": "Sismo", "severidad": "roja", "fecha": "24-09-2026 11:00 hrs"}
    tiendas = [{"comuna": "Arica", "cantidad_colaboradores": 10}]
    alerta = n.alerta_desde_tiendas(evento, tiendas)
    tarjeta = n._payload_teams(alerta)["attachments"][0]["content"]
    factsets = [b for b in tarjeta["body"] if b["type"] == "FactSet"]
    assert len(factsets) == 1
    titulos = {f["title"] for f in factsets[0]["facts"]}
    assert {"Tiendas en riesgo", "Comunas", "Fecha"} <= titulos


def test_payload_teams_usa_texto_plano_sin_datos_estructurados():
    """una alerta armada a mano, sin pasar por alerta_desde_tiendas, no pierde info."""
    tarjeta = n._payload_teams(_alerta())["attachments"][0]["content"]
    assert not any(b["type"] == "FactSet" for b in tarjeta["body"])
    assert any(b.get("text") == "3 tiendas" for b in tarjeta["body"])


def test_payload_teams_tiene_triangulo_de_peligro_sin_logo():
    """sin logo de empresa a pedido explicito. mismo simbolo de
    advertencia para todas las severidades porque el color lo
    distingue el fondo, no el icono. un triangulo rojo sobre fondo
    rojo se camuflaba, feedback real."""
    roja = n._payload_teams(_alerta(severidad="roja"))["attachments"][0]["content"]
    amarilla = n._payload_teams(_alerta(severidad="amarilla"))["attachments"][0]["content"]
    columnas_roja = roja["body"][0]["items"][0]["columns"]
    columnas_amarilla = amarilla["body"][0]["items"][0]["columns"]
    assert not any(item["type"] == "Image" for item in columnas_roja[0]["items"])
    assert columnas_roja[0]["items"][0]["text"] == "\u26A0\uFE0F"
    assert columnas_amarilla[0]["items"][0]["text"] == "\u26A0\uFE0F"


def test_payload_teams_titulo_sin_prefijo_de_severidad():
    """el prefijo de severidad del titulo generico sobra en teams. el
    triangulo y el fondo de color ya dicen de que severidad es."""
    evento = {"id": "e7", "titulo": "Sismo", "severidad": "roja"}
    alerta = n.alerta_desde_tiendas(evento, _tiendas("Arica"))
    assert "[ROJA]" in alerta.titulo  # el titulo generico si lo trae, whatsapp y consola lo necesitan
    tarjeta = n._payload_teams(alerta)["attachments"][0]["content"]
    titulo_en_tarjeta = tarjeta["body"][0]["items"][0]["columns"][1]["items"][0]["text"]
    assert "[ROJA]" not in titulo_en_tarjeta
    assert titulo_en_tarjeta == "Sismo"


def test_payload_teams_factset_en_orden_comunas_tiendas_fuente_fecha():
    """orden pedido explicitamente. comunas, tiendas en riesgo, fuente, fecha."""
    evento = {"id": "e8", "titulo": "Sismo", "severidad": "roja", "source": "CSN", "fecha": "24-09-2026 12:00 hrs"}
    alerta = n.alerta_desde_tiendas(evento, _tiendas("Arica"))
    tarjeta = n._payload_teams(alerta)["attachments"][0]["content"]
    factset = next(b for b in tarjeta["body"] if b["type"] == "FactSet")
    assert [f["title"] for f in factset["facts"]] == ["Comunas", "Tiendas en riesgo", "Fuente", "Fecha"]


def test_payload_teams_lista_todas_las_comunas_sin_truncar():
    """a diferencia de cuerpo, que trunca a 5 para whatsapp y consola,
    la tabla de teams muestra todas las comunas, a pedido explicito."""
    comunas = [f"Comuna{i}" for i in range(9)]
    evento = {"id": "e9", "titulo": "Sistema frontal", "severidad": "roja"}
    alerta = n.alerta_desde_tiendas(evento, _tiendas(*comunas))
    tarjeta = n._payload_teams(alerta)["attachments"][0]["content"]
    factset = next(b for b in tarjeta["body"] if b["type"] == "FactSet")
    valor_comunas = next(f["value"] for f in factset["facts"] if f["title"] == "Comunas")
    assert all(c in valor_comunas for c in comunas)
    assert "mas" not in valor_comunas


def test_proveedor_desconocido_cae_en_consola():
    """un typo en la variable de entorno no puede dejar al sistema mudo."""
    original = n.NOTIFICADOR
    n.NOTIFICADOR = "telegramo"  # no existe
    with _db_aislada():
        n.reiniciar_memoria()
        try:
            assert n.notificar(_alerta()).enviado
        finally:
            n.NOTIFICADOR = original


# ampliacion del 25-09-2026. tema fenomeno y area, y avisar cuando algo se resuelve


def test_cambio_de_tema_dispara_un_aviso_aunque_todo_lo_demas_siga_igual():
    def caso():
        evento = {"id": "t1", "titulo": "Alerta", "severidad": "roja", "tema": "por crecida"}
        primera = n.notificar(n.alerta_desde_tiendas(evento, _tiendas("Arica")))
        otro = {**evento, "tema": "por desborde"}
        segunda = n.notificar(n.alerta_desde_tiendas(otro, _tiendas("Arica")))
        return primera.enviado, segunda.enviado

    primera, segunda = _con_consola(caso)
    assert primera and segunda


def test_cambio_de_area_dispara_un_aviso_aunque_las_tiendas_no_cambien():
    def caso():
        evento = {"id": "t2", "titulo": "Alerta", "severidad": "roja", "area": {"anillos": [[[0, 0]]]}}
        primera = n.notificar(n.alerta_desde_tiendas(evento, _tiendas("Arica")))
        otro = {**evento, "area": {"anillos": [[[1, 1]]]}}
        segunda = n.notificar(n.alerta_desde_tiendas(otro, _tiendas("Arica")))
        return primera.enviado, segunda.enviado

    primera, segunda = _con_consola(caso)
    assert primera and segunda


def test_un_sismo_solo_se_avisa_una_vez_aunque_se_revise_la_magnitud():
    """antonella: un sismo ya paso. que el catalogo lo corrija despues,
    otra magnitud, otra area, otra severidad, no es una novedad real,
    es la misma noticia con mas precision. unica excepcion a
    "cualquier cambio notifica"."""
    def caso():
        evento = {"id": "sis1", "titulo": "Sismo", "severidad": "roja", "tipo": "sismo"}
        primera = n.notificar(n.alerta_desde_tiendas(evento, _tiendas("Arica")))
        # se revisa. sube la magnitud, mas tiendas, cambia el area, y hasta
        # escala de severidad. nada de eso debe volver a avisar
        revisado = {**evento, "severidad": "naranja", "area": {"anillos": [[[1, 1]]]}}
        segunda = n.notificar(n.alerta_desde_tiendas(revisado, _tiendas("Arica", "Iquique")))
        return primera.enviado, segunda.enviado

    primera, segunda = _con_consola(caso)
    assert primera and not segunda


def test_sismos_distintos_si_avisan_cada_uno():
    """la excepcion es por clave, es decir el mismo sismo, no "los sismos no avisan"."""
    def caso():
        e1 = n.notificar(n.alerta_desde_tiendas(
            {"id": "sis2", "titulo": "Sismo A", "severidad": "roja", "tipo": "sismo"}, _tiendas("Arica")
        ))
        e2 = n.notificar(n.alerta_desde_tiendas(
            {"id": "sis3", "titulo": "Sismo B", "severidad": "roja", "tipo": "sismo"}, _tiendas("Arica")
        ))
        return e1.enviado, e2.enviado

    e1, e2 = _con_consola(caso)
    assert e1 and e2


def test_un_evento_que_no_es_sismo_si_sigue_avisando_cambios():
    """la excepcion es solo para tipo sismo. todo lo demas conserva la
    regla ancha de severidad comunas tiendas tema fenomeno y area."""
    def caso():
        evento = {"id": "al1", "titulo": "Alerta", "severidad": "roja", "tipo": "alerta"}
        primera = n.notificar(n.alerta_desde_tiendas(evento, _tiendas("Arica")))
        segunda = n.notificar(n.alerta_desde_tiendas({**evento, "severidad": "naranja"}, _tiendas("Arica")))
        return primera.enviado, segunda.enviado

    primera, segunda = _con_consola(caso)
    assert primera and segunda
