"""Prueba end-to-end de la API de instalaciones (requiere server levantado).

No entra en la suite de `python -m tests` porque necesita el servidor
corriendo con ADMIN_KEY, igual que tools/probar_admin.py.

    python tools\\probar_instalaciones.py la-clave
"""
import json
import sys
import urllib.error
import urllib.request

BASE = "http://127.0.0.1:8000"
CLAVE = sys.argv[1] if len(sys.argv) > 1 else "hazzi-local-2026"
ok = fallos = 0


def pedir(metodo, ruta, datos=None, clave=CLAVE):
    req = urllib.request.Request(BASE + ruta, method=metodo)
    if clave:
        req.add_header("X-Admin-Key", clave)
    cuerpo = None
    if datos is not None:
        req.add_header("Content-Type", "application/json")
        cuerpo = json.dumps(datos).encode()
    try:
        with urllib.request.urlopen(req, cuerpo) as r:
            return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")


def check(nombre, condicion, detalle=""):
    global ok, fallos
    if condicion:
        ok += 1
        print(f"  OK   {nombre}")
    else:
        fallos += 1
        print(f"  FAIL {nombre} {detalle}")


print("== lectura ==")
codigo, d = pedir("GET", "/api/admin/instalaciones", clave=None)
check("la lectura no pide clave", codigo == 200, codigo)
check("trae el catalogo", {"tipos", "formatos", "estados"} <= set(d.get("catalogo", {})))
check("solo sucursal pide formato",
      [t["clave"] for t in d["catalogo"]["tipos"] if t["pide_formato"]] == ["sucursal"])
base_total = len(d["instalaciones"])
check("trae instalaciones de Lider", base_total > 0, base_total)
check("cada una tiene iid", all(i.get("iid") for i in d["instalaciones"]))

print("== seguridad ==")
codigo, _ = pedir("POST", "/api/admin/instalaciones", {"nombre": "x"}, clave="mala")
check("crear con clave mala da 401", codigo == 401, codigo)
codigo, _ = pedir("POST", "/api/admin/instalaciones", {"nombre": "x"}, clave=None)
check("crear sin clave da 401", codigo == 401, codigo)

print("== validacion ==")
codigo, d = pedir("POST", "/api/admin/instalaciones",
                  {"nombre": "Sin ubicar", "comuna": "Maipu", "tipo": "cd"})
check("sin coordenadas se rechaza", codigo == 400, codigo)
codigo, d = pedir("POST", "/api/admin/instalaciones",
                  {"nombre": "Mal tipo", "comuna": "Maipu", "tipo": "castillo",
                   "lat": -33.5, "lon": -70.7})
check("tipo inventado se rechaza", codigo == 400, codigo)
codigo, d = pedir("POST", "/api/admin/instalaciones",
                  {"nombre": "Fuera de Chile", "comuna": "Maipu", "tipo": "cd",
                   "lat": 40.7, "lon": -74.0})
check("coordenadas fuera de Chile se rechazan", codigo == 400, codigo)

print("== alta manual ==")
codigo, d = pedir("POST", "/api/admin/instalaciones", {
    "nombre": "CD Lo Aguirre (prueba)", "tipo": "cd", "comuna": "Pudahuel",
    "direccion": "Camino Lo Boza 100", "estado": "construccion",
    "lat": -33.45, "lon": -70.85,
})
check("se crea una instalacion manual", codigo == 200, d)
iid_manual = d.get("instalacion", {}).get("iid", "")
check("el iid manual empieza con m", iid_manual.startswith("m"), iid_manual)
check("un CD no guarda formato comercial", d["instalacion"].get("formato") == "")

codigo, d = pedir("GET", "/api/admin/instalaciones", clave=None)
check("la manual aparece en la lista", len(d["instalaciones"]) == base_total + 1)
nueva = next((i for i in d["instalaciones"] if i["iid"] == iid_manual), None)
check("conserva su estado", nueva and nueva["estado"] == "construccion")

print("== correccion de una tienda de Lider ==")
lider = next(i for i in d["instalaciones"] if i["origen"] == "lider")
iid_lider, lat_orig = lider["iid"], lider["lat"]
codigo, d = pedir("PUT", f"/api/admin/instalaciones/{iid_lider}",
                  {"lat": lat_orig + 0.01, "lon": lider["lon"]})
check("se guarda la correccion", codigo == 200, d)

codigo, d = pedir("GET", "/api/admin/instalaciones", clave=None)
corregida = next(i for i in d["instalaciones"] if i["iid"] == iid_lider)
check("la posicion corregida manda", abs(corregida["lat"] - (lat_orig + 0.01)) < 1e-6)
check("queda marcada como editada", corregida["editada"] is True)
check("la precision pasa a manual", corregida.get("precision") == "manual")
check("conserva el nombre de Lider", corregida["nombre"] == lider["nombre"])
check("no duplica la tienda", len(d["instalaciones"]) == base_total + 1)

print("== las cerradas salen del riesgo ==")
codigo, _ = pedir("PUT", f"/api/admin/instalaciones/{iid_manual}", {"estado": "cerrada"})
check("se puede cerrar una instalacion", codigo == 200)
codigo, d = pedir("GET", "/api/admin/instalaciones", clave=None)
cerrada = next(i for i in d["instalaciones"] if i["iid"] == iid_manual)
check("sigue visible en el admin", cerrada["estado"] == "cerrada")
with urllib.request.urlopen(BASE + "/api/stores") as r:
    stores = json.loads(r.read())
check("desaparece de /api/stores", all(s.get("iid") != iid_manual for s in stores))
check("las operativas siguen en /api/stores", any(s.get("iid") == iid_lider for s in stores))

print("== borrado ==")
codigo, d = pedir("DELETE", f"/api/admin/instalaciones/{iid_lider}")
check("descartar correccion dice 'restaurada'", d.get("accion") == "restaurada", d)
codigo, d = pedir("GET", "/api/admin/instalaciones", clave=None)
vuelta = next(i for i in d["instalaciones"] if i["iid"] == iid_lider)
check("la tienda vuelve a su posicion original", abs(vuelta["lat"] - lat_orig) < 1e-9)
check("ya no figura como editada", vuelta["editada"] is False)

codigo, d = pedir("DELETE", f"/api/admin/instalaciones/{iid_manual}")
check("eliminar una manual dice 'eliminada'", d.get("accion") == "eliminada", d)
codigo, d = pedir("GET", "/api/admin/instalaciones", clave=None)
check("vuelve al total original", len(d["instalaciones"]) == base_total)

codigo, _ = pedir("DELETE", "/api/admin/instalaciones/noexiste")
check("borrar algo inexistente da 404", codigo == 404, codigo)

print(f"\n{ok}/{ok + fallos} checks OK")
sys.exit(1 if fallos else 0)
