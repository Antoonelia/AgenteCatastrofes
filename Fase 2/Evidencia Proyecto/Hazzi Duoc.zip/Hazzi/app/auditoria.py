"""bitacora de auditoria. quien hizo que cambio y cuando.

vive aparte de admin_api.py por la misma razon que ese modulo vive
aparte de main.py: una sola responsabilidad por archivo. registrar()
se llama desde cada endpoint de escritura, nunca se infiere nada aca.

el rut nunca aparece completo. se guarda enmascarado (ver
usuarios.enmascarar_rut) porque un rut es dato sensible y la bitacora
es, por definicion, un registro que se conserva y que mas de una
persona puede llegar a ver. nombre y roles si se guardan en claro: no
son el dato sensible, son los que le dan sentido humano a la fila. una
cuenta puede tener mas de un rol a la vez (ver usuarios.py), por eso
roles se guarda como lista separada por comas, no como un solo valor.

solo lo lee el rol admin_usuarios (ver usuarios_api.py). el admin
operativo no necesita ver quien lo esta auditando a el.
"""
from __future__ import annotations

import json
from datetime import datetime

from sqlalchemy import Column, DateTime, Integer, MetaData, String, Table, Text, insert, select

from .db import engine

_metadata = MetaData()

auditoria_tabla = Table(
    "auditoria",
    _metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("rut_enmascarado", String, nullable=False),
    Column("nombre", String, nullable=False),
    Column("roles", String, nullable=False),
    Column("accion", String, nullable=False),
    Column("detalle", Text, nullable=True),  # json serializable, puede ser none
    Column("creado_en", DateTime, nullable=False),
)


def init_schema() -> None:
    _metadata.create_all(engine)


def registrar(usuario: dict, accion: str, detalle: dict | None = None) -> None:
    """una fila por accion de escritura. nunca lanza: un fallo al auditar
    no debe tumbar la accion que se estaba auditando. se registra el
    problema en consola y se sigue.
    """
    init_schema()
    try:
        with engine.begin() as conn:
            conn.execute(
                insert(auditoria_tabla).values(
                    rut_enmascarado=usuario.get("rut_enmascarado", ""),
                    nombre=usuario.get("nombre", ""),
                    roles=",".join(usuario.get("roles") or []),
                    accion=accion,
                    detalle=json.dumps(detalle, ensure_ascii=False) if detalle is not None else None,
                    creado_en=datetime.now(),
                )
            )
    except Exception as exc:  # noqa: BLE001
        print(f"[auditoria] no se pudo registrar '{accion}': {exc}")


def listar(limite: int = 200) -> list[dict]:
    """ultimas acciones, mas reciente primero."""
    init_schema()
    with engine.begin() as conn:
        filas = conn.execute(
            select(auditoria_tabla).order_by(auditoria_tabla.c.id.desc()).limit(limite)
        ).all()
    resultado = []
    for f in filas:
        detalle = None
        if f.detalle:
            try:
                detalle = json.loads(f.detalle)
            except (ValueError, TypeError):
                detalle = f.detalle
        resultado.append({
            "rut_enmascarado": f.rut_enmascarado,
            "nombre": f.nombre,
            "roles": f.roles.split(",") if f.roles else [],
            "accion": f.accion,
            "detalle": detalle,
            "creado_en": f.creado_en.isoformat(),
        })
    return resultado
