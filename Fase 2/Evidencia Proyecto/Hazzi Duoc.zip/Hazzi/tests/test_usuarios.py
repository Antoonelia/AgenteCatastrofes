"""tests de usuarios.py: ruts, claves y el ciclo de vida de una cuenta.

corre con usuarios.engine parcheado a sqlite temporal, ver
_aislar_motor.py -- mismo motivo que ya documenta _aislar_historial.py:
pisar DATABASE_URL no alcanza una vez que otro test ya importo el
engine real en este proceso.
"""
from __future__ import annotations

from app import usuarios

from ._aislar_motor import motor_temporal_para

RUT_VALIDO_8 = "11111111-1"
RUT_VALIDO_8_B = "22222222-2"
RUT_VALIDO_7 = "1234567-4"


# --- rut: normalizacion, digito verificador, mascara --------------------

def test_normaliza_puntos_espacios_y_mayusculas():
    assert usuarios.normalizar_rut("11.111.111-1") == "11111111-1"
    assert usuarios.normalizar_rut(" 11111111-1 ") == "11111111-1"
    assert usuarios.normalizar_rut("1.234.567-k") == "1234567-K"


def test_valida_el_digito_verificador_correcto():
    assert usuarios.validar_rut(RUT_VALIDO_8)
    assert usuarios.validar_rut(RUT_VALIDO_8_B)
    assert usuarios.validar_rut(RUT_VALIDO_7)


def test_rechaza_digito_verificador_incorrecto():
    assert not usuarios.validar_rut("11111111-5")


def test_rechaza_formato_invalido():
    assert not usuarios.validar_rut("no-es-un-rut")
    assert not usuarios.validar_rut("123-4")       # cuerpo demasiado corto
    assert not usuarios.validar_rut("123456789-1")  # cuerpo demasiado largo


def test_la_mascara_no_expone_el_rut_completo():
    enmascarado = usuarios.enmascarar_rut("11111111-1")
    assert enmascarado != "11111111-1"
    assert enmascarado.startswith("11")
    assert enmascarado.endswith("-1")
    assert "X" in enmascarado


# --- alta de usuarios -----------------------------------------------------

def test_crear_usuario_valido():
    with motor_temporal_para(usuarios):
        creado = usuarios.crear(RUT_VALIDO_8, "Ana Soto", "claveSegura123", "admin")
        assert creado["nombre"] == "Ana Soto"
        assert creado["roles"] == ["admin"]
        assert creado["activo"] is True
        assert "11" in creado["rut_enmascarado"]
        assert "clave" not in creado and "clave_hash" not in creado


def test_crear_rechaza_rut_invalido():
    with motor_temporal_para(usuarios):
        try:
            usuarios.crear("11111111-5", "Ana Soto", "claveSegura123", "admin")
            assert False, "debia lanzar ValueError"
        except ValueError:
            pass


def test_crear_rechaza_rol_desconocido():
    with motor_temporal_para(usuarios):
        try:
            usuarios.crear(RUT_VALIDO_8, "Ana Soto", "claveSegura123", "superusuario")
            assert False, "debia lanzar ValueError"
        except ValueError:
            pass


def test_crear_rechaza_clave_corta():
    with motor_temporal_para(usuarios):
        try:
            usuarios.crear(RUT_VALIDO_8, "Ana Soto", "corta", "admin")
            assert False, "debia lanzar ValueError"
        except ValueError:
            pass


def test_no_se_puede_duplicar_el_mismo_rut():
    with motor_temporal_para(usuarios):
        usuarios.crear(RUT_VALIDO_8, "Ana Soto", "claveSegura123", "admin")
        try:
            usuarios.crear(RUT_VALIDO_8, "Otro Nombre", "otraClave123", "admin_usuarios")
            assert False, "debia lanzar ValueError"
        except ValueError:
            pass


def test_el_mismo_rut_con_distinto_formato_se_detecta_como_duplicado():
    with motor_temporal_para(usuarios):
        usuarios.crear("11.111.111-1", "Ana Soto", "claveSegura123", "admin")
        try:
            usuarios.crear("11111111-1", "Otro Nombre", "otraClave123", "admin")
            assert False, "debia lanzar ValueError: mismo rut, distinto formato"
        except ValueError:
            pass


# --- login ----------------------------------------------------------------

def test_login_con_credenciales_correctas():
    with motor_temporal_para(usuarios):
        usuarios.crear(RUT_VALIDO_8, "Ana Soto", "claveSegura123", "admin")
        sesion = usuarios.verificar_login(RUT_VALIDO_8, "claveSegura123")
        assert sesion is not None
        assert sesion["roles"] == ["admin"]
        assert sesion["nombre"] == "Ana Soto"


def test_login_con_clave_incorrecta_falla():
    with motor_temporal_para(usuarios):
        usuarios.crear(RUT_VALIDO_8, "Ana Soto", "claveSegura123", "admin")
        assert usuarios.verificar_login(RUT_VALIDO_8, "claveIncorrecta") is None


def test_login_con_rut_inexistente_falla():
    with motor_temporal_para(usuarios):
        assert usuarios.verificar_login(RUT_VALIDO_8, "loquesea123") is None


def test_login_de_usuario_desactivado_falla():
    with motor_temporal_para(usuarios):
        creado = usuarios.crear(RUT_VALIDO_8, "Ana Soto", "claveSegura123", "admin")
        usuarios.cambiar_activo(creado["id"], False)
        assert usuarios.verificar_login(RUT_VALIDO_8, "claveSegura123") is None


def test_login_acepta_el_rut_con_puntos_aunque_se_creo_sin_ellos():
    with motor_temporal_para(usuarios):
        usuarios.crear(RUT_VALIDO_8, "Ana Soto", "claveSegura123", "admin")
        sesion = usuarios.verificar_login("11.111.111-1", "claveSegura123")
        assert sesion is not None


# --- administracion de cuentas --------------------------------------------

def test_crear_usuario_con_dos_roles_a_la_vez():
    """una cuenta puede tener admin Y admin_usuarios juntos. decision de
    antonella: una persona puede acceder a los dos paneles, mientras
    quede auditado (ver test_auditoria.py y usuarios_api.py)."""
    with motor_temporal_para(usuarios):
        creado = usuarios.crear(RUT_VALIDO_8, "Ana Soto", "claveSegura123", ["admin", "admin_usuarios"])
        assert sorted(creado["roles"]) == ["admin", "admin_usuarios"]


def test_crear_sin_ningun_rol_se_rechaza():
    with motor_temporal_para(usuarios):
        try:
            usuarios.crear(RUT_VALIDO_8, "Ana Soto", "claveSegura123", [])
            assert False, "debia lanzar ValueError"
        except ValueError:
            pass


def test_agregar_rol_a_una_cuenta_existente():
    with motor_temporal_para(usuarios):
        creado = usuarios.crear(RUT_VALIDO_8, "Ana Soto", "claveSegura123", "admin")
        actualizado = usuarios.agregar_rol(creado["id"], "admin_usuarios")
        assert sorted(actualizado["roles"]) == ["admin", "admin_usuarios"]


def test_agregar_un_rol_que_ya_tiene_es_idempotente():
    with motor_temporal_para(usuarios):
        creado = usuarios.crear(RUT_VALIDO_8, "Ana Soto", "claveSegura123", "admin")
        actualizado = usuarios.agregar_rol(creado["id"], "admin")
        assert actualizado["roles"] == ["admin"]


def test_quitar_rol_cuando_quedan_otros():
    with motor_temporal_para(usuarios):
        creado = usuarios.crear(RUT_VALIDO_8, "Ana Soto", "claveSegura123", ["admin", "admin_usuarios"])
        actualizado = usuarios.quitar_rol(creado["id"], "admin")
        assert actualizado["roles"] == ["admin_usuarios"]


def test_no_se_puede_quitar_el_unico_rol():
    with motor_temporal_para(usuarios):
        creado = usuarios.crear(RUT_VALIDO_8, "Ana Soto", "claveSegura123", "admin")
        try:
            usuarios.quitar_rol(creado["id"], "admin")
            assert False, "debia lanzar ValueError"
        except ValueError:
            pass


def test_cambiar_clave():
    with motor_temporal_para(usuarios):
        creado = usuarios.crear(RUT_VALIDO_8, "Ana Soto", "claveVieja123", "admin")
        usuarios.cambiar_clave(creado["id"], "claveNuevaSegura456")
        assert usuarios.verificar_login(RUT_VALIDO_8, "claveVieja123") is None
        assert usuarios.verificar_login(RUT_VALIDO_8, "claveNuevaSegura456") is not None


def test_cambiar_clave_rechaza_una_clave_corta():
    with motor_temporal_para(usuarios):
        creado = usuarios.crear(RUT_VALIDO_8, "Ana Soto", "claveVieja123", "admin")
        try:
            usuarios.cambiar_clave(creado["id"], "corta")
            assert False, "debia lanzar ValueError"
        except ValueError:
            pass


def test_listar_no_expone_datos_sensibles():
    with motor_temporal_para(usuarios):
        usuarios.crear(RUT_VALIDO_8, "Ana Soto", "claveSegura123", "admin")
        lista = usuarios.listar()
        assert len(lista) == 1
        for campo in ("rut_hash", "clave_hash", "clave_sal"):
            assert campo not in lista[0]
        assert lista[0]["rut_enmascarado"] != "11111111-1"


# --- editar (nombre + roles, el rut nunca cambia) --------------------------

def test_editar_actualiza_nombre_y_roles():
    with motor_temporal_para(usuarios):
        creado = usuarios.crear(RUT_VALIDO_8, "Ana Soto", "claveSegura123", "admin")
        actualizado = usuarios.editar(creado["id"], "Ana Soto Reyes", ["admin", "admin_usuarios"])
        assert actualizado["nombre"] == "Ana Soto Reyes"
        assert sorted(actualizado["roles"]) == ["admin", "admin_usuarios"]
        # el rut enmascarado no se toco
        assert actualizado["rut_enmascarado"] == creado["rut_enmascarado"]


def test_editar_sin_roles_se_rechaza():
    with motor_temporal_para(usuarios):
        creado = usuarios.crear(RUT_VALIDO_8, "Ana Soto", "claveSegura123", "admin")
        try:
            usuarios.editar(creado["id"], "Ana Soto", [])
            assert False, "debia lanzar ValueError"
        except ValueError:
            pass


def test_editar_con_nombre_vacio_se_rechaza():
    with motor_temporal_para(usuarios):
        creado = usuarios.crear(RUT_VALIDO_8, "Ana Soto", "claveSegura123", "admin")
        try:
            usuarios.editar(creado["id"], "   ", ["admin"])
            assert False, "debia lanzar ValueError"
        except ValueError:
            pass


def test_editar_usuario_inexistente_se_rechaza():
    with motor_temporal_para(usuarios):
        try:
            usuarios.editar(9999, "Quien Sea", ["admin"])
            assert False, "debia lanzar ValueError"
        except ValueError:
            pass


# --- eliminar (borrado real, no reversible) --------------------------------

def test_eliminar_borra_la_cuenta_por_completo():
    with motor_temporal_para(usuarios):
        creado = usuarios.crear(RUT_VALIDO_8, "Ana Soto", "claveSegura123", "admin")
        borrado = usuarios.eliminar(creado["id"])
        assert borrado["nombre"] == "Ana Soto"
        assert usuarios.listar() == []
        assert usuarios.verificar_login(RUT_VALIDO_8, "claveSegura123") is None


def test_eliminar_usuario_inexistente_se_rechaza():
    with motor_temporal_para(usuarios):
        try:
            usuarios.eliminar(9999)
            assert False, "debia lanzar ValueError"
        except ValueError:
            pass


def test_no_se_puede_eliminar_la_unica_cuenta_con_admin_usuarios():
    with motor_temporal_para(usuarios):
        unica = usuarios.crear(RUT_VALIDO_8, "Ana Soto", "claveSegura123", "admin_usuarios")
        try:
            usuarios.eliminar(unica["id"])
            assert False, "debia lanzar ValueError"
        except ValueError:
            pass


def test_se_puede_eliminar_admin_usuarios_si_hay_otra_cuenta_con_ese_rol():
    with motor_temporal_para(usuarios):
        uno = usuarios.crear(RUT_VALIDO_8, "Ana Soto", "claveSegura123", "admin_usuarios")
        usuarios.crear(RUT_VALIDO_8_B, "Beto Diaz", "claveSegura123", "admin_usuarios")
        usuarios.eliminar(uno["id"])  # no debe lanzar
        assert len(usuarios.listar()) == 1


def test_eliminar_una_cuenta_solo_admin_no_exige_otra_cuenta():
    """la proteccion es especifica del rol admin_usuarios (el unico que
    puede gestionar cuentas). una cuenta que solo tiene 'admin' se puede
    eliminar sin ninguna otra condicion."""
    with motor_temporal_para(usuarios):
        creado = usuarios.crear(RUT_VALIDO_8, "Ana Soto", "claveSegura123", "admin")
        usuarios.eliminar(creado["id"])  # no debe lanzar
        assert usuarios.listar() == []
