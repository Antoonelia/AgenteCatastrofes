"""dmc. direccion meteorologica. alertas y alarmas por arcgis publico.

ojo con esto: hubo un bug real corregido el 23-09-2026. el codigo antes
solo miraba un feed pensando que ahi venian los tres niveles aviso
alerta y alarma pero la dmc en realidad publica cada nivel en un
featureserver separado. avisos_zonas trae solo aviso que es informativo
y se descarta. alertas_area trae solo alerta. alarmas_vista trae solo
alarma. antes de esto hazzi nunca alcanzaba a ver una alerta ni una
alarma real sin importar que tan grave fuera el clima.

los tres feeds comparten casi los mismos campos asi que se procesan con
la misma logica. lo que cambia es el formato de fecha. avisos y alarmas
la mandan como texto y alertas como epoch en milisegundos asi que
_fecha detecta el tipo de dato en vez de asumir uno fijo.

la dmc publica el poligono real de cada zona bajo aviso asi que se usa
ese poligono tal cual en vez de inventar un circulo generico alrededor
del centroide como se hacia antes."""
from __future__ import annotations

from .. import area as area_mod
from .. import fenomeno as fenomeno_mod
from ..fetcher import json_de
from ..normalize import Event, ms_to_str, num, texto_fecha_cl
from ..regiones_cl import region_desde_texto

_QUERY = (
    "?where=1=1&outFields=*&returnCentroid=true&returnGeometry=true"
    "&maxAllowableOffset=0.02&outSR=4326&f=json"
)
# maxAllowableOffset simplifica los poligonos del lado del servidor. sin
# esto la respuesta pesa varias decenas de kb por el detalle de la costa
# que a escala de mapa nacional no se nota

_BASE = "https://services3.arcgis.com/CNzkI2T3GmfwkaAR/ArcGIS/rest/services/"

URL_AVISOS = _BASE + "Meteochile_AAA_Avisos_Zonas/FeatureServer/0/query" + _QUERY
URL_ALERTAS = _BASE + "Meteochile_AAA_Alertas_Area/FeatureServer/0/query" + _QUERY
URL_ALARMAS = _BASE + "Meteochile_AAA_Alarmas_Vista/FeatureServer/0/query" + _QUERY

_SEVERIDAD = {  # alerta es amarilla y alarma es roja. aviso no entra a
    # proposito. se filtra antes de convertirse en evento porque es el
    # equivalente meteorologico de una alerta verde. informativo y no
    # accionable
    "alerta": "amarilla",
    "alarma": "roja",
}


def _pick(attrs: dict, prefix: str):
    pl = prefix.lower()
    for k, v in attrs.items():
        if k.lower().startswith(pl):
            return v
    return None


def _fecha(attrs: dict) -> str | None:
    """alertas manda la fecha como epoch en milisegundos numero. avisos y
    alarmas la mandan como texto. se detecta por el tipo de dato en vez de
    asumir un formato fijo asi que si la dmc cambia de opinion en algun
    feed esto no se rompe en silencio."""
    val = _pick(attrs, "fecha_actu")
    if isinstance(val, (int, float)):
        return ms_to_str(val)
    return texto_fecha_cl(val)


def _area_zona(rings: list | None, tipo_aviso: str, zona: str) -> dict | None:
    """area de una zona bajo aviso dmc. el poligono oficial que ella misma
    dibuja.

    en alarma que es severidad roja se agrega ademas un margen de
    cercania marcado aparte como potencial. mismo criterio que usa
    senapred para sus alertas rojas. una alarma es el nivel mas grave que
    emite la dmc y conviene que las tiendas justo al otro lado del limite
    se preparen sin declararlas afectadas todavia. una alerta amarilla
    sigue siendo estricta y solo cuenta lo que cae literalmente adentro
    del poligono."""
    area = area_mod.por_anillos(
        rings, f"Zona bajo {tipo_aviso} DMC" + (f" ({zona})" if zona else "")
    )
    if area and _SEVERIDAD.get(tipo_aviso) == "roja":
        return area_mod.con_margen(
            area,
            area_mod.MARGEN_ALERTA_ROJA_KM,
            "Cercania a una zona en Alarma DMC: aun no declarada afectada, pero podria serlo",
        )
    return area


def urls_requeridas() -> list[str]:
    """urls que necesita esta fuente. son tres no una porque cada nivel
    vive en un featureserver separado."""
    return [URL_AVISOS, URL_ALERTAS, URL_ALARMAS]


def _procesar_features(features: list[dict], eventos: list[Event]) -> None:
    for feat in features:
        a = feat.get("attributes", {})
        centroid = feat.get("centroid") or {}
        tipo_aviso = (str(_pick(a, "tipo") or "")).strip().lower()
        if tipo_aviso not in _SEVERIDAD:
            continue  # aviso o tipo desconocido. no es accionable se descarta
        titulo = _pick(a, "titulo") or ""
        fenomeno_raw = _pick(a, "fenomeno") or _pick(a, "fen") or "Evento meteorologico"
        zona = _pick(a, "zona_real") or _pick(a, "textoZona") or ""
        area = _area_zona((feat.get("geometry") or {}).get("rings"), tipo_aviso, zona)
        eventos.append(
            Event(
                source="DMC",
                tipo="meteorologico",
                titulo=f"{fenomeno_raw} ({tipo_aviso.capitalize()})",
                severidad=_SEVERIDAD[tipo_aviso],
                region=region_desde_texto(titulo),
                lat=num(centroid.get("y")),
                lon=num(centroid.get("x")),
                fecha=_fecha(a),
                estado="Vigente",
                activa=True,
                detalle=titulo or fenomeno_raw,
                fenomeno=fenomeno_mod.detectar(fenomeno_raw, titulo),
                area=area,
            )
        )


def fetch_events(prefetched: dict[str, str] | None = None) -> list[Event]:
    eventos: list[Event] = []
    for url in (URL_AVISOS, URL_ALERTAS, URL_ALARMAS):
        data = json_de(url, prefetched)
        _procesar_features(data.get("features", []), eventos)
    return eventos
