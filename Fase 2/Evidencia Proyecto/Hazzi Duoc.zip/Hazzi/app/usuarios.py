"""usuarios reales para los roles de administracion.

reemplaza el admin_key compartido de antes. ahora cada admin es una fila
en esta tabla, identificada por su rut, no una clave que circula entre
todos.

una cuenta puede tener MAS DE UN ROL a la vez (ej. alguien que es tanto
"admin" como "admin_usuarios"). por eso los roles viven en una tabla
aparte, usuario_roles, no en una columna de usuarios: es una relacion
de muchos a muchos, no un dato del usuario. decision de antonella
04-10-2026: una misma persona puede tener acceso a los dos paneles,
mientras quede auditado (ver auditoria.py, cada alta/baja de rol se
registra con el detalle de los roles resultantes).

    admin           -- el de siempre. instalaciones y umbrales (area.py,
                       instalaciones.py, ajustes.py via admin_api.py).
    admin_usuarios  -- gestiona altas/bajas de usuarios y roles, cambia
                       claves y lee la bitacora de auditoria.

el rol "usuario" (monitoreo, solo lectura) no vive aca. no tiene permisos
de escritura asi que no necesita cuenta -- ver visitas.py para el
registro liviano de quien entro a mirar.

el rut es dato sensible (equivalente a un rut/ssn). nunca se guarda en
texto plano: se guarda hasheado para poder buscarlo en el login, y
enmascarado para poder mostrarlo en pantallas y en la bitacora sin
exponer el numero completo. la clave tampoco se guarda en texto plano,
se guarda con pbkdf2 y una sal propia por usuario.
"""
from __future__ import annotations

import hashlib
import re
import secrets
from datetime import datetime
from typing import Optional

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Integer,
    MetaData,
    PrimaryKeyConstraint,
    String,
    Table,
    delete,
    func,
    insert,
    select,
    update,
)

from .db import engine

ROLES = ("admin", "admin_usuarios")

_metadata = MetaData()

usuarios_tabla = Table(
    "usuarios",
    _metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("rut_hash", String, nullable=False, unique=True),
    Column("rut_enmascarado", String, nullable=False),
    Column("nombre", String, nullable=False),
    Column("clave_hash", String, nullable=False),
    Column("clave_sal", String, nullable=False),
    Column("activo", Boolean, nullable=False, default=True),
    Column("creado_en", DateTime, nullable=False),
)

# relacion muchos a muchos. la clave primaria compuesta evita de raiz
# que el mismo rol quede asignado dos veces a la misma persona
usuario_roles_tabla = Table(
    "usuario_roles",
    _metadata,
    Column("usuario_id", Integer, nullable=False),
    Column("rol", String, nullable=False),
    PrimaryKeyConstraint("usuario_id", "rol"),
)


def init_schema() -> None:
    """crea las tablas si no existen. idempotente."""
    _metadata.create_all(engine)


# --- rut: normalizacion, digito verificador, hash, mascara ---------------

_RE_RUT_SUCIO = re.compile(r"[.\s]")


def normalizar_rut(rut: str) -> str:
    """saca puntos y espacios, deja el guion, pone el dv en mayuscula.

    "12.345.678-9" y "12345678-9" y "12345678-9 " son el mismo rut para
    el sistema. sin esto cada forma de escribirlo crearia un usuario
    distinto en el hash.
    """
    limpio = _RE_RUT_SUCIO.sub("", rut or "").upper()
    if "-" not in limpio and len(limpio) > 1:
        limpio = limpio[:-1] + "-" + limpio[-1]
    return limpio


def _calcular_dv(cuerpo: str) -> str:
    """digito verificador chileno. modulo 11 con la serie 2 3 4 5 6 7."""
    suma = 0
    multiplicador = 2
    for digito in reversed(cuerpo):
        suma += int(digito) * multiplicador
        multiplicador = multiplicador + 1 if multiplicador < 7 else 2
    resto = 11 - (suma % 11)
    if resto == 11:
        return "0"
    if resto == 10:
        return "K"
    return str(resto)


def validar_rut(rut: str) -> bool:
    """true si el formato y el digito verificador son correctos."""
    normalizado = normalizar_rut(rut)
    if "-" not in normalizado:
        return False
    cuerpo, dv = normalizado.split("-", 1)
    if not cuerpo.isdigit() or not (7 <= len(cuerpo) <= 8) or len(dv) != 1:
        return False
    return _calcular_dv(cuerpo) == dv


def _hash_rut(rut_normalizado: str) -> str:
    """hash de busqueda. no reversible. el rut nunca se guarda en claro."""
    return hashlib.sha256(rut_normalizado.encode()).hexdigest()


def enmascarar_rut(rut_normalizado: str) -> str:
    """deja ver el inicio y el digito verificador, tapa el resto.

    alcanza para que un humano reconozca "ah, es fulano" sin que la
    bitacora o la pantalla de usuarios expongan el rut completo.
    """
    cuerpo, dv = rut_normalizado.split("-", 1)
    visible = cuerpo[:2] + "X" * (len(cuerpo) - 2) if len(cuerpo) > 2 else cuerpo
    return f"{visible}-{dv}"


# --- clave ------------------------------------------------------------

_PBKDF2_ITERACIONES = 200_000


def _generar_sal() -> str:
    return secrets.token_hex(16)


def _hash_clave(clave: str, sal_hex: str) -> str:
    return hashlib.pbkdf2_hmac(
        "sha256", clave.encode(), bytes.fromhex(sal_hex), _PBKDF2_ITERACIONES
    ).hex()


def _verificar_clave(clave: str, sal_hex: str, hash_esperado: str) -> bool:
    return secrets.compare_digest(_hash_clave(clave, sal_hex), hash_esperado)


def _validar_clave_nueva(clave: str) -> None:
    if len(clave or "") < 8:
        raise ValueError("La clave debe tener al menos 8 caracteres.")


# --- roles ----------------------------------------------------------------


def _roles_de(conn, usuario_id: int) -> list[str]:
    filas = conn.execute(
        select(usuario_roles_tabla.c.rol)
        .where(usuario_roles_tabla.c.usuario_id == usuario_id)
        .order_by(usuario_roles_tabla.c.rol)
    ).scalars().all()
    return list(filas)


def roles_de(usuario_id: int) -> list[str]:
    init_schema()
    with engine.begin() as conn:
        return _roles_de(conn, usuario_id)


# --- crud ---------------------------------------------------------------


def _fila_a_dict(conn, fila) -> dict:
    """version publica de una fila. nunca incluye rut_hash ni clave."""
    return {
        "id": fila.id,
        "rut_enmascarado": fila.rut_enmascarado,
        "nombre": fila.nombre,
        "roles": _roles_de(conn, fila.id),
        "activo": fila.activo,
        "creado_en": fila.creado_en.isoformat(),
    }


def existe_alguno() -> bool:
    """true si ya hay al menos un usuario. para decidir si hay que sembrar uno."""
    init_schema()
    with engine.begin() as conn:
        fila = conn.execute(select(usuarios_tabla.c.id).limit(1)).first()
    return fila is not None


def crear(rut: str, nombre: str, clave: str, roles) -> dict:
    """alta de un usuario admin con uno o mas roles. valida todo o lanza
    valueerror. roles acepta un string (un solo rol) o una lista."""
    lista_roles = [roles] if isinstance(roles, str) else list(roles or [])
    if not lista_roles:
        raise ValueError("Hay que asignar al menos un rol.")
    invalidos = sorted(set(lista_roles) - set(ROLES))
    if invalidos:
        raise ValueError(f"Rol invalido: {', '.join(invalidos)}. Debe ser uno de {', '.join(ROLES)}.")
    if not validar_rut(rut):
        raise ValueError("RUT invalido: revisa el numero y el digito verificador.")
    nombre = (nombre or "").strip()
    if not nombre:
        raise ValueError("El nombre no puede estar vacio.")
    _validar_clave_nueva(clave)

    normalizado = normalizar_rut(rut)
    rut_hash = _hash_rut(normalizado)

    init_schema()
    with engine.begin() as conn:
        existente = conn.execute(
            select(usuarios_tabla.c.id).where(usuarios_tabla.c.rut_hash == rut_hash)
        ).first()
        if existente:
            raise ValueError("Ya existe un usuario con ese RUT.")

        sal = _generar_sal()
        valores = {
            "rut_hash": rut_hash,
            "rut_enmascarado": enmascarar_rut(normalizado),
            "nombre": nombre,
            "clave_hash": _hash_clave(clave, sal),
            "clave_sal": sal,
            "activo": True,
            "creado_en": datetime.now(),
        }
        id_nuevo = conn.execute(insert(usuarios_tabla).values(**valores)).inserted_primary_key[0]
        conn.execute(
            insert(usuario_roles_tabla),
            [{"usuario_id": id_nuevo, "rol": r} for r in set(lista_roles)],
        )
        fila = conn.execute(
            select(usuarios_tabla).where(usuarios_tabla.c.id == id_nuevo)
        ).first()
        return _fila_a_dict(conn, fila)


def listar() -> list[dict]:
    """todos los usuarios, mas recientes primero. sin datos sensibles."""
    init_schema()
    with engine.begin() as conn:
        filas = conn.execute(
            select(usuarios_tabla).order_by(usuarios_tabla.c.creado_en.desc())
        ).all()
        return [_fila_a_dict(conn, f) for f in filas]


def verificar_login(rut: str, clave: str) -> Optional[dict]:
    """credenciales validas y cuenta activa -> datos de sesion. si no, none.

    a proposito no distingue en la respuesta si fallo el rut o la clave:
    un mensaje generico no regala pistas a quien intenta adivinar.
    """
    if not rut or not clave:
        return None
    normalizado = normalizar_rut(rut)
    rut_hash = _hash_rut(normalizado)

    init_schema()
    with engine.begin() as conn:
        fila = conn.execute(
            select(usuarios_tabla).where(usuarios_tabla.c.rut_hash == rut_hash)
        ).first()

        if fila is None or not fila.activo:
            return None
        if not _verificar_clave(clave, fila.clave_sal, fila.clave_hash):
            return None
        return {
            "id": fila.id,
            "nombre": fila.nombre,
            "roles": _roles_de(conn, fila.id),
            "rut_enmascarado": fila.rut_enmascarado,
        }


def agregar_rol(id_usuario: int, rol: str) -> dict:
    """suma un rol a una cuenta que ya existe. si ya lo tenia, no pasa nada
    (idempotente): sumar dos veces el mismo rol no es un error, es un no-op."""
    if rol not in ROLES:
        raise ValueError(f"Rol invalido: {rol}. Debe ser uno de {', '.join(ROLES)}.")
    init_schema()
    with engine.begin() as conn:
        fila = conn.execute(
            select(usuarios_tabla).where(usuarios_tabla.c.id == id_usuario)
        ).first()
        if fila is None:
            raise ValueError("Usuario no encontrado.")
        ya_lo_tiene = conn.execute(
            select(usuario_roles_tabla.c.rol)
            .where(usuario_roles_tabla.c.usuario_id == id_usuario, usuario_roles_tabla.c.rol == rol)
        ).first()
        if not ya_lo_tiene:
            conn.execute(insert(usuario_roles_tabla).values(usuario_id=id_usuario, rol=rol))
        return _fila_a_dict(conn, fila)


def quitar_rol(id_usuario: int, rol: str) -> dict:
    """saca un rol de una cuenta. una cuenta siempre debe quedar con al
    menos un rol -- si este es el ultimo, se rechaza en vez de dejar una
    cuenta sin ningun acceso (quedaria viva pero inutilizable, y nadie
    la veria como "inactiva" para darse cuenta)."""
    init_schema()
    with engine.begin() as conn:
        fila = conn.execute(
            select(usuarios_tabla).where(usuarios_tabla.c.id == id_usuario)
        ).first()
        if fila is None:
            raise ValueError("Usuario no encontrado.")
        actuales = _roles_de(conn, id_usuario)
        if rol not in actuales:
            raise ValueError("Esta cuenta no tiene ese rol.")
        if len(actuales) <= 1:
            raise ValueError("No se puede quitar el unico rol de una cuenta. Desactivala en su lugar.")
        conn.execute(
            delete(usuario_roles_tabla)
            .where(usuario_roles_tabla.c.usuario_id == id_usuario, usuario_roles_tabla.c.rol == rol)
        )
        return _fila_a_dict(conn, fila)


def editar(id_usuario: int, nombre: str, roles) -> dict:
    """actualiza nombre y el conjunto completo de roles de una cuenta que
    ya existe. el rut nunca se edita aca: es la identidad de login, y
    cambiarla a mitad de camino se parece mas a crear una cuenta nueva
    que a corregir un dato. si quedo mal escrito, la via es eliminar y
    volver a crear."""
    lista_roles = [roles] if isinstance(roles, str) else list(roles or [])
    if not lista_roles:
        raise ValueError("Hay que asignar al menos un rol.")
    invalidos = sorted(set(lista_roles) - set(ROLES))
    if invalidos:
        raise ValueError(f"Rol invalido: {', '.join(invalidos)}. Debe ser uno de {', '.join(ROLES)}.")
    nombre = (nombre or "").strip()
    if not nombre:
        raise ValueError("El nombre no puede estar vacio.")

    init_schema()
    with engine.begin() as conn:
        existe = conn.execute(
            select(usuarios_tabla.c.id).where(usuarios_tabla.c.id == id_usuario)
        ).first()
        if existe is None:
            raise ValueError("Usuario no encontrado.")
        conn.execute(
            update(usuarios_tabla).where(usuarios_tabla.c.id == id_usuario).values(nombre=nombre)
        )
        # se reemplaza el set completo de roles en vez de calcular un
        # diff agregar/quitar: mas simple, y la pantalla ya manda el
        # conjunto final completo (ver admin-usuarios.html)
        conn.execute(delete(usuario_roles_tabla).where(usuario_roles_tabla.c.usuario_id == id_usuario))
        conn.execute(
            insert(usuario_roles_tabla),
            [{"usuario_id": id_usuario, "rol": r} for r in set(lista_roles)],
        )
        fila = conn.execute(
            select(usuarios_tabla).where(usuarios_tabla.c.id == id_usuario)
        ).first()
        return _fila_a_dict(conn, fila)


def eliminar(id_usuario: int) -> dict:
    """borra una cuenta por completo (fila + sus roles). a diferencia de
    cambiar_activo (desactivar, reversible), esto no se puede deshacer --
    por eso usuarios_api audita el detalle completo de lo borrado. se
    rechaza si esta cuenta es la unica que todavia tiene el rol
    admin_usuarios: sin ella nadie podria volver a gestionar usuarios, un
    candado que se cierra solo con la llave adentro."""
    init_schema()
    with engine.begin() as conn:
        fila = conn.execute(
            select(usuarios_tabla).where(usuarios_tabla.c.id == id_usuario)
        ).first()
        if fila is None:
            raise ValueError("Usuario no encontrado.")
        datos = _fila_a_dict(conn, fila)
        if "admin_usuarios" in datos["roles"]:
            otros = conn.execute(
                select(func.count())
                .select_from(usuario_roles_tabla.join(
                    usuarios_tabla, usuarios_tabla.c.id == usuario_roles_tabla.c.usuario_id
                ))
                .where(
                    usuario_roles_tabla.c.rol == "admin_usuarios",
                    usuario_roles_tabla.c.usuario_id != id_usuario,
                    usuarios_tabla.c.activo.is_(True),
                )
            ).scalar_one()
            if otros == 0:
                raise ValueError(
                    "No se puede eliminar: es la unica cuenta activa con el rol Gestion de usuarios."
                )
        conn.execute(delete(usuario_roles_tabla).where(usuario_roles_tabla.c.usuario_id == id_usuario))
        conn.execute(delete(usuarios_tabla).where(usuarios_tabla.c.id == id_usuario))
        return datos


def cambiar_clave(id_usuario: int, clave_nueva: str) -> dict:
    """resetea la clave de una cuenta. lo usa admin_usuarios para arreglar
    un typo propio o ajeno -- no hay autoservicio de "olvide mi clave"
    todavia, asi que esta es la unica puerta de recuperacion."""
    _validar_clave_nueva(clave_nueva)
    sal = _generar_sal()
    return _actualizar(id_usuario, {"clave_hash": _hash_clave(clave_nueva, sal), "clave_sal": sal})


def cambiar_activo(id_usuario: int, activo: bool) -> dict:
    return _actualizar(id_usuario, {"activo": bool(activo)})


def _actualizar(id_usuario: int, valores: dict) -> dict:
    init_schema()
    with engine.begin() as conn:
        existe = conn.execute(
            select(usuarios_tabla.c.id).where(usuarios_tabla.c.id == id_usuario)
        ).first()
        if not existe:
            raise ValueError("Usuario no encontrado.")
        conn.execute(
            update(usuarios_tabla).where(usuarios_tabla.c.id == id_usuario).values(**valores)
        )
        fila = conn.execute(
            select(usuarios_tabla).where(usuarios_tabla.c.id == id_usuario)
        ).first()
        return _fila_a_dict(conn, fila)
