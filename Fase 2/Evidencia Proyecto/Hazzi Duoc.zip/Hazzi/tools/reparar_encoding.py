"""Repara el mojibake que introdujo un comando de PowerShell mal encodeado.

QUE PASO: para subir el ?v=34 a v=35 se uso
    Get-Content $f -Raw | ... | Set-Content $f -Encoding UTF8
Get-Content leyo los bytes UTF-8 interpretandolos como ANSI (cp1252), asi que
cada caracter no-ASCII se partio en sus bytes sueltos; Set-Content los volvio a
guardar como UTF-8, codificando CADA byte por separado. Resultado: 'o' se
convirtio en 'Ã³' (doble codificacion). De paso, Set-Content -Encoding UTF8
agrega BOM en Windows PowerShell.

Por eso aparecian simbolos raros tambien donde NO habia tildes: el guion largo
'--' y el punto medio '.', que tampoco son ASCII, se rompieron igual.

COMO SE REVIERTE: la operacion es exactamente invertible. Se vuelve a codificar
el texto en cp1252 (recuperando los bytes UTF-8 originales) y se decodifica como
UTF-8. Si algo no revierte limpio, el archivo se deja intacto y se avisa: mejor
un archivo feo que uno corrupto.
"""
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

BOM = "\ufeff"


def _bytes_originales(texto: str) -> bytes | None:
    """Deshace el paso 'bytes leidos como cp1252', recuperando los bytes reales.

    No alcanza con .encode("cp1252"): cinco bytes (0x81, 0x8D, 0x8F, 0x90, 0x9D)
    no estan definidos en cp1252, y el lector de PowerShell los dejo pasar tal
    cual como U+0081..U+009D. El codec de Python se niega a codificarlos de
    vuelta, asi que esos se traducen a mano por su valor numerico. Este es
    justo el caso de las comillas tipograficas, que terminan en 0x9D.
    """
    salida = bytearray()
    for ch in texto:
        try:
            salida += ch.encode("cp1252")
        except UnicodeEncodeError:
            if 0x80 <= ord(ch) <= 0x9F:   # byte crudo que cp1252 no define
                salida.append(ord(ch))
            else:
                return None               # no es mojibake, es texto legitimo
    return bytes(salida)


def _releer_como_cp1252(datos: bytes) -> str:
    """Simula el paso que rompio los archivos: leer bytes UTF-8 como si fueran
    cp1252. Los cinco bytes que cp1252 no define se dejan pasar como su propio
    valor, que es lo que hizo el lector de PowerShell."""
    return "".join(
        bytes([b]).decode("cp1252") if b not in (0x81, 0x8D, 0x8F, 0x90, 0x9D) else chr(b)
        for b in datos
    )


def reparar(texto: str) -> str | None:
    """Deshace la doble codificacion. None si el texto no la tiene o no revierte."""
    crudo = _bytes_originales(texto)
    if crudo is None:
        return None
    try:
        arreglado = crudo.decode("utf-8")
    except UnicodeDecodeError:
        return None
    # Red de seguridad: volver a APLICAR el dano sobre el texto reparado tiene
    # que reproducir exactamente lo que habia. Si no cuadra, la hipotesis esta
    # mal y el archivo se deja intacto.
    if _releer_como_cp1252(arreglado.encode("utf-8")) != texto:
        return None
    return arreglado


def main() -> int:
    problemas = 0
    for f in sorted(Path("app/static").glob("*.html")):
        crudo = f.read_bytes().decode("utf-8")
        tenia_bom = crudo.startswith(BOM)
        cuerpo = crudo.lstrip(BOM)

        arreglado = reparar(cuerpo)
        if arreglado is None:
            if any(m in cuerpo for m in ("Ã", "Â", "â€")):
                print(f"  !! {f.name}: parece danado pero NO revierte limpio -- sin tocar")
                problemas += 1
            elif tenia_bom:
                f.write_text(cuerpo, encoding="utf-8", newline="")
                print(f"  ok {f.name}: solo se quito el BOM")
            else:
                print(f"  -- {f.name}: ya estaba bien")
            continue

        f.write_text(arreglado, encoding="utf-8", newline="")
        cambios = sum(1 for a, b in zip(cuerpo, arreglado) if a != b)
        print(f"  ok {f.name}: mojibake reparado{' + BOM quitado' if tenia_bom else ''} "
              f"({len(cuerpo)} -> {len(arreglado)} chars)")
    return problemas


if __name__ == "__main__":
    sys.exit(main())
