"""regresion del flujo de archivado. como entra un evento al historial.

corre con historial.engine parcheado a una sqlite temporal propia via
motor_temporal(), ver _aislar_historial.py para el porque: pisar
DATABASE_URL no alcanza en un proceso donde otro test ya importo el
engine real antes.

lo que se verifica: un sismo bajo m4 entra directo al historial sin
pasar por vigentes. su fecha de archivo no se pisa en cada ciclo
porque si no nunca se purgaria. un evento vigente que desaparece de la
fuente se archiva como siempre. la purga respeta la retencion de cada
tipo, 7 dias los sismos y 15 el resto."""
from __future__ import annotations

from datetime import datetime, timedelta

from sqlalchemy import select, update

from ._aislar_historial import motor_temporal
from app import historial as h
from app.historial import clave_evento, historial_tabla, obtener_historial, registrar_ciclo

SISMO_MENOR = {
    "source": "CSN", "tipo": "sismo", "titulo": "M3.9 - 61 km al SE de Sierra Gorda",
    "severidad": "verde", "region": "61 km al SE de Sierra Gorda",
    "fecha": "08-09-2026 07:33 hrs", "activa": True, "mapa": False,
}
ALERTA = {
    "source": "SENAPRED", "tipo": "alerta", "titulo": "Alerta Amarilla", "comuna": "Arica",
    "severidad": "amarilla", "fecha": "08-09-2026 09:00 hrs", "activa": True,
}


def _fila(clave):
    with h.engine.begin() as conn:
        return conn.execute(
            select(historial_tabla.c.vigente, historial_tabla.c.ultima_vez_vigente)
            .where(historial_tabla.c.clave == clave)
        ).first()


def _envejecer(clave, dias):
    """simula que la fila se archivo hace `dias` dias."""
    with h.engine.begin() as conn:
        conn.execute(
            update(historial_tabla).where(historial_tabla.c.clave == clave)
            .values(ultima_vez_vigente=datetime.now() - timedelta(days=dias))
        )


def test_sismo_menor_entra_directo_al_historial():
    """nunca pasa por vigentes. se archiva en el mismo ciclo en que aparece."""
    with motor_temporal():
        registrar_ciclo([], [SISMO_MENOR])
        fila = _fila(clave_evento(SISMO_MENOR))
        assert fila is not None, "el sismo menor tiene que quedar guardado"
        assert fila.vigente is False, "debe entrar ya como archivado, no como vigente"
        assert any(e["titulo"] == SISMO_MENOR["titulo"] for e in obtener_historial())


def test_el_registro_no_reinicia_su_reloj_en_cada_ciclo():
    """si se refrescara el timestamp la purga no llegaria nunca."""
    with motor_temporal():
        registrar_ciclo([], [SISMO_MENOR])
        clave = clave_evento(SISMO_MENOR)
        _envejecer(clave, dias=3)
        antes = _fila(clave).ultima_vez_vigente
        registrar_ciclo([], [SISMO_MENOR])   # la fuente lo sigue trayendo
        assert _fila(clave).ultima_vez_vigente == antes, "no debe refrescarse"


def test_evento_vigente_se_archiva_cuando_desaparece():
    """el flujo de siempre no se rompe con el camino nuevo."""
    with motor_temporal():
        registrar_ciclo([ALERTA], [])
        clave = clave_evento(ALERTA)
        assert _fila(clave).vigente is True
        registrar_ciclo([], [])              # ya no viene en la fuente
        assert _fila(clave).vigente is False


def test_los_sismos_se_purgan_a_los_7_dias():
    with motor_temporal():
        registrar_ciclo([], [SISMO_MENOR])
        clave = clave_evento(SISMO_MENOR)
        _envejecer(clave, dias=5)
        registrar_ciclo([], [])
        assert _fila(clave) is not None, "a los 5 dias todavia tiene que estar"
        _envejecer(clave, dias=8)
        registrar_ciclo([], [])
        assert _fila(clave) is None, "pasados 7 dias el sismo se purga"


def test_los_demas_eventos_se_guardan_15_dias():
    """un sismo se va a los 7 dias pero una alerta con la misma edad se queda."""
    with motor_temporal():
        registrar_ciclo([ALERTA], [])
        registrar_ciclo([], [])              # se archiva
        clave = clave_evento(ALERTA)
        _envejecer(clave, dias=8)
        registrar_ciclo([], [])
        assert _fila(clave) is not None, "a los 8 dias una alerta sigue en el historial"
        _envejecer(clave, dias=16)
        registrar_ciclo([], [])
        assert _fila(clave) is None, "pasados 15 dias se purga"
