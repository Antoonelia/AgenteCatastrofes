"""aislamiento generico para tests que tocan tablas via el engine de un modulo.

mismo problema y misma solucion que _aislar_historial.py: el engine de
sqlalchemy se crea una sola vez por proceso en el primer import de
app.db, cacheado en el namespace de cada modulo que hizo "from .db
import engine". pisar DATABASE_URL despues no sirve de nada. hay que
reemplazar el atributo engine en cada modulo que se vaya a ejercitar y
restaurarlo al salir.

uso:

    from _aislar_motor import motor_temporal_para
    from app import usuarios, sesiones

    with motor_temporal_para(usuarios, sesiones):
        ...
"""
from __future__ import annotations

import tempfile
from contextlib import contextmanager
from pathlib import Path

from sqlalchemy import create_engine


@contextmanager
def motor_temporal_para(*modulos):
    """corre el bloque con el atributo engine de cada modulo apuntando a
    la MISMA sqlite temporal (para que las relaciones entre tablas de
    distintos modulos, como usuarios y sesiones, sigan funcionando), y
    restaura todo al salir pase lo que pase."""
    originales = [m.engine for m in modulos]
    tmp = Path(tempfile.mkdtemp()) / "hazard_test.db"
    temporal = create_engine(f"sqlite:///{tmp}", future=True)
    for m in modulos:
        m.engine = temporal
    try:
        for m in modulos:
            m.init_schema()
        yield
    finally:
        for m, original in zip(modulos, originales):
            m.engine = original
