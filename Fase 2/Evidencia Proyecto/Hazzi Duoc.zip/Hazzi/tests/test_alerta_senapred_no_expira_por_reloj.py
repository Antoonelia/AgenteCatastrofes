"""regresion del bug reportado por antonella el 28-09-2026: hazzi no
mostraba ningun evento vigente aunque senapred tenia alertas rojas
activas.

causa real: sources/senapred.py solo trae alertas con isActive=true,
asi que si un evento llega a filtrar_eventos es porque la propia
senapred sigue diciendo que esta vigente -- exactamente lo que su
narrativa promete cuando no da fecha fija ("vigente hasta que las
condiciones lo ameriten"). retention.py igual las descartaba a las 72h
sin renovacion, pisoteando esa declaracion. caso real capturado en
vivo: arauco y biobio por desborde (24-09-2026) seguian isActive a las
92-97h y hazzi las daba de baja como si hubieran caducado solas. ver
test_retention_region_reemplaza_comuna.py para el fix hermano de la
misma emergencia real (deduplicar por region)."""
from __future__ import annotations

from datetime import datetime

from app.retention import filtrar_eventos

_FMT = "%d-%m-%Y %H:%M hrs"

ALERTA_BIOBIO_DESBORDE = {
    "source": "SENAPRED", "tipo": "alerta", "severidad": "roja",
    "comuna": "Biobío", "region": "Biobío", "tema": "por desborde",
    "titulo": "Se modifica cobertura de Alerta Roja por desborde (Lluvia)",
    "fecha": "24-09-2026 14:10 hrs",  # sin vigencia_hasta, como la trae senapred
}


def test_alerta_roja_sin_fecha_explicita_sigue_vigente_pasadas_72h():
    """el caso que rompia: mas de 72h desde el ultimo aviso, sin fecha
    explicita, pero isActive (implicito en que llego hasta aca) dice
    que sigue. antes esto daba [] y era el bug reportado."""
    ahora = datetime.strptime("28-09-2026 10:00 hrs", _FMT)  # ~92h despues
    vigentes = filtrar_eventos([ALERTA_BIOBIO_DESBORDE], ahora=ahora)
    assert vigentes == [ALERTA_BIOBIO_DESBORDE]


def test_alerta_sin_fecha_explicita_igual_expira_si_queda_atascada_semanas():
    """el salvavidas ultimo sigue existiendo. si el feed de senapred
    nunca cierra ni actualiza una alerta en muchos dias, se asume feed
    roto y se descarta igual."""
    ahora = datetime.strptime("20-10-2026 14:10 hrs", _FMT)  # 26 dias despues
    assert filtrar_eventos([ALERTA_BIOBIO_DESBORDE], ahora=ahora) == []
