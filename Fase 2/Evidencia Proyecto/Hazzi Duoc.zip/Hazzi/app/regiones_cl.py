"""detecta regiones oficiales de chile a partir de texto libre.

lo comparten dmc y senapred porque ambas redactan sus titulos mencionando
regiones en prosa en vez de traer un campo estructurado confiable. se
busca contra esta lista fija en vez de adivinar por mayusculas y de paso
se normalizan las tildes para mostrar bonito sin importar como venga
escrito el original."""
from __future__ import annotations

import re
import unicodedata

REGIONES = [
    (r"arica\s+y\s+parinacota", "Arica y Parinacota"),
    (r"tarapaca", "Tarapacá"),
    (r"antofagasta", "Antofagasta"),
    (r"atacama", "Atacama"),
    (r"coquimbo", "Coquimbo"),
    (r"valparaiso", "Valparaíso"),
    (r"metropolitana", "Metropolitana"),
    (r"o.?higgins", "O'Higgins"),
    (r"maule", "Maule"),
    (r"nuble", "Ñuble"),
    (r"bio\s*bio", "Biobío"),
    (r"araucania", "La Araucanía"),
    (r"los\s+rios", "Los Ríos"),
    (r"los\s+lagos", "Los Lagos"),
    (r"aysen", "Aysén"),
    (r"magallanes", "Magallanes"),
]


def sin_tildes(s: str) -> str:
    """saca tildes y dieresis para comparar sin importar el acento exacto
    que traiga el texto de origen."""
    return "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c))


def regiones_desde_texto(texto: str) -> list[str]:
    """devuelve las regiones mencionadas en el texto en el orden en que
    aparecen y sin repetidas. lista vacia si no encuentra ninguna."""
    if not texto:
        return []
    t = sin_tildes(texto.lower())
    encontradas = []
    for patron, nombre in REGIONES:
        m = re.search(patron, t)
        if m:
            encontradas.append((m.start(), nombre))
    encontradas.sort(key=lambda x: x[0])
    vistas: list[str] = []
    for _, nombre in encontradas:
        if nombre not in vistas:
            vistas.append(nombre)
    return vistas


def region_desde_texto(texto: str) -> str | None:
    """como regiones_desde_texto pero devuelve un string listo para
    mostrar o none si no encontro nada."""
    vistas = regiones_desde_texto(texto)
    return ", ".join(vistas) if vistas else None


# el numero de region no sigue el orden de la lista de arriba. los rios
# arica y parinacota y nuble se crearon despues asi que quedaron con
# numeros nuevos al final en vez de renumerar todo. metropolitana no
# tiene numero romano se le dice rm. se usa para el cartel de region
# en el mapa.
REGION_NUMERO = {
    "Tarapacá": "I",
    "Antofagasta": "II",
    "Atacama": "III",
    "Coquimbo": "IV",
    "Valparaíso": "V",
    "Metropolitana": "RM",
    "O'Higgins": "VI",
    "Maule": "VII",
    "Biobío": "VIII",
    "La Araucanía": "IX",
    "Los Lagos": "X",
    "Aysén": "XI",
    "Magallanes": "XII",
    "Los Ríos": "XIV",
    "Arica y Parinacota": "XV",
    "Ñuble": "XVI",
}


def texto_numero_region(nombre_oficial: str) -> str:
    """algo como xv region para la mayoria. region metropolitana para la
    rm que no tiene numero. cadena vacia si el nombre no se reconoce."""
    numero = REGION_NUMERO.get(nombre_oficial)
    if numero is None:
        return ""
    if numero == "RM":
        return "Región Metropolitana"
    return f"{numero} Región"


# centro de cada region usando la capital regional como punto de
# referencia. no hace falta el centroide exacto alcanza con un punto
# conocido. se usa para pedir el clima de las 16 regiones de una vez
# en el cartel del mapa.
REGION_CENTRO: dict[str, tuple[float, float]] = {
    "Arica y Parinacota": (-18.4783, -70.3126),   # Arica
    "Tarapacá": (-20.2141, -70.1522),              # Iquique
    "Antofagasta": (-23.6509, -70.3975),           # Antofagasta
    "Atacama": (-27.3668, -70.3323),                # Copiapó
    "Coquimbo": (-29.9027, -71.2519),               # La Serena
    "Valparaíso": (-33.0472, -71.6127),             # Valparaíso
    "Metropolitana": (-33.4489, -70.6693),          # Santiago
    "O'Higgins": (-34.1708, -70.7444),              # Rancagua
    "Maule": (-35.4264, -71.6554),                  # Talca
    "Ñuble": (-36.6066, -72.1034),                  # Chillán
    "Biobío": (-36.8201, -73.0444),                 # Concepción
    "La Araucanía": (-38.7359, -72.5904),           # Temuco
    "Los Ríos": (-39.8142, -73.2459),               # Valdivia
    "Los Lagos": (-41.4693, -72.9424),              # Puerto Montt
    "Aysén": (-45.5712, -72.0685),                  # Coyhaique
    "Magallanes": (-53.1638, -70.9171),             # Punta Arenas
}
