"""regresion del bug del "evento fantasma" en el historial.

reproduce, con los datos reales que lo dispararon capturados de
hazard.db el 07-09-2026, el caso en que la fuente reescribe campos del
mismo evento entre dos ciclos. si la clave de identidad usa alguno de
esos campos mutables la version anterior queda huerfana y se archiva
como "finalizada" aunque el evento siga vigente."""
from __future__ import annotations

from app.historial import clave_evento
from app.retention import filtrar_eventos

# caso 1: senapred reescribe titulo fecha y hasta el fenomeno.
# ojo con el fenomeno: no viene en el feed, se deduce del texto del
# boletin (fenomeno.detectar), asi que pasa de none a "viento" cuando
# el boletin actualizado lo menciona. los valores de abajo son los
# reales de hazard.db
ARICA_ANTES = {
    "source": "SENAPRED", "tipo": "alerta", "comuna": "Arica", "region": None,
    "titulo": "Monitoreo Alerta Amarilla por evento meteorologico",
    "fecha": "06-09-2026 15:03 hrs", "fenomeno": None,
}
ARICA_DESPUES = {
    "source": "SENAPRED", "tipo": "alerta", "comuna": "Arica",
    "region": "Arica y Parinacota",
    "titulo": "Monitoreo Alerta Amarilla por evento meteorologico (Viento)",
    "fecha": "07-09-2026 12:32 hrs", "fenomeno": "viento",
}

# caso 2: conaf corrige la fecha de inicio del mismo incendio
LO_MARIN_ANTES = {
    "source": "CONAF", "tipo": "incendio", "comuna": "Tiltil", "titulo": "LO MARIN",
    "fecha": "07-09-2026 11:35 hrs", "estado": "En combate", "activa": True,
}
LO_MARIN_DESPUES = {
    "source": "CONAF", "tipo": "incendio", "comuna": "Tiltil", "titulo": "LO MARIN",
    "fecha": "07-09-2026 11:20 hrs", "estado": "Finalizado", "activa": False,
}


def test_alerta_senapred_conserva_identidad_aunque_cambie_titulo_fecha_y_fenomeno():
    assert clave_evento(ARICA_ANTES) == clave_evento(ARICA_DESPUES)


def test_incendio_conaf_conserva_identidad_aunque_la_fuente_corrija_la_fecha():
    assert clave_evento(LO_MARIN_ANTES) == clave_evento(LO_MARIN_DESPUES)


def test_eventos_distintos_no_colisionan():
    """el fix no debe irse al otro extremo y fusionar cosas distintas."""
    otra_comuna = {**ARICA_DESPUES, "comuna": "Camarones"}
    otro_incendio = {**LO_MARIN_DESPUES, "titulo": "EL PERAL"}
    assert clave_evento(ARICA_DESPUES) != clave_evento(otra_comuna)
    assert clave_evento(LO_MARIN_DESPUES) != clave_evento(otro_incendio)


def test_dos_sismos_distintos_mismo_lugar_siguen_separados():
    """en sismos la fecha si es del hecho. es lo unico que los distingue."""
    base = {"source": "CSN", "tipo": "sismo", "titulo": "M4.5 - Ovalle", "region": "Ovalle"}
    assert clave_evento({**base, "fecha": "07-09-2026 01:00 hrs"}) != \
           clave_evento({**base, "fecha": "07-09-2026 05:00 hrs"})


# caso 3: csn revisa el epicentro del mismo sismo, bug reportado en vivo.
# el csn publica primero una ubicacion automatica preliminar y despues
# la revisa con mas estaciones. el lugar autogenerado, que es distancia
# y rumbo a la ciudad de referencia, cambia aunque sea el mismo sismo.
# la pagina oficial del csn muestra una sola fila que se actualiza.
# antes hazzi lo duplicaba en el historial porque zona y titulo, que
# incluyen el lugar, formaban parte de la identidad
ATACAMA_PRELIMINAR = {
    "source": "CSN", "tipo": "sismo",
    "titulo": "M3.5 - 114 km al NE de San Pedro de Atacama",
    "region": "114 km al NE de San Pedro de Atacama",
    "fecha": "10-09-2026 09:27 hrs",
}
ATACAMA_REVISADO = {
    "source": "CSN", "tipo": "sismo",
    "titulo": "M3.5 - 102 km al NE de San Pedro de Atacama",
    "region": "102 km al NE de San Pedro de Atacama",
    "fecha": "10-09-2026 09:27 hrs",
}


def test_sismo_csn_conserva_identidad_aunque_el_csn_revise_el_epicentro():
    assert clave_evento(ATACAMA_PRELIMINAR) == clave_evento(ATACAMA_REVISADO)


def test_incendio_extinguido_no_sigue_vigente():
    """un incendio finalizado no puede seguir apareciendo en eventos vigentes."""
    assert filtrar_eventos([LO_MARIN_DESPUES]) == []
    assert filtrar_eventos([LO_MARIN_ANTES]) == [LO_MARIN_ANTES]
