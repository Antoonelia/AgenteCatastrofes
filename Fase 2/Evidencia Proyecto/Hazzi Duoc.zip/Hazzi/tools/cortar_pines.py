"""Recorta pin.png (grilla 2x2 con los 4 formatos de tienda) en 4 PNG
individuales, uno por formato, listos para usar como icono de marcador en el
mapa (ver app/static/mapa.html::pinTienda).

Uso puntual, se corre una sola vez a mano cuando llega un pin.png nuevo -- no
es parte del pipeline de la app, por eso vive en tools/ y no en app/.
"""
from __future__ import annotations

from pathlib import Path

from PIL import Image

ORIGEN = Path.home() / "Downloads" / "pin.png"
DESTINO = Path(__file__).resolve().parent.parent / "app" / "static" / "logos"

# Cuadrante -> nombre de archivo. Orden confirmado visualmente: arriba-izq
# Lider, arriba-der SuperBodega aCuenta, abajo-izq Express de Lider,
# abajo-der Central Mayorista.
CUADRANTES = {
    "pin-lider.png": (0, 0),
    "pin-acuenta.png": (1, 0),
    "pin-express.png": (0, 1),
    "pin-central.png": (1, 1),
}

PADDING = 14  # margen parejo alrededor del recorte ajustado, para que el glow (drop-shadow) no quede pegado al borde


def main() -> None:
    im = Image.open(ORIGEN).convert("RGBA")
    w, h = im.size
    cw, ch = w // 2, h // 2

    for nombre, (cx, cy) in CUADRANTES.items():
        cuadrante = im.crop((cx * cw, cy * ch, (cx + 1) * cw, (cy + 1) * ch))
        bbox = cuadrante.getbbox()  # recorta el margen transparente sobrante
        if bbox:
            x0, y0, x1, y1 = bbox
            x0 = max(0, x0 - PADDING)
            y0 = max(0, y0 - PADDING)
            x1 = min(cuadrante.width, x1 + PADDING)
            y1 = min(cuadrante.height, y1 + PADDING)
            cuadrante = cuadrante.crop((x0, y0, x1, y1))
        destino = DESTINO / nombre
        cuadrante.save(destino)
        print(f"{nombre}: {cuadrante.size} -> {destino}")


if __name__ == "__main__":
    main()
