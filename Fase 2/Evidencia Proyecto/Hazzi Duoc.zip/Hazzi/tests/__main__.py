from tests import main
import sys
sys.exit(main())
