"""tests del diagnostico. que el estado que muestra admin sea honesto.

el bug caro de esta pantalla no es que se vea fea. es que diga "todo
bien" cuando una fuente de gobierno lleva horas caida. eso es peor que
no tener la pantalla porque da confianza falsa."""
from __future__ import annotations

from app import diagnostico as d


def _limpio():
    d.reiniciar()


def _ciclo(por_fuente=None, errores=None, duracion=3.0, vigentes=5, tiendas=2):
    d.registrar(
        duracion_s=duracion,
        por_fuente=por_fuente or {},
        errores=errores or {},
        total_vigentes=vigentes,
        tiendas_en_riesgo=tiendas,
    )


# la distincion que justifica el modulo entero


def test_fuente_con_eventos_esta_ok():
    _limpio()
    _ciclo(por_fuente={"CSN": 4})
    fuente = next(f for f in d.resumen()["fuentes"] if f["fuente"] == "CSN")
    assert fuente["estado"] == d.ESTADO_OK
    assert fuente["eventos"] == 4


def test_fuente_que_responde_vacia_no_es_error():
    """cero eventos es lo normal un dia tranquilo. no es una falla."""
    _limpio()
    _ciclo(por_fuente={"CSN": 0})
    fuente = next(f for f in d.resumen()["fuentes"] if f["fuente"] == "CSN")
    assert fuente["estado"] == d.ESTADO_SIN_DATOS
    assert "normal" in fuente["detalle"]


def test_fuente_caida_es_error_con_su_motivo():
    _limpio()
    _ciclo(errores={"CONAF": "timeout tras 60s"})
    fuente = next(f for f in d.resumen()["fuentes"] if f["fuente"] == "CONAF")
    assert fuente["estado"] == d.ESTADO_ERROR
    assert "timeout" in fuente["detalle"]


def test_sin_ciclos_no_inventa_que_todo_anda_bien():
    _limpio()
    resumen = d.resumen()
    assert resumen["ciclos_registrados"] == 0
    assert resumen["ultimo_ciclo"] is None
    assert all(f["estado"] == d.ESTADO_SIN_DATOS for f in resumen["fuentes"])


# el fallo del prefetch afecta a 5 fuentes no a una


def test_fallo_de_prefetch_marca_las_cinco_fuentes_de_powershell():
    """si el proxy falla las 5 fuentes por powershell caen juntas.

    mostrarlo solo como "prefetch" esconderia por que hay 5 fuentes en cero."""
    _limpio()
    _ciclo(errores={"prefetch": "407 Proxy Authentication Required"})
    fuentes = {f["fuente"]: f["estado"] for f in d.resumen()["fuentes"]}
    for nombre in ("CONAF", "SERNAGEOMIN", "DMC", "USGS", "CSN"):
        assert fuentes[nombre] == d.ESTADO_ERROR, nombre


def test_senapred_no_se_ve_afectada_por_el_prefetch():
    """senapred va por aws appsync no por powershell. es independiente."""
    _limpio()
    _ciclo(por_fuente={"SENAPRED": 2}, errores={"prefetch": "fallo"})
    fuente = next(f for f in d.resumen()["fuentes"] if f["fuente"] == "SENAPRED")
    assert fuente["estado"] == d.ESTADO_OK


# confiabilidad. la senal que mira el usuario primero


def test_sin_errores_el_sistema_es_confiable():
    _limpio()
    _ciclo(por_fuente={"CSN": 3})
    assert d.resumen()["confiable"]


def test_con_una_fuente_caida_no_es_confiable():
    """el dashboard se ve igual de lindo con una fuente muerta. hay que decirlo."""
    _limpio()
    _ciclo(por_fuente={"CSN": 3}, errores={"CONAF": "timeout"})
    resumen = d.resumen()
    assert not resumen["confiable"]
    assert resumen["fuentes_error"] == 1


# historia de ciclos


def test_una_fuente_intermitente_se_delata_en_los_fallos_recientes():
    """aunque el ultimo ciclo le salga bien 3 de 4 fallos es una fuente enferma."""
    _limpio()
    for _ in range(3):
        _ciclo(errores={"DMC": "timeout"})
    _ciclo(por_fuente={"DMC": 1})
    fuente = next(f for f in d.resumen()["fuentes"] if f["fuente"] == "DMC")
    assert fuente["estado"] == d.ESTADO_OK  # el ultimo ciclo estuvo bien
    assert fuente["fallos_recientes"] == 3  # pero la historia lo delata


def test_no_se_acumulan_ciclos_para_siempre():
    _limpio()
    for _ in range(d.MAX_CICLOS + 15):
        _ciclo()
    assert d.resumen()["ciclos_registrados"] == d.MAX_CICLOS


def test_promedio_y_maximo_de_duracion():
    _limpio()
    _ciclo(duracion=2.0)
    _ciclo(duracion=4.0)
    resumen = d.resumen()
    assert resumen["duracion_promedio_s"] == 3.0
    assert resumen["duracion_maxima_s"] == 4.0


def test_el_ultimo_ciclo_es_el_mas_reciente():
    _limpio()
    _ciclo(vigentes=1)
    _ciclo(vigentes=9)
    assert d.resumen()["ultimo_ciclo"]["eventos_vigentes"] == 9


# configuracion


def test_la_configuracion_lista_lo_que_importa():
    claves = {c["clave"] for c in d.configuracion()}
    assert "Proveedor de IA" in claves
    assert "Canal de notificaciones" in claves
    assert "Base de datos" in claves


def test_las_limitaciones_conocidas_quedan_marcadas():
    """la dotacion estimada y el proxy con sesion son limitaciones reales.

    tienen que verse en ambar en la pantalla, no esconderse entre lo verde."""
    config = {c["clave"]: c for c in d.configuracion()}
    assert config["Dotacion por tienda"]["degradado"]
    assert config["Salida a internet"]["degradado"]


def test_la_url_de_base_de_datos_oculta_credenciales():
    """esta pantalla es justo donde alguien saca una captura para un ticket."""
    enmascarada = d._enmascarar("postgresql://hazzi:secreto123@servidor:5432/db")
    assert "secreto123" not in enmascarada
    assert "hazzi" in enmascarada
    assert "servidor:5432" in enmascarada


def test_sqlite_local_no_se_toca():
    url = "sqlite:///C:/ruta/data/hazard.db"
    assert d._enmascarar(url) == url


# formato


def test_formato_de_duracion_legible():
    assert d._formato_duracion(45) == "45s"
    assert d._formato_duracion(125) == "2m 5s"
    assert d._formato_duracion(7325) == "2h 2m"
    assert d._formato_duracion(180000) == "2d 2h"
