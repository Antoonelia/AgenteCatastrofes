"""Verifica que /historial sea una lista vertical: crece hacia abajo, nunca
se desliza de lado, ni en desktop ni en un telefono angosto."""
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    nav = p.chromium.launch(channel="chrome")
    pagina = nav.new_page()
    errores = []
    pagina.on("pageerror", lambda e: errores.append(str(e)))
    pagina.route("**://cdn.tailwindcss.com/**", lambda r: r.abort())

    pagina.goto("http://127.0.0.1:8000/historial", wait_until="domcontentloaded")
    pagina.wait_for_function("document.querySelectorAll('#tabla > li').length > 0", timeout=20000)
    pagina.wait_for_timeout(500)

    for ancho, nombre in ((1400, "desktop"), (375, "mobile")):
        pagina.set_viewport_size({"width": ancho, "height": 900})
        pagina.wait_for_timeout(300)
        info = pagina.evaluate("""() => {
            const sec = document.querySelector('#tabla').closest('section');
            const items = document.querySelectorAll('#tabla > li');
            return {
                items: items.length,
                esUL: document.getElementById('tabla').tagName,
                seccionAncho: sec.scrollWidth,
                seccionVisible: sec.clientWidth,
                overflowHorizontal: sec.scrollWidth > sec.clientWidth + 2,
                primerItemAncho: items[0] ? items[0].scrollWidth <= items[0].clientWidth + 2 : null,
                tieneChevron: !!document.querySelector('.hz-list-chevron'),
                tieneTabla: !!document.querySelector('table.hz-table'),
            };
        }""")
        print(f"[{nombre} {ancho}px]", info)
        Path("_qa_shots").mkdir(exist_ok=True)
        pagina.screenshot(path=f"_qa_shots/historial_{nombre}.png", full_page=True)

    # Click en el primer item: debe abrir el mismo modal de detalle de siempre.
    pagina.click("#tabla > li:first-child")
    pagina.wait_for_timeout(500)
    modal_visible = pagina.evaluate("!document.getElementById('modal').classList.contains('hidden')")
    print("modal abre al hacer click en un item:", modal_visible)
    pagina.screenshot(path="_qa_shots/historial_detalle.png")

    print("errores JS:", errores or "ninguno")
    nav.close()
