"""regresion del bug de "un solo evento de senapred en el historial".

reportado por antonella: hubo varias alertas amarillas y rojas durante
la semana pero el historial solo mostraba una. la causa: la identidad
de una alerta es (fuente, comuna), ver historial.clave_evento, a
proposito gruesa para no fragmentar un mismo aviso que la fuente va
reescribiendo mientras sigue vigente. el problema es que esa misma
base se reusaba para SIEMPRE, asi que un episodio nuevo en la misma
comuna, semanas despues, pisaba en la misma fila el registro archivado
del episodio anterior en vez de sumar uno nuevo. lo mismo le pasaba a
una alerta sin tienda cerca, que entra directo como registro: un
boletin nuevo en la misma comuna se descartaba en silencio porque la
clave ya existia.

corre con historial.engine parcheado a una sqlite temporal propia via
motor_temporal(), ver _aislar_historial.py para el porque: pisar
DATABASE_URL no alcanza en un proceso donde otro test ya importo el
engine real antes."""
from __future__ import annotations

from ._aislar_historial import motor_temporal
from app.historial import clave_evento, obtener_historial, registrar_ciclo

ALERTA_LUNES = {
    "source": "SENAPRED", "tipo": "alerta", "comuna": "Alto Biobío",
    "titulo": "Se declara Alerta Amarilla por crecida de Embalse Ralco (Lluvia)",
    "severidad": "amarilla", "fecha": "22-09-2026 08:00 hrs",
}
# misma comuna, mismo boletin, la fuente solo le actualizo la hora.
# tiene que seguir siendo el mismo episodio mientras este vigente
ALERTA_LUNES_ACTUALIZADA = {
    **ALERTA_LUNES,
    "titulo": "Se declara Alerta Amarilla por crecida de Embalse Ralco (Lluvia, Viento)",
    "fecha": "22-09-2026 14:00 hrs",
}
# misma comuna, jueves, un episodio distinto: subio a roja por desborde.
# la amarilla del lunes ya se archivo para entonces
ALERTA_JUEVES = {
    "source": "SENAPRED", "tipo": "alerta", "comuna": "Alto Biobío",
    "titulo": "Se declara Alerta Roja por desborde del río Biobío",
    "severidad": "roja", "fecha": "25-09-2026 10:00 hrs",
}

REGISTRO_LUNES = {
    "source": "SENAPRED", "tipo": "alerta", "comuna": "Futaleufú",
    "titulo": "Alerta Amarilla por viento", "severidad": "amarilla",
    "fecha": "22-09-2026 09:00 hrs", "mapa": False,
}
REGISTRO_JUEVES = {
    "source": "SENAPRED", "tipo": "alerta", "comuna": "Futaleufú",
    "titulo": "Alerta Roja por crecida", "severidad": "roja",
    "fecha": "25-09-2026 11:00 hrs", "mapa": False,
}


def _titulos_de(comuna):
    return {e["titulo"] for e in obtener_historial() if e.get("comuna") == comuna}


def test_dos_episodios_de_alerta_en_la_misma_comuna_no_se_pisan():
    """el caso real reportado: amarilla el lunes, ya resuelta, y una roja
    distinta el jueves. las dos tienen que quedar, no solo la ultima."""
    with motor_temporal():
        registrar_ciclo([ALERTA_LUNES], [])
        registrar_ciclo([], [])  # la fuente deja de traerla. se archiva
        registrar_ciclo([ALERTA_JUEVES], [])
        registrar_ciclo([], [])  # tambien se resuelve y se archiva

        titulos = _titulos_de("Alto Biobío")
        assert ALERTA_LUNES["titulo"] in titulos, "el episodio del lunes no puede desaparecer"
        assert ALERTA_JUEVES["titulo"] in titulos, "el episodio del jueves tiene que estar tambien"


def test_el_mismo_episodio_vigente_sigue_actualizando_una_sola_fila():
    """mientras el aviso sigue vigente, que la fuente le retoque el
    titulo no tiene que fragmentarlo en dos filas. esta es la garantia
    vieja, test_historial_identidad, y el fix nuevo no puede romperla."""
    with motor_temporal():
        registrar_ciclo([ALERTA_LUNES], [])
        registrar_ciclo([ALERTA_LUNES_ACTUALIZADA], [])  # sigue vigente, cambio el titulo

        historial_biobio = [e for e in obtener_historial() if e.get("comuna") == "Alto Biobío"]
        assert historial_biobio == [], "todavia esta vigente, no deberia estar en el historial"

        registrar_ciclo([], [])  # ahora si se resuelve
        historial_biobio = [e for e in obtener_historial() if e.get("comuna") == "Alto Biobío"]
        assert len(historial_biobio) == 1, "una sola fila para todo el episodio, no dos"
        assert historial_biobio[0]["titulo"] == ALERTA_LUNES_ACTUALIZADA["titulo"]


def test_un_registro_con_boletin_nuevo_en_la_misma_comuna_no_se_descarta():
    """alerta sin tienda cerca: entra directo como registro. un boletin
    distinto semanas despues no puede perderse solo porque la comuna
    ya tenia una fila."""
    with motor_temporal():
        registrar_ciclo([], [REGISTRO_LUNES])
        registrar_ciclo([], [REGISTRO_JUEVES])

        titulos = _titulos_de("Futaleufú")
        assert REGISTRO_LUNES["titulo"] in titulos, "el registro del lunes no puede perderse"
        assert REGISTRO_JUEVES["titulo"] in titulos, "el registro del jueves tiene que sumarse aparte"


def test_un_registro_repetido_no_se_duplica():
    """el mismo boletin, sin cambios, siguiendo vigente en la fuente
    ciclo tras ciclo no tiene que clonarse cada vez."""
    with motor_temporal():
        registrar_ciclo([], [REGISTRO_LUNES])
        registrar_ciclo([], [REGISTRO_LUNES])
        registrar_ciclo([], [REGISTRO_LUNES])

        coincidencias = [e for e in obtener_historial() if e["titulo"] == REGISTRO_LUNES["titulo"]]
        assert len(coincidencias) == 1, "el mismo boletin repetido no debe duplicarse"


def test_el_primer_episodio_de_una_identidad_guarda_la_clave_sin_sufijo():
    """compatibilidad: el primer episodio de siempre se sigue viendo
    identico a antes del fix, sin sufijo #2 ni nada raro."""
    with motor_temporal():
        registrar_ciclo([ALERTA_LUNES], [])
        registrar_ciclo([], [])
        fila = obtener_historial()[0]
        assert fila["comuna"] == "Alto Biobío"
        # la clave real no es un dato del json, pero si solo hubo un
        # episodio tiene que ser justo la base sin sufijo
        assert clave_evento(ALERTA_LUNES) == "SENAPRED|Alto Biobío"
