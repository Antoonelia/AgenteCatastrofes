"""extraccion de lugares desde titulos de senapred. ver sources/senapred.py.

caso real que motiva la mitad de este archivo: "se declara alerta roja
para la provincia de cautin" geocodificaba mal. nominatim resolvia el
nombre pelado "cautin" a una calle llamada asi en puerto montt, a mas
de 600 km de la provincia real en la araucania, en vez de al limite
administrativo, porque la calle hace match exacto de nombre y el
limite real se llama "provincia de cautin" en el mapa. la alerta
terminaba pintando un circulo de dano alrededor de una calle random y
afectando tiendas que no tenian nada que ver. la correccion es la
misma idea que ya se habia aplicado para regiones completas, ver el
caso de "arica y parinacota" mas abajo. no perder el calificador
administrativo al extraer el nombre."""
from __future__ import annotations

from app.sources.senapred import _lugares_desde_titulo


def test_provincia_singular_conserva_el_calificador():
    """sin el calificador el geocodificador puede confundirla con una
    calle homonima. caso real: la provincia de cautin resolvia a una
    calle en puerto montt. con el calificador pegado la busqueda queda
    sin ambiguedad."""
    titulo = "Se declara Alerta Roja para la provincia de Cautin por crecida"
    assert _lugares_desde_titulo(titulo) == ["Provincia de Cautin"]


def test_provincias_plural_conserva_el_calificador_en_cada_una():
    titulo = "Se declara Alerta Roja para las provincias de Cautin e Imperial por crecida"
    assert _lugares_desde_titulo(titulo) == ["Provincia de Cautin", "Provincia de Imperial"]


def test_provincia_del_tambien_se_reconoce():
    titulo = "Se declara Alerta Amarilla para la provincia del Biobio por viento"
    assert _lugares_desde_titulo(titulo) == ["Provincia de Biobio"]


def test_comunas_no_se_ven_afectadas_por_el_fix_de_provincia():
    """regresion. el fix de provincia no debe agregarle "provincia de" a comunas."""
    titulo = "Se declara Alerta Amarilla para las comunas de Lanco, Mariquina por crecida"
    assert _lugares_desde_titulo(titulo) == ["Lanco", "Mariquina"]


def test_region_completa_sigue_devolviendose_entera():
    """regresion. el caso ya arreglado de regiones, ver el docstring de
    _lugares_desde_titulo, no debe romperse con el cambio de provincias."""
    titulo = "Se declara Alerta Amarilla para la Region de Arica y Parinacota por viento"
    assert _lugares_desde_titulo(titulo) == ["Arica y Parinacota"]
