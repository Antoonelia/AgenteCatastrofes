/* common.js. header compartido, logo mas hamburguesa mas menu, y utilidades.
   se incluye en todas las paginas para no repetir el header. es dry. */

const NAV = [
  { href: "/inicio", label: "Inicio", key: "nav_inicio" },
  { href: "/mapa", label: "Mapa interactivo", key: "nav_mapa" },
  { href: "/tiendas", label: "Tiendas en riesgo", key: "nav_tiendas" },
  { href: "/eventos", label: "Eventos vigentes", key: "nav_eventos" },
  { href: "/historial", label: "Historial de eventos", key: "nav_historial" },
  { href: "/estadisticas", label: "Estadisticas", key: "nav_estadisticas" },
  // solo para sesiones de administrador, ver sesion.js. no es una
  // barrera de seguridad, es no ofrecer lo que no corresponde. la
  // barrera real es admin_key en el backend
  { href: "/admin", label: "Administracion", key: "nav_admin", soloAdmin: true },
  // solo para el rol admin_usuarios (ver sesion.js). separado de
  // "Administracion" a proposito: son dos roles distintos que no se
  // pisan, ver usuarios.py
  { href: "/admin/usuarios", label: "Usuarios y auditoria", key: "nav_admin_usuarios", soloAdminUsuarios: true },
];

// idioma, selector junto a la campana.
// el espanol vive inline en cada string, como siempre vivio, asi que no
// hay que duplicarlo aca. este diccionario solo carga los idiomas
// extra, hoy ingles, y t cae de vuelta al texto en espanol si falta
// una clave. asi, si manana se agrega un string nuevo y nadie lo
// traduce todavia, no se rompe nada. sale en espanol en vez de mostrar la clave
const IDIOMA_DEFAULT = "es";
const I18N = {
  en: {
    nav_inicio: "Home", nav_mapa: "Interactive map", nav_tiendas: "Stores at risk",
    nav_eventos: "Active events", nav_historial: "Event history", nav_estadisticas: "Statistics",
    nav_admin: "Administration", nav_admin_usuarios: "Users and audit log",
    adminnav_estado_label: "System status", adminnav_estado_desc: "Sources, cycles and internal health",
    adminnav_deteccion_label: "Detection", adminnav_deteccion_desc: "Thresholds that define what counts as an event",
    adminnav_instalaciones_label: "Facilities", adminnav_instalaciones_desc: "Stores, offices, distribution centers and plants",
    aria_abrir_menu: "Open menu", aria_menu_principal: "Main menu",
    title_notificaciones: "Notifications", title_mi_cuenta: "My account", title_idioma: "Language",
    pn_head_t: "Notifications", notif_limpiar: "Clear all",
    pn_foot_lbl: "Test alert sound", prueba_amarilla: "Yellow", prueba_roja: "Red",
    notif_vacio_t: "No notifications yet", notif_vacio_s: "We'll let you know as soon as something important happens",
    aria_eliminar_notif: "Delete notification", title_eliminar: "Delete",
    aria_editar_nombre: "Edit name", label_editar_nombre: "Edit name",
    nombre_guardar: "Save", nombre_cancelar: "Cancel",
    aria_cambiar_tema: "Change theme", modo_claro: "Light mode", modo_oscuro: "Dark mode",
    aria_cerrar_sesion: "Log out", cerrar_sesion: "Log out",
    aria_admin_subnav: "Administration sections",
  },
};
function getIdioma() {
  return localStorage.getItem("idioma") || IDIOMA_DEFAULT;
}
function setIdioma(id) {
  localStorage.setItem("idioma", id);
  document.documentElement.lang = id === "en" ? "en" : "es-CL";
}
// t(clave, textoEnEspanol). el espanol siempre viene inline en el
// llamado, una sola fuente visible en el propio markup. t solo lo
// reemplaza cuando hay traduccion cargada para el idioma activo
function t(clave, esTexto) {
  const dic = I18N[getIdioma()];
  return (dic && dic[clave]) || esTexto;
}

// escapa texto para meterlo en innerHTML, en atributos entre comillas
// (title, data-x, aria-label) y en popups de leaflet. todo lo que viene
// de una fuente externa, de un admin o del usuario (titulo, region,
// comuna, nombre de instalacion, etc.) pasa por aca antes de
// interpolarse, si no, un titulo con <img onerror=...> ejecutaria
// codigo en el navegador de quien mira el panel. el nombre NO puede ser
// escapar: admin-usuarios.js y admin-ajustes.html ya declaran el suyo
function escHtml(v) {
  return String(v == null ? '' : v).replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));
}

// sub navegacion dentro de administracion, la barra bajo el header.
// una sola fuente de verdad, igual que NAV. agregar una pagina de
// admin es agregar una linea aca y nada mas. si esto se copiara en
// cada html de admin tendriamos n copias del mismo menu y el dia que
// se sume una pagina nos olvidariamos de la mitad
const ADMIN_NAV = [
  { href: "/admin", label: "Estado del sistema", labelKey: "adminnav_estado_label",
    desc: "Fuentes, ciclos y salud interna", descKey: "adminnav_estado_desc" },
  { href: "/admin/ajustes", label: "Deteccion", labelKey: "adminnav_deteccion_label",
    desc: "Umbrales que definen que es un evento", descKey: "adminnav_deteccion_desc" },
  { href: "/admin/instalaciones", label: "Instalaciones", labelKey: "adminnav_instalaciones_label",
    desc: "Tiendas, oficinas, CDs y plantas", descKey: "adminnav_instalaciones_desc" },
];

// simbolos de la sub barra. mismo trazo que NAV_ICONOS, stroke 2 y
// currentColor, para que hereden el color del item, incluido modo oscuro
const ADMIN_ICONOS = {
  "/admin": '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>',
  "/admin/ajustes": '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/></svg>',
  "/admin/instalaciones": '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21h18"/><path d="M5 21V8l7-5 7 5v13"/><path d="M10 21v-6h4v6"/></svg>',
};

// dibuja la sub barra de administracion dentro de #admin-subnav si
// existe. la llama renderHeader, asi que cada pagina de admin solo
// necesita poner ese div y no sabe nada del contenido de la barra
function renderSubnav() {
  const cont = document.getElementById("admin-subnav");
  if (!cont) return;
  const path = location.pathname;

  const html = ADMIN_NAV.map((n) => {
    const activo = path === n.href;
    return `<a href="${n.href}" class="hz-sub-item${activo ? " activo" : ""}"
       ${activo ? 'aria-current="page"' : ""} title="${t(n.descKey, n.desc)}">
      <span class="hz-sub-ic">${ADMIN_ICONOS[n.href] || ""}</span>
      <span>${t(n.labelKey, n.label)}</span></a>`;
  }).join("");

  cont.innerHTML = `<nav class="hz-subnav" aria-label="${t('aria_admin_subnav', 'Secciones de administracion')}">
    <div class="hz-subnav-in">${html}</div></nav>`;
}

// un simbolo por seccion, una sola fuente de verdad, es dry. mismo
// trazo fino, stroke-width 2 y currentColor, que ya usa el resto de
// la app, asi heredan el color de texto del item, incluido dark mode,
// sin repetir estilos
const NAV_ICONOS = {
  "/": '<svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12l9-9 9 9"/><path d="M5 10v10a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V10"/></svg>',
  "/inicio": '<svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12l9-9 9 9"/><path d="M5 10v10a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V10"/></svg>',
  "/mapa": '<svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21"/><line x1="9" y1="3" x2="9" y2="18"/><line x1="15" y1="6" x2="15" y2="21"/></svg>',
  "/tiendas": '<svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l1-5h16l1 5"/><path d="M3 9a2 2 0 0 0 4 0 2 2 0 0 0 4 0 2 2 0 0 0 4 0 2 2 0 0 0 4 0"/><path d="M4 9v10a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1V9"/></svg>',
  "/eventos": '<svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 9v4M12 17h.01M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/></svg>',
  "/historial": '<svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 15 15"/></svg>',
  "/estadisticas": '<svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>',
  "/admin": '<svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
  "/admin/usuarios": '<svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/></svg>',
};

// aplica el tema guardado lo antes posible, evita parpadeo
(function initTema() {
  if (localStorage.getItem("tema") === "dark") {
    document.documentElement.classList.add("dark");
  }
})();

// aplica el idioma guardado al atributo lang del documento.
// accesibilidad: los lectores de pantalla necesitan saber en que idioma esta el contenido
(function initIdioma() {
  document.documentElement.lang = getIdioma() === "en" ? "en" : "es-CL";
})();

const CHECK_SVG = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#0071dc" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>';

const SPARK = `<img src="/static/logos/spark.webp" alt="Walmart Spark" width="32" height="32"
     style="display:inline-block;vertical-align:middle" />`;

// usuario, nombre editable y persistente.
// el nombre lo define el ingreso en la portada, ver sesion.js. este
// default solo aplica si alguien abre una pagina interna sin haber pasado por ahi
const NOMBRE_DEFAULT = "Invitado";

/* el nombre real vive en la sesion de ESTA pestana (sessionStorage via
 * sesionActual, ver sesion.js), que es propia de cada pestana -- nunca
 * se pisa con lo que otra pestana del mismo navegador este haciendo.
 * localStorage("userName") era la fuente vieja, compartida por TODAS
 * las pestanas a la vez: si entrabas como admin en una pestana y en
 * otra entrabas a Monitorear con otro nombre, la pestana del admin
 * terminaba mostrando ese otro nombre en el header al refrescar, aunque
 * la sesion real (cookie + permisos) seguia siendo la correcta -- bug
 * reportado por antonella 2026-10-05. ahora localStorage solo queda
 * como ultimo recurso para cuando no hay sesion en esta pestana. */
function getUserName() {
  const sesion = (typeof sesionActual === "function") ? sesionActual() : null;
  if (sesion && sesion.nombre) return sesion.nombre;
  return (localStorage.getItem("userName") || NOMBRE_DEFAULT).trim() || NOMBRE_DEFAULT;
}
function setUserName(nombre) {
  localStorage.setItem("userName", nombre.trim());
}
function getIniciales(nombre) {
  const partes = nombre.trim().split(/\s+/).filter(Boolean);
  if (partes.length === 0) return "?";
  if (partes.length === 1) return partes[0].slice(0, 2).toUpperCase();
  return (partes[0][0] + partes[partes.length - 1][0]).toUpperCase();
}
function getPrimerNombre() {
  return getUserName().trim().split(/\s+/)[0] || NOMBRE_DEFAULT;
}

function renderHeader() {
  const cont = document.getElementById("app-header");
  if (!cont) return;
  const path = location.pathname;
  const nombre = getUserName();
  // el nombre lo escribe el usuario (monitoreo) y viaja a innerHTML
  const iniciales = escHtml(getIniciales(nombre));
  const nombreSeguro = escHtml(nombre);
  // editar nombre desde el header: solo tiene sentido para el invitado
  // de Monitoreo (sin cuenta real, el nombre es solo una etiqueta de
  // cortesia). un admin o admin_usuarios ya tiene su nombre real en la
  // base, editable desde "Usuarios y auditoria" -- dejar este editor
  // suelto ademas de ese permitia que alguien se renombrara a si misma
  // sin que quede en la bitacora, y fue la causa de fondo del bug de
  // nombres cruzados entre pestanas.
  const puedeEditarNombre = !(typeof esAdmin === "function" && esAdmin())
    && !(typeof esAdminUsuarios === "function" && esAdminUsuarios());
  const items = NAV
    .filter((n) => !n.soloAdmin || (typeof esAdmin === "function" && esAdmin()))
    .filter((n) => !n.soloAdminUsuarios || (typeof esAdminUsuarios === "function" && esAdminUsuarios()))
    .map((n) => {
      const activo = path === n.href ? "menu-item-activo" : "";
      return `<a href="${n.href}" role="menuitem"
        class="menu-item flex items-center gap-3 px-4 py-2.5 ${activo}">
        <span class="hz-menu-ic">${NAV_ICONOS[n.href] || ""}</span><span>${t(n.key, n.label)}</span></a>`;
    }).join("");

  cont.innerHTML = `
  <div class="relative">
  <header class="hz-header text-white px-4 md:px-6 py-3 shadow flex items-center justify-between gap-4 relative">
    <button id="hamburger" aria-label="${t('aria_abrir_menu', 'Abrir menu')}" aria-expanded="false" aria-controls="menu"
            class="p-2 rounded-lg hover:bg-white/10 focus:outline-none focus:ring-4 focus:ring-yellow-300/40" style="z-index:1">
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#FFC220"
           stroke-width="2.4" stroke-linecap="round">
        <line x1="3" y1="6" x2="21" y2="6" />
        <line x1="3" y1="12" x2="21" y2="12" />
        <line x1="3" y1="18" x2="21" y2="18" />
      </svg>
    </button>

    <a href="/inicio" class="hz-brand absolute left-1/2 -translate-x-1/2 flex items-center gap-2.5" style="z-index:0" aria-label="Agente Hazzi - Inicio">
      <span class="text-2xl md:text-3xl font-extrabold tracking-tight text-white">Agente <span class="hz-nombre-brillo">Hazzi</span></span>
      ${SPARK}
    </a>

    <div class="flex items-center gap-1.5 md:gap-3 shrink-0" style="z-index:1">
      <button id="idioma-btn" aria-haspopup="true" aria-expanded="false" title="${t('title_idioma', 'Idioma')}"
              class="relative p-2.5 rounded-full hover:bg-white/10 focus:outline-none focus:ring-4 focus:ring-yellow-300/40">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
      </button>
      <button id="campana" aria-haspopup="true" aria-expanded="false" title="${t('title_notificaciones', 'Notificaciones')}"
              class="relative p-2.5 rounded-full hover:bg-white/10 focus:outline-none focus:ring-4 focus:ring-yellow-300/40">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>
        <span id="campana-badge" class="hz-bell-badge hidden">0</span>
      </button>
      <button id="avatar-btn" aria-haspopup="true" aria-expanded="false" title="${t('title_mi_cuenta', 'Mi cuenta')}"
              class="flex items-center gap-1.5 pl-1 pr-1.5 py-1 rounded-full hover:bg-white/10 focus:outline-none focus:ring-4 focus:ring-yellow-300/40">
        <span class="hz-avatar" id="avatar-iniciales">${iniciales}</span>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
      </button>
    </div>
  </header>
  <nav id="menu" role="menu" aria-label="${t('aria_menu_principal', 'Menu principal')}" class="hidden hz-menu-drawer" style="z-index:2000">
    <div class="hz-menu-head">
      <img src="/static/logos/hazzi-logo.png?v=2" alt="" width="32" height="29" />
      <span>Agente Hazzi</span>
    </div>
    <div class="hz-menu-items">${items}</div>
    <div class="hz-menu-foot">${SPARK}<span>Walmart Chile</span></div>
  </nav>
  <div id="menu-backdrop" class="hidden hz-menu-backdrop" style="z-index:1999"></div>
  <div id="panel-notif" class="hidden absolute right-4 top-full mt-2 w-96 max-w-[94vw] rounded-2xl overflow-hidden hz-notif-panel" style="z-index:2000">
    <div class="pn-head">
      <div class="pn-head-title">
        <img src="/static/logos/spark.webp" alt="Walmart" width="24" height="24" />
        <div>
          <div class="pn-head-t">${t('pn_head_t', 'Notificaciones')}</div>
          <div class="pn-head-s">Agente Hazzi \u00b7 Walmart Chile</div>
        </div>
      </div>
      <button id="notif-limpiar" title="${t('notif_limpiar', 'Limpiar todas')}">${t('notif_limpiar', 'Limpiar todo')}</button>
    </div>
    <div id="notif-lista"></div>
    <div class="pn-foot">
      <span class="pn-foot-lbl">${t('pn_foot_lbl', 'Probar sonido de alerta')}</span>
      <div class="pn-foot-btns">
        <button id="prueba-amarilla" class="pn-test pn-test--y">${t('prueba_amarilla', 'Amarilla')}</button>
        <button id="prueba-roja" class="pn-test pn-test--r">${t('prueba_roja', 'Roja')}</button>
      </div>
    </div>
  </div>
  <div id="idioma-menu" class="hidden absolute right-4 top-full mt-2 w-44 hz-dropdown-menu" style="z-index:2000">
    <button data-idioma="es" class="idioma-opt w-full flex items-center justify-between gap-2 px-4 py-2.5 text-left text-slate-700 hover:bg-blue-50 text-sm font-semibold">
      <span>Espa\u00f1ol</span><span class="idioma-check">${getIdioma() === 'es' ? CHECK_SVG : ''}</span>
    </button>
    <button data-idioma="en" class="idioma-opt w-full flex items-center justify-between gap-2 px-4 py-2.5 text-left text-slate-700 hover:bg-blue-50 text-sm font-semibold border-t border-slate-100">
      <span>English</span><span class="idioma-check">${getIdioma() === 'en' ? CHECK_SVG : ''}</span>
    </button>
  </div>
  <div id="avatar-menu" class="hidden absolute right-4 top-full mt-2 w-64 hz-dropdown-menu" style="z-index:2000">
    <div class="px-4 py-3 border-b border-slate-100 flex items-center gap-3">
      <span class="hz-avatar" id="avatar-iniciales-menu">${iniciales}</span>
      <div><div class="font-bold text-slate-800 text-sm leading-tight" id="avatar-nombre">${nombreSeguro}</div>
      <div class="text-xs text-slate-500">${escHtml((typeof etiquetaRol === "function" && etiquetaRol()) || "Gesti\u00f3n de Emergencias")}</div></div>
    </div>
    ${puedeEditarNombre ? `
    <div id="nombre-edit" class="hidden px-4 py-3 border-b border-slate-100">
      <label for="nombre-input" class="block text-xs font-semibold text-slate-500 mb-1">${t('label_editar_nombre', 'Editar nombre')}</label>
      <input id="nombre-input" type="text" maxlength="40" autocomplete="name"
             class="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-400" />
      <div class="flex gap-2 mt-2">
        <button id="nombre-guardar" class="flex-1 hz-btn text-sm">${t('nombre_guardar', 'Guardar')}</button>
        <button id="nombre-cancelar" class="hz-btn-secundario text-sm">${t('nombre_cancelar', 'Cancelar')}</button>
      </div>
    </div>
    <button id="nombre-editar-btn" aria-label="${t('aria_editar_nombre', 'Editar nombre')}"
            class="w-full flex items-center gap-2.5 px-4 py-2.5 text-left text-slate-700 hover:bg-blue-50 text-sm font-semibold border-b border-slate-100">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4z"/></svg>
      <span>${t('label_editar_nombre', 'Editar nombre')}</span>
    </button>` : ''}
    <button id="tema-btn" aria-label="${t('aria_cambiar_tema', 'Cambiar tema')}"
            class="w-full flex items-center gap-2.5 px-4 py-2.5 text-left text-slate-700 hover:bg-blue-50 text-sm font-semibold"></button>
    <button id="salir-btn" aria-label="${t('aria_cerrar_sesion', 'Cerrar sesion')}"
            class="w-full flex items-center gap-2.5 px-4 py-2.5 text-left text-slate-700 hover:bg-red-50 text-sm font-semibold border-t border-slate-100">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
      <span>${t('cerrar_sesion', 'Cerrar sesi\u00f3n')}</span>
    </button>
  </div>
  </div>`;

  const btn = document.getElementById("hamburger");
  const menu = document.getElementById("menu");
  const backdrop = document.getElementById("menu-backdrop");
  // duracion de la animacion de cierre, ver @keyframes menuSlideOut en
  // styles.css. se necesita en js para saber cuando recien esconder,
  // agregar la clase hidden, sin cortar la animacion a la mitad. lo
  // correcto seria leerla del css, pero eso complica de mas para una
  // duracion que no cambia. si se toca el keyframe, tocar esto tambien
  const MENU_CIERRE_MS = 180;
  let cierreTimer = null;

  function abrir() {
    clearTimeout(cierreTimer);
    menu.classList.remove("hidden", "cerrando");
    backdrop.classList.remove("hidden", "cerrando");
    // fuerza un reflow para que el navegador registre el estado sin
    // hidden antes de agregar la clase que dispara la animacion. si
    // no, a veces se salta directo al estado final sin animar, mismo
    // frame de render
    void menu.offsetWidth;
    menu.classList.add("abriendo");
    backdrop.classList.add("abriendo");
    btn.setAttribute("aria-expanded", "true");
    document.body.classList.add("hz-menu-open");
  }
  function cerrar() {
    if (menu.classList.contains("hidden")) return;  // ya cerrado, nada que animar
    menu.classList.remove("abriendo");
    backdrop.classList.remove("abriendo");
    menu.classList.add("cerrando");
    backdrop.classList.add("cerrando");
    btn.setAttribute("aria-expanded", "false");
    document.body.classList.remove("hz-menu-open");
    clearTimeout(cierreTimer);
    cierreTimer = setTimeout(() => {
      menu.classList.add("hidden");
      backdrop.classList.add("hidden");
      menu.classList.remove("cerrando");
      backdrop.classList.remove("cerrando");
    }, MENU_CIERRE_MS);
  }

  btn.addEventListener("click", (e) => {
    e.stopPropagation();
    menu.classList.contains("hidden") ? abrir() : cerrar();
  });
  backdrop.addEventListener("click", cerrar);
  document.addEventListener("click", cerrar);
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") cerrar(); });
  menu.addEventListener("click", (e) => e.stopPropagation());

  // toggle de tema
  const temaBtn = document.getElementById("tema-btn");
  const SOL = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.4 1.4M17.6 17.6L19 19M19 5l-1.4 1.4M6.4 17.6L5 19"/></svg>';
  const LUNA = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>';
  function pintarTemaBtn() {
    const dark = document.documentElement.classList.contains("dark");
    temaBtn.innerHTML = (dark ? SOL : LUNA) + `<span>${dark ? t('modo_claro', 'Modo claro') : t('modo_oscuro', 'Modo oscuro')}</span>`;
  }
  pintarTemaBtn();
  temaBtn.addEventListener("click", () => {
    const dark = document.documentElement.classList.toggle("dark");
    localStorage.setItem("tema", dark ? "dark" : "light");
    pintarTemaBtn();
    document.dispatchEvent(new CustomEvent("temacambio", { detail: { dark } }));
  });

  // cerrar sesion. vuelve a la portada y olvida el rol, ver sesion.js
  const salirBtn = document.getElementById("salir-btn");
  if (salirBtn) {
    salirBtn.addEventListener("click", () => {
      if (typeof cerrarSesion === "function") cerrarSesion();
      else location.href = "/";
    });
  }

  // dropdown de idioma, junto a la campana. elegir uno guarda la
  // preferencia y vuelve a pintar el header entero. es la forma mas
  // simple de refrescar todo el texto traducido sin mantener un
  // segundo camino de actualizacion en paralelo. es dry: renderHeader
  // ya sabe pintar todo esto una vez, lo reusamos en vez de duplicar la logica
  const idiomaBtn = document.getElementById("idioma-btn");
  const idiomaMenu = document.getElementById("idioma-menu");
  if (idiomaBtn && idiomaMenu) {
    idiomaBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      const abierto = !idiomaMenu.classList.toggle("hidden");
      idiomaBtn.setAttribute("aria-expanded", abierto);
    });
    idiomaMenu.querySelectorAll(".idioma-opt").forEach((op) => {
      op.addEventListener("click", (e) => {
        e.stopPropagation();
        const nuevo = op.getAttribute("data-idioma");
        if (nuevo === getIdioma()) { idiomaMenu.classList.add("hidden"); return; }
        setIdioma(nuevo);
        document.dispatchEvent(new CustomEvent("idiomacambio", { detail: { idioma: nuevo } }));
        renderHeader();
        if (typeof renderSubnav === "function") renderSubnav();
      });
    });
    document.addEventListener("click", (e) => {
      if (!idiomaMenu.contains(e.target) && !idiomaBtn.contains(e.target)) idiomaMenu.classList.add("hidden");
    });
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") idiomaMenu.classList.add("hidden"); });
  }

  // dropdown del avatar, el menu de usuario
  const avatarBtn = document.getElementById("avatar-btn");
  const avatarMenu = document.getElementById("avatar-menu");
  if (avatarBtn && avatarMenu) {
    avatarBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      const abierto = !avatarMenu.classList.toggle("hidden");
      avatarBtn.setAttribute("aria-expanded", abierto);
    });
    document.addEventListener("click", (e) => {
      if (!avatarMenu.contains(e.target) && !avatarBtn.contains(e.target)) avatarMenu.classList.add("hidden");
    });
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") avatarMenu.classList.add("hidden"); });
  }

  // editar nombre, inline en el dropdown y persistente
  const editarBtn = document.getElementById("nombre-editar-btn");
  const editBox = document.getElementById("nombre-edit");
  const input = document.getElementById("nombre-input");
  const guardarBtn = document.getElementById("nombre-guardar");
  const cancelarBtn = document.getElementById("nombre-cancelar");
  if (editarBtn && editBox && input && guardarBtn && cancelarBtn) {
    function abrirEdicion() {
      input.value = getUserName();
      editBox.classList.remove("hidden");
      editarBtn.classList.add("hidden");
      input.focus();
      input.select();
    }
    function cerrarEdicion() {
      editBox.classList.add("hidden");
      editarBtn.classList.remove("hidden");
    }
    function guardar() {
      const nuevo = input.value.trim();
      if (!nuevo) { input.focus(); return; }
      setUserName(nuevo);
      if (typeof actualizarNombreSesion === "function") actualizarNombreSesion(nuevo);
      const inis = getIniciales(nuevo);
      document.getElementById("avatar-nombre").textContent = nuevo;
      const a1 = document.getElementById("avatar-iniciales");
      const a2 = document.getElementById("avatar-iniciales-menu");
      if (a1) a1.textContent = inis;
      if (a2) a2.textContent = inis;
      cerrarEdicion();
      document.dispatchEvent(new CustomEvent("nombrecambio", { detail: { nombre: nuevo } }));
    }
    editarBtn.addEventListener("click", (e) => { e.stopPropagation(); abrirEdicion(); });
    guardarBtn.addEventListener("click", (e) => { e.stopPropagation(); guardar(); });
    cancelarBtn.addEventListener("click", (e) => { e.stopPropagation(); cerrarEdicion(); });
    input.addEventListener("click", (e) => e.stopPropagation());
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") { e.preventDefault(); guardar(); }
      else if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); cerrarEdicion(); }
    });
  }

  setupCampana();
}

// campana de notificaciones, en el header de todas las paginas.
// formato compacto a proposito. esto se pinta en columnas angostas,
// tarjetas de alertas activas y eventos recientes en inicio, y panel
// de notificaciones. antes, cualquier cosa de 24 horas o mas caia
// directo a toLocaleString completo, por ejemplo "08-09-2026, 7:39:00
// p. m.", unos 26 caracteres. eso empujaba tanto la columna del
// titulo que una palabra larga sin donde partirse, por ejemplo
// "emergencia", se desbordaba de su caja y quedaba pisando
// visualmente el texto de la fecha, bug reportado en alertas
// activas. con un tramo intermedio, "hace 3 d", y una fecha corta sin
// segundos como tope, el peor caso ronda los 12 o 13 caracteres en vez de 26
function _tiempoRel(ts) {
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return "hace instantes";
  if (s < 3600) return "hace " + Math.floor(s / 60) + " min";
  if (s < 86400) return "hace " + Math.floor(s / 3600) + " h";
  if (s < 604800) return "hace " + Math.floor(s / 86400) + " d";
  return new Date(ts).toLocaleDateString("es-CL", { day: "2-digit", month: "short" });
}
function setupCampana() {
  const campana = document.getElementById("campana");
  const panel = document.getElementById("panel-notif");
  const badge = document.getElementById("campana-badge");
  if (!campana || !panel || !badge) return;

  function renderBadge() {
    const u = notifUnread();
    if (u > 0) { badge.textContent = u > 9 ? "9+" : u; badge.classList.remove("hidden"); }
    else badge.classList.add("hidden");
  }
  function renderLista() {
    const hist = notifHistGet().slice(0, 10);
    const lista = document.getElementById("notif-lista");
    lista.innerHTML = hist.length
      ? hist.map((n, idx) => { const m = SEV_META[n.sev] || SEV_META.info; const clickable = n.href ? " notif-item--link" : ""; return `<div class="notif-item${clickable}" style="border-left:3px solid ${m.color}" data-idx="${idx}" data-href="${escHtml(n.href)}"><span class="ni-badge" style="background:${m.color}">${m.sym}</span>`
          + `<div class="ni-body"><div class="ni-t">${escHtml(n.titulo)}</div><div class="ni-m">${renderNotifRows(n.msg)}</div><div class="ni-time">${_tiempoRel(n.t)}</div></div>`
          + `<button class="notif-del" data-idx="${idx}" aria-label="${t('aria_eliminar_notif', 'Eliminar notificaci\u00f3n')}" title="${t('title_eliminar', 'Eliminar')}">\u00d7</button></div>`; }).join("")
      : `<div class="notif-vacio"><svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="#cbd5e1" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg><p>${t('notif_vacio_t', 'Sin notificaciones a\u00fan')}</p><span>${t('notif_vacio_s', 'Te avisaremos apenas ocurra algo importante')}</span></div>`;
    renderBadge();
  }
  campana.addEventListener("click", (e) => {
    e.stopPropagation();
    pedirPermisoNotif();  // gesto real del usuario. aqui el navegador si muestra el popup
    const abierto = !panel.classList.toggle("hidden");
    campana.setAttribute("aria-expanded", abierto);
    if (abierto) { notifMarkRead(); renderLista(); }
  });
  document.addEventListener("click", (e) => {
    if (!panel.contains(e.target) && !campana.contains(e.target)) panel.classList.add("hidden");
  });
  window.addEventListener("hz-notif", () => { renderBadge(); if (!panel.classList.contains("hidden")) renderLista(); });
  document.getElementById("notif-limpiar").addEventListener("click", () => { notifHistClear(); renderLista(); });
  document.getElementById("notif-lista").addEventListener("click", (e) => {
    const btn = e.target.closest(".notif-del");
    if (btn) {
      e.stopPropagation();
      notifHistRemove(parseInt(btn.dataset.idx, 10));
      renderLista();
      return;
    }
    const item = e.target.closest(".notif-item--link");
    if (item && item.dataset.href) { window.location.href = item.dataset.href; }
  });
  document.getElementById("prueba-amarilla").addEventListener("click", () =>
    notificar("PRUEBA: Alerta amarilla", "Sonido de aviso amarillo (precauci\u00f3n).", "amarilla"));
  document.getElementById("prueba-roja").addEventListener("click", () =>
    notificar("PRUEBA: Alerta ROJA", "Sonido de alerta roja (evacuaci\u00f3n).", "roja"));
  renderLista();
}

async function fetchEvents(refrescar = false) {
  const ctrl = new AbortController();
  // el backend sale a internet via powershell mas proxy corporativo por
  // cada fuente, conaf dmc senapred etc, con hasta 60 segundos de
  // timeout por fuente. 20 segundos se quedaba corto y abortaba la
  // request antes de que el backend terminara, dando "signal is
  // aborted without reason". 75 segundos cubre el peor caso, una
  // fuente lenta al limite, con margen, sin dejar la ui colgada para siempre
  const timeoutId = setTimeout(() => ctrl.abort(), 75000);
  try {
    const r = await fetch("/api/events" + (refrescar ? "?refrescar=true" : ""), { signal: ctrl.signal });
    return await r.json();
  } finally {
    clearTimeout(timeoutId);
  }
}

// eventos que dejaron de estar vigentes, retencion de 15 dias, ver
// historial.py. es una simple lectura de db, no dispara scraping ni
// necesita timeout largo como fetchEvents
async function fetchHistorial() {
  const r = await fetch("/api/historial");
  return await r.json();
}

// metadata visual por severidad, una sola fuente de verdad para toda la ui
const SEV_META = {
  roja:     { color: "#dc2626", icon: "\uD83D\uDD34", sym: "!" },
  naranja:  { color: "#ea580c", icon: "\uD83D\uDFE0", sym: "!" },
  amarilla: { color: "#d97706", icon: "\uD83D\uDFE1", sym: "!" },
  verde:    { color: "#16a34a", icon: "\uD83D\uDFE2", sym: "\u2713" },
  info:     { color: "#2563eb", icon: "\u2139\uFE0F", sym: "i" },
};

function badgeSev(sev) {
  const m = SEV_META[sev] || SEV_META.info;
  return `<span class="badge" style="background:${m.color}"><span class="dot"></span>${escHtml(sev)}</span>`;
}

// sucursal con 2 o mas eventos vigentes encima, compartido por inicio
// mapa sucursales y estadisticas, es dry. ver stores.py stores_at_risk:
// una tienda ya no pierde sus demas eventos por quedarse solo con el
// mas cercano, ahora vienen todos en t.eventos, y estas 3 funciones
// son el unico lugar donde se decide como mostrar eso, texto
// resumido, celda interactiva con el detalle, o el chequeo de
// pertenencia para contar sucursales por evento.

// texto plano para reportes que no pueden llevar html interactivo, pdf
// exportables. el evento si es uno solo, o un resumen de "n eventos vigentes"
function eventoCercanoTexto(t) {
  const eventos = t.eventos || [];
  return eventos.length > 1 ? `${eventos.length} eventos vigentes` : t.evento;
}

// celda interactiva para tablas en pantalla. si hay mas de un evento, un
// details plegable con la lista completa. mismo simbolo que el popup
// de region del mapa, circulo tenue mas icono del tipo coloreado por
// severidad, en vez de una badge de texto. la badge, "amarilla" mas
// punto, ocupaba mucho espacio al lado de la fecha y hora y quedaba
// desprolija con 2 o mas filas. onclick con stopPropagation porque las
// filas de estas tablas navegan al mapa al hacer click, si no, abrir
// el desplegable tambien dispararia esa navegacion
function eventoCercanoCelda(t) {
  const eventos = t.eventos || [];
  if (eventos.length <= 1) return escHtml(t.evento);
  const items = eventos.map(e => {
    const c = (SEV_META[e.severidad] || SEV_META.info).color;
    const glyph = glyphTipo(e.tipo).replaceAll('#fff', c);
    return `<li><span class="reg-pop-ic" style="background:${c}1a"><svg width="14" height="14" viewBox="0 0 24 24">${glyph}</svg></span>
      ${escHtml(e.evento)}${e.fecha ? ` <span class="hz-ev-fecha">${escHtml(e.fecha)}</span>` : ''}</li>`;
  }).join('');
  return `<details class="hz-eventos-det" onclick="event.stopPropagation()">
    <summary>${eventos.length} eventos vigentes</summary>
    <ul class="hz-eventos-list">${items}</ul>
  </details>`;
}

// si una tienda esta en riesgo por un evento puntual, por su titulo,
// revisa todos sus eventos vigentes, no solo el mas cercano, t.evento
function tiendaTieneEvento(t, tituloEvento) {
  return (t.eventos && t.eventos.length ? t.eventos : [t]).some(e => e.evento === tituloEvento);
}

// modelo de riesgo, compartido por inicio y mapa, es dry.
// a) riesgo por cobertura: que proporcion de la red de sucursales esta
//    afectada. devuelve pct nivel y color. con 45 de 396, un 11%
//    aproximado, da "medio", no "alto"
function riesgoCobertura(afectadas, total) {
  const pct = total > 0 ? (afectadas / total) * 100 : 0;
  let nivel, color;
  if (afectadas <= 0) { nivel = "Sin impacto"; color = "#16a34a"; }
  else if (pct < 5)   { nivel = "Bajo";        color = "#16a34a"; }
  else if (pct < 15)  { nivel = "Medio";       color = "#d97706"; }
  else if (pct < 30)  { nivel = "Alto";        color = "#ea580c"; }
  else                { nivel = "Critico";     color = "#dc2626"; }
  return { pct, nivel, color };
}
// c) estado general, matriz de 2 ejes: severidad (la peor alerta que toca
//    a alguna sucursal, tal cual viene de la fuente oficial) x cobertura
//    (el % de la red afectada). la cantidad de eventos no mueve el estado,
//    es solo un dato informativo aparte. la cobertura se agrupa en 3 bandas
//    reutilizando los umbrales de riesgoCobertura: baja, media y alta.
//    una alerta amarilla sobre gran parte de la red da "Atencion", no "Critico"
const ESTADO_META = {
  tranquilo: { label: "Tranquilo", color: "#16a34a", bg: "#dcfce7" },
  atencion:  { label: "Atención", color: "#d97706", bg: "#fef3c7" },
  alto:      { label: "Alto",      color: "#ea580c", bg: "#ffedd5" },
  critico:   { label: "Crítico", color: "#dc2626", bg: "#fee2e2" },
};
// filas: severidad, columnas: cobertura baja, media, alta
const MATRIZ_ESTADO = {
  amarilla: ["tranquilo", "atencion", "atencion"],
  naranja:  ["atencion",  "alto",     "alto"],
  roja:     ["alto",      "critico",  "critico"],
};
const BANDA_COBERTURA = [
  { label: "Baja",  color: "#16a34a" },
  { label: "Media", color: "#d97706" },
  { label: "Alta",  color: "#ea580c" },
];
function estadoSistema(tiendasEnRiesgo, totalTiendas) {
  const tiendas = tiendasEnRiesgo || [];
  const r = riesgoCobertura(tiendas.length, totalTiendas);
  const idxCob = ["Sin impacto", "Bajo"].includes(r.nivel) ? 0 : r.nivel === "Critico" ? 2 : 1;
  const cobertura = { ...BANDA_COBERTURA[idxCob], pct: r.pct };
  const sev = ["roja", "naranja", "amarilla"].find((s) => tiendas.some((t) => t.severidad === s)) || null;
  const clave = sev ? MATRIZ_ESTADO[sev][idxCob] : "tranquilo";
  return { ...ESTADO_META[clave], clave, sev, cobertura, afectadas: tiendas.length };
}

// b) riesgo critico: sucursales cuya alerta mas cercana es roja, nivel evacuacion
function contarSucursalesRojas(tiendas) {
  return (tiendas || []).filter((t) => t.severidad === "roja").length;
}

// una alerta preventiva, por ejemplo verde de senapred, se guarda en el
// historial pero no se dibuja en el mapa, flag mapa=false desde el
// backend. definicion unica y compartida para que el mapa y el
// historial concuerden, misma nocion de activa
function esPreventiva(e) { return !!(e && e.mapa === false); }
function contarActivas(eventos) { return (eventos || []).filter((e) => !esPreventiva(e)).length; }

// metadata visual por tipo de catastrofe, una sola fuente de verdad, es dry
const TIPO_META = {
  sismo:         { label: "Sismo",                 corto: "Sismos",       color: "#475569", fuente: "USGS y CSN" },
  incendio:      { label: "Incendio forestal",      corto: "Incendios",    color: "#ea580c", fuente: "CONAF" },
  volcan:        { label: "Actividad volcánica",    corto: "Volcanes",     color: "#b91c1c", fuente: "SERNAGEOMIN" },
  meteorologico: { label: "Evento meteorológico",   corto: "Meteorología", color: "#2563eb", fuente: "DMC" },
  alerta:        { label: "Alerta de emergencia",   corto: "Alertas",      color: "#7c3aed", fuente: "SENAPRED" },
};
function nombreTipo(tipo) { return (TIPO_META[tipo] || {}).label || tipo; }

// cada formato de tienda: color de acento, logo real, usado en el
// badge chico de tiendas y en el header del popup, y el pin de mapa
// nuevo, arte 3d tipo gota con la fachada del local, un asset por
// formato, ver tools/cortar_pines.py. pinRatio es el ancho sobre el
// alto natural del recorte, para que pinTienda en mapa.html calcule
// el icono sin deformarlo ni recortarlo con letterboxing. compartido
// entre el mapa, pin mas leyenda, y tiendas en riesgo, badge de logo
const FORMATO_META = [
  { match: f => f.includes("acuenta"), nombre: "Superbodega Acuenta", logo: "/static/logos/acuenta.png",
    // pin cambiado a pedido de antonella, 29-09-2026, por la foto real del
    // letrero "SuperBodega aCuenta" que dejo en Downloads, en vez del arte
    // 3d tipo gota que usan los otros tres formatos. por eso el ratio es
    // mucho mas angosto que alto, 1036/1421, y no un valor cercano a 1: es
    // un letrero completo con su poste hasta la base, no una fachada
    // recortada pareja. ver tools/reemplazar_pin_acuenta.py
    pin: "/static/logos/pin-acuenta.png", pinRatio: 1036 / 1421 },
  // pines de express y mayorista cambiados a pedido de antonella,
  // 29-09-2026 (misma tanda que acuenta): fotos reales del letrero/totem
  // con poste, no el arte 3d tipo gota original. igual que acuenta, la
  // proporcion cambia harto porque el letrero se extiende casi de borde a
  // borde del canvas. ver tools/reemplazar_pin_express_mayorista.py
  { match: f => f.includes("express"), nombre: "Express de Lider", logo: "/static/logos/express.jpg",
    pin: "/static/logos/pin-express.png", pinRatio: 1024 / 1515 },
  { match: f => f.includes("central") || f.includes("mayorista"), nombre: "Central Mayorista", logo: "/static/logos/mayorista.png",
    pin: "/static/logos/pin-central.png", pinRatio: 1024 / 1529 },
  { match: f => f === "lider", nombre: "Lider", logo: "/static/logos/lider.png",
    pin: "/static/logos/pin-lider.png", pinRatio: 928 / 1522 },
];
// instalaciones que no son tiendas: oficinas, centros de distribucion,
// plantas. las claves calzan con TIPOS en instalaciones.py.
// pin cambiado a pedido de antonella, 29-09-2026: antes se dibujaba un
// pin svg generico en azul walmart al vuelo (misma forma para las tres,
// solo cambiaba el trazo interior), y costaba distinguirlas de un
// vistazo en el mapa. ahora cada una usa su propia ilustracion real
// (torre = oficina, bodega con camion = cd, fabrica con chimeneas =
// planta), mismo criterio de recorte que los pines de tienda. ver
// tools/reemplazar_pins_instalaciones.py
// tamanoBase: 70 en vez del default de 50 (ver PIN_TAMANO_BASE en
// mapa.html). pedido de antonella 29-09-2026: con el default se veian
// chicos de cerca, porque al ser fotos horizontales (pinRatio > 1) el
// lado mas largo que se fija segun zoom es el ANCHO, no el alto -- y
// esa foto se ve mas "grandecita" con algo mas de tamano base que un
// pin angosto de tienda. instalaciones son pocas (a diferencia de las
// tiendas, que son cientos), asi que no hay riesgo de amontonamiento
// aunque sean un poco mas grandes.
const TIPO_INST_META = {
  oficina: { nombre: "Oficina", pin: "/static/logos/pin-oficina.png", pinRatio: 1440 / 1024, tamanoBase: 70 },
  cd:      { nombre: "Centro de distribucion", pin: "/static/logos/pin-cd.png", pinRatio: 671 / 365, tamanoBase: 70 },
  planta:  { nombre: "Planta productiva", pin: "/static/logos/pin-planta.png", pinRatio: 572 / 427, tamanoBase: 70 },
};

/**
 * identidad visual de una instalacion: color, logo y pin.
 *
 * acepta el objeto entero, lo preferido, o solo el string de formato,
 * por compatibilidad con las llamadas viejas. una oficina, un cd o una
 * planta no tienen formato comercial. antes caian en el objeto por
 * defecto con pin null, y el mapa terminaba pintando un img con src
 * null, un pin roto.
 */
function metaFormato(inst) {
  const esObjeto = inst && typeof inst === "object";
  const tipo = esObjeto ? inst.tipo : null;
  const formato = esObjeto ? inst.formato : inst;

  if (tipo && tipo !== "sucursal" && TIPO_INST_META[tipo]) {
    const m = TIPO_INST_META[tipo];
    return { nombre: m.nombre, logo: m.pin, pin: m.pin, pinRatio: m.pinRatio, tamanoBase: m.tamanoBase, esInstalacion: true, tipo };
  }

  const f = (formato || "").toLowerCase();
  return FORMATO_META.find(m => m.match(f))
    || { nombre: formato || "Instalacion", letra: "?", logo: null, pin: null, pinRatio: 1 };
}

/** nombre legible de una instalacion, sea tienda de lider o carga manual. */
function nombreInstalacion(t) {
  return (t && (t.nombre || t.formato)) || "Instalacion";
}

// simbolo, glifo svg interior blanco, segun tipo de catastrofe.
// compartido entre el mapa, index.html, y las estadisticas
function glyphTipo(tipo) {
  const W = "#fff";
  switch (tipo) {
    case "incendio":
      return `<path fill="${W}" d="M13.5.67s.74 2.65.74 4.8c0 2.06-1.35 3.73-3.41 3.73-2.07 0-3.63-1.67-3.63-3.73l.03-.36C5.21 7.51 4 10.62 4 14c0 4.42 3.58 8 8 8s8-3.58 8-8C20 8.61 17.41 3.8 13.5.67zM11.71 19c-1.78 0-3.22-1.4-3.22-3.14 0-1.62 1.05-2.76 2.81-3.12 1.77-.36 3.6-1.21 4.62-2.58.39 1.29.59 2.65.59 4.04 0 2.65-2.15 4.8-4.8 4.8z"/>`;
    case "meteorologico":
      return `<path fill="${W}" d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96z"/>`;
    case "volcan":
      // montana de dos picos con un crater marcado en el medio mas
      // una nube de humo saliendo. la version vieja, un trapecio liso
      // sin crater ni humo, no se leia como volcan a simple vista,
      // esta se identifica de una
      return `<path fill="${W}" d="M3 20 L9 8 L11 11 L13 11 L15 8 L21 20 Z"/><circle cx="12.4" cy="4.6" r="2.1" fill="${W}"/><circle cx="15.4" cy="3.1" r="1.3" fill="${W}"/>`;
    case "sismo":
      return `<polyline points="2,12 6,12 9,4 13,20 16,10 18,14 22,14" fill="none" stroke="${W}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>`;
    case "alerta":
      return `<path fill="${W}" d="M12 2 1 21h22L12 2zm0 5.5 6.9 11.9H5.1L12 7.5zM11 10v4h2v-4h-2zm0 5v2h2v-2h-2z"/>`;
    default:
      return `<text x="12" y="18" text-anchor="middle" font-size="17" font-weight="800" fill="${W}" font-family="Inter,sans-serif">!</text>`;
  }
}

// orden de gravedad de una severidad, menor es mas grave. compartido, es dry
const RANK_SEV = { roja: 0, naranja: 1, amarilla: 2, info: 3, verde: 4 };

// tabla de eventos, compartida entre eventos vigentes e historial.
// botones de filtro por fuente, pintados dentro de cont. onClick recibe la fuente elegida
function renderFiltrosFuente(cont, eventos, filtroActual, onClick) {
  const fuentes = ['TODAS', ...new Set(eventos.map(e => e.source))];
  cont.innerHTML = '';
  fuentes.forEach(f => {
    const activo = f === filtroActual;
    const b = document.createElement('button');
    b.textContent = f;
    b.className = 'px-3 py-1 rounded-full text-xs font-semibold transition '
      + (activo ? 'bg-blue-700 text-white shadow' : 'bg-white text-slate-600 hover:bg-blue-50 border border-slate-200');
    b.onclick = () => onClick(f);
    cont.appendChild(b);
  });
}

// ordena una lista de eventos segun el criterio del selector ordenar
// por, mismo menu en eventos vigentes e historial, misma logica, es dry
function ordenarEventos(lista, criterio) {
  const arr = lista.slice();
  switch (criterio) {
    case 'recientes': arr.sort((a, b) => fechaVal(b) - fechaVal(a)); break;
    case 'antiguos':  arr.sort((a, b) => fechaVal(a) - fechaVal(b)); break;
    case 'severidad': arr.sort((a, b) => (RANK_SEV[a.severidad] ?? 9) - (RANK_SEV[b.severidad] ?? 9)); break;
    case 'vigencia':  arr.sort((a, b) => (b.activa === true) - (a.activa === true)); break;
    case 'fuente':    arr.sort((a, b) => (a.source > b.source ? 1 : -1)); break;
  }
  return arr;
}

// una fila de la tabla de eventos vigentes. "ver detalle" manda al
// mapa, donde el evento si se ve porque sigue activo. el historial
// tiene su propia funcion, filaHistorialHTML mas abajo, porque diverge
// en casi todo: no navega a ningun lado, abre una card flotante, y
// suma una columna de icono. meterlo todo en una sola funcion con ifs
// por modo terminaba siendo mas dificil de leer que dos funciones
// chicas y separadas
function filaEventoHTML(e) {
  const clave = (e.titulo || '') + '|' + (e.fecha || '');
  const url = `/mapa?alerta=${encodeURIComponent(clave)}`;
  const dot = e.activa ? '#16a34a' : '#94a3b8';
  const estado = e.estado || (e.activa ? 'Activa' : 'Finalizada');
  const colEstado = `<span style="display:inline-flex;align-items:center;gap:5px"><span style="width:8px;height:8px;border-radius:9999px;background:${dot};display:inline-block"></span>${escHtml(estado)}</span>`;
  const flechaSvg = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>';
  const colVer = `<a href="${url}" class="hz-ver-mapa" aria-label="Ver detalle de ${escHtml(e.titulo)}" onclick="event.stopPropagation()">Ver detalle ${flechaSvg}</a>`;
  return `<tr class="hz-fila-clic" data-href="${url}">
    <td class="font-semibold">${escHtml(e.source)}</td>
    <td class="capitalize">${escHtml(e.tipo)}</td>
    <td>${escHtml(e.titulo)}</td>
    <td>${badgeSev(e.severidad)}</td>
    <td>${colEstado}</td>
    <td>${escHtml(e.fecha || '\u2014')}</td>
    <td>${escHtml(e.comuna || e.region || '\u2014')}</td>
    <td>${colVer}</td>
  </tr>`;
}

// fila de la tabla del historial. mismas columnas que filaEventoHTML
// mas un icono a la izquierda, coloreado por severidad, glifo por
// tipo, ayuda a distinguir de un vistazo, pedido explicito, y sin
// link. el evento ya no esta vigente, "ver detalle" abre una card
// flotante en la misma pagina, ver abrirDetalleHistorial en
// historial.html y construirDetalleEventoHTML mas abajo, compartida
// con el mapa, es dry, en vez de mandar a un mapa vacio.
// idx es la posicion del evento en la lista actualmente pintada, para
// poder recuperarlo al clickear
function filaHistorialHTML(e, idx) {
  const meta = SEV_META[e.severidad] || SEV_META.info;
  const flechaSvg = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>';
  // ojo: el boton no debe frenar la propagacion del click. no navega
  // a ningun lado por si solo, depende de que el click le llegue a la
  // tr, ver listener en historial.html, para que
  // abrirDetalleHistorial lo abra. stopPropagation aca lo dejaba
  // muerto, "ver detalle" no hacia nada
  const colVer = `<button type="button" class="hz-ver-mapa" data-idx="${idx}" aria-label="Ver detalle de ${escHtml(e.titulo)}">Ver detalle ${flechaSvg}</button>`;
  return `<tr class="hz-fila-clic" data-idx="${idx}">
    <td class="hz-td-icono"><span class="hz-row-ic" style="background:${meta.color}"><svg width="14" height="14" viewBox="0 0 24 24">${glyphTipo(e.tipo)}</svg></span></td>
    <td class="font-semibold">${escHtml(e.source)}</td>
    <td class="capitalize">${escHtml(e.tipo)}</td>
    <td>${escHtml(e.titulo)}</td>
    <td>${badgeSev(e.severidad)}</td>
    <td>${escHtml(e.fecha || '\u2014')}</td>
    <td>${escHtml(e.comuna || e.region || '\u2014')}</td>
    <td>${colVer}</td>
  </tr>`;
}

// el resplandor neon del modal de detalle es azul walmart por
// defecto, .modal-box en styles.css, el mismo que usa el modal de
// agregar instalacion. para el detalle de un evento eso no dice nada:
// un sismo m7 y una alerta amarilla se ven exactamente igual de
// "graves". esto le pisa el color por severidad real, roja naranja
// amarilla o verde, y lo deja en el azul de siempre para cualquier
// severidad rara, info por ejemplo, o si no se le llama. se resetea
// solo al abrir la proxima, pero cerrarModal en cada pagina igual lo
// limpia por prolijidad
function aplicarColorSeveridadModal(severidad) {
  const box = document.querySelector('#modal .modal-box');
  if (!box) return;
  box.classList.remove('sev-roja', 'sev-naranja', 'sev-amarilla', 'sev-verde');
  if (['roja', 'naranja', 'amarilla', 'verde'].includes(severidad)) {
    box.classList.add(`sev-${severidad}`);
  }
}

// contenido del modal de detalle de un evento: datos mas zonas y
// comunas afectadas mas sucursales cercanas, 30 km o menos. compartida
// entre el mapa, abrirDetalle, que ademas dispara el efecto visual, y
// el historial, abrirDetalleHistorial, sin efecto porque ahi no hay
// mapa ni fx-layer, para no duplicar esta logica en dos lados, es dry.
// todosEventos se usa solo para agrupar hermanos, alerta senapred multi
// comuna, zonas meteorologicas. alcanza con pasar la lista que cada
// pagina ya tiene a mano
function construirDetalleEventoHTML(e, todosEventos, rawTiendas) {
  const nombreTipoTxt = nombreTipo(e.tipo);

  let grupoEventos = [e];
  if (e.tipo === 'alerta' && e.source === 'SENAPRED') {
    grupoEventos = (todosEventos || []).filter(x => x.tipo === 'alerta' && x.source === 'SENAPRED' && x.titulo === e.titulo);
  }
  const puntos = grupoEventos.filter(g => g.lat != null && g.lon != null);

  let tiendasHtml = '<p style="color:#64748b">Sin coordenadas para calcular cercania.</p>';
  if (puntos.length && (rawTiendas || []).length) {
    // se pregunta por el area real de cada evento, ver distanciaArea,
    // no por un radio fijo: la comuna que declara senapred, el
    // poligono de la dmc o el radio que corresponde a esa magnitud o superficie
    const cerca = rawTiendas
      .map(t => {
        const ds = puntos.map(p => distanciaArea(p, t.lat, t.lon)).filter(d => d !== null);
        return ds.length ? { t, d: Math.min(...ds) } : null;
      })
      .filter(Boolean)
      .sort((a, b) => a.d - b.d);
    const areaTxt = (puntos.find(p => p.area) || {}).area?.motivo || 'el area afectada';
    if (cerca.length === 0) {
      tiendasHtml = `<p style="color:#16a34a">Ninguna sucursal dentro de ${escHtml(areaTxt)}.</p>`;
    } else {
      tiendasHtml = `<p style="margin-bottom:.4rem"><b>${cerca.length}</b> sucursal(es) en ${escHtml(areaTxt)}:</p>`
        + cerca.slice(0, 12).map(x => `<div class="kv"><b>${x.d === 0 ? 'dentro' : x.d.toFixed(1) + ' km'}</b> ${escHtml(nombreInstalacion(x.t))} \u2014 ${escHtml(x.t.comuna)}</div>`).join('')
        + (cerca.length > 12 ? `<p style="color:#64748b">\u2026 y ${cerca.length - 12} mas</p>` : '');
    }
  }

  let zonasHtml = '';
  if (e.tipo === 'meteorologico') {
    const fenomeno = (e.titulo || '').split(' (')[0];
    const zonas = (todosEventos || []).filter(x => x.tipo === 'meteorologico' && (x.titulo || '').split(' (')[0] === fenomeno);
    const nombres = [...new Set(zonas.map(z => z.region).filter(Boolean))];
    if (nombres.length) {
      zonasHtml = `<h4>Zonas afectadas (${nombres.length})</h4><div>` +
        nombres.map(n => `<span class="chip-zona">${escHtml(n)}</span>`).join('') + '</div>';
    }
  } else if (grupoEventos.length > 1) {
    const nombres = [...new Set(grupoEventos.map(z => z.comuna || z.region).filter(Boolean))];
    if (nombres.length) {
      zonasHtml = `<h4>Comunas afectadas (${nombres.length})</h4><div>` +
        nombres.map(n => `<span class="chip-zona">${escHtml(n)}</span>`).join('') + '</div>';
    }
  }

  // ojo: e.activa y e.estado son una foto de cuando el evento todavia
  // estaba vigente, asi los guarda el historial, ver historial.py. un
  // evento archivado, tiene archivado_en, hay que mostrarlo como
  // archivado siempre, sin importar lo que diga esa foto vieja. si no,
  // la card dice "vigente" para algo que dejo de estarlo hace dias
  const archivado = !!e.archivado_en;
  const dot = archivado ? '#94a3b8' : (e.activa ? '#16a34a' : '#94a3b8');
  const estadoTxt = archivado
    ? `Archivado ${_tiempoRel(new Date(e.archivado_en).getTime())}`
    : (e.estado || (e.activa ? 'Activa' : 'Finalizada'));
  const localidad = e.comuna || e.region;
  return `
    <div class="modal-cab" style="background:${escHtml(e.color)}">
      <h3>${escHtml(e.titulo)}</h3>
      <div class="sub">${escHtml(nombreTipoTxt)} \u00b7 ${escHtml(e.source)}</div>
    </div>
    <div class="modal-body">
      <div class="kv"><b>Severidad</b> ${badgeSev(e.severidad)}</div>
      <div class="kv"><b>Estado</b> <span style="display:inline-flex;align-items:center;gap:5px"><span style="width:8px;height:8px;border-radius:9999px;background:${dot};display:inline-block"></span>${escHtml(estadoTxt)}</span></div>
      ${e.fecha ? `<div class="kv"><b>Hora</b> ${escHtml(e.fecha)}</div>` : ''}
      ${localidad ? `<div class="kv"><b>Localidad</b> ${escHtml(localidad)}</div>` : ''}
      ${e.detalle ? `<div class="kv"><b>Detalle</b> ${escHtml(e.detalle)}</div>` : ''}
      ${(e.lat != null) ? `<div class="kv"><b>Ubicacion</b> ${(+e.lat).toFixed(3)}, ${(+e.lon).toFixed(3)}</div>` : ''}
      ${e.area ? `<div class="kv"><b>Area afectada</b> ${escHtml(e.area.motivo || (e.area.forma === 'poligono' ? 'Zona delimitada por la fuente' : e.area.radio_km + ' km'))}</div>` : ''}
      ${zonasHtml}
      <h4>Sucursales en el area afectada</h4>
      ${tiendasHtml}
    </div>`;
}

// convierte "DD-MM-YYYY HH:MM hrs" a timestamp en ms. sin fecha da -infinity
function fechaVal(e) {
  if (!e || !e.fecha) return -Infinity;
  const m = e.fecha.match(/(\d{2})-(\d{2})-(\d{4})\s+(\d{2}):(\d{2})/);
  if (!m) return -Infinity;
  return new Date(+m[3], +m[2] - 1, +m[1], +m[4], +m[5]).getTime();
}

// area afectada, espejo de app/area.py.
// el backend calcula el area de cada evento segun su naturaleza,
// magnitud del sismo, hectareas del incendio, poligono de la dmc,
// contorno de la comuna en alerta, y la manda en e.area. aca solo se
// pregunta si un punto cae adentro. la regla de cuanto abarca cada
// evento vive en un solo lugar, el backend

function _puntoEnAnillo(lat, lon, anillo) {
  let dentro = false;
  for (let i = 0, j = anillo.length - 1; i < anillo.length; j = i++) {
    const [xi, yi] = anillo[i], [xj, yj] = anillo[j];
    if ((yi > lat) !== (yj > lat) && lon < xi + (lat - yi) * (xj - xi) / (yj - yi)) dentro = !dentro;
  }
  return dentro;
}

// km hasta el borde del area: 0 si el punto esta dentro, null si queda
// fuera. devolver null, y no un numero grande, evita que cada pantalla
// tenga que reimplementar el umbral. basta con preguntar si es null
function distanciaArea(e, lat, lon) {
  const a = e.area;
  if (!a) {
    // evento sin area, fuente que no informa su tamano. radio
    // generico, el mismo fallback que usa el backend
    const d = haversine(e.lat, e.lon, lat, lon);
    return d <= 30 ? d : null;
  }
  if (a.forma === 'circulo') {
    const d = haversine(e.lat, e.lon, lat, lon);
    return d <= a.radio_km ? d : null;
  }
  if ((a.anillos || []).some(an => _puntoEnAnillo(lat, lon, an))) return 0;
  if (!a.margen_km) return null;
  const d = haversine(e.lat, e.lon, lat, lon);   // aproximacion para el margen
  return d <= (a.margen_km + 50) ? d : null;
}

// distancia en km entre dos coordenadas, formula de haversine
function haversine(lat1, lon1, lat2, lon2) {
  const r = 6371, rad = Math.PI / 180;
  const dLat = (lat2 - lat1) * rad, dLon = (lon2 - lon1) * rad;
  const a = Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * rad) * Math.cos(lat2 * rad) * Math.sin(dLon / 2) ** 2;
  return 2 * r * Math.asin(Math.sqrt(a));
}

// anima un numero de 0 a fin en unos 600ms, efecto count up
function animateCount(el, fin) {
  const dur = 600, t0 = performance.now();
  function paso(t) {
    const p = Math.min((t - t0) / dur, 1);
    const val = Math.round((1 - Math.pow(1 - p, 3)) * fin); // ease out cubic
    el.textContent = val;
    if (p < 1) requestAnimationFrame(paso);
  }
  requestAnimationFrame(paso);
}

// sonido, notificaciones y toasts

// un "ping" generado con webaudio, sin archivo de audio externo
let _audioCtx = null;
function _ctx() {
  _audioCtx = _audioCtx || new (window.AudioContext || window.webkitAudioContext)();
  if (_audioCtx.state === "suspended") { try { _audioCtx.resume(); } catch (e) {} }
  return _audioCtx;
}

// secuencia de beeps. notas es una lista de pares frecuencia y retardo en segundos
function _beepSeq(notes, type, gainMax, dur) {
  const ctx = _ctx(), t0 = ctx.currentTime;
  notes.forEach(([freq, delay]) => {
    const osc = ctx.createOscillator(), gain = ctx.createGain();
    osc.connect(gain); gain.connect(ctx.destination);
    osc.type = type;
    const t = t0 + delay;
    osc.frequency.setValueAtTime(freq, t);
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.exponentialRampToValueAtTime(gainMax, t + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.start(t); osc.stop(t + dur + 0.02);
  });
}

// sonido distinto segun severidad de la alerta
function ping(sev) {
  try {
    if (sev === "roja") {
      // alarma urgente: 3 beeps rapidos, onda square, tono grave medio
      _beepSeq([[523, 0], [523, 0.2], [523, 0.4]], "square", 0.18, 0.15);
    } else if (sev === "amarilla") {
      // aviso suave: 2 beeps ascendentes, onda sine
      _beepSeq([[660, 0], [880, 0.16]], "sine", 0.15, 0.22);
    } else {
      // ping neutro por defecto, el de siempre
      _beepSeq([[880, 0], [1320, 0.12]], "sine", 0.22, 0.3);
    }
  } catch (e) { /* audio no disponible */ }
}

// construye una fila "icono mas texto" para el cuerpo de una
// notificacion. varias filas se unen con salto de linea, ver
// renderNotifRows, que las pinta igual en el toast y en el panel de
// la campana. misma notificacion, misma pinta, es dry
function filaInfo(icono, texto) { return `${icono} ${texto}`; }

// emojis, pictogramas, al inicio de una linea se separan en icono mas
// texto. lineas sin icono, por ejemplo los mensajes de prueba, se
// pintan como texto plano
const _EMOJI_INICIO = /^\p{Extended_Pictographic}/u;
// el msg lo arman los llamadores (mapa.html) con <b> a proposito para
// resaltar etiquetas, mezclado con datos de la fuente (comunas, fechas).
// se escapa todo y solo se devuelve a la vida <b> y </b>, asi un dato con
// <img onerror=...> queda inerte pero el resaltado sigue funcionando.
// tambien cubre mensajes viejos que ya estan guardados en localStorage
function _msgSeguro(txt) {
  return escHtml(txt).replace(/&lt;(\/?)b&gt;/g, "<$1b>");
}
function renderNotifRows(msg) {
  return (msg || "").split("\n").filter(Boolean).map((linea) => {
    const sp = linea.indexOf(" ");
    const primero = sp > -1 ? linea.slice(0, sp) : "";
    if (sp > -1 && _EMOJI_INICIO.test(primero)) {
      return `<div class="nrow"><span class="nrow-ic">${escHtml(primero)}</span><span class="nrow-tx">${_msgSeguro(linea.slice(sp + 1))}</span></div>`;
    }
    return `<div class="nrow nrow--plain"><span class="nrow-tx">${_msgSeguro(linea)}</span></div>`;
  }).join("");
}

// historial de notificaciones, persistente en localStorage
const _NOTIF_KEY = "hz_notif_hist";
const _NOTIF_UNREAD = "hz_notif_unread";
function notifHistGet() { try { return JSON.parse(localStorage.getItem(_NOTIF_KEY) || "[]"); } catch (e) { return []; } }
function notifUnread() { return parseInt(localStorage.getItem(_NOTIF_UNREAD) || "0", 10) || 0; }
function notifMarkRead() { localStorage.setItem(_NOTIF_UNREAD, "0"); }
function notifHistAdd(sev, titulo, msg, href) {
  const hist = notifHistGet();
  hist.unshift({ t: Date.now(), sev: sev || "", titulo, href: href || "", msg: (msg || "").trim() });
  localStorage.setItem(_NOTIF_KEY, JSON.stringify(hist.slice(0, 20)));  // guardamos 20, la ui muestra 10
  localStorage.setItem(_NOTIF_UNREAD, String(notifUnread() + 1));
  try { window.dispatchEvent(new Event("hz-notif")); } catch (e) {}
}
// borra por posicion en el arreglo completo, no en la vista recortada
// a 10. funciona igual para notificaciones viejas y nuevas, sin depender de un id
function notifHistRemove(idx) {
  const hist = notifHistGet();
  hist.splice(idx, 1);
  localStorage.setItem(_NOTIF_KEY, JSON.stringify(hist));
  try { window.dispatchEvent(new Event("hz-notif")); } catch (e) {}
}
function notifHistClear() {
  localStorage.setItem(_NOTIF_KEY, "[]"); localStorage.setItem(_NOTIF_UNREAD, "0");
  try { window.dispatchEvent(new Event("hz-notif")); } catch (e) {}
}

function pedirPermisoNotif() {
  if ("Notification" in window && Notification.permission === "default") {
    Notification.requestPermission();
  }
}

function _ensureToasts() {
  let c = document.getElementById("toasts");
  if (!c) {
    c = document.createElement("div");
    c.id = "toasts";
    // si la pagina tiene un .map-wrap, por ejemplo /mapa, que puede
    // entrar en pantalla completa via fullscreen api, los toasts deben
    // vivir dentro de ese elemento. la fullscreen api oculta todo lo
    // que quede fuera del arbol del elemento fullscreen-eado, aunque
    // tenga position fixed, mismo motivo que el modal y el fx-layer
    // del mapa. en paginas sin mapa cae al body de siempre
    const contenedor = document.querySelector(".map-wrap") || document.body;
    contenedor.appendChild(c);
  }
  return c;
}

function toast(titulo, msg, sev, ms = 9000) {
  const c = _ensureToasts();
  const m = SEV_META[sev] || SEV_META.info;
  const el = document.createElement("div");
  el.className = "toast";
  el.style.setProperty("--toast-color", m.color);
  el.style.setProperty("--toast-ms", ms + "ms");
  el.innerHTML = `
    <span class="toast-ic" style="background:${m.color}">${m.sym}</span>
    <div class="toast-body">
      <div class="toast-head">
        <span class="toast-brand"><img src="/static/logos/spark.webp" alt="" width="11" height="11" />Agente Hazzi</span>
        <button class="toast-x" aria-label="Cerrar notificaci\u00f3n" title="Cerrar">&times;</button>
      </div>
      <div class="toast-title">${escHtml(titulo)}</div>
      <div class="toast-msg">${renderNotifRows(msg)}</div>
    </div>
    <span class="toast-bar"></span>`;
  el.querySelector(".toast-x").addEventListener("click", () => el.remove());
  c.appendChild(el);
  setTimeout(() => el.remove(), ms);
}

// notifica por el navegador si hay permiso, si no, muestra un toast.
// sev es roja, amarilla o vacio, y define el sonido y el color en el historial.
// href, opcional, es a donde llevar al usuario si aprieta la
// notificacion en la campanita
function notificar(titulo, msg, sev, href) {
  ping(sev);
  notifHistAdd(sev, titulo, msg, href);
  const dur = sev === "roja" ? 12000 : 9000;
  if ("Notification" in window && Notification.permission === "granted") {
    try {
      new Notification(titulo, {
        body: (msg || "").replace(/<[^>]+>/g, "").trim(),
        icon: "/static/logos/hazzi-icon.png",
      });
    } catch (e) { toast(titulo, msg, sev, dur); }
  } else {
    toast(titulo, msg, sev, dur);
  }
}

// la sub barra se dibuja junto con el header, y no en cada pagina,
// para que una pagina de admin nueva solo tenga que declarar el div admin-subnav
document.addEventListener("DOMContentLoaded", () => {
  renderHeader();
  renderSubnav();
});

// exportar: pdf con encabezado walmart y csv

// dibuja el encabezado con el spark de walmart en un jspdf ya creado.
// devuelve la posicion y donde puede seguir escribiendo el contenido
function pdfEncabezado(doc, titulo, subtitulo) {
  const azul = [0, 54, 207], spark = [255, 194, 32];
  const cx = 18, cy = 20;
  doc.setLineWidth(1.6);
  doc.setDrawColor(spark[0], spark[1], spark[2]);
  const rayos = [[14, 0, 44, 0], [7, 12.1, 22, 38.1], [-7, 12.1, -22, 38.1],
    [-14, 0, -44, 0], [-7, -12.1, -22, -38.1], [7, -12.1, 22, -38.1]];
  rayos.forEach(r => doc.line(cx + r[0] * 0.12, cy + r[1] * 0.12, cx + r[2] * 0.12, cy + r[3] * 0.12));
  doc.setFont("helvetica", "bold"); doc.setFontSize(18);
  doc.setTextColor(azul[0], azul[1], azul[2]);
  doc.text("Walmart", 26, 22);

  doc.setFontSize(13); doc.setTextColor(30, 41, 59);
  doc.text(titulo, 14, 36);
  doc.setFont("helvetica", "normal"); doc.setFontSize(9); doc.setTextColor(100, 116, 139);
  doc.text(subtitulo, 14, 42);
  return 47;
}

// descarga un array de objetos como csv, usa las keys del primer objeto como columnas
function descargarCSV(nombreArchivo, filas) {
  if (!filas.length) return;
  const cols = Object.keys(filas[0]);
  const escapar = (v) => `"${String(v == null ? '' : v).replace(/"/g, '""')}"`;
  const lineas = [cols.join(","), ...filas.map(f => cols.map(c => escapar(f[c])).join(","))];
  const blob = new Blob(["\uFEFF" + lineas.join("\r\n")], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = nombreArchivo;
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
}

// aplica colores legibles a chart.js segun el tema actual, claro u oscuro.
// se llama antes de crear los charts en cada pagina que los usa
function aplicarTemaCharts() {
  if (typeof Chart === "undefined") return;
  const oscuro = document.documentElement.classList.contains("dark");
  Chart.defaults.color = oscuro ? "#f8fafc" : "#475569";
  Chart.defaults.borderColor = oscuro ? "#233a7a" : "#e2e8f0";
}
