"""Repara el mojibake ya guardado en eventos_historial (bug de fetch.ps1,
arreglado en el fetcher pero las filas viejas quedaron con el dato malo).

Mismo patron que el mojibake de los .html (ver tools/reparar_encoding.py):
UTF-8 leido como cp1252 y reescrito como UTF-8. Aca ademas hay que recalcular
la CLAVE primaria de los sismos, porque incluye el titulo (ver
historial.clave_evento) -- si solo se pisa el JSON y no la clave, la fila
queda con una clave que ya no coincide con la que calculan los ciclos futuros.
"""
import json
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from sqlalchemy import delete, insert, select, update

from app import historial
from app.db import engine
from tools.reparar_encoding import reparar

CAMPOS_TEXTO = ("titulo", "region", "comuna", "detalle", "estado")


def _reparar_evento(e: dict) -> tuple[dict, bool]:
    cambiado = False
    nuevo = dict(e)
    for campo in CAMPOS_TEXTO:
        valor = nuevo.get(campo)
        if isinstance(valor, str):
            arreglado = reparar(valor)
            if arreglado is not None and arreglado != valor:
                nuevo[campo] = arreglado
                cambiado = True
    return nuevo, cambiado


def main() -> int:
    historial.init_schema()
    tabla = historial.historial_tabla
    tocadas = 0
    with engine.begin() as conn:
        filas = conn.execute(select(tabla)).mappings().all()
        for f in filas:
            e = json.loads(f["datos"])
            nuevo, cambiado = _reparar_evento(e)
            if not cambiado:
                continue

            clave_vieja = f["clave"]
            clave_nueva = historial.clave_evento(nuevo)
            print(f"  {clave_vieja[:60]!r} -> titulo: {nuevo.get('titulo')!r}")

            if clave_nueva == clave_vieja:
                conn.execute(
                    update(tabla).where(tabla.c.clave == clave_vieja)
                    .values(datos=json.dumps(nuevo, ensure_ascii=False))
                )
            else:
                # La clave cambia (el titulo forma parte de ella en sismos):
                # borrar la fila vieja e insertar con la clave correcta, salvo
                # que ya exista una fila con esa clave (no deberia pasar para
                # estos casos, pero mejor no perder datos si pasara).
                ya_existe = conn.execute(
                    select(tabla.c.clave).where(tabla.c.clave == clave_nueva)
                ).first()
                conn.execute(delete(tabla).where(tabla.c.clave == clave_vieja))
                if not ya_existe:
                    conn.execute(insert(tabla).values(
                        clave=clave_nueva,
                        datos=json.dumps(nuevo, ensure_ascii=False),
                        vigente=f["vigente"],
                        ultima_vez_vigente=f["ultima_vez_vigente"],
                    ))
            tocadas += 1

    print(f"\n{tocadas} fila(s) reparada(s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
