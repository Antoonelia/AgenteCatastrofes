"""eventos volcanicos de senapred. enriquece sernageomin con fecha y perimetro.

sources/sernageomin.py (arcgis featureserver) trae el nivel de alerta
tecnica por volcan pero no trae la fecha del ultimo cambio ni el
perimetro de seguridad declarado -- esa fuente simplemente no lo
expone. la misma api graphql de senapred que ya usa sources/senapred.py
para alertas (ver senapred_client.py, mismas credenciales de invitado)
tiene otra consulta separada: eventosByDate con type: "Evento" en vez
de type: "Alerta". esa consulta trae comunicados de prensa de todo
tipo -- sismos menores, incendios estructurales, fugas de material
peligroso, monitoreo meteorologico -- y tambien, cuando corresponde,
comunicados sobre actividad volcanica. de esos ultimos interesan dos
cosas: una fecha real (fechaHora) y casi siempre el perimetro de
seguridad vigente, declarado como texto libre dentro de contenido,
igual que sources/senapred.py ya parsea boletines de la dmc citados
dentro de sus propias alertas.

no se registra como fuente en app/main.py porque no genera eventos
propios para el dashboard -- solo enriquece los volcanes que ya trae
sernageomin.py. pedirlo aun asi para cada volcan verde seria trabajo de
red desperdiciado, asi que sernageomin.py solo lo consulta si tiene al
menos un volcan con alerta real que enriquecer.
"""
from __future__ import annotations

import html as html_mod
import re

from ..regiones_cl import sin_tildes
from ..senapred_client import graphql

_LIMIT = 40  # comunicados mas recientes a revisar. mismo criterio que senapred.py

_QUERY = """query EventosByDate($type: String!, $sortDirection: ModelSortDirection, $limit: Int) {
  eventosByDate(type: $type, sortDirection: $sortDirection, limit: $limit) {
    items { id titulo fechaHora contenido }
  }
}"""

_TAG = re.compile(r"<[^>]+>")
_FECHA_ISO = re.compile(r"(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})")

# "...por actividad del Complejo Volcanico Nevados de Chillan" o
# "...por actividad de la <nombre>". el nombre del volcan queda al
# final del titulo en los comunicados reales vistos hasta ahora
_POR_ACTIVIDAD_DE = re.compile(r"actividad de(?:l| la)\s+(.+?)\s*$", re.I)

# sernageomin nombra sus volcanes con un prefijo segun el tipo de
# formacion (volcan, complejo volcanico, grupo volcanico). se saca
# para comparar solo la parte que de verdad identifica al volcan
_PREFIJO_VOLCAN = re.compile(r"^(complejo volc\u00e1nico|grupo volc\u00e1nico|volc\u00e1n)\s+", re.I)

# tres formas en que un comunicado declara el perimetro, de mas a menos
# especifica. la primera es la que trae el caso real de nevados de
# chillan: una modificacion que reemplaza un perimetro viejo por uno
# nuevo, y el nuevo es el que manda. las otras dos son fallback para
# comunicados que declaran un perimetro sin ser una modificacion
_PASANDO_A = re.compile(r"pasando de[^.]*?\ba\s+([\d.,]+)\s*kil\u00f3metro", re.I)
_RADIO_REFERENCIAL = re.compile(r"radio referencial de\s+([\d.,]+)\s*kil\u00f3metro", re.I)
_PERIMETRO_DE = re.compile(r"per\u00edmetro de seguridad[^.]*?\bde\s+([\d.,]+)\s*kil\u00f3metro", re.I)


def _texto_plano(html_str: str | None) -> str:
    """igual criterio que sources/senapred.py: el contenido viene en\n    html y hay que limpiarlo a texto plano para buscarle palabras clave."""
    if not html_str:
        return ""
    sin_tags = _TAG.sub(" ", html_str)
    return re.sub(r"\s+", " ", html_mod.unescape(sin_tags)).strip()


def _fmt_fecha(iso: str | None) -> str | None:
    """convierte 2026-09-27t13:06:40.4040-03:00 a 27-09-2026 13:06 hrs."""
    if not iso:
        return None
    m = _FECHA_ISO.match(iso)
    if not m:
        return iso
    y, mo, d, h, mi = m.groups()
    return f"{d}-{mo}-{y} {h}:{mi} hrs"


def nombre_base(nombre: str) -> str:
    """nombre de un volcan sin su prefijo generico y sin tildes.

    sirve para cruzar el nombre que da sernageomin (por ejemplo\n    "Complejo Volcanico Nevados de Chillan") contra el que menciona un\n    comunicado de senapred, que suele repetir el mismo nombre completo\n    con el mismo prefijo pero no siempre con la misma tilde o\n    capitalizacion segun el canal que lo redacto."""
    sin_prefijo = _PREFIJO_VOLCAN.sub("", (nombre or "").strip())
    return sin_tildes(sin_prefijo).strip().lower()


def _perimetro_km(contenido_txt: str) -> float | None:
    """km del perimetro de seguridad vigente segun el comunicado.

    none si el comunicado no menciona ningun numero de kilometros, por\n    ejemplo un cierre de evento que no toca el perimetro."""
    for patron in (_PASANDO_A, _RADIO_REFERENCIAL, _PERIMETRO_DE):
        m = patron.search(contenido_txt)
        if m:
            try:
                return float(m.group(1).replace(",", "."))
            except ValueError:
                continue
    return None


def eventos_volcanicos() -> dict[str, dict]:
    """ultimo comunicado volcanico de senapred, uno por volcan.

    la clave es nombre_base(volcan) para poder cruzar directo con el\n    campo Nombre que trae sernageomin. cada valor trae fecha (dd-mm-yyyy\n    hh:mm hrs o none) y perimetro_km (float o none).\n\n    best effort: ante cualquier falla de red o de la api devuelve\n    vacio y sernageomin.py sigue mostrando sus volcanes sin este\n    enriquecimiento, igual que se comportaba antes de que esto\n    existiera. nunca debe tumbar la recoleccion de volcanes por un\n    problema de esta consulta aparte."""
    try:
        res = graphql(_QUERY, {"type": "Evento", "sortDirection": "DESC", "limit": _LIMIT})
        items = (res.get("data") or {}).get("eventosByDate", {}).get("items", []) or []
    except Exception:  # noqa: BLE001 - sin esto no se pierde nada, solo no se enriquece
        return {}

    out: dict[str, dict] = {}
    for it in items:
        titulo = it.get("titulo") or ""
        m = _POR_ACTIVIDAD_DE.search(titulo)
        if not m:
            continue  # no es un comunicado volcanico. es sismo, incendio, etc
        clave = nombre_base(m.group(1))
        if not clave or clave in out:
            continue  # ya se tiene una version mas nueva de este volcan. items vienen desc
        contenido_txt = _texto_plano(it.get("contenido"))
        out[clave] = {
            "fecha": _fmt_fecha(it.get("fechaHora")),
            "perimetro_km": _perimetro_km(contenido_txt),
        }
    return out
