"""Quita el BOM UTF-8 del inicio de los HTML (idempotente).

Un BOM antes del <!DOCTYPE> es invisible al leer el archivo pero real para
el navegador: cuenta como contenido antes del doctype y puede disparar
quirks mode. Lo dejo como script y no como comando suelto porque el
one-liner equivalente es justo el tipo de cosa que se escribe mal a las
apuradas (y ya me paso una vez hoy con la codificacion).
"""
from __future__ import annotations

from pathlib import Path

BOM = b"\xef\xbb\xbf"
RAIZ = Path(__file__).resolve().parent.parent


def main() -> int:
    tocados = 0
    for archivo in sorted((RAIZ / "app" / "static").glob("*.html")):
        crudo = archivo.read_bytes()
        if crudo.startswith(BOM):
            archivo.write_bytes(crudo[len(BOM):])
            print(f"  BOM quitado  {archivo.name}")
            tocados += 1
        else:
            print(f"  limpio       {archivo.name}")
    print(f"\n{tocados} archivo(s) con BOM.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
