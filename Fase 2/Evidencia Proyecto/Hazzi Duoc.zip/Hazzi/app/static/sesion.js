/* sesion.js. quien entro y con que roles.

   monitoreo: solo pide nombre, sin cuenta. se registra en visitas.py
   (quien entro a mirar, sin duplicar por reingreso) pero no hay nada
   que proteger, es de solo lectura. decision de antonella.

   administrador y admin_usuarios: login real contra el backend con
   RUT + clave (ver usuarios.py y auth_api.py). una cuenta puede tener
   los dos roles a la vez -- por eso la sesion guarda una LISTA de
   roles, no uno solo. la barrera real es la sesion server-side con
   cookie httponly -- lo que vive aca en sessionStorage es solo una
   copia liviana de nombre y roles para no tener que pedirle a
   /api/auth/yo en cada click de menu. si la cookie vence o se borra,
   la proxima llamada a la api devuelve 401 y listo, no hace falta
   duplicar esa validacion aca.
*/

const SESION_CLAVE = "hazziSesion";
const ULTIMO_NOMBRE = "hazziUltimoNombre";
const PORTADA = "/";

const ETIQUETA_ROL = {
  usuario: "Monitoreo",
  admin: "Administrador",
  admin_usuarios: "Gestion de usuarios",
};

function sesionActual() {
  try {
    const cruda = sessionStorage.getItem(SESION_CLAVE);
    if (!cruda) return null;
    const s = JSON.parse(cruda);
    if (!s || !s.nombre || !Array.isArray(s.roles) || s.roles.length === 0) return null;
    return s;
  } catch (e) {
    return null;
  }
}

function _guardarSesion(nombre, roles) {
  const limpio = String(nombre || "").trim();
  const listaRoles = (Array.isArray(roles) ? roles : [roles]).filter((r) => ETIQUETA_ROL[r]);
  if (!limpio || listaRoles.length === 0) return false;
  sessionStorage.setItem(SESION_CLAVE, JSON.stringify({ nombre: limpio, roles: listaRoles }));
  localStorage.setItem(ULTIMO_NOMBRE, limpio);
  // el header ya sabe leer userName. se mantiene sincronizado para no
  // duplicar la fuente del nombre. es dry con common.js
  localStorage.setItem("userName", limpio);
  return true;
}

/** entra como monitoreo. sin cuenta, solo registra quien paso a mirar. */
function iniciarSesionMonitoreo(nombre) {
  const ok = _guardarSesion(nombre, ["usuario"]);
  if (ok) {
    fetch("/api/auth/visita", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ nombre: String(nombre).trim() }),
      // keepalive: quien llama navega a /inicio justo despues, y sin esto el
      // navegador puede abortar el request en vuelo y la visita no queda
      keepalive: true,
    }).catch(() => {});  // best effort. si falla, igual puede monitorear
  }
  return ok;
}

/** login real de administrador. devuelve { ok, error, roles }.
 *  con timeout propio: sin esto, si el server no contesta (ej. un lock
 *  de la base que tarda de mas) el boton de login quedaba pegado en
 *  "Verificando..." para siempre, sin ningun aviso de que algo fallo. */
async function loginAdmin(rut, clave) {
  const control = new AbortController();
  const vencimiento = setTimeout(() => control.abort(), 12000);
  try {
    const r = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ rut, clave }),
      signal: control.signal,
    });
    const cuerpo = await r.json().catch(() => ({}));
    if (!r.ok) return { ok: false, error: cuerpo.detail || `HTTP ${r.status}` };
    const u = cuerpo.usuario;
    _guardarSesion(u.nombre, u.roles);
    return { ok: true, roles: u.roles };
  } catch (e) {
    const motivo = e.name === "AbortError"
      ? "El servidor no respondio a tiempo. Intenta de nuevo."
      : "No se pudo contactar al servidor.";
    return { ok: false, error: motivo };
  } finally {
    clearTimeout(vencimiento);
  }
}

function cerrarSesion() {
  fetch("/api/auth/logout", { method: "POST" }).catch(() => {}).finally(() => {
    sessionStorage.removeItem(SESION_CLAVE);
    location.href = PORTADA;
  });
}

function ultimoNombre() {
  return localStorage.getItem(ULTIMO_NOMBRE) || "";
}

/** cambia el nombre de la sesion de ESTA pestana nada mas, sin tocar
 *  roles. lo usa el editor de nombre del header (ver common.js), que
 *  ahora solo se muestra para el invitado de Monitoreo -- un admin
 *  real edita su nombre desde "Usuarios y auditoria", no desde aca. */
function actualizarNombreSesion(nombre) {
  const s = sesionActual();
  if (!s) return;
  const limpio = String(nombre || "").trim();
  if (!limpio) return;
  s.nombre = limpio;
  sessionStorage.setItem(SESION_CLAVE, JSON.stringify(s));
}

function esAdmin() {
  const s = sesionActual();
  return !!s && s.roles.includes("admin");
}

function esAdminUsuarios() {
  const s = sesionActual();
  return !!s && s.roles.includes("admin_usuarios");
}

/** "Administrador" o "Administrador + Gestion de usuarios" si tiene los dos */
function etiquetaRol() {
  const s = sesionActual();
  if (!s) return "";
  return s.roles.map((r) => ETIQUETA_ROL[r] || r).join(" + ");
}

/**
 * guardia de pagina. se llama al tope de cada pantalla interna.
 * sin sesion va a la portada. sin el permiso que pide la pagina va a
 * donde diga caida.
 */
function exigirSesion({ admin = false, adminUsuarios = false, caida = "/inicio" } = {}) {
  const s = sesionActual();
  if (!s) {
    location.replace(PORTADA);
    return null;
  }
  if (admin && !s.roles.includes("admin")) {
    location.replace(caida);
    return null;
  }
  if (adminUsuarios && !s.roles.includes("admin_usuarios")) {
    location.replace(caida);
    return null;
  }
  return s;
}
