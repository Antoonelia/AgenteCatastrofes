"""tests del chip de clima. app/clima.py.

solo logica pura y cache. las llamadas de red se reemplazan por
dobles, asi que estos tests corren sin internet y sin depender de que
nominatim u open-meteo esten arriba."""
from __future__ import annotations

from app import clima


def _sin_cache():
    clima._cache.clear()


def _con_dobles(lugar=None, temp=None, falla_lugar=False, falla_clima=False):
    """reemplaza las dos consultas de red por dobles controlados.

    devuelve una funcion para restaurar los originales."""
    orig_lugar, orig_temp = clima._lugar, clima._temperatura

    def _l(lat, lon):
        if falla_lugar:
            raise RuntimeError("nominatim caido")
        return lugar

    def _t(lat, lon):
        if falla_clima:
            raise RuntimeError("open-meteo caido")
        return temp, "Despejado", "despejado"

    clima._lugar, clima._temperatura = _l, _t
    return lambda: (setattr(clima, "_lugar", orig_lugar),
                    setattr(clima, "_temperatura", orig_temp))


def test_devuelve_lugar_y_temperatura():
    _sin_cache()
    restaurar = _con_dobles(lugar="Santiago", temp=8)
    try:
        d = clima.clima_actual(-33.4489, -70.6693)
        assert d["lugar"] == "Santiago"
        assert d["temperatura"] == 8
        assert d["descripcion"] == "Despejado"
    finally:
        restaurar()


def test_si_falla_la_ubicacion_igual_devuelve_la_temperatura():
    """un servicio caido no puede dejar el chip entero sin datos.

    cada consulta se protege por separado justamente para esto."""
    _sin_cache()
    restaurar = _con_dobles(temp=8, falla_lugar=True)
    try:
        d = clima.clima_actual(-33.4489, -70.6693)
        assert d["lugar"] is None
        assert d["temperatura"] == 8
    finally:
        restaurar()


def test_si_falla_el_clima_igual_devuelve_la_ubicacion():
    _sin_cache()
    restaurar = _con_dobles(lugar="Santiago", falla_clima=True)
    try:
        d = clima.clima_actual(-33.4489, -70.6693)
        assert d["lugar"] == "Santiago"
        assert d["temperatura"] is None
    finally:
        restaurar()


def test_si_fallan_las_dos_no_revienta():
    """el chip es informativo. nunca debe tumbar el inicio."""
    _sin_cache()
    restaurar = _con_dobles(falla_lugar=True, falla_clima=True)
    try:
        d = clima.clima_actual(-33.4489, -70.6693)
        assert d == {"lugar": None, "temperatura": None, "descripcion": None, "categoria": None}
    finally:
        restaurar()


def test_coordenadas_cercanas_comparten_cache():
    """se redondea a 2 decimales, como 1 km. dos puntos del mismo
    barrio son una sola consulta y de paso no se manda la posicion
    exacta del usuario."""
    _sin_cache()
    llamadas = []
    orig_lugar, orig_temp = clima._lugar, clima._temperatura
    clima._lugar = lambda lat, lon: (llamadas.append((lat, lon)), "Santiago")[1]
    clima._temperatura = lambda lat, lon: (8, "Despejado")
    try:
        clima.clima_actual(-33.44891, -70.66931)
        clima.clima_actual(-33.44894, -70.66934)   # unos 3 metros mas alla
        assert len(llamadas) == 1, "la segunda consulta deberia salir del cache"
        assert llamadas[0] == (-33.45, -70.67), "las coordenadas se redondean"
    finally:
        clima._lugar, clima._temperatura = orig_lugar, orig_temp


def test_zonas_distintas_no_comparten_cache():
    _sin_cache()
    llamadas = []
    orig_lugar, orig_temp = clima._lugar, clima._temperatura
    clima._lugar = lambda lat, lon: (llamadas.append((lat, lon)), "X")[1]
    clima._temperatura = lambda lat, lon: (8, "Despejado")
    try:
        clima.clima_actual(-33.4489, -70.6693)     # santiago
        clima.clima_actual(-23.6500, -70.4000)     # antofagasta
        assert len(llamadas) == 2
    finally:
        clima._lugar, clima._temperatura = orig_lugar, orig_temp


def test_si_le_pasan_el_lugar_no_geocodifica():
    """cuando el usuario ya eligio su comuna sabemos el nombre.
    pedirselo a nominatim seria una llamada de red al pedo y podria
    devolver la ciudad o la provincia en vez de la comuna elegida."""
    _sin_cache()
    restaurar = _con_dobles(lugar="NO DEBERIA USARSE", temp=8)
    try:
        d = clima.clima_actual(-33.4489, -70.6693, lugar="Providencia")
        assert d["lugar"] == "Providencia"
        assert d["temperatura"] == 8
    finally:
        restaurar()


def test_el_lugar_elegido_gana_incluso_con_cache_caliente():
    """dos comunas vecinas caen en la misma clave de cache, como 1 km.
    la segunda no puede quedarse con el nombre de la primera."""
    _sin_cache()
    restaurar = _con_dobles(temp=8)
    try:
        primera = clima.clima_actual(-33.4489, -70.6693, lugar="Santiago")
        segunda = clima.clima_actual(-33.4489, -70.6693, lugar="Providencia")
        assert primera["lugar"] == "Santiago"
        assert segunda["lugar"] == "Providencia"
        assert segunda["temperatura"] == 8
    finally:
        restaurar()


def test_descripcion_de_codigos_wmo():
    assert clima._descripcion(0) == "Despejado"
    assert clima._descripcion(2) == "Parcialmente nublado"
    assert clima._descripcion(65) == "Lluvia"
    assert clima._descripcion(75) == "Nieve"
    assert clima._descripcion(95) == "Tormenta"


def test_codigo_desconocido_no_revienta():
    assert clima._descripcion(999) == "Sin datos"
    assert clima._descripcion(None) == "Sin datos"


def test_categoria_por_codigo_wmo():
    assert clima._categoria(0, None) == "despejado"
    assert clima._categoria(2, None) == "parcial"
    assert clima._categoria(65, None) == "lluvia"
    assert clima._categoria(75, None) == "nieve"
    assert clima._categoria(95, None) == "tormenta"


def test_viento_fuerte_pisa_una_categoria_tranquila():
    """despejado parcial y nublado con viento fuerte pasan a viento.
    son las unicas categorias tranquilas donde el viento es lo mas
    notable."""
    assert clima._categoria(0, 55) == "viento"
    assert clima._categoria(3, 41) == "viento"
    assert clima._categoria(0, 39) == "despejado", "por debajo del umbral no pisa nada"


def test_viento_fuerte_no_pisa_lluvia_ni_tormenta():
    """si ya esta lloviendo o hay tormenta eso es mas informativo que
    el viento. el viento no las tapa aunque sople fuerte."""
    assert clima._categoria(65, 80) == "lluvia"
    assert clima._categoria(95, 80) == "tormenta"


def test_clima_regiones_trae_las_16_con_cache():
    """clima_regiones pide todas las regiones en un solo fetch_many,
    cachea 10 minutos, y una region sin datos no tumba a las otras 15."""
    from app.regiones_cl import REGION_CENTRO
    from app.fetcher import fetch_many as fetch_many_original

    clima._cache_regiones = None
    llamadas = []

    def _fetch_many_falso(urls):
        llamadas.append(urls)
        salida = {}
        for i, url in enumerate(urls):
            if i == 0:
                continue  # la primera url falla y no viene en el resultado
            salida[url] = (
                '{"current": {"temperature_2m": 15.4, "weather_code": 61, "wind_speed_10m": 5}}'
            )
        return salida

    # clima_regiones importa fetch_many dentro de la funcion, un import
    # local, asi que alcanza con parchar el nombre en su modulo de origen
    import app.fetcher as fetcher_mod
    orig_fetcher = fetcher_mod.fetch_many
    fetcher_mod.fetch_many = _fetch_many_falso
    try:
        resultado = clima.clima_regiones()
        assert len(resultado) == len(REGION_CENTRO) == 16
        assert len(llamadas) == 1, "debe ser un solo fetch_many para las 16"
        # la primera region, la que fallo, queda con datos en none y no revienta
        primera = next(iter(REGION_CENTRO))
        assert resultado[primera]["temperatura"] is None
        # el resto trae lo que devolvio el doble
        segunda = list(REGION_CENTRO)[1]
        assert resultado[segunda]["temperatura"] == 15
        assert resultado[segunda]["categoria"] == "lluvia"

        # segunda llamada usa el cache. no hay que volver a pedir nada
        clima.clima_regiones()
        assert len(llamadas) == 1, "la segunda llamada deberia salir del cache"
    finally:
        fetcher_mod.fetch_many = orig_fetcher
        clima._cache_regiones = None
