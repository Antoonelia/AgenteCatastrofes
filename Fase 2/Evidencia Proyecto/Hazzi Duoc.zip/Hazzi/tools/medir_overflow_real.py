"""Mide el comportamiento real de la tabla del historial SIN depender del CDN
de Tailwind (que ahora mismo el proxy corporativo esta bloqueando -- mismo
patron que con Leaflet en sesiones anteriores). Inyecta a mano solo las
clases utilitarias que la pagina realmente usa, para que la medicion sea
fiel a lo que un usuario real ve con internet funcionando."""
from playwright.sync_api import sync_playwright

TAILWIND_MINIMO = """
.max-w-6xl { max-width: 72rem; } .mx-auto { margin-left:auto; margin-right:auto; }
.p-4 { padding: 1rem; } .space-y-4 > * + * { margin-top: 1rem; }
.bg-white { background: #fff; } .rounded-xl { border-radius: .75rem; }
.shadow { box-shadow: 0 1px 3px rgba(0,0,0,.15); } .overflow-hidden { overflow: hidden; }
"""

with sync_playwright() as p:
    nav = p.chromium.launch(channel="chrome")
    pagina = nav.new_page()
    pagina.route("**://fonts.googleapis.com/**", lambda r: r.abort())
    pagina.route("**://cdn.tailwindcss.com/**", lambda r: r.abort())
    pagina.goto("http://127.0.0.1:8000/historial", wait_until="domcontentloaded")
    pagina.add_style_tag(content=TAILWIND_MINIMO)
    pagina.wait_for_function("document.querySelectorAll('#tabla > tr').length > 0", timeout=20000)
    pagina.wait_for_timeout(300)

    for ancho, nombre in ((1400, "desktop"), (375, "mobile")):
        pagina.set_viewport_size({"width": ancho, "height": 700})
        pagina.wait_for_timeout(200)
        info = pagina.evaluate("""() => {
            const sec = document.querySelector('#tabla').closest('section');
            const wrap = document.querySelector('#tabla').closest('div');
            const tabla = document.querySelector('table.hz-table');
            return {
                seccionOverflowComputado: getComputedStyle(sec).overflow,
                wrapOverflowX: getComputedStyle(wrap).overflowX,
                seccionClientW: sec.clientWidth, tablaClientW: tabla.clientWidth,
                bodyScrollW: document.body.scrollWidth, ventana: window.innerWidth,
                paginaConScrollHorizontal: document.documentElement.scrollWidth > window.innerWidth + 2,
                wrapTieneScrollHorizontalPropio: wrap.scrollWidth > wrap.clientWidth + 2,
                contenidoOcultoSinAcceso: tabla.clientWidth > wrap.clientWidth && wrap.scrollWidth <= wrap.clientWidth + 2,
            };
        }""")
        print(f"[{nombre} {ancho}px]")
        for k, v in info.items():
            print(f"   {k}: {v}")
    nav.close()
