"""clima actual de una comuna. el chip de inicio.

dos datos dos fuentes publicas sin api key. comuna o ciudad viene de
geocodificacion inversa de nominatim que es el mismo servicio que ya
usa stores.py para ubicar las tiendas asi que no se suma un proveedor
nuevo. la temperatura viene de open-meteo.

las dos salen por el proxy corporativo via fetcher porque el navegador
de la red walmart no llega directo a internet asi que la consulta la
hace el backend y no el frontend.

sobre la ubicacion: la idea original era tomarla del navegador pero la
politica corporativa de chrome la bloquea para todos los sitios asi que
en esta red nunca va a estar disponible. en su lugar el usuario elige
su comuna de una lista y la eleccion queda guardada en el navegador. si
algun dia se habilita el permiso clima_actual ya acepta coordenadas y
no habria que tocar nada."""
from __future__ import annotations

import json
import time
import urllib.parse

from .fetcher import fetch_json

_PRECISION_GRADOS = 2  # la ubicacion se redondea antes de consultar. dos
# decimales son como 1 km de sobra para saber en que comuna estamos y que
# temperatura hace. de paso el cache sirve para todo un barrio en vez de un
# punto exacto y no se manda la posicion precisa del usuario a un servicio
# externo

_CACHE_TTL = 600.0     # diez minutos. la temperatura no cambia mas rapido que eso
_cache: dict[tuple[float, float], tuple[float, dict]] = {}

# codigos wmo a descripcion corta. agrupados por familia porque el
# detalle fino de open-meteo distingue cosas como llovizna ligera
# moderada o densa que no aportan a un chip de una linea
_WMO = [
    ({0}, "Despejado"),
    ({1, 2}, "Parcialmente nublado"),
    ({3}, "Nublado"),
    ({45, 48}, "Neblina"),
    ({51, 53, 55, 56, 57}, "Llovizna"),
    ({61, 63, 65, 66, 67, 80, 81, 82}, "Lluvia"),
    ({71, 73, 75, 77, 85, 86}, "Nieve"),
    ({95, 96, 99}, "Tormenta"),
]


def _descripcion(codigo) -> str:
    for codigos, texto in _WMO:
        if codigo in codigos:
            return texto
    return "Sin datos"


# mismos grupos de codigos wmo que arriba pero con una clave corta
# pensada para elegir un icono en el frontend en vez de un texto para
# mostrar. va separado de _wmo y no fusionado en una sola tabla porque
# _descripcion ya se usaba antes de que existiera esto y varios tests y
# llamadores dependen de su texto tal cual. no vale la pena tocarla de mas
_CATEGORIA = [
    ({0}, "despejado"),
    ({1, 2}, "parcial"),
    ({3}, "nublado"),
    ({45, 48}, "neblina"),
    ({51, 53, 55, 56, 57}, "llovizna"),
    ({61, 63, 65, 66, 67, 80, 81, 82}, "lluvia"),
    ({71, 73, 75, 77, 85, 86}, "nieve"),
    ({95, 96, 99}, "tormenta"),
]

# desde esta velocidad de viento en km por hora el viento pasa a ser lo
# mas notable del clima. solo pisa una categoria tranquila como
# despejado parcial o nublado. si ademas esta lloviendo o nevando esa
# info importa mas que el viento y se deja como esta
_UMBRAL_VIENTO_KMH = 40.0
_CATEGORIAS_VENTEABLES = {"despejado", "parcial", "nublado"}


def _categoria(codigo, viento_kmh: float | None) -> str:
    cat = "despejado"
    for codigos, nombre in _CATEGORIA:
        if codigo in codigos:
            cat = nombre
            break
    if viento_kmh is not None and viento_kmh >= _UMBRAL_VIENTO_KMH and cat in _CATEGORIAS_VENTEABLES:
        return "viento"
    return cat


def _lugar(lat: float, lon: float) -> str | None:
    """nombre de la comuna o ciudad para unas coordenadas. none si no se pudo."""
    url = (
        "https://nominatim.openstreetmap.org/reverse"
        f"?lat={lat}&lon={lon}&format=json&zoom=10&addressdetails=1&accept-language=es"
    )
    datos = fetch_json(url).get("address", {})
    time.sleep(1)  # nominatim pide como maximo una peticion por segundo
    # de lo mas especifico a lo mas general. en chile una comuna puede venir
    # en cualquiera de estos campos segun como este mapeada en osm
    for campo in ("city", "town", "village", "municipality", "county", "state"):
        if datos.get(campo):
            return datos[campo]
    return None


def _temperatura(lat: float, lon: float) -> tuple[float | None, str, str]:
    url = (
        "https://api.open-meteo.com/v1/forecast"
        f"?latitude={lat}&longitude={lon}"
        "&current=temperature_2m,weather_code,wind_speed_10m"
        f"&timezone={urllib.parse.quote('America/Santiago')}"
    )
    actual = fetch_json(url).get("current", {})
    temp = actual.get("temperature_2m")
    codigo = actual.get("weather_code")
    return (
        round(temp) if temp is not None else None,
        _descripcion(codigo),
        _categoria(codigo, actual.get("wind_speed_10m")),
    )


def comunas_disponibles() -> list[str]:
    """comunas que se pueden elegir en el chip ordenadas alfabeticamente.

    son las comunas donde hay tiendas. reutiliza el cache que ya
    construye stores.py asi que no cuesta ninguna consulta externa ni
    hay que mantener una lista aparte."""
    from .stores import build_stores

    return sorted({t["comuna"] for t in build_stores() if t.get("comuna")})


def clima_de_comuna(comuna: str) -> dict:
    """clima de una comuna elegida por su nombre.

    reutiliza el geocoder y el cache de comunas de stores.py. las
    comunas con tiendas ya estan resueltas ahi asi que en la practica
    no sale a internet para ubicarla. como el nombre ya lo sabemos se
    le pasa a clima_actual para que no gaste una geocodificacion
    inversa al pedo."""
    from .stores import _load_comunas_cache, geocode_comuna

    coord = geocode_comuna(comuna, _load_comunas_cache())
    if not coord:
        raise ValueError(f"no se pudo ubicar la comuna {comuna!r}")
    return clima_actual(*coord, lugar=comuna)


def clima_actual(lat: float, lon: float, lugar: str | None = None) -> dict:
    """lugar temperatura y descripcion para unas coordenadas.

    si lugar viene dado porque el usuario eligio su comuna se usa ese
    nombre y se saltea la geocodificacion inversa. es una llamada de
    red menos y ademas respeta lo que eligio el usuario. nominatim
    podria devolver la ciudad o la provincia y quedaria raro elegir
    providencia y ver santiago.

    cachea 10 minutos por zona. si una de las dos consultas falla
    devuelve igual lo que si se pudo obtener porque es un chip
    informativo que nunca debe romper el inicio por no tener internet
    un momento."""
    clave = (round(lat, _PRECISION_GRADOS), round(lon, _PRECISION_GRADOS))
    ahora = time.time()
    guardado = _cache.get(clave)
    if guardado and ahora - guardado[0] < _CACHE_TTL:
        return {**guardado[1], "lugar": lugar} if lugar else guardado[1]

    resultado: dict = {"lugar": lugar, "temperatura": None, "descripcion": None, "categoria": None}
    # cada consulta se protege por separado a proposito. si falla el
    # nombre de la comuna igual queremos mostrar la temperatura y al
    # reves. un chip informativo no puede tumbar el inicio por un
    # servicio caido
    if lugar is None:
        try:
            resultado["lugar"] = _lugar(*clave)
        except Exception:  # noqa: BLE001
            pass
    try:
        resultado["temperatura"], resultado["descripcion"], resultado["categoria"] = _temperatura(*clave)
    except Exception:  # noqa: BLE001
        pass

    _cache[clave] = (ahora, resultado)
    return resultado


_CACHE_REGIONES_TTL = 600.0
_cache_regiones: tuple[float, dict] | None = None


def clima_regiones() -> dict[str, dict]:
    """clima actual de las 16 regiones de chile todas en una sola pasada.

    lo usa el cartel de clima por region del mapa. reusa fetch_many el
    mismo truco que usan las fuentes de eventos para pagar una sola vez
    el arranque de powershell en vez de 16. esto importa mas aca
    porque a diferencia de las fuentes de eventos esto se puede llamar
    seguido ya que el mapa lo pide al cargar.

    cachea 10 minutos igual que clima_actual. el clima no cambia mas
    rapido que eso y evita golpear open-meteo 16 veces cada vez que
    alguien abre el mapa."""
    global _cache_regiones
    from .fetcher import fetch_many
    from .regiones_cl import REGION_CENTRO

    ahora = time.time()
    if _cache_regiones and ahora - _cache_regiones[0] < _CACHE_REGIONES_TTL:
        return _cache_regiones[1]

    def _url(lat: float, lon: float) -> str:
        return (
            "https://api.open-meteo.com/v1/forecast"
            f"?latitude={lat}&longitude={lon}"
            "&current=temperature_2m,weather_code,wind_speed_10m"
            f"&timezone={urllib.parse.quote('America/Santiago')}"
        )

    urls = {nombre: _url(lat, lon) for nombre, (lat, lon) in REGION_CENTRO.items()}
    crudo = fetch_many(list(urls.values()))

    resultado: dict[str, dict] = {}
    for nombre, (lat, lon) in REGION_CENTRO.items():
        base = {"lat": lat, "lon": lon, "temperatura": None, "descripcion": None, "categoria": None}
        texto = crudo.get(urls[nombre])
        if texto:
            try:
                actual = json.loads(texto).get("current", {})
                temp = actual.get("temperature_2m")
                codigo = actual.get("weather_code")
                base["temperatura"] = round(temp) if temp is not None else None
                base["descripcion"] = _descripcion(codigo)
                base["categoria"] = _categoria(codigo, actual.get("wind_speed_10m"))
            except Exception:  # noqa: BLE001 - una region mal no debe tumbar las otras 15
                pass
        resultado[nombre] = base

    _cache_regiones = (ahora, resultado)
    return resultado
