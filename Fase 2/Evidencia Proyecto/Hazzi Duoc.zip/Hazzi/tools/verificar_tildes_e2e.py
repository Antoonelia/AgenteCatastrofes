"""Verifica en un navegador real que no queden simbolos raros en ninguna pagina.

Busca en el texto RENDERIZADO (no en el archivo) las marcas tipicas de doble
codificacion y el caracter de reemplazo. Asi se comprueba lo que de verdad
ve Antonella, no lo que dice el disco.
"""
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from playwright.sync_api import sync_playwright

PAGINAS = ["/", "/mapa", "/eventos", "/tiendas", "/historial", "/estadisticas"]
MALAS = ("Ã", "Â", "â€", "\ufffd")
_VENDOR = Path(__file__).parent.parent / "_qa_vendor"


def _cdn(route):
    url = route.request.url
    for nombre, tipo in (("leaflet.js", "application/javascript"), ("leaflet.css", "text/css")):
        if nombre in url and (_VENDOR / nombre).exists():
            return route.fulfill(status=200, content_type=tipo, body=(_VENDOR / nombre).read_bytes())
    return route.abort()


def main() -> int:
    fallos = 0
    with sync_playwright() as p:
        nav = p.chromium.launch(channel="chrome")
        pagina = nav.new_page(viewport={"width": 1440, "height": 900})
        pagina.route("**://cdn.tailwindcss.com/**", lambda r: r.abort())
        pagina.route("**://cdn.jsdelivr.net/**", lambda r: r.abort())
        pagina.route("**://unpkg.com/**", _cdn)
        pagina.route("**://*.tile.openstreetmap.org/**", lambda r: r.abort())

        for ruta in PAGINAS:
            pagina.goto(f"http://127.0.0.1:8000{ruta}", wait_until="domcontentloaded")
            pagina.wait_for_timeout(2500)
            texto = pagina.evaluate("document.body.innerText")
            encontrados = {m: texto.count(m) for m in MALAS if m in texto}
            charset = pagina.evaluate("document.characterSet")
            if encontrados:
                fallos += 1
                print(f"  FALLA {ruta:<15} charset={charset}  {encontrados}")
                for m in encontrados:
                    i = texto.find(m)
                    print(f"         ...{texto[max(0, i - 60):i + 60]!r}...")
            else:
                print(f"  OK    {ruta:<15} charset={charset}")
        nav.close()
    print()
    print("SIN SIMBOLOS RAROS" if not fallos else f"{fallos} pagina(s) con problemas")
    return 1 if fallos else 0


if __name__ == "__main__":
    sys.exit(main())
