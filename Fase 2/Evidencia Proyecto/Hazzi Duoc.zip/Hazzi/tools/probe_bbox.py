"""Sonda: Nominatim ya nos da el boundingbox de cada comuna (lo estamos tirando)."""
import sys
import urllib.parse

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from app.fetcher import fetch_json

for lugar in ("Sierra Gorda", "Santiago", "Providencia", "Natales", "Vitacura"):
    q = urllib.parse.quote(f"{lugar}, Chile")
    url = f"https://nominatim.openstreetmap.org/search?q={q}&format=json&limit=1&countrycodes=cl"
    d = fetch_json(url)
    if not d:
        print(f"{lugar:<15} sin resultado")
        continue
    bb = d[0].get("boundingbox")
    print(f"{lugar:<15} bbox={bb}  tipo={d[0].get('type')}")
