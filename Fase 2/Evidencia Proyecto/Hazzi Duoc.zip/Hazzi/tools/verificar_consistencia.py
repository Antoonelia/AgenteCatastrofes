"""Verificacion end-to-end del fix del evento fantasma.

Contrasta lo que devuelve el API vigente contra el Historial y falla si algun
evento aparece en los dos lados a la vez -- que es, literalmente, el sintoma
del bug: \"esta vigente pero tambien esta archivado en el Historial\".
"""
from __future__ import annotations

import json
import urllib.request

BASE = "http://127.0.0.1:8000"


def _get(ruta: str) -> dict:
    with urllib.request.urlopen(f"{BASE}{ruta}", timeout=120) as r:
        return json.loads(r.read().decode("utf-8"))


def main() -> int:
    from app.historial import clave_evento

    vigentes = _get("/api/events?refrescar=true")["eventos"]
    archivados = _get("/api/historial")["eventos"]

    print(f"vigentes: {len(vigentes)} | archivados: {len(archivados)}\n")
    for e in vigentes:
        print(f"  VIGENTE   {clave_evento(e)}  [{e.get('estado')}]")
    for e in archivados:
        print(f"  archivado {clave_evento(e)}  [{e.get('estado')}]")

    problemas = []
    en_ambos = {clave_evento(e) for e in vigentes} & {clave_evento(e) for e in archivados}
    if en_ambos:
        problemas.append(f"eventos vigentes Y archivados a la vez: {sorted(en_ambos)}")

    zombies = [e["titulo"] for e in vigentes if e.get("activa") is False]
    if zombies:
        problemas.append(f"eventos no activos listados como vigentes: {zombies}")

    print()
    for p in problemas:
        print(f"  FALLA: {p}")
    print("  Todo consistente." if not problemas else "")
    return 1 if problemas else 0


if __name__ == "__main__":
    raise SystemExit(main())
