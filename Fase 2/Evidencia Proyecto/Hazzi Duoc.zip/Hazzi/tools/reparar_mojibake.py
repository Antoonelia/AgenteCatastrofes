"""Repara el doble-encodeado UTF-8 (mojibake) de los HTML.

QUE PASO: un `Get-Content | Set-Content -Encoding UTF8` de PowerShell leyo
archivos UTF-8 interpretandolos como cp1252 y los volvio a escribir como
UTF-8. Resultado: cada byte del UTF-8 original se convirtio en su propio
caracter. El clasico "AquÃ­" donde decia "Aqui" con tilde.

COMO SE DESHACE: es una funcion invertible. Si el texto actual se puede
codificar de vuelta a cp1252 y el resultado es UTF-8 valido, entonces ESE
es el contenido original. Si no se puede, el archivo esta sano y no se toca.

La condicion de arriba es la salvaguarda: un archivo correcto con tildes de
verdad falla al codificarse a cp1252 (o no produce UTF-8 valido), asi que
este script no puede "arreglar" algo que ya estaba bien.

Uso:  python tools/reparar_mojibake.py [--aplicar]
Sin --aplicar solo informa que haria (dry-run).
"""
from __future__ import annotations

import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
OBJETIVOS = sorted((RAIZ / "app" / "static").glob("*.html"))


def reparado(crudo: bytes) -> bytes | None:
    """Bytes corregidos, o None si el archivo no esta doble-encodeado.

    Se hace CARACTER POR CARACTER y no con un `texto.encode("cp1252")` de
    una: los HTML tienen simbolos que cp1252 no representa (flechas, emoji,
    guiones largos legitimos) y un solo caracter asi abortaba la conversion
    del archivo entero -- que fue justo lo que paso en el primer intento.

    Un caracter dentro del repertorio cp1252 se asume mojibake y se convierte
    de vuelta a su byte original; cualquier otro se deja intacto.
    """
    try:
        texto = crudo.decode("utf-8")
    except UnicodeDecodeError:
        return None  # no es UTF-8: no es este problema

    salida = bytearray()
    for ch in texto:
        try:
            salida += ch.encode("cp1252")
        except UnicodeEncodeError:
            salida += ch.encode("utf-8")  # nunca fue mojibake, se respeta

    candidato = bytes(salida)
    # El BOM (EF BB BF) se lee como '\ufeff' y al pasar por cp1252 vuelve a
    # salir como BOM, asi que sobrevive a la conversion. Un BOM al inicio de
    # un HTML es invisible pero real: puede colarse como texto antes del
    # <!DOCTYPE> y disparar quirks mode en algunos navegadores.
    if candidato.startswith(b"\xef\xbb\xbf"):
        candidato = candidato[3:]
    if candidato == crudo:
        return None  # nada cambio: el archivo estaba sano
    try:
        candidato.decode("utf-8")
    except UnicodeDecodeError:
        return None  # el resultado no seria texto valido: mejor no tocar
    return candidato


def main() -> int:
    aplicar = "--aplicar" in sys.argv
    tocados = 0
    for archivo in OBJETIVOS:
        crudo = archivo.read_bytes()
        fix = reparado(crudo)
        if fix is None:
            print(f"  ok    {archivo.name}")
            continue
        tocados += 1
        print(f"  FIX   {archivo.name}  ({len(crudo)} -> {len(fix)} bytes)")
        if aplicar:
            archivo.write_bytes(fix)

    print(f"\n{tocados} archivo(s) con mojibake.", end=" ")
    print("Reparados." if aplicar else "Dry-run: usar --aplicar para escribir.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
