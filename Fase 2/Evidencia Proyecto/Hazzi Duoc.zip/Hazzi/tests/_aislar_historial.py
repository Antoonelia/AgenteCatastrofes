"""aislamiento real para tests que tocan historial.py.

bug que esto arregla, encontrado en vivo el 29-09-2026: los tests de
historial creian estar aislados contra una sqlite temporal porque
hacian os.environ["DATABASE_URL"] = f"sqlite:///{tmp}" antes de
importar app.db. eso alcanza SI app.db.engine todavia no se creo en
este proceso. el problema es que tests/__init__.py importa TODOS los
modulos test_*.py en un mismo proceso, en orden alfabetico, y
test_ajustes.py (que corre antes que cualquier test_historial_*) hace
"from app import ajustes" que a su vez hace "from .db import engine".
esa primera importacion crea el engine real UNA sola vez, leyendo
DATABASE_URL en ese instante, casi siempre sin nada seteado todavia asi
que cae al default de db.py: el data/hazard.db de produccion. una vez
creado ese engine queda cacheado en sys.modules. todo os.environ que
alguien pise despues no lo re-crea. resultado: registrar_ciclo() y
_limpiar() de los tests de historial corrian sin saberlo contra la
base real, y el ultimo test en tocarla dejaba lo que fuera que hubiera
insertado como si fuera el estado real del sistema. asi es como una
corrida de "python -m tests" le borro a antonella el historial de
verdad -- volcanes, sismos, alertas de semanas -- y lo dejo con una
sola fila fantasma de un fixture de test.

la leccion: si algo importa el engine antes que vos, pisar la
variable de entorno no sirve de nada. hay que parchear el objeto
engine que los modulos ya tienen en su namespace, exactamente como ya
hacia _aislado() en test_ajustes.py con ajustes._engine. esto hace lo
mismo pero para historial.engine, que es donde vive el uso real.

uso:

    from _aislar_historial import motor_temporal

    with motor_temporal():
        registrar_ciclo(...)
        ...
"""
from __future__ import annotations

import tempfile
from contextlib import contextmanager
from pathlib import Path

from sqlalchemy import create_engine

from app import historial


@contextmanager
def motor_temporal():
    """corre el bloque con historial.engine apuntando a una sqlite
    temporal propia, y lo restaura al salir pase lo que pase. nunca
    toca data/hazard.db sin importar que otro modulo se haya
    importado antes en este proceso."""
    original = historial.engine
    tmp = Path(tempfile.mkdtemp()) / "hazard_test.db"
    temporal = create_engine(f"sqlite:///{tmp}", future=True)
    historial.engine = temporal
    try:
        historial.init_schema()
        yield
    finally:
        historial.engine = original
