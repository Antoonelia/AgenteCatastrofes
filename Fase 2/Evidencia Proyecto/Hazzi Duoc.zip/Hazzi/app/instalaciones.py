"""instalaciones walmart. catalogo editable que se superpone al scraping.

por que existe: stores.py baja las tiendas del buscador de lider y las
geocodifica con nominatim. eso da una base amplia pero tiene dos
limites que solo una persona puede resolver. primero hay tiendas mal
ubicadas porque nominatim falla con direcciones ambiguas y la tienda
termina en el centroide de su comuna o peor en un homonimo. nadie salvo
alguien que conoce la sucursal puede corregir ese punto. segundo lider
solo lista tiendas operativas. no aparecen oficinas centros de
distribucion plantas productivas ni las sucursales en construccion o
en remodelacion que tambien tienen gente adentro y por lo tanto
tambien importan cuando hay una catastrofe cerca.

diseno: se guarda el parche no la copia. si alguien corrige la
posicion de una tienda de lider en la base queda unicamente esa
correccion. el resto de los campos se siguen leyendo del scraping. asi
cuando lider actualice su listado las correcciones se mantienen y los
datos nuevos llegan igual. la alternativa de copiar las 400 tiendas a
sql habria congelado el catalogo el dia de la copia y obligado a
resolver a mano cada alta o baja posterior.

lider como base que se regenera mas los parches y altas en sql es
igual a la lista final.

de ahi que existan dos clases de fila. origen_lider es un parche
parcial que solo pisa los campos editados. origen_manual es una
instalacion completa que no existe en el scraping.

identidad: cada instalacion tiene un iid estable derivado de su
direccion y formato originales. es estable a proposito. editar la
direccion no cambia el iid porque si cambiara se romperia el vinculo
con la fila de parche y con la dotacion que se indexa por direccion
mas formato. sin esto corregir una direccion haria desaparecer en
silencio los colaboradores de esa tienda."""
from __future__ import annotations

import hashlib
import time
from typing import Any, NamedTuple

from sqlalchemy import Boolean, Column, Float, Integer, MetaData, String, Table, delete, insert, inspect, select, text, update

from .db import engine as _engine

ORIGEN_LIDER = "lider"
ORIGEN_MANUAL = "manual"
# marca una tienda de lider que se pidio hacer desaparecer para
# siempre, ver eliminar(). no es un tercer "tipo" de instalacion, es
# un estado especial que aplicar() usa para saltarsela sin importar
# lo que traiga el scraping en cada ciclo
ORIGEN_EXCLUIDA = "excluida"


class Tipo(NamedTuple):
    """un tipo de instalacion tal como se ofrece en el formulario."""

    clave: str
    etiqueta: str
    pide_formato: bool


# lista cerrada a proposito. el usuario elige no escribe. texto libre
# aca significaria "oficina" "Oficina" y "Of." conviviendo como tres
# tipos distintos y ningun filtro ni icono podria agruparlos
TIPOS: tuple[Tipo, ...] = (
    Tipo("sucursal", "Sucursal", True),
    Tipo("oficina", "Oficina", False),
    Tipo("cd", "Centro de distribucion", False),
    Tipo("planta", "Planta productiva", False),
)

# solo las sucursales tienen formato comercial. una planta productiva
# no es express ni acuenta. los nombres calzan con los que produce el
# scraping de lider para que metaformato en common.js les asigne su
# logo y color sin tener que mantener una segunda tabla
FORMATOS: tuple[str, ...] = (
    "Lider",
    "Express de Lider",
    "Superbodega Acuenta",
    "Central Mayorista",
)


class Estado(NamedTuple):
    clave: str
    etiqueta: str
    en_riesgo: bool


# el estado no es decorativo. decide si la instalacion entra al
# calculo de riesgo. una sucursal cerrada generando alertas rojas es
# ruido puro y una en construccion si importa porque hay cuadrilla
# trabajando adentro
ESTADOS: tuple[Estado, ...] = (
    Estado("operativa", "Operativa", True),
    Estado("construccion", "En construccion", True),
    Estado("remodelacion", "En remodelacion", True),
    Estado("cerrada", "Cerrada", False),
)

_TIPOS_POR_CLAVE = {t.clave: t for t in TIPOS}
_ESTADOS_POR_CLAVE = {e.clave: e for e in ESTADOS}

TIPO_DEFECTO = "sucursal"
ESTADO_DEFECTO = "operativa"

# campos que un parche sobre una tienda de lider puede pisar. el resto
# que es comuna y region se sigue leyendo del scraping. favorito
# queda afuera a proposito: no es una correccion de dato, es una
# marca personal, asi que no debe hacer que aplicar() la muestre como
# "editada" (ver mas abajo)
_CAMPOS_PARCHE = ("nombre", "tipo", "formato", "direccion", "estado", "lat", "lon", "notas")

_metadata = MetaData()

instalaciones_tabla = Table(
    "instalaciones",
    _metadata,
    Column("iid", String, primary_key=True),
    Column("origen", String, nullable=False),
    # en un parche estas columnas pueden ser null. null significa que
    # no se edito y hay que usar el valor de lider lo cual es distinto
    # de editarlo y dejarlo vacio. por eso no se usan strings vacios
    # como centinela
    Column("nombre", String),
    Column("tipo", String),
    Column("formato", String),
    Column("direccion", String),
    Column("comuna", String),
    Column("region", String),
    Column("estado", String),
    Column("lat", Float),
    Column("lon", Float),
    Column("notas", String),
    Column("actualizado", Integer),
    # marca personal, no un dato de la instalacion en si. separada de
    # _CAMPOS_PARCHE: favoritear una tienda de lider no debe pisar
    # ningun campo real ni hacerla aparecer como "editada"
    Column("favorito", Boolean),
)


# columnas agregadas despues de la version original de la tabla. create_all
# no altera una tabla que ya existe como un hazard.db de instalaciones
# viejas, asi que se migran a mano aca. idempotente, se salta si ya estan.
_COLUMNAS_NUEVAS = {"favorito": "BOOLEAN"}


def init_schema() -> None:
    """crea la tabla si no existe y migra columnas nuevas si faltan."""
    _metadata.create_all(_engine)
    existentes = {c["name"] for c in inspect(_engine).get_columns("instalaciones")}
    faltantes = {n: t for n, t in _COLUMNAS_NUEVAS.items() if n not in existentes}
    if not faltantes:
        return
    with _engine.begin() as conn:
        for nombre, tipo_sql in faltantes.items():
            conn.execute(text("ALTER TABLE instalaciones ADD COLUMN " + nombre + " " + tipo_sql))


def iid_de_tienda(direccion: str, formato: str) -> str:
    """identificador estable de una tienda del scraping.

    se deriva de direccion mas formato porque es la misma llave que ya
    usa dotacion.py. la direccion sola no es unica porque hay dos
    "central mayorista" en la misma direccion en los datos reales. el
    hash se calcula una vez sobre los valores originales de lider y
    despues no cambia aunque se edite la direccion. de eso depende que
    el parche siga apuntando a su tienda."""
    crudo = f"{(direccion or '').strip().lower()}||{(formato or '').strip().lower()}"
    return "l" + hashlib.sha1(crudo.encode("utf-8")).hexdigest()[:12]


def _iid_manual() -> str:
    """identificador para una instalacion creada a mano."""
    return "m" + hashlib.sha1(str(time.time_ns()).encode("utf-8")).hexdigest()[:12]


def tipo_valido(clave: str) -> bool:
    return clave in _TIPOS_POR_CLAVE


def estado_valido(clave: str) -> bool:
    return clave in _ESTADOS_POR_CLAVE


def cuenta_para_riesgo(estado: str | None) -> bool:
    """true si una instalacion en este estado debe entrar al calculo de riesgo.

    ante un estado desconocido devuelve true porque es preferible
    alertar de mas que dejar una instalacion con gente fuera del
    monitoreo por un dato mal escrito."""
    e = _ESTADOS_POR_CLAVE.get(estado or ESTADO_DEFECTO)
    return e.en_riesgo if e else True


def catalogo() -> dict[str, Any]:
    """tipos formatos y estados para que el formulario se arme solo."""
    return {
        "tipos": [{"clave": t.clave, "etiqueta": t.etiqueta, "pide_formato": t.pide_formato} for t in TIPOS],
        "formatos": list(FORMATOS),
        "estados": [{"clave": e.clave, "etiqueta": e.etiqueta, "en_riesgo": e.en_riesgo} for e in ESTADOS],
    }


def _validar(datos: dict, *, completo: bool) -> dict:
    """valida y normaliza lo que llega del formulario.

    completo en true exige los campos minimos de un alta manual. en
    un parche se aceptan campos sueltos. lo que no viene no se toca."""
    limpio: dict[str, Any] = {}

    tipo = (datos.get("tipo") or "").strip()
    if tipo:
        if not tipo_valido(tipo):
            raise ValueError(f"Tipo desconocido: {tipo}")
        limpio["tipo"] = tipo
    elif completo:
        limpio["tipo"] = TIPO_DEFECTO

    estado = (datos.get("estado") or "").strip()
    if estado:
        if not estado_valido(estado):
            raise ValueError(f"Estado desconocido: {estado}")
        limpio["estado"] = estado
    elif completo:
        limpio["estado"] = ESTADO_DEFECTO

    # el formato solo tiene sentido en sucursales. si el tipo no lo
    # pide se guarda vacio en vez de rechazar asi cambiar una sucursal
    # a oficina no obliga a limpiar el campo a mano desde el formulario
    formato = (datos.get("formato") or "").strip()
    tipo_final = limpio.get("tipo") or (datos.get("tipo") or "").strip()
    pide = _TIPOS_POR_CLAVE.get(tipo_final, _TIPOS_POR_CLAVE[TIPO_DEFECTO]).pide_formato
    if "formato" in datos or completo:
        if not pide:
            limpio["formato"] = ""
        elif formato and formato not in FORMATOS:
            raise ValueError(f"Formato desconocido: {formato}")
        else:
            limpio["formato"] = formato

    for campo in ("nombre", "direccion", "comuna", "region", "notas"):
        if campo in datos:
            limpio[campo] = (datos.get(campo) or "").strip()

    if "favorito" in datos:
        limpio["favorito"] = bool(datos.get("favorito"))

    for campo in ("lat", "lon"):
        if campo in datos and datos.get(campo) is not None and datos.get(campo) != "":
            try:
                limpio[campo] = float(datos[campo])
            except (TypeError, ValueError) as exc:
                raise ValueError(f"{campo}: se esperaba un numero.") from exc

    # chile continental e insular entran holgados en estos rangos. el
    # objetivo es atajar un pin arrastrado fuera del mapa o
    # coordenadas invertidas
    if "lat" in limpio and not -60.0 <= limpio["lat"] <= -15.0:
        raise ValueError("La latitud debe estar entre -60 y -15 (Chile).")
    if "lon" in limpio and not -120.0 <= limpio["lon"] <= -60.0:
        raise ValueError("La longitud debe estar entre -120 y -60 (Chile).")

    if completo:
        if not limpio.get("nombre"):
            raise ValueError("El nombre es obligatorio.")
        if not limpio.get("comuna"):
            raise ValueError("La comuna es obligatoria.")
        if "lat" not in limpio or "lon" not in limpio:
            raise ValueError("Falta ubicar la instalacion en el mapa.")

    return limpio


def _fila_a_dict(fila) -> dict:
    return {c.name: fila[c.name] for c in instalaciones_tabla.columns}


def todas() -> dict[str, dict]:
    """todo lo guardado indexado por iid entre parches y altas manuales."""
    try:
        init_schema()
        with _engine.begin() as conn:
            return {f["iid"]: _fila_a_dict(f) for f in conn.execute(select(instalaciones_tabla)).mappings()}
    except Exception:  # noqa: BLE001
        return {}  # sin base todavia. el sistema opera solo con lider


def crear(datos: dict) -> dict:
    """alta de una instalacion que no existe en el scraping."""
    limpio = _validar(datos, completo=True)
    iid = _iid_manual()
    fila = {
        "iid": iid,
        "origen": ORIGEN_MANUAL,
        "actualizado": int(time.time()),
        **{c: limpio.get(c) for c in _CAMPOS_PARCHE},
        "comuna": limpio.get("comuna", ""),
        "region": limpio.get("region", ""),
        "favorito": limpio.get("favorito", False),
    }
    init_schema()
    with _engine.begin() as conn:
        conn.execute(insert(instalaciones_tabla), fila)
    return fila


def guardar_parche(iid: str, datos: dict, base: dict | None = None) -> dict:
    """guarda o actualiza la correccion de una tienda del scraping.

    base son los datos de lider de esa tienda. se usan solo para
    completar comuna y region en la primera edicion de modo que la
    fila sirva tambien como registro legible sin tener que cruzarla
    siempre con el scraping."""
    limpio = _validar(datos, completo=False)
    if not limpio:
        raise ValueError("No hay cambios que guardar.")

    init_schema()
    with _engine.begin() as conn:
        existe = conn.execute(
            select(instalaciones_tabla.c.iid).where(instalaciones_tabla.c.iid == iid)
        ).first()
        valores = {**limpio, "actualizado": int(time.time())}
        if existe:
            conn.execute(
                update(instalaciones_tabla).where(instalaciones_tabla.c.iid == iid).values(**valores)
            )
        else:
            conn.execute(
                insert(instalaciones_tabla),
                {
                    "iid": iid,
                    "origen": ORIGEN_LIDER,
                    "comuna": (base or {}).get("comuna", ""),
                    "region": (base or {}).get("region", ""),
                    **valores,
                },
            )
        fila = conn.execute(
            select(instalaciones_tabla).where(instalaciones_tabla.c.iid == iid)
        ).mappings().first()
    return _fila_a_dict(fila)


def eliminar(iid: str) -> str:
    """borra una instalacion manual, o excluye una de lider para siempre.

    una manual se borra de verdad: no existe fuera de esta tabla asi
    que no vuelve. una de lider en cambio se vuelve a traer del
    scraping en cada ciclo (ver aplicar), asi que borrar su fila no
    alcanza -- volveria enseguida con sus datos originales. lo que se
    guarda en su lugar es una marca de EXCLUSION PERMANENTE
    (origen=excluida): aplicar() la salta del resultado sin importar lo
    que traiga el scraping de ahi en mas. reversible desde reincluir().

    pedido explicito de antonella, 29-09-2026: antes esto solo
    descartaba la correccion editada de una tienda de lider y la
    tienda volvia a aparecer con sus datos originales -- no servia
    para una tienda duplicada, cerrada de verdad, o mal cargada por
    lider mismo, que es exactamente el caso que necesitaba resolver.

    devuelve que paso, "eliminada" o "excluida", para que el frontend
    pueda mostrar un mensaje distinto en cada caso."""
    init_schema()
    with _engine.begin() as conn:
        fila = conn.execute(
            select(instalaciones_tabla.c.origen).where(instalaciones_tabla.c.iid == iid)
        ).first()
        if fila and fila[0] == ORIGEN_MANUAL:
            conn.execute(delete(instalaciones_tabla).where(instalaciones_tabla.c.iid == iid))
            return "eliminada"
        # sin fila (la tienda nunca se edito) solo es valida si es un iid
        # de lider de verdad. cualquier otro string es un pedido invalido
        if not fila and not iid.startswith("l"):
            raise ValueError("Esa instalacion no existe.")
        valores = {"origen": ORIGEN_EXCLUIDA, "actualizado": int(time.time())}
        if fila:
            conn.execute(
                update(instalaciones_tabla).where(instalaciones_tabla.c.iid == iid).values(**valores)
            )
        else:
            conn.execute(insert(instalaciones_tabla), {"iid": iid, **valores})
        return "excluida"


def reincluir(iid: str) -> None:
    """deshace una exclusion: la tienda vuelve a aparecer con sus datos
    originales de lider en el proximo refresco.

    borra la fila entera, no solo el origen, porque una fila excluida
    no conserva ninguna correccion util (eliminar() no la actualiza
    mientras esta excluida). es lo mismo que "nunca se toco", que es
    justo el estado al que se quiere volver."""
    init_schema()
    with _engine.begin() as conn:
        fila = conn.execute(
            select(instalaciones_tabla.c.origen).where(instalaciones_tabla.c.iid == iid)
        ).first()
        if not fila or fila[0] != ORIGEN_EXCLUIDA:
            raise ValueError("Esa instalacion no esta excluida.")
        conn.execute(delete(instalaciones_tabla).where(instalaciones_tabla.c.iid == iid))


def aplicar(tiendas: list[dict], *, incluir_excluidas: bool = False) -> list[dict]:
    """combina el scraping de lider con lo guardado. es la lista final.

    cada tienda de lider recibe su iid y si tiene parche los campos
    editados. despues se agregan las instalaciones manuales. las
    cerradas se marcan pero no se filtran aca porque el admin necesita
    verlas para reabrirlas. quien decide excluirlas del riesgo es
    cuenta_para_riesgo en main.py.

    las EXCLUIDAS (ver eliminar) son distintas de las cerradas: por
    defecto ni siquiera entran al resultado, para que el mapa publico
    en /api/stores nunca las muestre. incluir_excluidas=True es solo
    para la pantalla de administracion, que necesita listarlas
    (marcadas con excluida=True) para poder reincluirlas."""
    guardadas = todas()
    resultado: list[dict] = []

    for t in tiendas:
        iid = iid_de_tienda(t.get("direccion", ""), t.get("formato", ""))
        parche = guardadas.get(iid)
        excluida = bool(parche and parche.get("origen") == ORIGEN_EXCLUIDA)
        if excluida and not incluir_excluidas:
            continue
        base = {
            **t,
            "iid": iid,
            "origen": ORIGEN_LIDER,
            "tipo": TIPO_DEFECTO,
            "estado": ESTADO_DEFECTO,
            "nombre": t.get("formato") or "",
            "editada": False,
            "excluida": excluida,
            "favorito": bool(parche.get("favorito")) if parche else False,
        }
        if parche and excluida:
            base["actualizado"] = parche.get("actualizado")
        elif parche:
            # solo pisan los campos realmente editados. un null en el
            # parche significa seguir usando el dato de lider. favorito
            # se guarda en la misma fila de parche pero no cuenta como
            # edicion real: marcar una tienda como favorita no debe
            # mostrarla con el chip "editada"
            cambios = {c: parche[c] for c in _CAMPOS_PARCHE if parche.get(c) not in (None, "")}
            base.update(cambios)
            if cambios:
                base["editada"] = True
            base["actualizado"] = parche.get("actualizado")
            if cambios.get("lat") is not None:
                base["precision"] = "manual"
        resultado.append(base)

    for fila in guardadas.values():
        if fila.get("origen") != ORIGEN_MANUAL:
            continue
        resultado.append({
            **{c: fila.get(c) for c in ("iid", "origen", "nombre", "tipo", "formato",
                                        "direccion", "comuna", "region", "estado",
                                        "lat", "lon", "notas", "actualizado")},
            "precision": "manual",
            "editada": True,
            "favorito": bool(fila.get("favorito")),
        })

    return resultado


def operativas(instalaciones: list[dict]) -> list[dict]:
    """solo las que deben entrar al calculo de riesgo. ver estados."""
    return [i for i in instalaciones if cuenta_para_riesgo(i.get("estado"))]
