"""tests de notificador_estado.py. la logica pura de si este evento
cambio desde la ultima vez que se aviso.

corre contra una sqlite temporal propia, nunca el hazard.db real.
mismo criterio que test_ajustes.py _aislado y test_notificador.py
_db_aislada."""
from __future__ import annotations

import tempfile
from contextlib import contextmanager
from pathlib import Path

from sqlalchemy import create_engine

from app import notificador_estado as e


@contextmanager
def _db_aislada():
    original = e._engine
    tmp = Path(tempfile.mkdtemp()) / "test_notificador_estado.db"
    e._engine = create_engine(f"sqlite:///{tmp}", future=True)
    try:
        yield
    finally:
        e._engine = original


def test_evento_nunca_visto_es_nueva():
    with _db_aislada():
        tipo, descripcion = e.clasificar("x1", "roja", ["Arica"], 5)
        assert tipo == "nueva"
        assert descripcion == ""


def test_mismo_estado_es_sin_cambios():
    with _db_aislada():
        e.guardar("x2", "roja", ["Arica"], 5)
        tipo, descripcion = e.clasificar("x2", "roja", ["Arica"], 5)
        assert tipo == "sin_cambios"
        assert descripcion == ""


def test_comunas_en_otro_orden_no_cuentan_como_cambio():
    """el orden no importa. son un conjunto, no una lista posicional."""
    with _db_aislada():
        e.guardar("x3", "roja", ["Arica", "Iquique"], 2)
        tipo, _ = e.clasificar("x3", "roja", ["Iquique", "Arica"], 2)
        assert tipo == "sin_cambios"


def test_escalada_de_severidad_es_modificada_y_dice_escalo():
    with _db_aislada():
        e.guardar("x4", "amarilla", [], 0)
        tipo, descripcion = e.clasificar("x4", "roja", [], 0)
        assert tipo == "modificada"
        assert "amarilla a roja" in descripcion
        assert "Escalo" in descripcion


def test_baja_de_severidad_es_modificada_y_dice_bajo():
    with _db_aislada():
        e.guardar("x5", "roja", [], 0)
        tipo, descripcion = e.clasificar("x5", "amarilla", [], 0)
        assert tipo == "modificada"
        assert "Bajo" in descripcion


def test_agregar_comuna_es_modificada_y_la_nombra():
    with _db_aislada():
        e.guardar("x6", "roja", ["Arica"], 1)
        tipo, descripcion = e.clasificar("x6", "roja", ["Arica", "Iquique"], 2)
        assert tipo == "modificada"
        assert "Se agregaron comunas: Iquique" in descripcion


def test_quitar_comuna_es_modificada_y_lo_dice():
    with _db_aislada():
        e.guardar("x7", "roja", ["Arica", "Iquique"], 2)
        tipo, descripcion = e.clasificar("x7", "roja", ["Arica"], 1)
        assert tipo == "modificada"
        assert "Ya no incluye: Iquique" in descripcion


def test_cambio_de_tiendas_es_modificada_y_muestra_antes_y_despues():
    with _db_aislada():
        e.guardar("x8", "roja", ["Arica"], 5)
        tipo, descripcion = e.clasificar("x8", "roja", ["Arica"], 8)
        assert tipo == "modificada"
        assert "5" in descripcion and "8" in descripcion


def test_varios_cambios_a_la_vez_se_listan_todos():
    with _db_aislada():
        e.guardar("x9", "amarilla", ["Arica"], 1)
        tipo, descripcion = e.clasificar("x9", "roja", ["Arica", "Iquique"], 2)
        assert tipo == "modificada"
        assert "amarilla a roja" in descripcion
        assert "Se agregaron comunas" in descripcion
        assert "Tiendas en riesgo" in descripcion


def test_guardar_reemplaza_el_estado_anterior_no_lo_acumula():
    """un evento solo tiene un estado vigente. guardar dos veces no
    debe dejar filas duplicadas."""
    with _db_aislada():
        e.guardar("x10", "amarilla", ["Arica"], 1)
        e.guardar("x10", "roja", ["Arica", "Iquique"], 2)
        with e._engine.begin() as conn:
            filas = conn.execute(e._tabla_estado.select()).fetchall()
        assert len(filas) == 1
        tipo, _ = e.clasificar("x10", "roja", ["Arica", "Iquique"], 2)
        assert tipo == "sin_cambios"  # ya quedo guardado el estado nuevo


def test_reiniciar_borra_el_estado():
    with _db_aislada():
        e.guardar("x11", "roja", ["Arica"], 1)
        e.reiniciar()
        tipo, _ = e.clasificar("x11", "roja", ["Arica"], 1)
        assert tipo == "nueva"


# ampliacion del 25-09-2026. tema fenomeno y area tambien cuentan como cambio real


def test_cambio_de_tema_es_modificada_y_lo_dice():
    with _db_aislada():
        e.guardar("x12", "roja", [], 0, tema="por crecida")
        tipo, descripcion = e.clasificar("x12", "roja", [], 0, tema="por desborde")
        assert tipo == "modificada"
        assert "por crecida -> por desborde" in descripcion


def test_cambio_de_fenomeno_es_modificada_y_lo_dice():
    with _db_aislada():
        e.guardar("x13", "roja", [], 0, fenomeno="lluvia")
        tipo, descripcion = e.clasificar("x13", "roja", [], 0, fenomeno="viento")
        assert tipo == "modificada"
        assert "lluvia -> viento" in descripcion


def test_cambio_de_area_es_modificada():
    with _db_aislada():
        e.guardar("x14", "roja", [], 0, area_hash="hash1")
        tipo, descripcion = e.clasificar("x14", "roja", [], 0, area_hash="hash2")
        assert tipo == "modificada"
        assert "area de cobertura" in descripcion


def test_fila_vieja_sin_tema_no_genera_falso_cambio():
    """una fila guardada antes de esta ampliacion no tiene tema y queda vacia.
    la primera vez que se compara con un tema real no debe marcarse como
    cambio. solo empieza a compararse desde la proxima vez."""
    with _db_aislada():
        e.guardar("x15", "roja", [], 0)  # sin tema, como antes de la ampliacion
        tipo, _ = e.clasificar("x15", "roja", [], 0, tema="por crecida")
        assert tipo == "sin_cambios"


def test_existe_es_falso_para_una_clave_nunca_guardada():
    with _db_aislada():
        assert not e.existe("nunca-existio")


def test_existe_es_verdadero_tras_guardar():
    with _db_aislada():
        e.guardar("r4", "roja", ["Arica"], 1)
        assert e.existe("r4")
