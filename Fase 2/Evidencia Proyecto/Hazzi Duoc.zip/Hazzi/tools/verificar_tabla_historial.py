"""Verifica que /historial vuelva a ser tabla, pero SIN scroll interno propio
en el eje vertical (la pagina entera scrollea), con scroll horizontal SOLO si
la tabla no entra (fallback normal en mobile, no un rectangulo chico), y que
conserve el icono a la izquierda. Inyecta las clases utilitarias minimas que
la pagina usa porque el CDN de Tailwind esta caido por el proxy corporativo
en este sandbox (mismo patron que Leaflet en sesiones anteriores) -- sin esto
la medicion de overflow/rounded-corners seria una mentira.
"""
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from playwright.sync_api import sync_playwright

TAILWIND_MINIMO = """
.max-w-6xl { max-width: 72rem; } .mx-auto { margin-left:auto; margin-right:auto; }
.p-4 { padding: 1rem; } .space-y-4 > * + * { margin-top: 1rem; }
.bg-white { background: #fff; } .rounded-xl { border-radius: .75rem; }
.shadow { box-shadow: 0 1px 3px rgba(0,0,0,.15); } .overflow-hidden { overflow: hidden; }
"""

with sync_playwright() as p:
    nav = p.chromium.launch(channel="chrome")
    pagina = nav.new_page()
    errores = []
    pagina.on("pageerror", lambda e: errores.append(str(e)))
    pagina.route("**://cdn.tailwindcss.com/**", lambda r: r.abort())
    pagina.route("**://fonts.googleapis.com/**", lambda r: r.abort())

    pagina.goto("http://127.0.0.1:8000/historial", wait_until="domcontentloaded")
    pagina.add_style_tag(content=TAILWIND_MINIMO)
    pagina.wait_for_function("document.querySelectorAll('#tabla > tr').length > 0", timeout=20000)
    pagina.wait_for_timeout(500)

    for ancho, nombre in ((1400, "desktop"), (375, "mobile")):
        pagina.set_viewport_size({"width": ancho, "height": 700})
        pagina.wait_for_timeout(300)
        info = pagina.evaluate("""() => {
            const sec = document.querySelector('#tabla').closest('section');
            const wrap = document.querySelector('#tabla').closest('div');
            const filas = document.querySelectorAll('#tabla > tr');
            return {
                esTABLE: !!document.querySelector('table.hz-table'),
                filas: filas.length,
                seccionTieneAltoFijo: !!sec.style.maxHeight,
                wrapTieneAltoFijo: !!wrap.style.maxHeight,
                paginaAltoTotal: document.documentElement.scrollHeight,
                tieneIconoEnFila: !!filas[0].querySelector('.hz-row-ic'),
                contenidoOcultoSinAcceso: document.querySelector('table.hz-table').clientWidth > wrap.clientWidth
                                          && wrap.scrollWidth <= wrap.clientWidth + 2,
            };
        }""")
        print(f"[{nombre} {ancho}px]")
        for k, v in info.items():
            print(f"   {k}: {v}")
        Path("_qa_shots").mkdir(exist_ok=True)
        pagina.screenshot(path=f"_qa_shots/historial_tabla_{nombre}.png", full_page=True)

    pagina.click("#tabla > tr:first-child")
    pagina.wait_for_timeout(500)
    modal_visible = pagina.evaluate("!document.getElementById('modal').classList.contains('hidden')")
    print("modal abre al hacer click en una fila:", modal_visible)

    print("errores JS:", errores or "ninguno")
    nav.close()
