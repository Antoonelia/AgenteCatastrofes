"""tiendas walmart y lider chile. carga geocodificacion por comuna y calculo de riesgo.

las tiendas vienen del buscador de lider que es marca propia de walmart
chile no competencia sin coordenadas. se geocodifica por comuna con
nominatim de osm y se cachea. cada tienda queda en el centroide de su
comuna mas un jitter chico deterministico para que no se encimen."""
from __future__ import annotations

import hashlib
import json
import re
import time
import urllib.parse
from pathlib import Path

from . import area as area_mod
from .fetcher import fetch_json, fetch_text

STORES_URL = "https://apps.lider.cl/landing/json/storeListHtml.html"

_DATA = Path(__file__).parent.parent / "data"
_DATA.mkdir(exist_ok=True)
_COMUNAS_CACHE = _DATA / "comunas_geo.json"
_DIRECCIONES_CACHE = _DATA / "direcciones_geo.json"
_STORES_CACHE = _DATA / "stores_geo.json"

RISK_RADIUS_KM = 30.0  # radio generico solo para eventos cuya fuente no
# informa su area real. el area de verdad la calcula area.py evento por evento
SEVERIDAD_RIESGO = {"roja", "naranja", "amarilla"}

_MIN_PUNTOS_ANILLO = 5  # un anillo con esta cantidad de puntos o menos es un
# islote o esquirla de costa no un contorno con tiendas adentro

_TR = re.compile(r"<tr>(.*?)</tr>", re.DOTALL)
_TD = re.compile(r"<td[^>]*>(.*?)</td>", re.DOTALL)
_TAG = re.compile(r"<[^>]+>")


def _limpiar(html_fragment: str) -> str:
    txt = _TAG.sub(" ", html_fragment)
    return re.sub(r"\s+", " ", txt).strip()


def parse_stores(html: str) -> list[dict]:
    """extrae tiendas del html. formato comuna direccion region.

    lider a veces repite la misma tienda dos veces en su propio html:
    identica en formato y direccion pero con la region escrita distinto
    ("Metropolitana" vs "Metropolitana de Santiago"). visto en
    produccion con "Central Mayorista" de Cerrillos. no es un problema
    de nuestro geocoding ni de nominatim, viene asi de la fuente.

    se deduplica aca por formato+direccion, la misma llave exacta que
    usa iid_de_tienda en instalaciones.py para identificar una tienda.
    si no se filtra aca, las dos filas terminan con el mismo iid y la
    tienda aparece duplicada en el mapa y en el admin. se conserva la
    primera fila vista y se descarta el resto."""
    tiendas = []
    vistas: set[tuple[str, str]] = set()
    for fila in _TR.findall(html):
        celdas = [_limpiar(td) for td in _TD.findall(fila)]
        if len(celdas) < 5:
            continue
        formato, comuna, direccion, _estado, region = celdas[:5]
        if not comuna:
            continue
        clave = (formato.strip().lower(), direccion.strip().lower())
        if clave in vistas:
            continue
        vistas.add(clave)
        tiendas.append(
            {"formato": formato, "comuna": comuna, "direccion": direccion, "region": region}
        )
    return tiendas


def _jitter(seed: str, escala: float = 0.03) -> tuple[float, float]:
    """desplazamiento chico deterministico segun la direccion."""
    h = hashlib.md5(seed.encode("utf-8")).hexdigest()
    dx = (int(h[:4], 16) / 65535 - 0.5) * escala
    dy = (int(h[4:8], 16) / 65535 - 0.5) * escala
    return dx, dy


def _load_comunas_cache() -> dict:
    if _COMUNAS_CACHE.exists():
        return json.loads(_COMUNAS_CACHE.read_text(encoding="utf-8"))
    return {}


# un nombre de calle o de comuna se puede repetir en varias partes de
# chile. o'higgins es la calle mas comun del pais y general lagos es
# ademas el nombre de una comuna real en el extremo norte. cuando pasa
# eso nominatim a veces devuelve el homonimo equivocado. se vio en
# produccion: dos tiendas de la comuna de victoria en la araucania
# quedaron geocodificadas una en santiago y la otra a 2000 km cerca de
# arica. si la direccion cae mas lejos que esto de su propia comuna se
# descarta y se cae al centro de la comuna igual que si nominatim no la
# hubiera encontrado. el umbral es generoso a proposito porque chile
# tiene comunas rurales enormes y no queremos castigar una direccion
# buena en una comuna grande. 150 km ya no se explica por el tamano de
# ninguna comuna solo por una direccion mal geocodificada
_MAX_KM_DIRECCION_VS_COMUNA = 150.0


def _load_direcciones_cache() -> dict:
    if _DIRECCIONES_CACHE.exists():
        return json.loads(_DIRECCIONES_CACHE.read_text(encoding="utf-8"))
    return {}


def _direccion_es_creible(coord: tuple[float, float], centro_comuna: tuple[float, float] | None) -> bool:
    """false si una direccion geocodificada cae demasiado lejos del
    centro de su propia comuna. es senal de que nominatim la confundio
    con un homonimo en otra parte del pais.

    sin centro de comuna para comparar no hay como invalidarla. se
    acepta tal cual porque es mejor una direccion sin verificar que
    ninguna tienda en el mapa."""
    if not centro_comuna:
        return True
    return area_mod.haversine(coord[0], coord[1], centro_comuna[0], centro_comuna[1]) <= _MAX_KM_DIRECCION_VS_COMUNA


def geocode_direccion(direccion: str, comuna: str, cache: dict) -> tuple[float, float] | None:
    """geocodifica la direccion completa calle mas comuna no solo la comuna.

    esto ubica la tienda en su punto real del mapa en vez del centro de
    la comuna. si nominatim no encuentra la direccion exacta devuelve
    none y quien llama cae de vuelta a geocode_comuna.

    el parametro comuna no se usa para geocodificar. nominatim solo ve
    la direccion. build_stores es quien valida el resultado contra ella
    via _direccion_es_creible porque esa validacion necesita el centro
    de la comuna que ya se pide aparte y se cachea por su cuenta. no
    tiene sentido duplicar esa llamada aca adentro."""
    clave = direccion.strip()
    if clave in cache:
        c = cache[clave]
        return (c["lat"], c["lon"]) if c else None
    try:
        q = urllib.parse.quote(f"{direccion}, Chile")
        url = f"https://nominatim.openstreetmap.org/search?q={q}&format=json&limit=1&countrycodes=cl"
        d = fetch_json(url)
        time.sleep(1)  # nominatim pide como maximo una peticion por segundo
        if d:
            lat, lon = float(d[0]["lat"]), float(d[0]["lon"])
            cache[clave] = {"lat": lat, "lon": lon}
            return lat, lon
    except Exception:  # noqa: BLE001
        pass
    cache[clave] = None
    return None


def _buscar_comuna(comuna: str, cache: dict) -> dict | None:
    """datos geograficos de una comuna. centro y contorno real. none si
    no existe.

    nominatim devuelve el poligono de la comuna en la misma peticion en
    que devuelve el centro gratis. antes se pedia solo el centro y se
    descartaba el contorno que es justo lo que hace falta para saber
    que area cubre una alerta declarada para la comuna de x.

    las entradas viejas del cache no tienen poly. se vuelven a pedir una
    sola vez y quedan completas. es una migracion silenciosa sin borrar
    el cache."""
    if comuna in cache and (cache[comuna] is None or "poly" in cache[comuna]):
        return cache[comuna]
    try:
        url = (
            "https://nominatim.openstreetmap.org/search"
            f"?q={urllib.parse.quote(comuna + ', Chile')}&format=json&limit=1&countrycodes=cl"
            # polygon_threshold simplifica el contorno en el servidor. a
            # escala de mapa nacional el detalle fino no se ve y solo pesa mas
            "&polygon_geojson=1&polygon_threshold=0.01"
        )
        d = fetch_json(url)
        time.sleep(1)  # nominatim pide como maximo una peticion por segundo
        if d:
            cache[comuna] = {
                "lat": float(d[0]["lat"]),
                "lon": float(d[0]["lon"]),
                "poly": _anillos_geojson(d[0].get("geojson")),
            }
            return cache[comuna]
    except Exception:  # noqa: BLE001
        pass
    cache[comuna] = None
    return None


def _anillos_geojson(geo: dict | None) -> list | None:
    """normaliza un geojson de nominatim a una lista plana de anillos utiles.

    una comuna puede venir como polygon un solo contorno o multipolygon
    varios por ejemplo si incluye islas. los dos se aplanan al mismo
    formato que usan los poligonos de la dmc para que area.py trate a
    todos por igual.

    ademas se descartan los micro anillos. osm digitaliza cada islote y
    cada esquirla de costa como un anillo propio y algunas comunas
    llegan con cientos. se midio una vez: biobio traia 999 anillos 995
    de ellos de 5 puntos o menos. 119 kb de ruido para dibujar y
    recorrer sin ninguna tienda adentro. el contorno que de verdad
    importaba era uno solo de 317 puntos."""
    if not geo:
        return None
    tipo, coords = geo.get("type"), geo.get("coordinates") or []
    if tipo == "Polygon":
        anillos = coords
    elif tipo == "MultiPolygon":
        anillos = [anillo for poly in coords for anillo in poly]
    else:
        return None  # point o linestring no delimita un area
    utiles = [a for a in anillos if a and len(a) > _MIN_PUNTOS_ANILLO]
    if not utiles and anillos:
        # si todos eran chicos se conserva el mayor. mejor un contorno tosco
        # que ninguno porque sin area el evento cae al radio generico
        utiles = [max(anillos, key=len)] if len(max(anillos, key=len)) >= 3 else []
    return utiles or None


def geocode_comuna(comuna: str, cache: dict) -> tuple[float, float] | None:
    c = _buscar_comuna(comuna, cache)
    return (c["lat"], c["lon"]) if c else None


def build_stores(force: bool = False) -> list[dict]:
    """descarga parsea y geocodifica las tiendas. cachea el resultado.

    primero intenta ubicar cada tienda por su direccion completa calle
    mas comuna que es su posicion real. si nominatim no la encuentra o
    la encuentra pero demasiado lejos de su propia comuna homonimos
    como o'higgins o general lagos cae de vuelta al centro de la comuna
    mas un jitter chico metodo viejo para que la tienda igual aparezca
    en el mapa aunque sea con menos precision."""
    if _STORES_CACHE.exists() and not force:
        return json.loads(_STORES_CACHE.read_text(encoding="utf-8"))

    html = fetch_text(STORES_URL)
    tiendas = parse_stores(html)
    cache_comunas = _load_comunas_cache()
    cache_direcciones = _load_direcciones_cache()

    resultado = []
    for t in tiendas:
        centro_comuna = geocode_comuna(t["comuna"], cache_comunas)
        coord = geocode_direccion(t["direccion"], t["comuna"], cache_direcciones) if t.get("direccion") else None
        if coord and not _direccion_es_creible(coord, centro_comuna):
            coord = None  # nominatim la confundio con un homonimo en otra parte de chile
        if coord:
            resultado.append({**t, "lat": coord[0], "lon": coord[1], "precision": "direccion"})
            continue
        if not centro_comuna:
            continue
        dx, dy = _jitter(t["direccion"] or t["comuna"])
        resultado.append({**t, "lat": centro_comuna[0] + dy, "lon": centro_comuna[1] + dx, "precision": "comuna"})

    _COMUNAS_CACHE.write_text(json.dumps(cache_comunas, ensure_ascii=False, indent=2), encoding="utf-8")
    _DIRECCIONES_CACHE.write_text(json.dumps(cache_direcciones, ensure_ascii=False, indent=2), encoding="utf-8")
    _STORES_CACHE.write_text(json.dumps(resultado, ensure_ascii=False, indent=2), encoding="utf-8")
    return resultado


def geocode_lugares(nombres: list[str]) -> dict[str, dict]:
    """geocodifica varios lugares comunas o regiones reutilizando el cache de comunas.

    comparte data/comunas_geo.json con las tiendas asi que muchos
    nombres ya van a estar cacheados. persiste el cache al terminar.

    devuelve un diccionario con lat lon y poly por nombre. el contorno
    va incluido porque viene en la misma peticion y es lo que permite
    que una alerta declarada para la comuna de x cubra exactamente esa
    comuna y no un circulo fijo."""
    cache = _load_comunas_cache()
    out: dict[str, dict] = {}
    for n in nombres:
        datos = _buscar_comuna(n, cache)
        if datos:
            out[n] = datos
    _COMUNAS_CACHE.write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding="utf-8")
    return out


def haversine(lat1, lon1, lat2, lon2) -> float:
    """distancia en km entre dos puntos. reexportado desde area.py que es la unica definicion."""
    return area_mod.haversine(lat1, lon1, lat2, lon2)


def _alcance(e: dict, t: dict) -> float | None:
    """km desde una tienda al evento si esta dentro del area afectada. none si no.

    el area la define cada evento segun su propia naturaleza. la
    magnitud del sismo las hectareas del incendio el poligono que
    publica la dmc o el contorno de la comuna en alerta. si un evento
    no trae area porque la fuente no tiene el dato se cae al radio
    generico que es lo que antes se aplicaba a todos por igual y ahora
    es solo el ultimo recurso."""
    lat, lon = e.get("lat"), e.get("lon")
    if lat is None or lon is None:
        return None
    if e.get("area"):
        return area_mod.distancia_km(e["area"], lat, lon, t["lat"], t["lon"])
    d = area_mod.haversine(lat, lon, t["lat"], t["lon"])
    return round(d, 1) if d <= RISK_RADIUS_KM else None


def eventos_con_impacto(eventos: list[dict], tiendas: list[dict]) -> list[dict]:
    """descarta eventos que no tienen ninguna sucursal en su area afectada.

    al sistema solo le importa la red de tiendas. si ninguna sucursal
    cae dentro del area realmente afectada el evento no afecta el
    negocio y se descarta por completo. no solo del calculo de riesgo
    sino de toda la app mapa tabla y contadores. un evento sin
    coordenadas tampoco se puede verificar. si no sabemos donde ocurrio
    no podemos confirmar que afecte una tienda asi que se descarta
    tambien."""
    return [e for e in eventos if any(_alcance(e, t) is not None for t in tiendas)]


def stores_at_risk(eventos: list[dict], tiendas: list[dict]) -> list[dict]:
    """cruza eventos severos con las tiendas que caen en su area afectada.

    antes se guardaba solo el evento mas cercano por tienda y el resto
    se perdia. si por ejemplo en arica hay dos alertas vigentes
    distintas sobre la misma sucursal una sanitaria y una
    meteorologica la ui solo mostraba una y la otra desaparecia por
    completo de tiendas en riesgo aunque las dos siguieran vigentes.

    ahora se juntan todos los eventos severos que alcanzan a cada
    tienda en el campo nuevo eventos que es una lista pero la tienda
    sigue apareciendo una sola vez no se duplica la fila por tener dos
    o mas eventos encima. los campos sueltos de siempre como evento
    tipo severidad fecha y distancia_km quedan con los datos del mas
    cercano exactamente igual que antes para no romper nada de lo que
    ya los lee directo en docenas de lugares del frontend. son
    simplemente el primer elemento de eventos."""
    severos = [
        e for e in eventos
        if e.get("lat") is not None and e.get("lon") is not None
        and e.get("severidad") in SEVERIDAD_RIESGO
    ]
    en_riesgo = []
    for t in tiendas:
        coincidencias = []
        for e in severos:
            d = _alcance(e, t)
            if d is None:
                continue
            area = e.get("area") or {}
            # dentro del area declarada o solo cerca. no es lo mismo y la ui
            # lo muestra distinto
            potencial = bool(area.get("margen_km")) and d > 0 and area.get("forma") == "poligono"
            coincidencias.append({
                "distancia_km": d,
                "evento": e["titulo"],
                "tipo": e["tipo"],
                "severidad": e["severidad"],
                "fecha": e.get("fecha"),
                "clase_riesgo": "potencial" if potencial else "afectada",
                "motivo_area": area.get("margen_motivo") if potencial else area.get("motivo"),
            })
        if not coincidencias:
            continue
        coincidencias.sort(key=lambda c: c["distancia_km"])
        en_riesgo.append({**t, **coincidencias[0], "eventos": coincidencias})
    en_riesgo.sort(key=lambda x: x["distancia_km"])
    return en_riesgo


def tiendas_de_evento(evento: dict, tiendas: list[dict]) -> list[dict]:
    """tiendas que caen en el area afectada de un evento puntual.

    mismo criterio que stores_at_risk que reusa _alcance pero indexado
    por evento en vez de por tienda. es lo que necesita notificador.py
    para armar una alerta consolidada por evento."""
    return [t for t in tiendas if _alcance(evento, t) is not None]
