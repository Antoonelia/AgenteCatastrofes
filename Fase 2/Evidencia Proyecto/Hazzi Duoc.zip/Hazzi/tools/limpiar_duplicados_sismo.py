"""Limpieza puntual (una sola vez): fusiona duplicados de sismo que ya
quedaron guardados en hazard.db ANTES del fix de identidad en historial.py
(ver commit que cambia _IDENTIDAD_POR_TIPO['sismo']). El fix evita duplicados
NUEVOS, pero no toca lo que ya esta en la base -- este script si.

Agrupa las filas existentes por la clave NUEVA (recalculada con
clave_evento) y, si dos o mas filas caen en el mismo grupo, se queda con la
mas reciente (ultima_vez_vigente) y borra el resto.
"""
from __future__ import annotations

import json
from collections import defaultdict

from sqlalchemy import delete, select

from app.db import engine
from app.historial import clave_evento, historial_tabla, init_schema


def main() -> None:
    init_schema()
    with engine.begin() as conn:
        filas = conn.execute(select(historial_tabla)).mappings().all()
        grupos: dict[str, list] = defaultdict(list)
        for f in filas:
            evento = json.loads(f["datos"])
            grupos[clave_evento(evento)].append(f)

        a_borrar = []
        for nueva_clave, fs in grupos.items():
            if len(fs) <= 1:
                continue
            fs.sort(key=lambda f: f["ultima_vez_vigente"], reverse=True)
            print(f"Duplicado -> clave nueva: {nueva_clave}")
            for f in fs:
                print(f"  - {f['clave']} | {json.loads(f['datos']).get('titulo')}")
            a_borrar.extend(f["clave"] for f in fs[1:])

        if a_borrar:
            conn.execute(delete(historial_tabla).where(historial_tabla.c.clave.in_(a_borrar)))
            print(f"Borrados {len(a_borrar)} duplicados: {a_borrar}")
        else:
            print("No se encontraron duplicados.")


if __name__ == "__main__":
    main()
