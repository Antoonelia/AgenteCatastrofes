"""sanity check de geocodificacion. una direccion no puede caer en
otra parte del pais solo porque su calle o su comuna tiene un nombre
repetido.

el caso real que motiva esto: dos tiendas de la comuna de victoria, la
araucania, quedaron geocodificadas por su direccion completa. una en
santiago ("o'higgins 240", la calle mas repetida de chile) y la otra a
2000 km cerca de arica ("general lagos 1278", que ademas es el nombre
de una comuna real en el extremo norte). nominatim eligio el homonimo
equivocado en los dos casos."""
from __future__ import annotations

from app.stores import _MAX_KM_DIRECCION_VS_COMUNA, _direccion_es_creible, parse_stores

_VICTORIA = (-38.2278, -72.3306)  # comuna de victoria, la araucania
_SANTIAGO = (-33.4489, -70.6693)
_ARICA = (-18.4783, -70.3126)


def test_dentro_del_umbral_se_acepta():
    cerca = (-38.20, -72.30)  # unos pocos km del centro de victoria
    assert _direccion_es_creible(cerca, _VICTORIA)


def test_direccion_en_santiago_no_es_creible_para_comuna_del_sur():
    """el caso real. o'higgins 240 geocodificado en santiago y no en victoria."""
    assert not _direccion_es_creible(_SANTIAGO, _VICTORIA)


def test_direccion_en_arica_no_es_creible_para_comuna_del_sur():
    """el caso real. general lagos 1278 geocodificado cerca de arica y no en victoria."""
    assert not _direccion_es_creible(_ARICA, _VICTORIA)


def test_sin_centro_de_comuna_no_se_puede_invalidar():
    """sin nada contra que comparar se acepta tal cual. no se inventa un rechazo."""
    assert _direccion_es_creible(_SANTIAGO, None)


def test_justo_en_el_borde_del_umbral():
    """a la distancia exacta del umbral todavia se acepta. un poco mas alla no."""
    # un grado de latitud son unos 111 km. nos movemos lo justo para cruzar el umbral
    km_por_grado = 111.32
    grados_umbral = _MAX_KM_DIRECCION_VS_COMUNA / km_por_grado
    justo_adentro = (_VICTORIA[0] - grados_umbral * 0.99, _VICTORIA[1])
    justo_afuera = (_VICTORIA[0] - grados_umbral * 1.05, _VICTORIA[1])
    assert _direccion_es_creible(justo_adentro, _VICTORIA)
    assert not _direccion_es_creible(justo_afuera, _VICTORIA)


# parseo del html de lider

def _fila(formato, comuna, direccion, estado="Abierta", region="Metropolitana"):
    return f"<tr><td>{formato}</td><td>{comuna}</td><td>{direccion}</td><td>{estado}</td><td>{region}</td></tr>"


def test_parse_stores_lee_una_fila_normal():
    html = _fila("Lider", "Maipu", "Av Uno 100")
    tiendas = parse_stores(html)
    assert len(tiendas) == 1
    assert tiendas[0]["formato"] == "Lider"
    assert tiendas[0]["comuna"] == "Maipu"


def test_parse_stores_deduplica_la_misma_tienda_repetida():
    """caso real de produccion: "Central Mayorista" de Cerrillos aparecia
    dos veces en el html de lider, identica salvo por como escribe la
    region. sin deduplicar, las dos filas terminan con el mismo iid
    (formato+direccion) y la tienda sale duplicada en mapa y admin."""
    html = (
        _fila("Central Mayorista", "Cerrillos", "Americo Vespucio 2500, Cerrillos", region="Metropolitana")
        + _fila("Central Mayorista", "Cerrillos", "Americo Vespucio 2500, Cerrillos", region="Metropolitana de Santiago")
    )
    tiendas = parse_stores(html)
    assert len(tiendas) == 1


def test_parse_stores_no_confunde_formatos_ni_direcciones_distintas():
    """la deduplicacion es por formato+direccion exactos. dos tiendas
    reales y distintas en la misma comuna no se pierden."""
    html = _fila("Lider", "Cerrillos", "Calle Uno 1") + _fila("Express de Lider", "Cerrillos", "Calle Uno 1")
    assert len(parse_stores(html)) == 2
    html = _fila("Lider", "Cerrillos", "Calle Uno 1") + _fila("Lider", "Cerrillos", "Calle Dos 2")
    assert len(parse_stores(html)) == 2


def test_parse_stores_ignora_mayusculas_y_espacios_al_deduplicar():
    html = _fila("Lider", "Cerrillos", "Calle Uno 1") + _fila("  LIDER  ", "Cerrillos", "  calle uno 1  ")
    assert len(parse_stores(html)) == 1
