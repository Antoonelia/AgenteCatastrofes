"""Diagnostico del mojibake: que rompio exactamente y donde.

Compara los .html actuales contra la version anterior al commit del area,
que es donde se colo el bug: el comando de PowerShell que subio el ?v=34 a
v=35 leyo los archivos como ANSI y los reescribio como UTF-8, convirtiendo
cada caracter no-ASCII en su version doblemente codificada.
"""
import subprocess
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

BOM = b"\xef\xbb\xbf"
# Marcas tipicas de UTF-8 leido como Latin-1 y vuelto a guardar como UTF-8.
SOSPECHOSAS = ("Ã³", "Ã¡", "Ã­", "Ã©", "Ãº", "Ã±", "Â©", "Â·", "â€", "Ã\u008d")


def version_previa(ruta: str) -> bytes:
    return subprocess.run(
        ["git", "show", f"HEAD~1:Hazard/{ruta}"], capture_output=True, check=False
    ).stdout


for f in sorted(Path("app/static").glob("*.html")):
    ruta = f.as_posix()
    actual = f.read_bytes()
    previo = version_previa(ruta)
    txt = actual.decode("utf-8", errors="replace")
    hallazgos = {m: txt.count(m) for m in SOSPECHOSAS if m in txt}
    print(f"{f.name:<22} BOM_ahora={'si' if actual[:3] == BOM else 'no':<3} "
          f"BOM_antes={'si' if previo[:3] == BOM else 'no':<3} "
          f"bytes {len(previo)} -> {len(actual)}")
    if hallazgos:
        print(f"    mojibake: {hallazgos}")
