"""dotacion de colaboradores por sucursal. capa de persistencia sql.

hoy funciona con sqlite local sin pedir permisos ni configuracion. si en
algun momento aparece una fuente oficial se cambia solo la variable de
entorno database_url y el resto del sistema ni se entera.

la version externa de este proyecto estima la dotacion segun el formato
de la tienda en vez de usar datos reales de rrhh. es a proposito no un
placeholder. asi se puede dimensionar el impacto de un evento sobre las
personas sin depender de sistemas internos de la organizacion. ver
integracion_sql.md si mas adelante se quiere reemplazar por una fuente
real."""
from __future__ import annotations

import random

from sqlalchemy import (
    Boolean,
    Column,
    Integer,
    MetaData,
    String,
    Table,
    delete,
    func,
    insert,
    select,
)

from .db import DATABASE_URL, engine as _engine

_RANGOS_MOCK = {
    "Lider": (60, 120),
    "Express de Lider": (15, 35),
    "Superbodega Acuenta": (25, 55),
    "Central Mayorista": (80, 150),
}  # rangos tipicos de dotacion segun formato de tienda. son una
   # aproximacion razonable no un dato oficial de walmart
_RANGO_DEFECTO = (20, 60)

_metadata = MetaData()

dotacion_tabla = Table(
    "dotacion",
    _metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("direccion", String, nullable=False),
    Column("comuna", String, nullable=False),
    Column("formato", String),
    Column("cantidad_colaboradores", Integer, nullable=False),
    Column("es_estimado", Boolean, nullable=False, default=True),
)


def clave(direccion: str, formato: str) -> str:
    """llave para unir tienda con dotacion. la direccion sola se repite en
    los datos reales asi que se combina con el formato. por eso esta tabla
    no usa la direccion como primary key. esto se descubrio probando con
    datos reales no fue una decision de escritorio."""
    return f"{direccion}||{formato}"


def init_schema() -> None:
    """crea la tabla si no existe."""
    _metadata.create_all(_engine)


def seed_mock(tiendas: list[dict], forzar: bool = False) -> int:
    """genera dotacion estimada por tienda. es deterministica segun la
    direccion asi que no cambia entre corridas. solo siembra si la tabla
    esta vacia salvo que se pase forzar=true. devuelve cuantas filas se
    escribieron."""
    with _engine.begin() as conn:
        if not forzar:
            existentes = conn.execute(select(func.count()).select_from(dotacion_tabla)).scalar()
            if existentes:
                return 0
        filas = []
        for t in tiendas:
            direccion = t.get("direccion") or ""
            comuna = t.get("comuna") or ""
            formato = t.get("formato") or ""
            lo, hi = _RANGOS_MOCK.get(formato, _RANGO_DEFECTO)
            random.seed(direccion + comuna)  # deterministico. mismos datos entre corridas
            filas.append(
                {
                    "direccion": direccion,
                    "comuna": comuna,
                    "formato": formato,
                    "cantidad_colaboradores": random.randint(lo, hi),
                    "es_estimado": True,
                }
            )
        conn.execute(delete(dotacion_tabla))
        conn.execute(insert(dotacion_tabla), filas)
        return len(filas)


def obtener_todas() -> dict[str, dict]:
    """devuelve todas las filas indexadas por direccion mas formato."""
    with _engine.begin() as conn:
        filas = conn.execute(select(dotacion_tabla)).mappings().all()
    return {clave(f["direccion"], f["formato"]): dict(f) for f in filas}


def asegurar_datos(tiendas: list[dict]) -> None:
    """punto de entrada para main.py. crea el esquema y siembra si hace falta."""
    init_schema()
    seed_mock(tiendas)
