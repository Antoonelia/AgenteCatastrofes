"""cliente minimo para la api appsync de senapred.

la api oficial usa aws appsync detras de cognito. el identity pool permite
acceso invitado asi que se piden credenciales aws temporales anonimas y se
firma la peticion con sigv4 sin registro ni login.

requiere boto3 y salida a internet via proxy corporativo. si algo falla
fetch_events de la fuente lo captura y el resto del sistema sigue."""
from __future__ import annotations

import json
import os
import ssl
import time
import urllib.request
from pathlib import Path

os.environ.setdefault("HTTPS_PROXY", "http://sysproxy.wal-mart.com:8080")
os.environ.setdefault("HTTP_PROXY", "http://sysproxy.wal-mart.com:8080")
# el proxy corporativo se usa para que boto3 y urllib puedan salir igual
# que el resto del proyecto. setdefault respeta cualquier proxy ya
# configurado

_CA_BUNDLE_CACHE = Path(__file__).parent.parent / "data" / "ca_bundle.pem"
_CA_BUNDLE_TTL = 24 * 60 * 60  # los certificados raiz no cambian de un dia para otro


def _ca_bundle() -> str:
    """cacert de botocore mas los certificados raiz en los que windows
    ya confia, incluido el que usa el proxy corporativo para re-firmar
    el trafico https que pasa por el.

    boto3 no lee el almacen de certificados de windows: trae el suyo
    propio embebido (botocore/cacert.pem) y valida solo contra eso. por
    eso _guest_credentials fallaba con "self-signed certificate in
    certificate chain" al pedir credenciales de cognito, mientras el
    resto de hazzi sigue andando bien: el resto sale por powershell
    (ver fetcher.py) que si confia en el almacen de windows. la
    solucion no es dejar de validar, es sumarle a la validacion el
    certificado que windows ya tiene como confiable. se cachea en
    disco porque enumerar el almacen no es gratis y no hace falta
    repetirlo en cada ciclo."""
    if _CA_BUNDLE_CACHE.exists() and time.time() - _CA_BUNDLE_CACHE.stat().st_mtime < _CA_BUNDLE_TTL:
        return str(_CA_BUNDLE_CACHE)

    import botocore

    base = Path(botocore.__file__).parent / "cacert.pem"
    partes = [base.read_text(encoding="utf-8")]
    vistos = set()
    for almacen in ("ROOT", "CA"):
        for der, tipo, _ in ssl.enum_certificates(almacen):
            if tipo != "x509_asn":
                continue
            pem = ssl.DER_cert_to_PEM_cert(der)
            if pem not in vistos:
                vistos.add(pem)
                partes.append(pem)

    _CA_BUNDLE_CACHE.parent.mkdir(parents=True, exist_ok=True)
    _CA_BUNDLE_CACHE.write_text("\n".join(partes), encoding="utf-8")
    return str(_CA_BUNDLE_CACHE)

_POOL = "us-east-1:17c696bc-53e1-49a2-991f-f1b65f752fda"
_ENDPOINT = "https://rz2uv7ifxbgflh2bqmp6kmh4le.appsync-api.us-east-1.amazonaws.com/graphql"
_REGION = "us-east-1"
_SERVICE = "appsync"

_CREDS_CACHE: dict = {"creds": None, "expira": 0.0}
_CREDS_TTL = 50 * 60  # las credenciales duran 1 hora. se cachean con
# margen para nunca usar una vencida a mitad de un ciclo


def _guest_credentials():
    """credenciales aws temporales de invitado. reusa las cacheadas
    mientras no esten por vencer."""
    ahora = time.time()
    if _CREDS_CACHE["creds"] is not None and ahora < _CREDS_CACHE["expira"]:
        return _CREDS_CACHE["creds"]

    import boto3
    from botocore.credentials import Credentials

    ci = boto3.client("cognito-identity", region_name=_REGION, verify=_ca_bundle())
    ident = ci.get_id(IdentityPoolId=_POOL)["IdentityId"]
    c = ci.get_credentials_for_identity(IdentityId=ident)["Credentials"]
    creds = Credentials(c["AccessKeyId"], c["SecretKey"], c["SessionToken"])
    _CREDS_CACHE["creds"] = creds
    _CREDS_CACHE["expira"] = ahora + _CREDS_TTL
    return creds


def graphql(query: str, variables: dict, creds=None) -> dict:
    """ejecuta una operacion graphql firmada con sigv4. devuelve el json completo."""
    from botocore.auth import SigV4Auth
    from botocore.awsrequest import AWSRequest

    creds = creds or _guest_credentials()
    body = json.dumps({"query": query, "variables": variables})
    req = AWSRequest(method="POST", url=_ENDPOINT, data=body,
                     headers={"Content-Type": "application/json"})
    SigV4Auth(creds, _SERVICE, _REGION).add_auth(req)
    pr = req.prepare()
    payload = pr.body.encode() if isinstance(pr.body, str) else pr.body
    r = urllib.request.urlopen(
        urllib.request.Request(pr.url, data=payload, headers=dict(pr.headers), method="POST"),
        timeout=40,
    )
    return json.loads(r.read())
